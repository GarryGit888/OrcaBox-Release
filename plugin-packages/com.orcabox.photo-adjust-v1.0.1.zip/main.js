var vh = { exports: {} }, Hr = {};
var Y0;
function Xg() {
  if (Y0) return Hr;
  Y0 = 1;
  var r = /* @__PURE__ */ Symbol.for("react.transitional.element"), h = /* @__PURE__ */ Symbol.for("react.fragment");
  function u(c, g, m) {
    var b = null;
    if (m !== void 0 && (b = "" + m), g.key !== void 0 && (b = "" + g.key), "key" in g) {
      m = {};
      for (var A in g)
        A !== "key" && (m[A] = g[A]);
    } else m = g;
    return g = m.ref, {
      $$typeof: r,
      type: c,
      key: b,
      ref: g !== void 0 ? g : null,
      props: m
    };
  }
  return Hr.Fragment = h, Hr.jsx = u, Hr.jsxs = u, Hr;
}
var z0;
function Jg() {
  return z0 || (z0 = 1, vh.exports = Xg()), vh.exports;
}
var s = Jg(), Mh = { exports: {} }, Zr = {}, wh = { exports: {} }, Eh = {};
var q0;
function Pg() {
  return q0 || (q0 = 1, (function(r) {
    function h(q, O) {
      var K = q.length;
      q.push(O);
      t: for (; 0 < K; ) {
        var Ct = K - 1 >>> 1, R = q[Ct];
        if (0 < g(R, O))
          q[Ct] = O, q[K] = R, K = Ct;
        else break t;
      }
    }
    function u(q) {
      return q.length === 0 ? null : q[0];
    }
    function c(q) {
      if (q.length === 0) return null;
      var O = q[0], K = q.pop();
      if (K !== O) {
        q[0] = K;
        t: for (var Ct = 0, R = q.length, Q = R >>> 1; Ct < Q; ) {
          var nt = 2 * (Ct + 1) - 1, $ = q[nt], ft = nt + 1, qt = q[ft];
          if (0 > g($, K))
            ft < R && 0 > g(qt, $) ? (q[Ct] = qt, q[ft] = K, Ct = ft) : (q[Ct] = $, q[nt] = K, Ct = nt);
          else if (ft < R && 0 > g(qt, K))
            q[Ct] = qt, q[ft] = K, Ct = ft;
          else break t;
        }
      }
      return O;
    }
    function g(q, O) {
      var K = q.sortIndex - O.sortIndex;
      return K !== 0 ? K : q.id - O.id;
    }
    if (r.unstable_now = void 0, typeof performance == "object" && typeof performance.now == "function") {
      var m = performance;
      r.unstable_now = function() {
        return m.now();
      };
    } else {
      var b = Date, A = b.now();
      r.unstable_now = function() {
        return b.now() - A;
      };
    }
    var v = [], y = [], S = 1, C = null, k = 3, j = !1, L = !1, Z = !1, it = !1, mt = typeof setTimeout == "function" ? setTimeout : null, tt = typeof clearTimeout == "function" ? clearTimeout : null, Y = typeof setImmediate < "u" ? setImmediate : null;
    function W(q) {
      for (var O = u(y); O !== null; ) {
        if (O.callback === null) c(y);
        else if (O.startTime <= q)
          c(y), O.sortIndex = O.expirationTime, h(v, O);
        else break;
        O = u(y);
      }
    }
    function et(q) {
      if (Z = !1, W(q), !L)
        if (u(v) !== null)
          L = !0, rt || (rt = !0, Yt());
        else {
          var O = u(y);
          O !== null && Et(et, O.startTime - q);
        }
    }
    var rt = !1, Mt = -1, J = 5, ht = -1;
    function Tt() {
      return it ? !0 : !(r.unstable_now() - ht < J);
    }
    function kt() {
      if (it = !1, rt) {
        var q = r.unstable_now();
        ht = q;
        var O = !0;
        try {
          t: {
            L = !1, Z && (Z = !1, tt(Mt), Mt = -1), j = !0;
            var K = k;
            try {
              e: {
                for (W(q), C = u(v); C !== null && !(C.expirationTime > q && Tt()); ) {
                  var Ct = C.callback;
                  if (typeof Ct == "function") {
                    C.callback = null, k = C.priorityLevel;
                    var R = Ct(
                      C.expirationTime <= q
                    );
                    if (q = r.unstable_now(), typeof R == "function") {
                      C.callback = R, W(q), O = !0;
                      break e;
                    }
                    C === u(v) && c(v), W(q);
                  } else c(v);
                  C = u(v);
                }
                if (C !== null) O = !0;
                else {
                  var Q = u(y);
                  Q !== null && Et(
                    et,
                    Q.startTime - q
                  ), O = !1;
                }
              }
              break t;
            } finally {
              C = null, k = K, j = !1;
            }
            O = void 0;
          }
        } finally {
          O ? Yt() : rt = !1;
        }
      }
    }
    var Yt;
    if (typeof Y == "function")
      Yt = function() {
        Y(kt);
      };
    else if (typeof MessageChannel < "u") {
      var ge = new MessageChannel(), Lt = ge.port2;
      ge.port1.onmessage = kt, Yt = function() {
        Lt.postMessage(null);
      };
    } else
      Yt = function() {
        mt(kt, 0);
      };
    function Et(q, O) {
      Mt = mt(function() {
        q(r.unstable_now());
      }, O);
    }
    r.unstable_IdlePriority = 5, r.unstable_ImmediatePriority = 1, r.unstable_LowPriority = 4, r.unstable_NormalPriority = 3, r.unstable_Profiling = null, r.unstable_UserBlockingPriority = 2, r.unstable_cancelCallback = function(q) {
      q.callback = null;
    }, r.unstable_forceFrameRate = function(q) {
      0 > q || 125 < q ? console.error(
        "forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"
      ) : J = 0 < q ? Math.floor(1e3 / q) : 5;
    }, r.unstable_getCurrentPriorityLevel = function() {
      return k;
    }, r.unstable_next = function(q) {
      switch (k) {
        case 1:
        case 2:
        case 3:
          var O = 3;
          break;
        default:
          O = k;
      }
      var K = k;
      k = O;
      try {
        return q();
      } finally {
        k = K;
      }
    }, r.unstable_requestPaint = function() {
      it = !0;
    }, r.unstable_runWithPriority = function(q, O) {
      switch (q) {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
          break;
        default:
          q = 3;
      }
      var K = k;
      k = q;
      try {
        return O();
      } finally {
        k = K;
      }
    }, r.unstable_scheduleCallback = function(q, O, K) {
      var Ct = r.unstable_now();
      switch (typeof K == "object" && K !== null ? (K = K.delay, K = typeof K == "number" && 0 < K ? Ct + K : Ct) : K = Ct, q) {
        case 1:
          var R = -1;
          break;
        case 2:
          R = 250;
          break;
        case 5:
          R = 1073741823;
          break;
        case 4:
          R = 1e4;
          break;
        default:
          R = 5e3;
      }
      return R = K + R, q = {
        id: S++,
        callback: O,
        priorityLevel: q,
        startTime: K,
        expirationTime: R,
        sortIndex: -1
      }, K > Ct ? (q.sortIndex = K, h(y, q), u(v) === null && q === u(y) && (Z ? (tt(Mt), Mt = -1) : Z = !0, Et(et, K - Ct))) : (q.sortIndex = R, h(v, q), L || j || (L = !0, rt || (rt = !0, Yt()))), q;
    }, r.unstable_shouldYield = Tt, r.unstable_wrapCallback = function(q) {
      var O = k;
      return function() {
        var K = k;
        k = O;
        try {
          return q.apply(this, arguments);
        } finally {
          k = K;
        }
      };
    };
  })(Eh)), Eh;
}
var Q0;
function _g() {
  return Q0 || (Q0 = 1, wh.exports = Pg()), wh.exports;
}
var Rh = { exports: {} }, Kt = {};
var L0;
function $g() {
  if (L0) return Kt;
  L0 = 1;
  var r = /* @__PURE__ */ Symbol.for("react.transitional.element"), h = /* @__PURE__ */ Symbol.for("react.portal"), u = /* @__PURE__ */ Symbol.for("react.fragment"), c = /* @__PURE__ */ Symbol.for("react.strict_mode"), g = /* @__PURE__ */ Symbol.for("react.profiler"), m = /* @__PURE__ */ Symbol.for("react.consumer"), b = /* @__PURE__ */ Symbol.for("react.context"), A = /* @__PURE__ */ Symbol.for("react.forward_ref"), v = /* @__PURE__ */ Symbol.for("react.suspense"), y = /* @__PURE__ */ Symbol.for("react.memo"), S = /* @__PURE__ */ Symbol.for("react.lazy"), C = Symbol.iterator;
  function k(R) {
    return R === null || typeof R != "object" ? null : (R = C && R[C] || R["@@iterator"], typeof R == "function" ? R : null);
  }
  var j = {
    isMounted: function() {
      return !1;
    },
    enqueueForceUpdate: function() {
    },
    enqueueReplaceState: function() {
    },
    enqueueSetState: function() {
    }
  }, L = Object.assign, Z = {};
  function it(R, Q, nt) {
    this.props = R, this.context = Q, this.refs = Z, this.updater = nt || j;
  }
  it.prototype.isReactComponent = {}, it.prototype.setState = function(R, Q) {
    if (typeof R != "object" && typeof R != "function" && R != null)
      throw Error(
        "takes an object of state variables to update or a function which returns an object of state variables."
      );
    this.updater.enqueueSetState(this, R, Q, "setState");
  }, it.prototype.forceUpdate = function(R) {
    this.updater.enqueueForceUpdate(this, R, "forceUpdate");
  };
  function mt() {
  }
  mt.prototype = it.prototype;
  function tt(R, Q, nt) {
    this.props = R, this.context = Q, this.refs = Z, this.updater = nt || j;
  }
  var Y = tt.prototype = new mt();
  Y.constructor = tt, L(Y, it.prototype), Y.isPureReactComponent = !0;
  var W = Array.isArray, et = { H: null, A: null, T: null, S: null, V: null }, rt = Object.prototype.hasOwnProperty;
  function Mt(R, Q, nt, $, ft, qt) {
    return nt = qt.ref, {
      $$typeof: r,
      type: R,
      key: Q,
      ref: nt !== void 0 ? nt : null,
      props: qt
    };
  }
  function J(R, Q) {
    return Mt(
      R.type,
      Q,
      void 0,
      void 0,
      void 0,
      R.props
    );
  }
  function ht(R) {
    return typeof R == "object" && R !== null && R.$$typeof === r;
  }
  function Tt(R) {
    var Q = { "=": "=0", ":": "=2" };
    return "$" + R.replace(/[=:]/g, function(nt) {
      return Q[nt];
    });
  }
  var kt = /\/+/g;
  function Yt(R, Q) {
    return typeof R == "object" && R !== null && R.key != null ? Tt("" + R.key) : Q.toString(36);
  }
  function ge() {
  }
  function Lt(R) {
    switch (R.status) {
      case "fulfilled":
        return R.value;
      case "rejected":
        throw R.reason;
      default:
        switch (typeof R.status == "string" ? R.then(ge, ge) : (R.status = "pending", R.then(
          function(Q) {
            R.status === "pending" && (R.status = "fulfilled", R.value = Q);
          },
          function(Q) {
            R.status === "pending" && (R.status = "rejected", R.reason = Q);
          }
        )), R.status) {
          case "fulfilled":
            return R.value;
          case "rejected":
            throw R.reason;
        }
    }
    throw R;
  }
  function Et(R, Q, nt, $, ft) {
    var qt = typeof R;
    (qt === "undefined" || qt === "boolean") && (R = null);
    var Nt = !1;
    if (R === null) Nt = !0;
    else
      switch (qt) {
        case "bigint":
        case "string":
        case "number":
          Nt = !0;
          break;
        case "object":
          switch (R.$$typeof) {
            case r:
            case h:
              Nt = !0;
              break;
            case S:
              return Nt = R._init, Et(
                Nt(R._payload),
                Q,
                nt,
                $,
                ft
              );
          }
      }
    if (Nt)
      return ft = ft(R), Nt = $ === "" ? "." + Yt(R, 0) : $, W(ft) ? (nt = "", Nt != null && (nt = Nt.replace(kt, "$&/") + "/"), Et(ft, Q, nt, "", function(ct) {
        return ct;
      })) : ft != null && (ht(ft) && (ft = J(
        ft,
        nt + (ft.key == null || R && R.key === ft.key ? "" : ("" + ft.key).replace(
          kt,
          "$&/"
        ) + "/") + Nt
      )), Q.push(ft)), 1;
    Nt = 0;
    var me = $ === "" ? "." : $ + ":";
    if (W(R))
      for (var ne = 0; ne < R.length; ne++)
        $ = R[ne], qt = me + Yt($, ne), Nt += Et(
          $,
          Q,
          nt,
          qt,
          ft
        );
    else if (ne = k(R), typeof ne == "function")
      for (R = ne.call(R), ne = 0; !($ = R.next()).done; )
        $ = $.value, qt = me + Yt($, ne++), Nt += Et(
          $,
          Q,
          nt,
          qt,
          ft
        );
    else if (qt === "object") {
      if (typeof R.then == "function")
        return Et(
          Lt(R),
          Q,
          nt,
          $,
          ft
        );
      throw Q = String(R), Error(
        "Objects are not valid as a React child (found: " + (Q === "[object Object]" ? "object with keys {" + Object.keys(R).join(", ") + "}" : Q) + "). If you meant to render a collection of children, use an array instead."
      );
    }
    return Nt;
  }
  function q(R, Q, nt) {
    if (R == null) return R;
    var $ = [], ft = 0;
    return Et(R, $, "", "", function(qt) {
      return Q.call(nt, qt, ft++);
    }), $;
  }
  function O(R) {
    if (R._status === -1) {
      var Q = R._result;
      Q = Q(), Q.then(
        function(nt) {
          (R._status === 0 || R._status === -1) && (R._status = 1, R._result = nt);
        },
        function(nt) {
          (R._status === 0 || R._status === -1) && (R._status = 2, R._result = nt);
        }
      ), R._status === -1 && (R._status = 0, R._result = Q);
    }
    if (R._status === 1) return R._result.default;
    throw R._result;
  }
  var K = typeof reportError == "function" ? reportError : function(R) {
    if (typeof window == "object" && typeof window.ErrorEvent == "function") {
      var Q = new window.ErrorEvent("error", {
        bubbles: !0,
        cancelable: !0,
        message: typeof R == "object" && R !== null && typeof R.message == "string" ? String(R.message) : String(R),
        error: R
      });
      if (!window.dispatchEvent(Q)) return;
    } else if (typeof process == "object" && typeof process.emit == "function") {
      process.emit("uncaughtException", R);
      return;
    }
    console.error(R);
  };
  function Ct() {
  }
  return Kt.Children = {
    map: q,
    forEach: function(R, Q, nt) {
      q(
        R,
        function() {
          Q.apply(this, arguments);
        },
        nt
      );
    },
    count: function(R) {
      var Q = 0;
      return q(R, function() {
        Q++;
      }), Q;
    },
    toArray: function(R) {
      return q(R, function(Q) {
        return Q;
      }) || [];
    },
    only: function(R) {
      if (!ht(R))
        throw Error(
          "React.Children.only expected to receive a single React element child."
        );
      return R;
    }
  }, Kt.Component = it, Kt.Fragment = u, Kt.Profiler = g, Kt.PureComponent = tt, Kt.StrictMode = c, Kt.Suspense = v, Kt.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = et, Kt.__COMPILER_RUNTIME = {
    __proto__: null,
    c: function(R) {
      return et.H.useMemoCache(R);
    }
  }, Kt.cache = function(R) {
    return function() {
      return R.apply(null, arguments);
    };
  }, Kt.cloneElement = function(R, Q, nt) {
    if (R == null)
      throw Error(
        "The argument must be a React element, but you passed " + R + "."
      );
    var $ = L({}, R.props), ft = R.key, qt = void 0;
    if (Q != null)
      for (Nt in Q.ref !== void 0 && (qt = void 0), Q.key !== void 0 && (ft = "" + Q.key), Q)
        !rt.call(Q, Nt) || Nt === "key" || Nt === "__self" || Nt === "__source" || Nt === "ref" && Q.ref === void 0 || ($[Nt] = Q[Nt]);
    var Nt = arguments.length - 2;
    if (Nt === 1) $.children = nt;
    else if (1 < Nt) {
      for (var me = Array(Nt), ne = 0; ne < Nt; ne++)
        me[ne] = arguments[ne + 2];
      $.children = me;
    }
    return Mt(R.type, ft, void 0, void 0, qt, $);
  }, Kt.createContext = function(R) {
    return R = {
      $$typeof: b,
      _currentValue: R,
      _currentValue2: R,
      _threadCount: 0,
      Provider: null,
      Consumer: null
    }, R.Provider = R, R.Consumer = {
      $$typeof: m,
      _context: R
    }, R;
  }, Kt.createElement = function(R, Q, nt) {
    var $, ft = {}, qt = null;
    if (Q != null)
      for ($ in Q.key !== void 0 && (qt = "" + Q.key), Q)
        rt.call(Q, $) && $ !== "key" && $ !== "__self" && $ !== "__source" && (ft[$] = Q[$]);
    var Nt = arguments.length - 2;
    if (Nt === 1) ft.children = nt;
    else if (1 < Nt) {
      for (var me = Array(Nt), ne = 0; ne < Nt; ne++)
        me[ne] = arguments[ne + 2];
      ft.children = me;
    }
    if (R && R.defaultProps)
      for ($ in Nt = R.defaultProps, Nt)
        ft[$] === void 0 && (ft[$] = Nt[$]);
    return Mt(R, qt, void 0, void 0, null, ft);
  }, Kt.createRef = function() {
    return { current: null };
  }, Kt.forwardRef = function(R) {
    return { $$typeof: A, render: R };
  }, Kt.isValidElement = ht, Kt.lazy = function(R) {
    return {
      $$typeof: S,
      _payload: { _status: -1, _result: R },
      _init: O
    };
  }, Kt.memo = function(R, Q) {
    return {
      $$typeof: y,
      type: R,
      compare: Q === void 0 ? null : Q
    };
  }, Kt.startTransition = function(R) {
    var Q = et.T, nt = {};
    et.T = nt;
    try {
      var $ = R(), ft = et.S;
      ft !== null && ft(nt, $), typeof $ == "object" && $ !== null && typeof $.then == "function" && $.then(Ct, K);
    } catch (qt) {
      K(qt);
    } finally {
      et.T = Q;
    }
  }, Kt.unstable_useCacheRefresh = function() {
    return et.H.useCacheRefresh();
  }, Kt.use = function(R) {
    return et.H.use(R);
  }, Kt.useActionState = function(R, Q, nt) {
    return et.H.useActionState(R, Q, nt);
  }, Kt.useCallback = function(R, Q) {
    return et.H.useCallback(R, Q);
  }, Kt.useContext = function(R) {
    return et.H.useContext(R);
  }, Kt.useDebugValue = function() {
  }, Kt.useDeferredValue = function(R, Q) {
    return et.H.useDeferredValue(R, Q);
  }, Kt.useEffect = function(R, Q, nt) {
    var $ = et.H;
    if (typeof nt == "function")
      throw Error(
        "useEffect CRUD overload is not enabled in this build of React."
      );
    return $.useEffect(R, Q);
  }, Kt.useId = function() {
    return et.H.useId();
  }, Kt.useImperativeHandle = function(R, Q, nt) {
    return et.H.useImperativeHandle(R, Q, nt);
  }, Kt.useInsertionEffect = function(R, Q) {
    return et.H.useInsertionEffect(R, Q);
  }, Kt.useLayoutEffect = function(R, Q) {
    return et.H.useLayoutEffect(R, Q);
  }, Kt.useMemo = function(R, Q) {
    return et.H.useMemo(R, Q);
  }, Kt.useOptimistic = function(R, Q) {
    return et.H.useOptimistic(R, Q);
  }, Kt.useReducer = function(R, Q, nt) {
    return et.H.useReducer(R, Q, nt);
  }, Kt.useRef = function(R) {
    return et.H.useRef(R);
  }, Kt.useState = function(R) {
    return et.H.useState(R);
  }, Kt.useSyncExternalStore = function(R, Q, nt) {
    return et.H.useSyncExternalStore(
      R,
      Q,
      nt
    );
  }, Kt.useTransition = function() {
    return et.H.useTransition();
  }, Kt.version = "19.1.0", Kt;
}
var O0;
function Ih() {
  return O0 || (O0 = 1, Rh.exports = $g()), Rh.exports;
}
var Sh = { exports: {} }, sa = {};
var K0;
function tm() {
  if (K0) return sa;
  K0 = 1;
  var r = Ih();
  function h(v) {
    var y = "https://react.dev/errors/" + v;
    if (1 < arguments.length) {
      y += "?args[]=" + encodeURIComponent(arguments[1]);
      for (var S = 2; S < arguments.length; S++)
        y += "&args[]=" + encodeURIComponent(arguments[S]);
    }
    return "Minified React error #" + v + "; visit " + y + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
  }
  function u() {
  }
  var c = {
    d: {
      f: u,
      r: function() {
        throw Error(h(522));
      },
      D: u,
      C: u,
      L: u,
      m: u,
      X: u,
      S: u,
      M: u
    },
    p: 0,
    findDOMNode: null
  }, g = /* @__PURE__ */ Symbol.for("react.portal");
  function m(v, y, S) {
    var C = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
    return {
      $$typeof: g,
      key: C == null ? null : "" + C,
      children: v,
      containerInfo: y,
      implementation: S
    };
  }
  var b = r.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;
  function A(v, y) {
    if (v === "font") return "";
    if (typeof y == "string")
      return y === "use-credentials" ? y : "";
  }
  return sa.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = c, sa.createPortal = function(v, y) {
    var S = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
    if (!y || y.nodeType !== 1 && y.nodeType !== 9 && y.nodeType !== 11)
      throw Error(h(299));
    return m(v, y, null, S);
  }, sa.flushSync = function(v) {
    var y = b.T, S = c.p;
    try {
      if (b.T = null, c.p = 2, v) return v();
    } finally {
      b.T = y, c.p = S, c.d.f();
    }
  }, sa.preconnect = function(v, y) {
    typeof v == "string" && (y ? (y = y.crossOrigin, y = typeof y == "string" ? y === "use-credentials" ? y : "" : void 0) : y = null, c.d.C(v, y));
  }, sa.prefetchDNS = function(v) {
    typeof v == "string" && c.d.D(v);
  }, sa.preinit = function(v, y) {
    if (typeof v == "string" && y && typeof y.as == "string") {
      var S = y.as, C = A(S, y.crossOrigin), k = typeof y.integrity == "string" ? y.integrity : void 0, j = typeof y.fetchPriority == "string" ? y.fetchPriority : void 0;
      S === "style" ? c.d.S(
        v,
        typeof y.precedence == "string" ? y.precedence : void 0,
        {
          crossOrigin: C,
          integrity: k,
          fetchPriority: j
        }
      ) : S === "script" && c.d.X(v, {
        crossOrigin: C,
        integrity: k,
        fetchPriority: j,
        nonce: typeof y.nonce == "string" ? y.nonce : void 0
      });
    }
  }, sa.preinitModule = function(v, y) {
    if (typeof v == "string")
      if (typeof y == "object" && y !== null) {
        if (y.as == null || y.as === "script") {
          var S = A(
            y.as,
            y.crossOrigin
          );
          c.d.M(v, {
            crossOrigin: S,
            integrity: typeof y.integrity == "string" ? y.integrity : void 0,
            nonce: typeof y.nonce == "string" ? y.nonce : void 0
          });
        }
      } else y == null && c.d.M(v);
  }, sa.preload = function(v, y) {
    if (typeof v == "string" && typeof y == "object" && y !== null && typeof y.as == "string") {
      var S = y.as, C = A(S, y.crossOrigin);
      c.d.L(v, S, {
        crossOrigin: C,
        integrity: typeof y.integrity == "string" ? y.integrity : void 0,
        nonce: typeof y.nonce == "string" ? y.nonce : void 0,
        type: typeof y.type == "string" ? y.type : void 0,
        fetchPriority: typeof y.fetchPriority == "string" ? y.fetchPriority : void 0,
        referrerPolicy: typeof y.referrerPolicy == "string" ? y.referrerPolicy : void 0,
        imageSrcSet: typeof y.imageSrcSet == "string" ? y.imageSrcSet : void 0,
        imageSizes: typeof y.imageSizes == "string" ? y.imageSizes : void 0,
        media: typeof y.media == "string" ? y.media : void 0
      });
    }
  }, sa.preloadModule = function(v, y) {
    if (typeof v == "string")
      if (y) {
        var S = A(y.as, y.crossOrigin);
        c.d.m(v, {
          as: typeof y.as == "string" && y.as !== "script" ? y.as : void 0,
          crossOrigin: S,
          integrity: typeof y.integrity == "string" ? y.integrity : void 0
        });
      } else c.d.m(v);
  }, sa.requestFormReset = function(v) {
    c.d.r(v);
  }, sa.unstable_batchedUpdates = function(v, y) {
    return v(y);
  }, sa.useFormState = function(v, y, S) {
    return b.H.useFormState(v, y, S);
  }, sa.useFormStatus = function() {
    return b.H.useHostTransitionStatus();
  }, sa.version = "19.1.0", sa;
}
var H0;
function em() {
  if (H0) return Sh.exports;
  H0 = 1;
  function r() {
    if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function"))
      try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(r);
      } catch (h) {
        console.error(h);
      }
  }
  return r(), Sh.exports = tm(), Sh.exports;
}
var Z0;
function am() {
  if (Z0) return Zr;
  Z0 = 1;
  var r = _g(), h = Ih(), u = em();
  function c(t) {
    var e = "https://react.dev/errors/" + t;
    if (1 < arguments.length) {
      e += "?args[]=" + encodeURIComponent(arguments[1]);
      for (var a = 2; a < arguments.length; a++)
        e += "&args[]=" + encodeURIComponent(arguments[a]);
    }
    return "Minified React error #" + t + "; visit " + e + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
  }
  function g(t) {
    return !(!t || t.nodeType !== 1 && t.nodeType !== 9 && t.nodeType !== 11);
  }
  function m(t) {
    var e = t, a = t;
    if (t.alternate) for (; e.return; ) e = e.return;
    else {
      t = e;
      do
        e = t, (e.flags & 4098) !== 0 && (a = e.return), t = e.return;
      while (t);
    }
    return e.tag === 3 ? a : null;
  }
  function b(t) {
    if (t.tag === 13) {
      var e = t.memoizedState;
      if (e === null && (t = t.alternate, t !== null && (e = t.memoizedState)), e !== null) return e.dehydrated;
    }
    return null;
  }
  function A(t) {
    if (m(t) !== t)
      throw Error(c(188));
  }
  function v(t) {
    var e = t.alternate;
    if (!e) {
      if (e = m(t), e === null) throw Error(c(188));
      return e !== t ? null : t;
    }
    for (var a = t, n = e; ; ) {
      var o = a.return;
      if (o === null) break;
      var i = o.alternate;
      if (i === null) {
        if (n = o.return, n !== null) {
          a = n;
          continue;
        }
        break;
      }
      if (o.child === i.child) {
        for (i = o.child; i; ) {
          if (i === a) return A(o), t;
          if (i === n) return A(o), e;
          i = i.sibling;
        }
        throw Error(c(188));
      }
      if (a.return !== n.return) a = o, n = i;
      else {
        for (var f = !1, d = o.child; d; ) {
          if (d === a) {
            f = !0, a = o, n = i;
            break;
          }
          if (d === n) {
            f = !0, n = o, a = i;
            break;
          }
          d = d.sibling;
        }
        if (!f) {
          for (d = i.child; d; ) {
            if (d === a) {
              f = !0, a = i, n = o;
              break;
            }
            if (d === n) {
              f = !0, n = i, a = o;
              break;
            }
            d = d.sibling;
          }
          if (!f) throw Error(c(189));
        }
      }
      if (a.alternate !== n) throw Error(c(190));
    }
    if (a.tag !== 3) throw Error(c(188));
    return a.stateNode.current === a ? t : e;
  }
  function y(t) {
    var e = t.tag;
    if (e === 5 || e === 26 || e === 27 || e === 6) return t;
    for (t = t.child; t !== null; ) {
      if (e = y(t), e !== null) return e;
      t = t.sibling;
    }
    return null;
  }
  var S = Object.assign, C = /* @__PURE__ */ Symbol.for("react.element"), k = /* @__PURE__ */ Symbol.for("react.transitional.element"), j = /* @__PURE__ */ Symbol.for("react.portal"), L = /* @__PURE__ */ Symbol.for("react.fragment"), Z = /* @__PURE__ */ Symbol.for("react.strict_mode"), it = /* @__PURE__ */ Symbol.for("react.profiler"), mt = /* @__PURE__ */ Symbol.for("react.provider"), tt = /* @__PURE__ */ Symbol.for("react.consumer"), Y = /* @__PURE__ */ Symbol.for("react.context"), W = /* @__PURE__ */ Symbol.for("react.forward_ref"), et = /* @__PURE__ */ Symbol.for("react.suspense"), rt = /* @__PURE__ */ Symbol.for("react.suspense_list"), Mt = /* @__PURE__ */ Symbol.for("react.memo"), J = /* @__PURE__ */ Symbol.for("react.lazy"), ht = /* @__PURE__ */ Symbol.for("react.activity"), Tt = /* @__PURE__ */ Symbol.for("react.memo_cache_sentinel"), kt = Symbol.iterator;
  function Yt(t) {
    return t === null || typeof t != "object" ? null : (t = kt && t[kt] || t["@@iterator"], typeof t == "function" ? t : null);
  }
  var ge = /* @__PURE__ */ Symbol.for("react.client.reference");
  function Lt(t) {
    if (t == null) return null;
    if (typeof t == "function")
      return t.$$typeof === ge ? null : t.displayName || t.name || null;
    if (typeof t == "string") return t;
    switch (t) {
      case L:
        return "Fragment";
      case it:
        return "Profiler";
      case Z:
        return "StrictMode";
      case et:
        return "Suspense";
      case rt:
        return "SuspenseList";
      case ht:
        return "Activity";
    }
    if (typeof t == "object")
      switch (t.$$typeof) {
        case j:
          return "Portal";
        case Y:
          return (t.displayName || "Context") + ".Provider";
        case tt:
          return (t._context.displayName || "Context") + ".Consumer";
        case W:
          var e = t.render;
          return t = t.displayName, t || (t = e.displayName || e.name || "", t = t !== "" ? "ForwardRef(" + t + ")" : "ForwardRef"), t;
        case Mt:
          return e = t.displayName || null, e !== null ? e : Lt(t.type) || "Memo";
        case J:
          e = t._payload, t = t._init;
          try {
            return Lt(t(e));
          } catch {
          }
      }
    return null;
  }
  var Et = Array.isArray, q = h.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, O = u.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, K = {
    pending: !1,
    data: null,
    method: null,
    action: null
  }, Ct = [], R = -1;
  function Q(t) {
    return { current: t };
  }
  function nt(t) {
    0 > R || (t.current = Ct[R], Ct[R] = null, R--);
  }
  function $(t, e) {
    R++, Ct[R] = t.current, t.current = e;
  }
  var ft = Q(null), qt = Q(null), Nt = Q(null), me = Q(null);
  function ne(t, e) {
    switch ($(Nt, e), $(qt, t), $(ft, null), e.nodeType) {
      case 9:
      case 11:
        t = (t = e.documentElement) && (t = t.namespaceURI) ? u0(t) : 0;
        break;
      default:
        if (t = e.tagName, e = e.namespaceURI)
          e = u0(e), t = h0(e, t);
        else
          switch (t) {
            case "svg":
              t = 1;
              break;
            case "math":
              t = 2;
              break;
            default:
              t = 0;
          }
    }
    nt(ft), $(ft, t);
  }
  function ct() {
    nt(ft), nt(qt), nt(Nt);
  }
  function mn(t) {
    t.memoizedState !== null && $(me, t);
    var e = ft.current, a = h0(e, t.type);
    e !== a && ($(qt, t), $(ft, a));
  }
  function an(t) {
    qt.current === t && (nt(ft), nt(qt)), me.current === t && (nt(me), qr._currentValue = K);
  }
  var Ha = Object.prototype.hasOwnProperty, Oe = r.unstable_scheduleCallback, bn = r.unstable_cancelCallback, Hi = r.unstable_shouldYield, Zi = r.unstable_requestPaint, ea = r.unstable_now, xn = r.unstable_getCurrentPriorityLevel, aa = r.unstable_ImmediatePriority, On = r.unstable_UserBlockingPriority, nn = r.unstable_NormalPriority, vo = r.unstable_LowPriority, ri = r.unstable_IdlePriority, Kn = r.log, Mo = r.unstable_setDisableYieldValue, Za = null, Se = null;
  function ya(t) {
    if (typeof Kn == "function" && Mo(t), Se && typeof Se.setStrictMode == "function")
      try {
        Se.setStrictMode(Za, t);
      } catch {
      }
  }
  var be = Math.clz32 ? Math.clz32 : Wa, si = Math.log, ci = Math.LN2;
  function Wa(t) {
    return t >>>= 0, t === 0 ? 32 : 31 - (si(t) / ci | 0) | 0;
  }
  var je = 256, Va = 4194304;
  function na(t) {
    var e = t & 42;
    if (e !== 0) return e;
    switch (t & -t) {
      case 1:
        return 1;
      case 2:
        return 2;
      case 4:
        return 4;
      case 8:
        return 8;
      case 16:
        return 16;
      case 32:
        return 32;
      case 64:
        return 64;
      case 128:
        return 128;
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return t & 4194048;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
        return t & 62914560;
      case 67108864:
        return 67108864;
      case 134217728:
        return 134217728;
      case 268435456:
        return 268435456;
      case 536870912:
        return 536870912;
      case 1073741824:
        return 0;
      default:
        return t;
    }
  }
  function Fa(t, e, a) {
    var n = t.pendingLanes;
    if (n === 0) return 0;
    var o = 0, i = t.suspendedLanes, f = t.pingedLanes;
    t = t.warmLanes;
    var d = n & 134217727;
    return d !== 0 ? (n = d & ~i, n !== 0 ? o = na(n) : (f &= d, f !== 0 ? o = na(f) : a || (a = d & ~t, a !== 0 && (o = na(a))))) : (d = n & ~i, d !== 0 ? o = na(d) : f !== 0 ? o = na(f) : a || (a = n & ~t, a !== 0 && (o = na(a)))), o === 0 ? 0 : e !== 0 && e !== o && (e & i) === 0 && (i = o & -o, a = e & -e, i >= a || i === 32 && (a & 4194048) !== 0) ? e : o;
  }
  function oa(t, e) {
    return (t.pendingLanes & ~(t.suspendedLanes & ~t.pingedLanes) & e) === 0;
  }
  function yn(t, e) {
    switch (t) {
      case 1:
      case 2:
      case 4:
      case 8:
      case 64:
        return e + 250;
      case 16:
      case 32:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return e + 5e3;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
        return -1;
      case 67108864:
      case 134217728:
      case 268435456:
      case 536870912:
      case 1073741824:
        return -1;
      default:
        return -1;
    }
  }
  function Hn() {
    var t = je;
    return je <<= 1, (je & 4194048) === 0 && (je = 256), t;
  }
  function Ge() {
    var t = Va;
    return Va <<= 1, (Va & 62914560) === 0 && (Va = 4194304), t;
  }
  function Zn(t) {
    for (var e = [], a = 0; 31 > a; a++) e.push(t);
    return e;
  }
  function An(t, e) {
    t.pendingLanes |= e, e !== 268435456 && (t.suspendedLanes = 0, t.pingedLanes = 0, t.warmLanes = 0);
  }
  function ui(t, e, a, n, o, i) {
    var f = t.pendingLanes;
    t.pendingLanes = a, t.suspendedLanes = 0, t.pingedLanes = 0, t.warmLanes = 0, t.expiredLanes &= a, t.entangledLanes &= a, t.errorRecoveryDisabledLanes &= a, t.shellSuspendCounter = 0;
    var d = t.entanglements, E = t.expirationTimes, V = t.hiddenUpdates;
    for (a = f & ~a; 0 < a; ) {
      var F = 31 - be(a), X = 1 << F;
      d[F] = 0, E[F] = -1;
      var D = V[F];
      if (D !== null)
        for (V[F] = null, F = 0; F < D.length; F++) {
          var z = D[F];
          z !== null && (z.lane &= -536870913);
        }
      a &= ~X;
    }
    n !== 0 && Vt(t, n, 0), i !== 0 && o === 0 && t.tag !== 0 && (t.suspendedLanes |= i & ~(f & ~e));
  }
  function Vt(t, e, a) {
    t.pendingLanes |= e, t.suspendedLanes &= ~e;
    var n = 31 - be(e);
    t.entangledLanes |= e, t.entanglements[n] = t.entanglements[n] | 1073741824 | a & 4194090;
  }
  function we(t, e) {
    var a = t.entangledLanes |= e;
    for (t = t.entanglements; a; ) {
      var n = 31 - be(a), o = 1 << n;
      o & e | t[n] & e && (t[n] |= e), a &= ~o;
    }
  }
  function ce(t) {
    switch (t) {
      case 2:
        t = 1;
        break;
      case 8:
        t = 4;
        break;
      case 32:
        t = 16;
        break;
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
        t = 128;
        break;
      case 268435456:
        t = 134217728;
        break;
      default:
        t = 0;
    }
    return t;
  }
  function bt(t) {
    return t &= -t, 2 < t ? 8 < t ? (t & 134217727) !== 0 ? 32 : 268435456 : 8 : 2;
  }
  function yt() {
    var t = O.p;
    return t !== 0 ? t : (t = window.event, t === void 0 ? 32 : U0(t.type));
  }
  function xt(t, e) {
    var a = O.p;
    try {
      return O.p = t, e();
    } finally {
      O.p = a;
    }
  }
  var de = Math.random().toString(36).slice(2), Rt = "__reactFiber$" + de, dt = "__reactProps$" + de, Ot = "__reactContainer$" + de, Ht = "__reactEvents$" + de, ue = "__reactListeners$" + de, It = "__reactHandles$" + de, ve = "__reactResources$" + de, ke = "__reactMarker$" + de;
  function Ke(t) {
    delete t[Rt], delete t[dt], delete t[Ht], delete t[ue], delete t[It];
  }
  function Aa(t) {
    var e = t[Rt];
    if (e) return e;
    for (var a = t.parentNode; a; ) {
      if (e = a[Ot] || a[Rt]) {
        if (a = e.alternate, e.child !== null || a !== null && a.child !== null)
          for (t = g0(t); t !== null; ) {
            if (a = t[Rt]) return a;
            t = g0(t);
          }
        return e;
      }
      t = a, a = t.parentNode;
    }
    return null;
  }
  function Wn(t) {
    if (t = t[Rt] || t[Ot]) {
      var e = t.tag;
      if (e === 5 || e === 6 || e === 13 || e === 26 || e === 27 || e === 3)
        return t;
    }
    return null;
  }
  function hi(t) {
    var e = t.tag;
    if (e === 5 || e === 26 || e === 27 || e === 6) return t.stateNode;
    throw Error(c(33));
  }
  function on(t) {
    var e = t[ve];
    return e || (e = t[ve] = { hoistableStyles: /* @__PURE__ */ new Map(), hoistableScripts: /* @__PURE__ */ new Map() }), e;
  }
  function xe(t) {
    t[ke] = !0;
  }
  var Ql = /* @__PURE__ */ new Set(), Ga = {};
  function ln(t, e) {
    vn(t, e), vn(t + "Capture", e);
  }
  function vn(t, e) {
    for (Ga[t] = e, t = 0; t < e.length; t++)
      Ql.add(e[t]);
  }
  var fi = RegExp(
    "^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"
  ), Wi = {}, di = {};
  function Ll(t) {
    return Ha.call(di, t) ? !0 : Ha.call(Wi, t) ? !1 : fi.test(t) ? di[t] = !0 : (Wi[t] = !0, !1);
  }
  function wo(t, e, a) {
    if (Ll(e))
      if (a === null) t.removeAttribute(e);
      else {
        switch (typeof a) {
          case "undefined":
          case "function":
          case "symbol":
            t.removeAttribute(e);
            return;
          case "boolean":
            var n = e.toLowerCase().slice(0, 5);
            if (n !== "data-" && n !== "aria-") {
              t.removeAttribute(e);
              return;
            }
        }
        t.setAttribute(e, "" + a);
      }
  }
  function pi(t, e, a) {
    if (a === null) t.removeAttribute(e);
    else {
      switch (typeof a) {
        case "undefined":
        case "function":
        case "symbol":
        case "boolean":
          t.removeAttribute(e);
          return;
      }
      t.setAttribute(e, "" + a);
    }
  }
  function ia(t, e, a, n) {
    if (n === null) t.removeAttribute(a);
    else {
      switch (typeof n) {
        case "undefined":
        case "function":
        case "symbol":
        case "boolean":
          t.removeAttribute(a);
          return;
      }
      t.setAttributeNS(e, a, "" + n);
    }
  }
  var Eo, Fi;
  function Fn(t) {
    if (Eo === void 0)
      try {
        throw Error();
      } catch (a) {
        var e = a.stack.trim().match(/\n( *(at )?)/);
        Eo = e && e[1] || "", Fi = -1 < a.stack.indexOf(`
    at`) ? " (<anonymous>)" : -1 < a.stack.indexOf("@") ? "@unknown:0:0" : "";
      }
    return `
` + Eo + t + Fi;
  }
  var gi = !1;
  function Gi(t, e) {
    if (!t || gi) return "";
    gi = !0;
    var a = Error.prepareStackTrace;
    Error.prepareStackTrace = void 0;
    try {
      var n = {
        DetermineComponentFrameRoot: function() {
          try {
            if (e) {
              var X = function() {
                throw Error();
              };
              if (Object.defineProperty(X.prototype, "props", {
                set: function() {
                  throw Error();
                }
              }), typeof Reflect == "object" && Reflect.construct) {
                try {
                  Reflect.construct(X, []);
                } catch (z) {
                  var D = z;
                }
                Reflect.construct(t, [], X);
              } else {
                try {
                  X.call();
                } catch (z) {
                  D = z;
                }
                t.call(X.prototype);
              }
            } else {
              try {
                throw Error();
              } catch (z) {
                D = z;
              }
              (X = t()) && typeof X.catch == "function" && X.catch(function() {
              });
            }
          } catch (z) {
            if (z && D && typeof z.stack == "string")
              return [z.stack, D.stack];
          }
          return [null, null];
        }
      };
      n.DetermineComponentFrameRoot.displayName = "DetermineComponentFrameRoot";
      var o = Object.getOwnPropertyDescriptor(
        n.DetermineComponentFrameRoot,
        "name"
      );
      o && o.configurable && Object.defineProperty(
        n.DetermineComponentFrameRoot,
        "name",
        { value: "DetermineComponentFrameRoot" }
      );
      var i = n.DetermineComponentFrameRoot(), f = i[0], d = i[1];
      if (f && d) {
        var E = f.split(`
`), V = d.split(`
`);
        for (o = n = 0; n < E.length && !E[n].includes("DetermineComponentFrameRoot"); )
          n++;
        for (; o < V.length && !V[o].includes(
          "DetermineComponentFrameRoot"
        ); )
          o++;
        if (n === E.length || o === V.length)
          for (n = E.length - 1, o = V.length - 1; 1 <= n && 0 <= o && E[n] !== V[o]; )
            o--;
        for (; 1 <= n && 0 <= o; n--, o--)
          if (E[n] !== V[o]) {
            if (n !== 1 || o !== 1)
              do
                if (n--, o--, 0 > o || E[n] !== V[o]) {
                  var F = `
` + E[n].replace(" at new ", " at ");
                  return t.displayName && F.includes("<anonymous>") && (F = F.replace("<anonymous>", t.displayName)), F;
                }
              while (1 <= n && 0 <= o);
            break;
          }
      }
    } finally {
      gi = !1, Error.prepareStackTrace = a;
    }
    return (a = t ? t.displayName || t.name : "") ? Fn(a) : "";
  }
  function $r(t) {
    switch (t.tag) {
      case 26:
      case 27:
      case 5:
        return Fn(t.type);
      case 16:
        return Fn("Lazy");
      case 13:
        return Fn("Suspense");
      case 19:
        return Fn("SuspenseList");
      case 0:
      case 15:
        return Gi(t.type, !1);
      case 11:
        return Gi(t.type.render, !1);
      case 1:
        return Gi(t.type, !0);
      case 31:
        return Fn("Activity");
      default:
        return "";
    }
  }
  function Ol(t) {
    try {
      var e = "";
      do
        e += $r(t), t = t.return;
      while (t);
      return e;
    } catch (a) {
      return `
Error generating stack: ` + a.message + `
` + a.stack;
    }
  }
  function la(t) {
    switch (typeof t) {
      case "bigint":
      case "boolean":
      case "number":
      case "string":
      case "undefined":
        return t;
      case "object":
        return t;
      default:
        return "";
    }
  }
  function ts(t) {
    var e = t.type;
    return (t = t.nodeName) && t.toLowerCase() === "input" && (e === "checkbox" || e === "radio");
  }
  function es(t) {
    var e = ts(t) ? "checked" : "value", a = Object.getOwnPropertyDescriptor(
      t.constructor.prototype,
      e
    ), n = "" + t[e];
    if (!t.hasOwnProperty(e) && typeof a < "u" && typeof a.get == "function" && typeof a.set == "function") {
      var o = a.get, i = a.set;
      return Object.defineProperty(t, e, {
        configurable: !0,
        get: function() {
          return o.call(this);
        },
        set: function(f) {
          n = "" + f, i.call(this, f);
        }
      }), Object.defineProperty(t, e, {
        enumerable: a.enumerable
      }), {
        getValue: function() {
          return n;
        },
        setValue: function(f) {
          n = "" + f;
        },
        stopTracking: function() {
          t._valueTracker = null, delete t[e];
        }
      };
    }
  }
  function Gn(t) {
    t._valueTracker || (t._valueTracker = es(t));
  }
  function mi(t) {
    if (!t) return !1;
    var e = t._valueTracker;
    if (!e) return !0;
    var a = e.getValue(), n = "";
    return t && (n = ts(t) ? t.checked ? "true" : "false" : t.value), t = n, t !== a ? (e.setValue(t), !0) : !1;
  }
  function Ii(t) {
    if (t = t || (typeof document < "u" ? document : void 0), typeof t > "u") return null;
    try {
      return t.activeElement || t.body;
    } catch {
      return t.body;
    }
  }
  var Kc = /[\n"\\]/g;
  function ca(t) {
    return t.replace(
      Kc,
      function(e) {
        return "\\" + e.charCodeAt(0).toString(16) + " ";
      }
    );
  }
  function Kl(t, e, a, n, o, i, f, d) {
    t.name = "", f != null && typeof f != "function" && typeof f != "symbol" && typeof f != "boolean" ? t.type = f : t.removeAttribute("type"), e != null ? f === "number" ? (e === 0 && t.value === "" || t.value != e) && (t.value = "" + la(e)) : t.value !== "" + la(e) && (t.value = "" + la(e)) : f !== "submit" && f !== "reset" || t.removeAttribute("value"), e != null ? Xi(t, f, la(e)) : a != null ? Xi(t, f, la(a)) : n != null && t.removeAttribute("value"), o == null && i != null && (t.defaultChecked = !!i), o != null && (t.checked = o && typeof o != "function" && typeof o != "symbol"), d != null && typeof d != "function" && typeof d != "symbol" && typeof d != "boolean" ? t.name = "" + la(d) : t.removeAttribute("name");
  }
  function Ie(t, e, a, n, o, i, f, d) {
    if (i != null && typeof i != "function" && typeof i != "symbol" && typeof i != "boolean" && (t.type = i), e != null || a != null) {
      if (!(i !== "submit" && i !== "reset" || e != null))
        return;
      a = a != null ? "" + la(a) : "", e = e != null ? "" + la(e) : a, d || e === t.value || (t.value = e), t.defaultValue = e;
    }
    n = n ?? o, n = typeof n != "function" && typeof n != "symbol" && !!n, t.checked = d ? t.checked : !!n, t.defaultChecked = !!n, f != null && typeof f != "function" && typeof f != "symbol" && typeof f != "boolean" && (t.name = f);
  }
  function Xi(t, e, a) {
    e === "number" && Ii(t.ownerDocument) === t || t.defaultValue === "" + a || (t.defaultValue = "" + a);
  }
  function In(t, e, a, n) {
    if (t = t.options, e) {
      e = {};
      for (var o = 0; o < a.length; o++)
        e["$" + a[o]] = !0;
      for (a = 0; a < t.length; a++)
        o = e.hasOwnProperty("$" + t[a].value), t[a].selected !== o && (t[a].selected = o), o && n && (t[a].defaultSelected = !0);
    } else {
      for (a = "" + la(a), e = null, o = 0; o < t.length; o++) {
        if (t[o].value === a) {
          t[o].selected = !0, n && (t[o].defaultSelected = !0);
          return;
        }
        e !== null || t[o].disabled || (e = t[o]);
      }
      e !== null && (e.selected = !0);
    }
  }
  function Mn(t, e, a) {
    if (e != null && (e = "" + la(e), e !== t.value && (t.value = e), a == null)) {
      t.defaultValue !== e && (t.defaultValue = e);
      return;
    }
    t.defaultValue = a != null ? "" + la(a) : "";
  }
  function Ji(t, e, a, n) {
    if (e == null) {
      if (n != null) {
        if (a != null) throw Error(c(92));
        if (Et(n)) {
          if (1 < n.length) throw Error(c(93));
          n = n[0];
        }
        a = n;
      }
      a == null && (a = ""), e = a;
    }
    a = la(e), t.defaultValue = a, n = t.textContent, n === a && n !== "" && n !== null && (t.value = n);
  }
  function Ro(t, e) {
    if (e) {
      var a = t.firstChild;
      if (a && a === t.lastChild && a.nodeType === 3) {
        a.nodeValue = e;
        return;
      }
    }
    t.textContent = e;
  }
  var bi = new Set(
    "animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(
      " "
    )
  );
  function Hl(t, e, a) {
    var n = e.indexOf("--") === 0;
    a == null || typeof a == "boolean" || a === "" ? n ? t.setProperty(e, "") : e === "float" ? t.cssFloat = "" : t[e] = "" : n ? t.setProperty(e, a) : typeof a != "number" || a === 0 || bi.has(e) ? e === "float" ? t.cssFloat = a : t[e] = ("" + a).trim() : t[e] = a + "px";
  }
  function xi(t, e, a) {
    if (e != null && typeof e != "object")
      throw Error(c(62));
    if (t = t.style, a != null) {
      for (var n in a)
        !a.hasOwnProperty(n) || e != null && e.hasOwnProperty(n) || (n.indexOf("--") === 0 ? t.setProperty(n, "") : n === "float" ? t.cssFloat = "" : t[n] = "");
      for (var o in e)
        n = e[o], e.hasOwnProperty(o) && a[o] !== n && Hl(t, o, n);
    } else
      for (var i in e)
        e.hasOwnProperty(i) && Hl(t, i, e[i]);
  }
  function Pi(t) {
    if (t.indexOf("-") === -1) return !1;
    switch (t) {
      case "annotation-xml":
      case "color-profile":
      case "font-face":
      case "font-face-src":
      case "font-face-uri":
      case "font-face-format":
      case "font-face-name":
      case "missing-glyph":
        return !1;
      default:
        return !0;
    }
  }
  var _i = /* @__PURE__ */ new Map([
    ["acceptCharset", "accept-charset"],
    ["htmlFor", "for"],
    ["httpEquiv", "http-equiv"],
    ["crossOrigin", "crossorigin"],
    ["accentHeight", "accent-height"],
    ["alignmentBaseline", "alignment-baseline"],
    ["arabicForm", "arabic-form"],
    ["baselineShift", "baseline-shift"],
    ["capHeight", "cap-height"],
    ["clipPath", "clip-path"],
    ["clipRule", "clip-rule"],
    ["colorInterpolation", "color-interpolation"],
    ["colorInterpolationFilters", "color-interpolation-filters"],
    ["colorProfile", "color-profile"],
    ["colorRendering", "color-rendering"],
    ["dominantBaseline", "dominant-baseline"],
    ["enableBackground", "enable-background"],
    ["fillOpacity", "fill-opacity"],
    ["fillRule", "fill-rule"],
    ["floodColor", "flood-color"],
    ["floodOpacity", "flood-opacity"],
    ["fontFamily", "font-family"],
    ["fontSize", "font-size"],
    ["fontSizeAdjust", "font-size-adjust"],
    ["fontStretch", "font-stretch"],
    ["fontStyle", "font-style"],
    ["fontVariant", "font-variant"],
    ["fontWeight", "font-weight"],
    ["glyphName", "glyph-name"],
    ["glyphOrientationHorizontal", "glyph-orientation-horizontal"],
    ["glyphOrientationVertical", "glyph-orientation-vertical"],
    ["horizAdvX", "horiz-adv-x"],
    ["horizOriginX", "horiz-origin-x"],
    ["imageRendering", "image-rendering"],
    ["letterSpacing", "letter-spacing"],
    ["lightingColor", "lighting-color"],
    ["markerEnd", "marker-end"],
    ["markerMid", "marker-mid"],
    ["markerStart", "marker-start"],
    ["overlinePosition", "overline-position"],
    ["overlineThickness", "overline-thickness"],
    ["paintOrder", "paint-order"],
    ["panose-1", "panose-1"],
    ["pointerEvents", "pointer-events"],
    ["renderingIntent", "rendering-intent"],
    ["shapeRendering", "shape-rendering"],
    ["stopColor", "stop-color"],
    ["stopOpacity", "stop-opacity"],
    ["strikethroughPosition", "strikethrough-position"],
    ["strikethroughThickness", "strikethrough-thickness"],
    ["strokeDasharray", "stroke-dasharray"],
    ["strokeDashoffset", "stroke-dashoffset"],
    ["strokeLinecap", "stroke-linecap"],
    ["strokeLinejoin", "stroke-linejoin"],
    ["strokeMiterlimit", "stroke-miterlimit"],
    ["strokeOpacity", "stroke-opacity"],
    ["strokeWidth", "stroke-width"],
    ["textAnchor", "text-anchor"],
    ["textDecoration", "text-decoration"],
    ["textRendering", "text-rendering"],
    ["transformOrigin", "transform-origin"],
    ["underlinePosition", "underline-position"],
    ["underlineThickness", "underline-thickness"],
    ["unicodeBidi", "unicode-bidi"],
    ["unicodeRange", "unicode-range"],
    ["unitsPerEm", "units-per-em"],
    ["vAlphabetic", "v-alphabetic"],
    ["vHanging", "v-hanging"],
    ["vIdeographic", "v-ideographic"],
    ["vMathematical", "v-mathematical"],
    ["vectorEffect", "vector-effect"],
    ["vertAdvY", "vert-adv-y"],
    ["vertOriginX", "vert-origin-x"],
    ["vertOriginY", "vert-origin-y"],
    ["wordSpacing", "word-spacing"],
    ["writingMode", "writing-mode"],
    ["xmlnsXlink", "xmlns:xlink"],
    ["xHeight", "x-height"]
  ]), as = /^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;
  function yi(t) {
    return as.test("" + t) ? "javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')" : t;
  }
  var Ai = null;
  function rn(t) {
    return t = t.target || t.srcElement || window, t.correspondingUseElement && (t = t.correspondingUseElement), t.nodeType === 3 ? t.parentNode : t;
  }
  var Ia = null, So = null;
  function wn(t) {
    var e = Wn(t);
    if (e && (t = e.stateNode)) {
      var a = t[dt] || null;
      t: switch (t = e.stateNode, e.type) {
        case "input":
          if (Kl(
            t,
            a.value,
            a.defaultValue,
            a.defaultValue,
            a.checked,
            a.defaultChecked,
            a.type,
            a.name
          ), e = a.name, a.type === "radio" && e != null) {
            for (a = t; a.parentNode; ) a = a.parentNode;
            for (a = a.querySelectorAll(
              'input[name="' + ca(
                "" + e
              ) + '"][type="radio"]'
            ), e = 0; e < a.length; e++) {
              var n = a[e];
              if (n !== t && n.form === t.form) {
                var o = n[dt] || null;
                if (!o) throw Error(c(90));
                Kl(
                  n,
                  o.value,
                  o.defaultValue,
                  o.defaultValue,
                  o.checked,
                  o.defaultChecked,
                  o.type,
                  o.name
                );
              }
            }
            for (e = 0; e < a.length; e++)
              n = a[e], n.form === t.form && mi(n);
          }
          break t;
        case "textarea":
          Mn(t, a.value, a.defaultValue);
          break t;
        case "select":
          e = a.value, e != null && In(t, !!a.multiple, e, !1);
      }
    }
  }
  var Xn = !1;
  function qe(t, e, a) {
    if (Xn) return t(e, a);
    Xn = !0;
    try {
      var n = t(e);
      return n;
    } finally {
      if (Xn = !1, (Ia !== null || So !== null) && (Is(), Ia && (e = Ia, t = So, So = Ia = null, wn(e), t)))
        for (e = 0; e < t.length; e++) wn(t[e]);
    }
  }
  function ua(t, e) {
    var a = t.stateNode;
    if (a === null) return null;
    var n = a[dt] || null;
    if (n === null) return null;
    a = n[e];
    t: switch (e) {
      case "onClick":
      case "onClickCapture":
      case "onDoubleClick":
      case "onDoubleClickCapture":
      case "onMouseDown":
      case "onMouseDownCapture":
      case "onMouseMove":
      case "onMouseMoveCapture":
      case "onMouseUp":
      case "onMouseUpCapture":
      case "onMouseEnter":
        (n = !n.disabled) || (t = t.type, n = !(t === "button" || t === "input" || t === "select" || t === "textarea")), t = !n;
        break t;
      default:
        t = !1;
    }
    if (t) return null;
    if (a && typeof a != "function")
      throw Error(
        c(231, e, typeof a)
      );
    return a;
  }
  var ha = !(typeof window > "u" || typeof window.document > "u" || typeof window.document.createElement > "u"), Da = !1;
  if (ha)
    try {
      var sn = {};
      Object.defineProperty(sn, "passive", {
        get: function() {
          Da = !0;
        }
      }), window.addEventListener("test", sn, sn), window.removeEventListener("test", sn, sn);
    } catch {
      Da = !1;
    }
  var va = null, Jn = null, To = null;
  function ns() {
    if (To) return To;
    var t, e = Jn, a = e.length, n, o = "value" in va ? va.value : va.textContent, i = o.length;
    for (t = 0; t < a && e[t] === o[t]; t++) ;
    var f = a - t;
    for (n = 1; n <= f && e[a - n] === o[i - n]; n++) ;
    return To = o.slice(t, 1 < n ? 1 - n : void 0);
  }
  function Pn(t) {
    var e = t.keyCode;
    return "charCode" in t ? (t = t.charCode, t === 0 && e === 13 && (t = 13)) : t = e, t === 10 && (t = 13), 32 <= t || t === 13 ? t : 0;
  }
  function Ma() {
    return !0;
  }
  function Xa() {
    return !1;
  }
  function Te(t) {
    function e(a, n, o, i, f) {
      this._reactName = a, this._targetInst = o, this.type = n, this.nativeEvent = i, this.target = f, this.currentTarget = null;
      for (var d in t)
        t.hasOwnProperty(d) && (a = t[d], this[d] = a ? a(i) : i[d]);
      return this.isDefaultPrevented = (i.defaultPrevented != null ? i.defaultPrevented : i.returnValue === !1) ? Ma : Xa, this.isPropagationStopped = Xa, this;
    }
    return S(e.prototype, {
      preventDefault: function() {
        this.defaultPrevented = !0;
        var a = this.nativeEvent;
        a && (a.preventDefault ? a.preventDefault() : typeof a.returnValue != "unknown" && (a.returnValue = !1), this.isDefaultPrevented = Ma);
      },
      stopPropagation: function() {
        var a = this.nativeEvent;
        a && (a.stopPropagation ? a.stopPropagation() : typeof a.cancelBubble != "unknown" && (a.cancelBubble = !0), this.isPropagationStopped = Ma);
      },
      persist: function() {
      },
      isPersistent: Ma
    }), e;
  }
  var Ee = {
    eventPhase: 0,
    bubbles: 0,
    cancelable: 0,
    timeStamp: function(t) {
      return t.timeStamp || Date.now();
    },
    defaultPrevented: 0,
    isTrusted: 0
  }, En = Te(Ee), _n = S({}, Ee, { view: 0, detail: 0 }), $n = Te(_n), cn, vi, Rn, Co = S({}, _n, {
    screenX: 0,
    screenY: 0,
    clientX: 0,
    clientY: 0,
    pageX: 0,
    pageY: 0,
    ctrlKey: 0,
    shiftKey: 0,
    altKey: 0,
    metaKey: 0,
    getModifierState: eo,
    button: 0,
    buttons: 0,
    relatedTarget: function(t) {
      return t.relatedTarget === void 0 ? t.fromElement === t.srcElement ? t.toElement : t.fromElement : t.relatedTarget;
    },
    movementX: function(t) {
      return "movementX" in t ? t.movementX : (t !== Rn && (Rn && t.type === "mousemove" ? (cn = t.screenX - Rn.screenX, vi = t.screenY - Rn.screenY) : vi = cn = 0, Rn = t), cn);
    },
    movementY: function(t) {
      return "movementY" in t ? t.movementY : vi;
    }
  }), os = Te(Co), No = S({}, Co, { dataTransfer: 0 }), to = Te(No), is = S({}, _n, { relatedTarget: 0 }), Sn = Te(is), Mi = S({}, Ee, {
    animationName: 0,
    elapsedTime: 0,
    pseudoElement: 0
  }), $i = Te(Mi), Hc = S({}, Ee, {
    clipboardData: function(t) {
      return "clipboardData" in t ? t.clipboardData : window.clipboardData;
    }
  }), Zc = Te(Hc), wi = S({}, Ee, { data: 0 }), Qe = Te(wi), wa = {
    Esc: "Escape",
    Spacebar: " ",
    Left: "ArrowLeft",
    Up: "ArrowUp",
    Right: "ArrowRight",
    Down: "ArrowDown",
    Del: "Delete",
    Win: "OS",
    Menu: "ContextMenu",
    Apps: "ContextMenu",
    Scroll: "ScrollLock",
    MozPrintableKey: "Unidentified"
  }, tl = {
    8: "Backspace",
    9: "Tab",
    12: "Clear",
    13: "Enter",
    16: "Shift",
    17: "Control",
    18: "Alt",
    19: "Pause",
    20: "CapsLock",
    27: "Escape",
    32: " ",
    33: "PageUp",
    34: "PageDown",
    35: "End",
    36: "Home",
    37: "ArrowLeft",
    38: "ArrowUp",
    39: "ArrowRight",
    40: "ArrowDown",
    45: "Insert",
    46: "Delete",
    112: "F1",
    113: "F2",
    114: "F3",
    115: "F4",
    116: "F5",
    117: "F6",
    118: "F7",
    119: "F8",
    120: "F9",
    121: "F10",
    122: "F11",
    123: "F12",
    144: "NumLock",
    145: "ScrollLock",
    224: "Meta"
  }, Zl = {
    Alt: "altKey",
    Control: "ctrlKey",
    Meta: "metaKey",
    Shift: "shiftKey"
  };
  function Tn(t) {
    var e = this.nativeEvent;
    return e.getModifierState ? e.getModifierState(t) : (t = Zl[t]) ? !!e[t] : !1;
  }
  function eo() {
    return Tn;
  }
  var Ei = S({}, _n, {
    key: function(t) {
      if (t.key) {
        var e = wa[t.key] || t.key;
        if (e !== "Unidentified") return e;
      }
      return t.type === "keypress" ? (t = Pn(t), t === 13 ? "Enter" : String.fromCharCode(t)) : t.type === "keydown" || t.type === "keyup" ? tl[t.keyCode] || "Unidentified" : "";
    },
    code: 0,
    location: 0,
    ctrlKey: 0,
    shiftKey: 0,
    altKey: 0,
    metaKey: 0,
    repeat: 0,
    locale: 0,
    getModifierState: eo,
    charCode: function(t) {
      return t.type === "keypress" ? Pn(t) : 0;
    },
    keyCode: function(t) {
      return t.type === "keydown" || t.type === "keyup" ? t.keyCode : 0;
    },
    which: function(t) {
      return t.type === "keypress" ? Pn(t) : t.type === "keydown" || t.type === "keyup" ? t.keyCode : 0;
    }
  }), Wl = Te(Ei), Fl = S({}, Co, {
    pointerId: 0,
    width: 0,
    height: 0,
    pressure: 0,
    tangentialPressure: 0,
    tiltX: 0,
    tiltY: 0,
    twist: 0,
    pointerType: 0,
    isPrimary: 0
  }), el = Te(Fl), wt = S({}, _n, {
    touches: 0,
    targetTouches: 0,
    changedTouches: 0,
    altKey: 0,
    metaKey: 0,
    ctrlKey: 0,
    shiftKey: 0,
    getModifierState: eo
  }), fa = Te(wt), Gl = S({}, Ee, {
    propertyName: 0,
    elapsedTime: 0,
    pseudoElement: 0
  }), _ = Te(Gl), Xe = S({}, Co, {
    deltaX: function(t) {
      return "deltaX" in t ? t.deltaX : "wheelDeltaX" in t ? -t.wheelDeltaX : 0;
    },
    deltaY: function(t) {
      return "deltaY" in t ? t.deltaY : "wheelDeltaY" in t ? -t.wheelDeltaY : "wheelDelta" in t ? -t.wheelDelta : 0;
    },
    deltaZ: 0,
    deltaMode: 0
  }), ls = Te(Xe), rs = S({}, Ee, {
    newState: 0,
    oldState: 0
  }), al = Te(rs), Il = [9, 13, 27, 32], Xl = ha && "CompositionEvent" in window, un = null;
  ha && "documentMode" in document && (un = document.documentMode);
  var Be = ha && "TextEvent" in window && !un, Uo = ha && (!Xl || un && 8 < un && 11 >= un), Cn = " ", ao = !1;
  function nl(t, e) {
    switch (t) {
      case "keyup":
        return Il.indexOf(e.keyCode) !== -1;
      case "keydown":
        return e.keyCode !== 229;
      case "keypress":
      case "mousedown":
      case "focusout":
        return !0;
      default:
        return !1;
    }
  }
  function Jl(t) {
    return t = t.detail, typeof t == "object" && "data" in t ? t.data : null;
  }
  var Ut = !1;
  function ye(t, e) {
    switch (t) {
      case "compositionend":
        return Jl(e);
      case "keypress":
        return e.which !== 32 ? null : (ao = !0, Cn);
      case "textInput":
        return t = e.data, t === Cn && ao ? null : t;
      default:
        return null;
    }
  }
  function ol(t, e) {
    if (Ut)
      return t === "compositionend" || !Xl && nl(t, e) ? (t = ns(), To = Jn = va = null, Ut = !1, t) : null;
    switch (t) {
      case "paste":
        return null;
      case "keypress":
        if (!(e.ctrlKey || e.altKey || e.metaKey) || e.ctrlKey && e.altKey) {
          if (e.char && 1 < e.char.length)
            return e.char;
          if (e.which) return String.fromCharCode(e.which);
        }
        return null;
      case "compositionend":
        return Uo && e.locale !== "ko" ? null : e.data;
      default:
        return null;
    }
  }
  var Ya = {
    color: !0,
    date: !0,
    datetime: !0,
    "datetime-local": !0,
    email: !0,
    month: !0,
    number: !0,
    password: !0,
    range: !0,
    search: !0,
    tel: !0,
    text: !0,
    time: !0,
    url: !0,
    week: !0
  };
  function jo(t) {
    var e = t && t.nodeName && t.nodeName.toLowerCase();
    return e === "input" ? !!Ya[t.type] : e === "textarea";
  }
  function Ce(t, e, a, n) {
    Ia ? So ? So.push(n) : So = [n] : Ia = n, e = tc(e, "onChange"), 0 < e.length && (a = new En(
      "onChange",
      "change",
      null,
      a,
      n
    ), t.push({ event: a, listeners: e }));
  }
  var hn = null, Ea = null;
  function Nn(t) {
    i0(t, 0);
  }
  function il(t) {
    var e = hi(t);
    if (mi(e)) return t;
  }
  function Ja(t, e) {
    if (t === "change") return e;
  }
  var ll = !1;
  if (ha) {
    var Un;
    if (ha) {
      var Pl = "oninput" in document;
      if (!Pl) {
        var Ri = document.createElement("div");
        Ri.setAttribute("oninput", "return;"), Pl = typeof Ri.oninput == "function";
      }
      Un = Pl;
    } else Un = !1;
    ll = Un && (!document.documentMode || 9 < document.documentMode);
  }
  function ss() {
    hn && (hn.detachEvent("onpropertychange", rl), Ea = hn = null);
  }
  function rl(t) {
    if (t.propertyName === "value" && il(Ea)) {
      var e = [];
      Ce(
        e,
        Ea,
        t,
        rn(t)
      ), qe(Nn, e);
    }
  }
  function Wc(t, e, a) {
    t === "focusin" ? (ss(), hn = e, Ea = a, hn.attachEvent("onpropertychange", rl)) : t === "focusout" && ss();
  }
  function cs(t) {
    if (t === "selectionchange" || t === "keyup" || t === "keydown")
      return il(Ea);
  }
  function Fc(t, e) {
    if (t === "click") return il(e);
  }
  function Gc(t, e) {
    if (t === "input" || t === "change")
      return il(e);
  }
  function Ic(t, e) {
    return t === e && (t !== 0 || 1 / t === 1 / e) || t !== t && e !== e;
  }
  var da = typeof Object.is == "function" ? Object.is : Ic;
  function Si(t, e) {
    if (da(t, e)) return !0;
    if (typeof t != "object" || t === null || typeof e != "object" || e === null)
      return !1;
    var a = Object.keys(t), n = Object.keys(e);
    if (a.length !== n.length) return !1;
    for (n = 0; n < a.length; n++) {
      var o = a[n];
      if (!Ha.call(e, o) || !da(t[o], e[o]))
        return !1;
    }
    return !0;
  }
  function us(t) {
    for (; t && t.firstChild; ) t = t.firstChild;
    return t;
  }
  function hs(t, e) {
    var a = us(t);
    t = 0;
    for (var n; a; ) {
      if (a.nodeType === 3) {
        if (n = t + a.textContent.length, t <= e && n >= e)
          return { node: a, offset: e - t };
        t = n;
      }
      t: {
        for (; a; ) {
          if (a.nextSibling) {
            a = a.nextSibling;
            break t;
          }
          a = a.parentNode;
        }
        a = void 0;
      }
      a = us(a);
    }
  }
  function st(t, e) {
    return t && e ? t === e ? !0 : t && t.nodeType === 3 ? !1 : e && e.nodeType === 3 ? st(t, e.parentNode) : "contains" in t ? t.contains(e) : t.compareDocumentPosition ? !!(t.compareDocumentPosition(e) & 16) : !1 : !1;
  }
  function _l(t) {
    t = t != null && t.ownerDocument != null && t.ownerDocument.defaultView != null ? t.ownerDocument.defaultView : window;
    for (var e = Ii(t.document); e instanceof t.HTMLIFrameElement; ) {
      try {
        var a = typeof e.contentWindow.location.href == "string";
      } catch {
        a = !1;
      }
      if (a) t = e.contentWindow;
      else break;
      e = Ii(t.document);
    }
    return e;
  }
  function Ti(t) {
    var e = t && t.nodeName && t.nodeName.toLowerCase();
    return e && (e === "input" && (t.type === "text" || t.type === "search" || t.type === "tel" || t.type === "url" || t.type === "password") || e === "textarea" || t.contentEditable === "true");
  }
  var fs = ha && "documentMode" in document && 11 >= document.documentMode, ko = null, $l = null, Ci = null, tr = !1;
  function ds(t, e, a) {
    var n = a.window === a ? a.document : a.nodeType === 9 ? a : a.ownerDocument;
    tr || ko == null || ko !== Ii(n) || (n = ko, "selectionStart" in n && Ti(n) ? n = { start: n.selectionStart, end: n.selectionEnd } : (n = (n.ownerDocument && n.ownerDocument.defaultView || window).getSelection(), n = {
      anchorNode: n.anchorNode,
      anchorOffset: n.anchorOffset,
      focusNode: n.focusNode,
      focusOffset: n.focusOffset
    }), Ci && Si(Ci, n) || (Ci = n, n = tc($l, "onSelect"), 0 < n.length && (e = new En(
      "onSelect",
      "select",
      null,
      e,
      a
    ), t.push({ event: e, listeners: n }), e.target = ko)));
  }
  function no(t, e) {
    var a = {};
    return a[t.toLowerCase()] = e.toLowerCase(), a["Webkit" + t] = "webkit" + e, a["Moz" + t] = "moz" + e, a;
  }
  var Bo = {
    animationend: no("Animation", "AnimationEnd"),
    animationiteration: no("Animation", "AnimationIteration"),
    animationstart: no("Animation", "AnimationStart"),
    transitionrun: no("Transition", "TransitionRun"),
    transitionstart: no("Transition", "TransitionStart"),
    transitioncancel: no("Transition", "TransitionCancel"),
    transitionend: no("Transition", "TransitionEnd")
  }, He = {}, ps = {};
  ha && (ps = document.createElement("div").style, "AnimationEvent" in window || (delete Bo.animationend.animation, delete Bo.animationiteration.animation, delete Bo.animationstart.animation), "TransitionEvent" in window || delete Bo.transitionend.transition);
  function oo(t) {
    if (He[t]) return He[t];
    if (!Bo[t]) return t;
    var e = Bo[t], a;
    for (a in e)
      if (e.hasOwnProperty(a) && a in ps)
        return He[t] = e[a];
    return t;
  }
  var gs = oo("animationend"), ms = oo("animationiteration"), bs = oo("animationstart"), Xc = oo("transitionrun"), jn = oo("transitionstart"), xs = oo("transitioncancel"), er = oo("transitionend"), ys = /* @__PURE__ */ new Map(), io = "abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(
    " "
  );
  io.push("scrollEnd");
  function pa(t, e) {
    ys.set(t, e), ln(e, [t]);
  }
  var sl = /* @__PURE__ */ new WeakMap();
  function ga(t, e) {
    if (typeof t == "object" && t !== null) {
      var a = sl.get(t);
      return a !== void 0 ? a : (e = {
        value: t,
        source: e,
        stack: Ol(e)
      }, sl.set(t, e), e);
    }
    return {
      value: t,
      source: e,
      stack: Ol(e)
    };
  }
  var Ra = [], lo = 0, ar = 0;
  function cl() {
    for (var t = lo, e = ar = lo = 0; e < t; ) {
      var a = Ra[e];
      Ra[e++] = null;
      var n = Ra[e];
      Ra[e++] = null;
      var o = Ra[e];
      Ra[e++] = null;
      var i = Ra[e];
      if (Ra[e++] = null, n !== null && o !== null) {
        var f = n.pending;
        f === null ? o.next = o : (o.next = f.next, f.next = o), n.pending = o;
      }
      i !== 0 && As(a, o, i);
    }
  }
  function ul(t, e, a, n) {
    Ra[lo++] = t, Ra[lo++] = e, Ra[lo++] = a, Ra[lo++] = n, ar |= n, t.lanes |= n, t = t.alternate, t !== null && (t.lanes |= n);
  }
  function nr(t, e, a, n) {
    return ul(t, e, a, n), hl(t);
  }
  function Vo(t, e) {
    return ul(t, null, null, e), hl(t);
  }
  function As(t, e, a) {
    t.lanes |= a;
    var n = t.alternate;
    n !== null && (n.lanes |= a);
    for (var o = !1, i = t.return; i !== null; )
      i.childLanes |= a, n = i.alternate, n !== null && (n.childLanes |= a), i.tag === 22 && (t = i.stateNode, t === null || t._visibility & 1 || (o = !0)), t = i, i = i.return;
    return t.tag === 3 ? (i = t.stateNode, o && e !== null && (o = 31 - be(a), t = i.hiddenUpdates, n = t[o], n === null ? t[o] = [e] : n.push(e), e.lane = a | 536870912), i) : null;
  }
  function hl(t) {
    if (50 < Ur)
      throw Ur = 0, Wu = null, Error(c(185));
    for (var e = t.return; e !== null; )
      t = e, e = t.return;
    return t.tag === 3 ? t.stateNode : null;
  }
  var Do = {};
  function Jc(t, e, a, n) {
    this.tag = t, this.key = a, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.refCleanup = this.ref = null, this.pendingProps = e, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = n, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null;
  }
  function ma(t, e, a, n) {
    return new Jc(t, e, a, n);
  }
  function or(t) {
    return t = t.prototype, !(!t || !t.isReactComponent);
  }
  function Pa(t, e) {
    var a = t.alternate;
    return a === null ? (a = ma(
      t.tag,
      e,
      t.key,
      t.mode
    ), a.elementType = t.elementType, a.type = t.type, a.stateNode = t.stateNode, a.alternate = t, t.alternate = a) : (a.pendingProps = e, a.type = t.type, a.flags = 0, a.subtreeFlags = 0, a.deletions = null), a.flags = t.flags & 65011712, a.childLanes = t.childLanes, a.lanes = t.lanes, a.child = t.child, a.memoizedProps = t.memoizedProps, a.memoizedState = t.memoizedState, a.updateQueue = t.updateQueue, e = t.dependencies, a.dependencies = e === null ? null : { lanes: e.lanes, firstContext: e.firstContext }, a.sibling = t.sibling, a.index = t.index, a.ref = t.ref, a.refCleanup = t.refCleanup, a;
  }
  function vs(t, e) {
    t.flags &= 65011714;
    var a = t.alternate;
    return a === null ? (t.childLanes = 0, t.lanes = e, t.child = null, t.subtreeFlags = 0, t.memoizedProps = null, t.memoizedState = null, t.updateQueue = null, t.dependencies = null, t.stateNode = null) : (t.childLanes = a.childLanes, t.lanes = a.lanes, t.child = a.child, t.subtreeFlags = 0, t.deletions = null, t.memoizedProps = a.memoizedProps, t.memoizedState = a.memoizedState, t.updateQueue = a.updateQueue, t.type = a.type, e = a.dependencies, t.dependencies = e === null ? null : {
      lanes: e.lanes,
      firstContext: e.firstContext
    }), t;
  }
  function fl(t, e, a, n, o, i) {
    var f = 0;
    if (n = t, typeof t == "function") or(t) && (f = 1);
    else if (typeof t == "string")
      f = Yg(
        t,
        a,
        ft.current
      ) ? 26 : t === "html" || t === "head" || t === "body" ? 27 : 5;
    else
      t: switch (t) {
        case ht:
          return t = ma(31, a, e, o), t.elementType = ht, t.lanes = i, t;
        case L:
          return ro(a.children, o, i, e);
        case Z:
          f = 8, o |= 24;
          break;
        case it:
          return t = ma(12, a, e, o | 2), t.elementType = it, t.lanes = i, t;
        case et:
          return t = ma(13, a, e, o), t.elementType = et, t.lanes = i, t;
        case rt:
          return t = ma(19, a, e, o), t.elementType = rt, t.lanes = i, t;
        default:
          if (typeof t == "object" && t !== null)
            switch (t.$$typeof) {
              case mt:
              case Y:
                f = 10;
                break t;
              case tt:
                f = 9;
                break t;
              case W:
                f = 11;
                break t;
              case Mt:
                f = 14;
                break t;
              case J:
                f = 16, n = null;
                break t;
            }
          f = 29, a = Error(
            c(130, t === null ? "null" : typeof t, "")
          ), n = null;
      }
    return e = ma(f, a, e, o), e.elementType = t, e.type = n, e.lanes = i, e;
  }
  function ro(t, e, a, n) {
    return t = ma(7, t, n, e), t.lanes = a, t;
  }
  function dl(t, e, a) {
    return t = ma(6, t, null, e), t.lanes = a, t;
  }
  function ir(t, e, a) {
    return e = ma(
      4,
      t.children !== null ? t.children : [],
      t.key,
      e
    ), e.lanes = a, e.stateNode = {
      containerInfo: t.containerInfo,
      pendingChildren: null,
      implementation: t.implementation
    }, e;
  }
  var Yo = [], zo = 0, za = null, kn = 0, Sa = [], Ta = 0, so = null, fn = 1, G = "";
  function qo(t, e) {
    Yo[zo++] = kn, Yo[zo++] = za, za = t, kn = e;
  }
  function Qo(t, e, a) {
    Sa[Ta++] = fn, Sa[Ta++] = G, Sa[Ta++] = so, so = t;
    var n = fn;
    t = G;
    var o = 32 - be(n) - 1;
    n &= ~(1 << o), a += 1;
    var i = 32 - be(e) + o;
    if (30 < i) {
      var f = o - o % 5;
      i = (n & (1 << f) - 1).toString(32), n >>= f, o -= f, fn = 1 << 32 - be(e) + o | a << o | n, G = i + t;
    } else
      fn = 1 << i | a << o | n, G = t;
  }
  function pl(t) {
    t.return !== null && (qo(t, 1), Qo(t, 1, 0));
  }
  function lr(t) {
    for (; t === za; )
      za = Yo[--zo], Yo[zo] = null, kn = Yo[--zo], Yo[zo] = null;
    for (; t === so; )
      so = Sa[--Ta], Sa[Ta] = null, G = Sa[--Ta], Sa[Ta] = null, fn = Sa[--Ta], Sa[Ta] = null;
  }
  var Je = null, pt = null, Ft = !1, Bn = null, _a = !1, rr = Error(c(519));
  function co(t) {
    var e = Error(c(418, ""));
    throw ji(ga(e, t)), rr;
  }
  function Ms(t) {
    var e = t.stateNode, a = t.type, n = t.memoizedProps;
    switch (e[Rt] = t, e[dt] = n, a) {
      case "dialog":
        Jt("cancel", e), Jt("close", e);
        break;
      case "iframe":
      case "object":
      case "embed":
        Jt("load", e);
        break;
      case "video":
      case "audio":
        for (a = 0; a < kr.length; a++)
          Jt(kr[a], e);
        break;
      case "source":
        Jt("error", e);
        break;
      case "img":
      case "image":
      case "link":
        Jt("error", e), Jt("load", e);
        break;
      case "details":
        Jt("toggle", e);
        break;
      case "input":
        Jt("invalid", e), Ie(
          e,
          n.value,
          n.defaultValue,
          n.checked,
          n.defaultChecked,
          n.type,
          n.name,
          !0
        ), Gn(e);
        break;
      case "select":
        Jt("invalid", e);
        break;
      case "textarea":
        Jt("invalid", e), Ji(e, n.value, n.defaultValue, n.children), Gn(e);
    }
    a = n.children, typeof a != "string" && typeof a != "number" && typeof a != "bigint" || e.textContent === "" + a || n.suppressHydrationWarning === !0 || c0(e.textContent, a) ? (n.popover != null && (Jt("beforetoggle", e), Jt("toggle", e)), n.onScroll != null && Jt("scroll", e), n.onScrollEnd != null && Jt("scrollend", e), n.onClick != null && (e.onclick = ec), e = !0) : e = !1, e || co(t);
  }
  function sr(t) {
    for (Je = t.return; Je; )
      switch (Je.tag) {
        case 5:
        case 13:
          _a = !1;
          return;
        case 27:
        case 3:
          _a = !0;
          return;
        default:
          Je = Je.return;
      }
  }
  function Ni(t) {
    if (t !== Je) return !1;
    if (!Ft) return sr(t), Ft = !0, !1;
    var e = t.tag, a;
    if ((a = e !== 3 && e !== 27) && ((a = e === 5) && (a = t.type, a = !(a !== "form" && a !== "button") || rh(t.type, t.memoizedProps)), a = !a), a && pt && co(t), sr(t), e === 13) {
      if (t = t.memoizedState, t = t !== null ? t.dehydrated : null, !t) throw Error(c(317));
      t: {
        for (t = t.nextSibling, e = 0; t; ) {
          if (t.nodeType === 8)
            if (a = t.data, a === "/$") {
              if (e === 0) {
                pt = gn(t.nextSibling);
                break t;
              }
              e--;
            } else
              a !== "$" && a !== "$!" && a !== "$?" || e++;
          t = t.nextSibling;
        }
        pt = null;
      }
    } else
      e === 27 ? (e = pt, ti(t.type) ? (t = hh, hh = null, pt = t) : pt = e) : pt = Je ? gn(t.stateNode.nextSibling) : null;
    return !0;
  }
  function Ui() {
    pt = Je = null, Ft = !1;
  }
  function ws() {
    var t = Bn;
    return t !== null && (ja === null ? ja = t : ja.push.apply(
      ja,
      t
    ), Bn = null), t;
  }
  function ji(t) {
    Bn === null ? Bn = [t] : Bn.push(t);
  }
  var cr = Q(null), uo = null, dn = null;
  function Vn(t, e, a) {
    $(cr, e._currentValue), e._currentValue = a;
  }
  function ra(t) {
    t._currentValue = cr.current, nt(cr);
  }
  function ur(t, e, a) {
    for (; t !== null; ) {
      var n = t.alternate;
      if ((t.childLanes & e) !== e ? (t.childLanes |= e, n !== null && (n.childLanes |= e)) : n !== null && (n.childLanes & e) !== e && (n.childLanes |= e), t === a) break;
      t = t.return;
    }
  }
  function l(t, e, a, n) {
    var o = t.child;
    for (o !== null && (o.return = t); o !== null; ) {
      var i = o.dependencies;
      if (i !== null) {
        var f = o.child;
        i = i.firstContext;
        t: for (; i !== null; ) {
          var d = i;
          i = o;
          for (var E = 0; E < e.length; E++)
            if (d.context === e[E]) {
              i.lanes |= a, d = i.alternate, d !== null && (d.lanes |= a), ur(
                i.return,
                a,
                t
              ), n || (f = null);
              break t;
            }
          i = d.next;
        }
      } else if (o.tag === 18) {
        if (f = o.return, f === null) throw Error(c(341));
        f.lanes |= a, i = f.alternate, i !== null && (i.lanes |= a), ur(f, a, t), f = null;
      } else f = o.child;
      if (f !== null) f.return = o;
      else
        for (f = o; f !== null; ) {
          if (f === t) {
            f = null;
            break;
          }
          if (o = f.sibling, o !== null) {
            o.return = f.return, f = o;
            break;
          }
          f = f.return;
        }
      o = f;
    }
  }
  function p(t, e, a, n) {
    t = null;
    for (var o = e, i = !1; o !== null; ) {
      if (!i) {
        if ((o.flags & 524288) !== 0) i = !0;
        else if ((o.flags & 262144) !== 0) break;
      }
      if (o.tag === 10) {
        var f = o.alternate;
        if (f === null) throw Error(c(387));
        if (f = f.memoizedProps, f !== null) {
          var d = o.type;
          da(o.pendingProps.value, f.value) || (t !== null ? t.push(d) : t = [d]);
        }
      } else if (o === me.current) {
        if (f = o.alternate, f === null) throw Error(c(387));
        f.memoizedState.memoizedState !== o.memoizedState.memoizedState && (t !== null ? t.push(qr) : t = [qr]);
      }
      o = o.return;
    }
    t !== null && l(
      e,
      t,
      a,
      n
    ), e.flags |= 262144;
  }
  function x(t) {
    for (t = t.firstContext; t !== null; ) {
      if (!da(
        t.context._currentValue,
        t.memoizedValue
      ))
        return !0;
      t = t.next;
    }
    return !1;
  }
  function w(t) {
    uo = t, dn = null, t = t.dependencies, t !== null && (t.firstContext = null);
  }
  function N(t) {
    return ot(uo, t);
  }
  function H(t, e) {
    return uo === null && w(t), ot(t, e);
  }
  function ot(t, e) {
    var a = e._currentValue;
    if (e = { context: e, memoizedValue: a, next: null }, dn === null) {
      if (t === null) throw Error(c(308));
      dn = e, t.dependencies = { lanes: 0, firstContext: e }, t.flags |= 524288;
    } else dn = dn.next = e;
    return a;
  }
  var P = typeof AbortController < "u" ? AbortController : function() {
    var t = [], e = this.signal = {
      aborted: !1,
      addEventListener: function(a, n) {
        t.push(n);
      }
    };
    this.abort = function() {
      e.aborted = !0, t.forEach(function(a) {
        return a();
      });
    };
  }, at = r.unstable_scheduleCallback, zt = r.unstable_NormalPriority, Bt = {
    $$typeof: Y,
    Consumer: null,
    Provider: null,
    _currentValue: null,
    _currentValue2: null,
    _threadCount: 0
  };
  function ee() {
    return {
      controller: new P(),
      data: /* @__PURE__ */ new Map(),
      refCount: 0
    };
  }
  function Zt(t) {
    t.refCount--, t.refCount === 0 && at(zt, function() {
      t.controller.abort();
    });
  }
  var Pt = null, Dn = 0, Ca = 0, ho = null;
  function gl(t, e) {
    if (Pt === null) {
      var a = Pt = [];
      Dn = 0, Ca = _u(), ho = {
        status: "pending",
        value: void 0,
        then: function(n) {
          a.push(n);
        }
      };
    }
    return Dn++, e.then(hr, hr), e;
  }
  function hr() {
    if (--Dn === 0 && Pt !== null) {
      ho !== null && (ho.status = "fulfilled");
      var t = Pt;
      Pt = null, Ca = 0, ho = null;
      for (var e = 0; e < t.length; e++) (0, t[e])();
    }
  }
  function ml(t, e) {
    var a = [], n = {
      status: "pending",
      value: null,
      reason: null,
      then: function(o) {
        a.push(o);
      }
    };
    return t.then(
      function() {
        n.status = "fulfilled", n.value = e;
        for (var o = 0; o < a.length; o++) (0, a[o])(e);
      },
      function(o) {
        for (n.status = "rejected", n.reason = o, o = 0; o < a.length; o++)
          (0, a[o])(void 0);
      }
    ), n;
  }
  var Jh = q.S;
  q.S = function(t, e) {
    typeof e == "object" && e !== null && typeof e.then == "function" && gl(t, e), Jh !== null && Jh(t, e);
  };
  var ki = Q(null);
  function Pc() {
    var t = ki.current;
    return t !== null ? t : fe.pooledCache;
  }
  function Es(t, e) {
    e === null ? $(ki, ki.current) : $(ki, e.pool);
  }
  function Ph() {
    var t = Pc();
    return t === null ? null : { parent: Bt._currentValue, pool: t };
  }
  var fr = Error(c(460)), _h = Error(c(474)), Rs = Error(c(542)), _c = { then: function() {
  } };
  function $h(t) {
    return t = t.status, t === "fulfilled" || t === "rejected";
  }
  function Ss() {
  }
  function tf(t, e, a) {
    switch (a = t[a], a === void 0 ? t.push(e) : a !== e && (e.then(Ss, Ss), e = a), e.status) {
      case "fulfilled":
        return e.value;
      case "rejected":
        throw t = e.reason, af(t), t;
      default:
        if (typeof e.status == "string") e.then(Ss, Ss);
        else {
          if (t = fe, t !== null && 100 < t.shellSuspendCounter)
            throw Error(c(482));
          t = e, t.status = "pending", t.then(
            function(n) {
              if (e.status === "pending") {
                var o = e;
                o.status = "fulfilled", o.value = n;
              }
            },
            function(n) {
              if (e.status === "pending") {
                var o = e;
                o.status = "rejected", o.reason = n;
              }
            }
          );
        }
        switch (e.status) {
          case "fulfilled":
            return e.value;
          case "rejected":
            throw t = e.reason, af(t), t;
        }
        throw dr = e, fr;
    }
  }
  var dr = null;
  function ef() {
    if (dr === null) throw Error(c(459));
    var t = dr;
    return dr = null, t;
  }
  function af(t) {
    if (t === fr || t === Rs)
      throw Error(c(483));
  }
  var Lo = !1;
  function $c(t) {
    t.updateQueue = {
      baseState: t.memoizedState,
      firstBaseUpdate: null,
      lastBaseUpdate: null,
      shared: { pending: null, lanes: 0, hiddenCallbacks: null },
      callbacks: null
    };
  }
  function tu(t, e) {
    t = t.updateQueue, e.updateQueue === t && (e.updateQueue = {
      baseState: t.baseState,
      firstBaseUpdate: t.firstBaseUpdate,
      lastBaseUpdate: t.lastBaseUpdate,
      shared: t.shared,
      callbacks: null
    });
  }
  function Oo(t) {
    return { lane: t, tag: 0, payload: null, callback: null, next: null };
  }
  function Ko(t, e, a) {
    var n = t.updateQueue;
    if (n === null) return null;
    if (n = n.shared, (oe & 2) !== 0) {
      var o = n.pending;
      return o === null ? e.next = e : (e.next = o.next, o.next = e), n.pending = e, e = hl(t), As(t, null, a), e;
    }
    return ul(t, n, e, a), hl(t);
  }
  function pr(t, e, a) {
    if (e = e.updateQueue, e !== null && (e = e.shared, (a & 4194048) !== 0)) {
      var n = e.lanes;
      n &= t.pendingLanes, a |= n, e.lanes = a, we(t, a);
    }
  }
  function eu(t, e) {
    var a = t.updateQueue, n = t.alternate;
    if (n !== null && (n = n.updateQueue, a === n)) {
      var o = null, i = null;
      if (a = a.firstBaseUpdate, a !== null) {
        do {
          var f = {
            lane: a.lane,
            tag: a.tag,
            payload: a.payload,
            callback: null,
            next: null
          };
          i === null ? o = i = f : i = i.next = f, a = a.next;
        } while (a !== null);
        i === null ? o = i = e : i = i.next = e;
      } else o = i = e;
      a = {
        baseState: n.baseState,
        firstBaseUpdate: o,
        lastBaseUpdate: i,
        shared: n.shared,
        callbacks: n.callbacks
      }, t.updateQueue = a;
      return;
    }
    t = a.lastBaseUpdate, t === null ? a.firstBaseUpdate = e : t.next = e, a.lastBaseUpdate = e;
  }
  var au = !1;
  function gr() {
    if (au) {
      var t = ho;
      if (t !== null) throw t;
    }
  }
  function mr(t, e, a, n) {
    au = !1;
    var o = t.updateQueue;
    Lo = !1;
    var i = o.firstBaseUpdate, f = o.lastBaseUpdate, d = o.shared.pending;
    if (d !== null) {
      o.shared.pending = null;
      var E = d, V = E.next;
      E.next = null, f === null ? i = V : f.next = V, f = E;
      var F = t.alternate;
      F !== null && (F = F.updateQueue, d = F.lastBaseUpdate, d !== f && (d === null ? F.firstBaseUpdate = V : d.next = V, F.lastBaseUpdate = E));
    }
    if (i !== null) {
      var X = o.baseState;
      f = 0, F = V = E = null, d = i;
      do {
        var D = d.lane & -536870913, z = D !== d.lane;
        if (z ? (te & D) === D : (n & D) === D) {
          D !== 0 && D === Ca && (au = !0), F !== null && (F = F.next = {
            lane: 0,
            tag: d.tag,
            payload: d.payload,
            callback: null,
            next: null
          });
          t: {
            var Dt = t, St = d;
            D = e;
            var se = a;
            switch (St.tag) {
              case 1:
                if (Dt = St.payload, typeof Dt == "function") {
                  X = Dt.call(se, X, D);
                  break t;
                }
                X = Dt;
                break t;
              case 3:
                Dt.flags = Dt.flags & -65537 | 128;
              case 0:
                if (Dt = St.payload, D = typeof Dt == "function" ? Dt.call(se, X, D) : Dt, D == null) break t;
                X = S({}, X, D);
                break t;
              case 2:
                Lo = !0;
            }
          }
          D = d.callback, D !== null && (t.flags |= 64, z && (t.flags |= 8192), z = o.callbacks, z === null ? o.callbacks = [D] : z.push(D));
        } else
          z = {
            lane: D,
            tag: d.tag,
            payload: d.payload,
            callback: d.callback,
            next: null
          }, F === null ? (V = F = z, E = X) : F = F.next = z, f |= D;
        if (d = d.next, d === null) {
          if (d = o.shared.pending, d === null)
            break;
          z = d, d = z.next, z.next = null, o.lastBaseUpdate = z, o.shared.pending = null;
        }
      } while (!0);
      F === null && (E = X), o.baseState = E, o.firstBaseUpdate = V, o.lastBaseUpdate = F, i === null && (o.shared.lanes = 0), Jo |= f, t.lanes = f, t.memoizedState = X;
    }
  }
  function nf(t, e) {
    if (typeof t != "function")
      throw Error(c(191, t));
    t.call(e);
  }
  function of(t, e) {
    var a = t.callbacks;
    if (a !== null)
      for (t.callbacks = null, t = 0; t < a.length; t++)
        nf(a[t], e);
  }
  var bl = Q(null), Ts = Q(0);
  function lf(t, e) {
    t = yo, $(Ts, t), $(bl, e), yo = t | e.baseLanes;
  }
  function nu() {
    $(Ts, yo), $(bl, bl.current);
  }
  function ou() {
    yo = Ts.current, nt(bl), nt(Ts);
  }
  var Ho = 0, Wt = null, le = null, Ve = null, Cs = !1, xl = !1, Bi = !1, Ns = 0, br = 0, yl = null, Lp = 0;
  function Ne() {
    throw Error(c(321));
  }
  function iu(t, e) {
    if (e === null) return !1;
    for (var a = 0; a < e.length && a < t.length; a++)
      if (!da(t[a], e[a])) return !1;
    return !0;
  }
  function lu(t, e, a, n, o, i) {
    return Ho = i, Wt = e, e.memoizedState = null, e.updateQueue = null, e.lanes = 0, q.H = t === null || t.memoizedState === null ? Hf : Zf, Bi = !1, i = a(n, o), Bi = !1, xl && (i = sf(
      e,
      a,
      n,
      o
    )), rf(t), i;
  }
  function rf(t) {
    q.H = Ds;
    var e = le !== null && le.next !== null;
    if (Ho = 0, Ve = le = Wt = null, Cs = !1, br = 0, yl = null, e) throw Error(c(300));
    t === null || Ze || (t = t.dependencies, t !== null && x(t) && (Ze = !0));
  }
  function sf(t, e, a, n) {
    Wt = t;
    var o = 0;
    do {
      if (xl && (yl = null), br = 0, xl = !1, 25 <= o) throw Error(c(301));
      if (o += 1, Ve = le = null, t.updateQueue != null) {
        var i = t.updateQueue;
        i.lastEffect = null, i.events = null, i.stores = null, i.memoCache != null && (i.memoCache.index = 0);
      }
      q.H = Gp, i = e(a, n);
    } while (xl);
    return i;
  }
  function Op() {
    var t = q.H, e = t.useState()[0];
    return e = typeof e.then == "function" ? xr(e) : e, t = t.useState()[0], (le !== null ? le.memoizedState : null) !== t && (Wt.flags |= 1024), e;
  }
  function ru() {
    var t = Ns !== 0;
    return Ns = 0, t;
  }
  function su(t, e, a) {
    e.updateQueue = t.updateQueue, e.flags &= -2053, t.lanes &= ~a;
  }
  function cu(t) {
    if (Cs) {
      for (t = t.memoizedState; t !== null; ) {
        var e = t.queue;
        e !== null && (e.pending = null), t = t.next;
      }
      Cs = !1;
    }
    Ho = 0, Ve = le = Wt = null, xl = !1, br = Ns = 0, yl = null;
  }
  function Na() {
    var t = {
      memoizedState: null,
      baseState: null,
      baseQueue: null,
      queue: null,
      next: null
    };
    return Ve === null ? Wt.memoizedState = Ve = t : Ve = Ve.next = t, Ve;
  }
  function De() {
    if (le === null) {
      var t = Wt.alternate;
      t = t !== null ? t.memoizedState : null;
    } else t = le.next;
    var e = Ve === null ? Wt.memoizedState : Ve.next;
    if (e !== null)
      Ve = e, le = t;
    else {
      if (t === null)
        throw Wt.alternate === null ? Error(c(467)) : Error(c(310));
      le = t, t = {
        memoizedState: le.memoizedState,
        baseState: le.baseState,
        baseQueue: le.baseQueue,
        queue: le.queue,
        next: null
      }, Ve === null ? Wt.memoizedState = Ve = t : Ve = Ve.next = t;
    }
    return Ve;
  }
  function uu() {
    return { lastEffect: null, events: null, stores: null, memoCache: null };
  }
  function xr(t) {
    var e = br;
    return br += 1, yl === null && (yl = []), t = tf(yl, t, e), e = Wt, (Ve === null ? e.memoizedState : Ve.next) === null && (e = e.alternate, q.H = e === null || e.memoizedState === null ? Hf : Zf), t;
  }
  function Us(t) {
    if (t !== null && typeof t == "object") {
      if (typeof t.then == "function") return xr(t);
      if (t.$$typeof === Y) return N(t);
    }
    throw Error(c(438, String(t)));
  }
  function hu(t) {
    var e = null, a = Wt.updateQueue;
    if (a !== null && (e = a.memoCache), e == null) {
      var n = Wt.alternate;
      n !== null && (n = n.updateQueue, n !== null && (n = n.memoCache, n != null && (e = {
        data: n.data.map(function(o) {
          return o.slice();
        }),
        index: 0
      })));
    }
    if (e == null && (e = { data: [], index: 0 }), a === null && (a = uu(), Wt.updateQueue = a), a.memoCache = e, a = e.data[e.index], a === void 0)
      for (a = e.data[e.index] = Array(t), n = 0; n < t; n++)
        a[n] = Tt;
    return e.index++, a;
  }
  function fo(t, e) {
    return typeof e == "function" ? e(t) : e;
  }
  function js(t) {
    var e = De();
    return fu(e, le, t);
  }
  function fu(t, e, a) {
    var n = t.queue;
    if (n === null) throw Error(c(311));
    n.lastRenderedReducer = a;
    var o = t.baseQueue, i = n.pending;
    if (i !== null) {
      if (o !== null) {
        var f = o.next;
        o.next = i.next, i.next = f;
      }
      e.baseQueue = o = i, n.pending = null;
    }
    if (i = t.baseState, o === null) t.memoizedState = i;
    else {
      e = o.next;
      var d = f = null, E = null, V = e, F = !1;
      do {
        var X = V.lane & -536870913;
        if (X !== V.lane ? (te & X) === X : (Ho & X) === X) {
          var D = V.revertLane;
          if (D === 0)
            E !== null && (E = E.next = {
              lane: 0,
              revertLane: 0,
              action: V.action,
              hasEagerState: V.hasEagerState,
              eagerState: V.eagerState,
              next: null
            }), X === Ca && (F = !0);
          else if ((Ho & D) === D) {
            V = V.next, D === Ca && (F = !0);
            continue;
          } else
            X = {
              lane: 0,
              revertLane: V.revertLane,
              action: V.action,
              hasEagerState: V.hasEagerState,
              eagerState: V.eagerState,
              next: null
            }, E === null ? (d = E = X, f = i) : E = E.next = X, Wt.lanes |= D, Jo |= D;
          X = V.action, Bi && a(i, X), i = V.hasEagerState ? V.eagerState : a(i, X);
        } else
          D = {
            lane: X,
            revertLane: V.revertLane,
            action: V.action,
            hasEagerState: V.hasEagerState,
            eagerState: V.eagerState,
            next: null
          }, E === null ? (d = E = D, f = i) : E = E.next = D, Wt.lanes |= X, Jo |= X;
        V = V.next;
      } while (V !== null && V !== e);
      if (E === null ? f = i : E.next = d, !da(i, t.memoizedState) && (Ze = !0, F && (a = ho, a !== null)))
        throw a;
      t.memoizedState = i, t.baseState = f, t.baseQueue = E, n.lastRenderedState = i;
    }
    return o === null && (n.lanes = 0), [t.memoizedState, n.dispatch];
  }
  function du(t) {
    var e = De(), a = e.queue;
    if (a === null) throw Error(c(311));
    a.lastRenderedReducer = t;
    var n = a.dispatch, o = a.pending, i = e.memoizedState;
    if (o !== null) {
      a.pending = null;
      var f = o = o.next;
      do
        i = t(i, f.action), f = f.next;
      while (f !== o);
      da(i, e.memoizedState) || (Ze = !0), e.memoizedState = i, e.baseQueue === null && (e.baseState = i), a.lastRenderedState = i;
    }
    return [i, n];
  }
  function cf(t, e, a) {
    var n = Wt, o = De(), i = Ft;
    if (i) {
      if (a === void 0) throw Error(c(407));
      a = a();
    } else a = e();
    var f = !da(
      (le || o).memoizedState,
      a
    );
    f && (o.memoizedState = a, Ze = !0), o = o.queue;
    var d = ff.bind(null, n, o, t);
    if (yr(2048, 8, d, [t]), o.getSnapshot !== e || f || Ve !== null && Ve.memoizedState.tag & 1) {
      if (n.flags |= 2048, Al(
        9,
        ks(),
        hf.bind(
          null,
          n,
          o,
          a,
          e
        ),
        null
      ), fe === null) throw Error(c(349));
      i || (Ho & 124) !== 0 || uf(n, e, a);
    }
    return a;
  }
  function uf(t, e, a) {
    t.flags |= 16384, t = { getSnapshot: e, value: a }, e = Wt.updateQueue, e === null ? (e = uu(), Wt.updateQueue = e, e.stores = [t]) : (a = e.stores, a === null ? e.stores = [t] : a.push(t));
  }
  function hf(t, e, a, n) {
    e.value = a, e.getSnapshot = n, df(e) && pf(t);
  }
  function ff(t, e, a) {
    return a(function() {
      df(e) && pf(t);
    });
  }
  function df(t) {
    var e = t.getSnapshot;
    t = t.value;
    try {
      var a = e();
      return !da(t, a);
    } catch {
      return !0;
    }
  }
  function pf(t) {
    var e = Vo(t, 2);
    e !== null && Ka(e, t, 2);
  }
  function pu(t) {
    var e = Na();
    if (typeof t == "function") {
      var a = t;
      if (t = a(), Bi) {
        ya(!0);
        try {
          a();
        } finally {
          ya(!1);
        }
      }
    }
    return e.memoizedState = e.baseState = t, e.queue = {
      pending: null,
      lanes: 0,
      dispatch: null,
      lastRenderedReducer: fo,
      lastRenderedState: t
    }, e;
  }
  function gf(t, e, a, n) {
    return t.baseState = a, fu(
      t,
      le,
      typeof n == "function" ? n : fo
    );
  }
  function Kp(t, e, a, n, o) {
    if (Vs(t)) throw Error(c(485));
    if (t = e.action, t !== null) {
      var i = {
        payload: o,
        action: t,
        next: null,
        isTransition: !0,
        status: "pending",
        value: null,
        reason: null,
        listeners: [],
        then: function(f) {
          i.listeners.push(f);
        }
      };
      q.T !== null ? a(!0) : i.isTransition = !1, n(i), a = e.pending, a === null ? (i.next = e.pending = i, mf(e, i)) : (i.next = a.next, e.pending = a.next = i);
    }
  }
  function mf(t, e) {
    var a = e.action, n = e.payload, o = t.state;
    if (e.isTransition) {
      var i = q.T, f = {};
      q.T = f;
      try {
        var d = a(o, n), E = q.S;
        E !== null && E(f, d), bf(t, e, d);
      } catch (V) {
        gu(t, e, V);
      } finally {
        q.T = i;
      }
    } else
      try {
        i = a(o, n), bf(t, e, i);
      } catch (V) {
        gu(t, e, V);
      }
  }
  function bf(t, e, a) {
    a !== null && typeof a == "object" && typeof a.then == "function" ? a.then(
      function(n) {
        xf(t, e, n);
      },
      function(n) {
        return gu(t, e, n);
      }
    ) : xf(t, e, a);
  }
  function xf(t, e, a) {
    e.status = "fulfilled", e.value = a, yf(e), t.state = a, e = t.pending, e !== null && (a = e.next, a === e ? t.pending = null : (a = a.next, e.next = a, mf(t, a)));
  }
  function gu(t, e, a) {
    var n = t.pending;
    if (t.pending = null, n !== null) {
      n = n.next;
      do
        e.status = "rejected", e.reason = a, yf(e), e = e.next;
      while (e !== n);
    }
    t.action = null;
  }
  function yf(t) {
    t = t.listeners;
    for (var e = 0; e < t.length; e++) (0, t[e])();
  }
  function Af(t, e) {
    return e;
  }
  function vf(t, e) {
    if (Ft) {
      var a = fe.formState;
      if (a !== null) {
        t: {
          var n = Wt;
          if (Ft) {
            if (pt) {
              e: {
                for (var o = pt, i = _a; o.nodeType !== 8; ) {
                  if (!i) {
                    o = null;
                    break e;
                  }
                  if (o = gn(
                    o.nextSibling
                  ), o === null) {
                    o = null;
                    break e;
                  }
                }
                i = o.data, o = i === "F!" || i === "F" ? o : null;
              }
              if (o) {
                pt = gn(
                  o.nextSibling
                ), n = o.data === "F!";
                break t;
              }
            }
            co(n);
          }
          n = !1;
        }
        n && (e = a[0]);
      }
    }
    return a = Na(), a.memoizedState = a.baseState = e, n = {
      pending: null,
      lanes: 0,
      dispatch: null,
      lastRenderedReducer: Af,
      lastRenderedState: e
    }, a.queue = n, a = Lf.bind(
      null,
      Wt,
      n
    ), n.dispatch = a, n = pu(!1), i = Au.bind(
      null,
      Wt,
      !1,
      n.queue
    ), n = Na(), o = {
      state: e,
      dispatch: null,
      action: t,
      pending: null
    }, n.queue = o, a = Kp.bind(
      null,
      Wt,
      o,
      i,
      a
    ), o.dispatch = a, n.memoizedState = t, [e, a, !1];
  }
  function Mf(t) {
    var e = De();
    return wf(e, le, t);
  }
  function wf(t, e, a) {
    if (e = fu(
      t,
      e,
      Af
    )[0], t = js(fo)[0], typeof e == "object" && e !== null && typeof e.then == "function")
      try {
        var n = xr(e);
      } catch (f) {
        throw f === fr ? Rs : f;
      }
    else n = e;
    e = De();
    var o = e.queue, i = o.dispatch;
    return a !== e.memoizedState && (Wt.flags |= 2048, Al(
      9,
      ks(),
      Hp.bind(null, o, a),
      null
    )), [n, i, t];
  }
  function Hp(t, e) {
    t.action = e;
  }
  function Ef(t) {
    var e = De(), a = le;
    if (a !== null)
      return wf(e, a, t);
    De(), e = e.memoizedState, a = De();
    var n = a.queue.dispatch;
    return a.memoizedState = t, [e, n, !1];
  }
  function Al(t, e, a, n) {
    return t = { tag: t, create: a, deps: n, inst: e, next: null }, e = Wt.updateQueue, e === null && (e = uu(), Wt.updateQueue = e), a = e.lastEffect, a === null ? e.lastEffect = t.next = t : (n = a.next, a.next = t, t.next = n, e.lastEffect = t), t;
  }
  function ks() {
    return { destroy: void 0, resource: void 0 };
  }
  function Rf() {
    return De().memoizedState;
  }
  function Bs(t, e, a, n) {
    var o = Na();
    n = n === void 0 ? null : n, Wt.flags |= t, o.memoizedState = Al(
      1 | e,
      ks(),
      a,
      n
    );
  }
  function yr(t, e, a, n) {
    var o = De();
    n = n === void 0 ? null : n;
    var i = o.memoizedState.inst;
    le !== null && n !== null && iu(n, le.memoizedState.deps) ? o.memoizedState = Al(e, i, a, n) : (Wt.flags |= t, o.memoizedState = Al(
      1 | e,
      i,
      a,
      n
    ));
  }
  function Sf(t, e) {
    Bs(8390656, 8, t, e);
  }
  function Tf(t, e) {
    yr(2048, 8, t, e);
  }
  function Cf(t, e) {
    return yr(4, 2, t, e);
  }
  function Nf(t, e) {
    return yr(4, 4, t, e);
  }
  function Uf(t, e) {
    if (typeof e == "function") {
      t = t();
      var a = e(t);
      return function() {
        typeof a == "function" ? a() : e(null);
      };
    }
    if (e != null)
      return t = t(), e.current = t, function() {
        e.current = null;
      };
  }
  function jf(t, e, a) {
    a = a != null ? a.concat([t]) : null, yr(4, 4, Uf.bind(null, e, t), a);
  }
  function mu() {
  }
  function kf(t, e) {
    var a = De();
    e = e === void 0 ? null : e;
    var n = a.memoizedState;
    return e !== null && iu(e, n[1]) ? n[0] : (a.memoizedState = [t, e], t);
  }
  function Bf(t, e) {
    var a = De();
    e = e === void 0 ? null : e;
    var n = a.memoizedState;
    if (e !== null && iu(e, n[1]))
      return n[0];
    if (n = t(), Bi) {
      ya(!0);
      try {
        t();
      } finally {
        ya(!1);
      }
    }
    return a.memoizedState = [n, e], n;
  }
  function bu(t, e, a) {
    return a === void 0 || (Ho & 1073741824) !== 0 ? t.memoizedState = e : (t.memoizedState = a, t = Yd(), Wt.lanes |= t, Jo |= t, a);
  }
  function Vf(t, e, a, n) {
    return da(a, e) ? a : bl.current !== null ? (t = bu(t, a, n), da(t, e) || (Ze = !0), t) : (Ho & 42) === 0 ? (Ze = !0, t.memoizedState = a) : (t = Yd(), Wt.lanes |= t, Jo |= t, e);
  }
  function Df(t, e, a, n, o) {
    var i = O.p;
    O.p = i !== 0 && 8 > i ? i : 8;
    var f = q.T, d = {};
    q.T = d, Au(t, !1, e, a);
    try {
      var E = o(), V = q.S;
      if (V !== null && V(d, E), E !== null && typeof E == "object" && typeof E.then == "function") {
        var F = ml(
          E,
          n
        );
        Ar(
          t,
          e,
          F,
          Oa(t)
        );
      } else
        Ar(
          t,
          e,
          n,
          Oa(t)
        );
    } catch (X) {
      Ar(
        t,
        e,
        { then: function() {
        }, status: "rejected", reason: X },
        Oa()
      );
    } finally {
      O.p = i, q.T = f;
    }
  }
  function Zp() {
  }
  function xu(t, e, a, n) {
    if (t.tag !== 5) throw Error(c(476));
    var o = Yf(t).queue;
    Df(
      t,
      o,
      e,
      K,
      a === null ? Zp : function() {
        return zf(t), a(n);
      }
    );
  }
  function Yf(t) {
    var e = t.memoizedState;
    if (e !== null) return e;
    e = {
      memoizedState: K,
      baseState: K,
      baseQueue: null,
      queue: {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: fo,
        lastRenderedState: K
      },
      next: null
    };
    var a = {};
    return e.next = {
      memoizedState: a,
      baseState: a,
      baseQueue: null,
      queue: {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: fo,
        lastRenderedState: a
      },
      next: null
    }, t.memoizedState = e, t = t.alternate, t !== null && (t.memoizedState = e), e;
  }
  function zf(t) {
    var e = Yf(t).next.queue;
    Ar(t, e, {}, Oa());
  }
  function yu() {
    return N(qr);
  }
  function qf() {
    return De().memoizedState;
  }
  function Qf() {
    return De().memoizedState;
  }
  function Wp(t) {
    for (var e = t.return; e !== null; ) {
      switch (e.tag) {
        case 24:
        case 3:
          var a = Oa();
          t = Oo(a);
          var n = Ko(e, t, a);
          n !== null && (Ka(n, e, a), pr(n, e, a)), e = { cache: ee() }, t.payload = e;
          return;
      }
      e = e.return;
    }
  }
  function Fp(t, e, a) {
    var n = Oa();
    a = {
      lane: n,
      revertLane: 0,
      action: a,
      hasEagerState: !1,
      eagerState: null,
      next: null
    }, Vs(t) ? Of(e, a) : (a = nr(t, e, a, n), a !== null && (Ka(a, t, n), Kf(a, e, n)));
  }
  function Lf(t, e, a) {
    var n = Oa();
    Ar(t, e, a, n);
  }
  function Ar(t, e, a, n) {
    var o = {
      lane: n,
      revertLane: 0,
      action: a,
      hasEagerState: !1,
      eagerState: null,
      next: null
    };
    if (Vs(t)) Of(e, o);
    else {
      var i = t.alternate;
      if (t.lanes === 0 && (i === null || i.lanes === 0) && (i = e.lastRenderedReducer, i !== null))
        try {
          var f = e.lastRenderedState, d = i(f, a);
          if (o.hasEagerState = !0, o.eagerState = d, da(d, f))
            return ul(t, e, o, 0), fe === null && cl(), !1;
        } catch {
        }
      if (a = nr(t, e, o, n), a !== null)
        return Ka(a, t, n), Kf(a, e, n), !0;
    }
    return !1;
  }
  function Au(t, e, a, n) {
    if (n = {
      lane: 2,
      revertLane: _u(),
      action: n,
      hasEagerState: !1,
      eagerState: null,
      next: null
    }, Vs(t)) {
      if (e) throw Error(c(479));
    } else
      e = nr(
        t,
        a,
        n,
        2
      ), e !== null && Ka(e, t, 2);
  }
  function Vs(t) {
    var e = t.alternate;
    return t === Wt || e !== null && e === Wt;
  }
  function Of(t, e) {
    xl = Cs = !0;
    var a = t.pending;
    a === null ? e.next = e : (e.next = a.next, a.next = e), t.pending = e;
  }
  function Kf(t, e, a) {
    if ((a & 4194048) !== 0) {
      var n = e.lanes;
      n &= t.pendingLanes, a |= n, e.lanes = a, we(t, a);
    }
  }
  var Ds = {
    readContext: N,
    use: Us,
    useCallback: Ne,
    useContext: Ne,
    useEffect: Ne,
    useImperativeHandle: Ne,
    useLayoutEffect: Ne,
    useInsertionEffect: Ne,
    useMemo: Ne,
    useReducer: Ne,
    useRef: Ne,
    useState: Ne,
    useDebugValue: Ne,
    useDeferredValue: Ne,
    useTransition: Ne,
    useSyncExternalStore: Ne,
    useId: Ne,
    useHostTransitionStatus: Ne,
    useFormState: Ne,
    useActionState: Ne,
    useOptimistic: Ne,
    useMemoCache: Ne,
    useCacheRefresh: Ne
  }, Hf = {
    readContext: N,
    use: Us,
    useCallback: function(t, e) {
      return Na().memoizedState = [
        t,
        e === void 0 ? null : e
      ], t;
    },
    useContext: N,
    useEffect: Sf,
    useImperativeHandle: function(t, e, a) {
      a = a != null ? a.concat([t]) : null, Bs(
        4194308,
        4,
        Uf.bind(null, e, t),
        a
      );
    },
    useLayoutEffect: function(t, e) {
      return Bs(4194308, 4, t, e);
    },
    useInsertionEffect: function(t, e) {
      Bs(4, 2, t, e);
    },
    useMemo: function(t, e) {
      var a = Na();
      e = e === void 0 ? null : e;
      var n = t();
      if (Bi) {
        ya(!0);
        try {
          t();
        } finally {
          ya(!1);
        }
      }
      return a.memoizedState = [n, e], n;
    },
    useReducer: function(t, e, a) {
      var n = Na();
      if (a !== void 0) {
        var o = a(e);
        if (Bi) {
          ya(!0);
          try {
            a(e);
          } finally {
            ya(!1);
          }
        }
      } else o = e;
      return n.memoizedState = n.baseState = o, t = {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: t,
        lastRenderedState: o
      }, n.queue = t, t = t.dispatch = Fp.bind(
        null,
        Wt,
        t
      ), [n.memoizedState, t];
    },
    useRef: function(t) {
      var e = Na();
      return t = { current: t }, e.memoizedState = t;
    },
    useState: function(t) {
      t = pu(t);
      var e = t.queue, a = Lf.bind(null, Wt, e);
      return e.dispatch = a, [t.memoizedState, a];
    },
    useDebugValue: mu,
    useDeferredValue: function(t, e) {
      var a = Na();
      return bu(a, t, e);
    },
    useTransition: function() {
      var t = pu(!1);
      return t = Df.bind(
        null,
        Wt,
        t.queue,
        !0,
        !1
      ), Na().memoizedState = t, [!1, t];
    },
    useSyncExternalStore: function(t, e, a) {
      var n = Wt, o = Na();
      if (Ft) {
        if (a === void 0)
          throw Error(c(407));
        a = a();
      } else {
        if (a = e(), fe === null)
          throw Error(c(349));
        (te & 124) !== 0 || uf(n, e, a);
      }
      o.memoizedState = a;
      var i = { value: a, getSnapshot: e };
      return o.queue = i, Sf(ff.bind(null, n, i, t), [
        t
      ]), n.flags |= 2048, Al(
        9,
        ks(),
        hf.bind(
          null,
          n,
          i,
          a,
          e
        ),
        null
      ), a;
    },
    useId: function() {
      var t = Na(), e = fe.identifierPrefix;
      if (Ft) {
        var a = G, n = fn;
        a = (n & ~(1 << 32 - be(n) - 1)).toString(32) + a, e = "«" + e + "R" + a, a = Ns++, 0 < a && (e += "H" + a.toString(32)), e += "»";
      } else
        a = Lp++, e = "«" + e + "r" + a.toString(32) + "»";
      return t.memoizedState = e;
    },
    useHostTransitionStatus: yu,
    useFormState: vf,
    useActionState: vf,
    useOptimistic: function(t) {
      var e = Na();
      e.memoizedState = e.baseState = t;
      var a = {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: null,
        lastRenderedState: null
      };
      return e.queue = a, e = Au.bind(
        null,
        Wt,
        !0,
        a
      ), a.dispatch = e, [t, e];
    },
    useMemoCache: hu,
    useCacheRefresh: function() {
      return Na().memoizedState = Wp.bind(
        null,
        Wt
      );
    }
  }, Zf = {
    readContext: N,
    use: Us,
    useCallback: kf,
    useContext: N,
    useEffect: Tf,
    useImperativeHandle: jf,
    useInsertionEffect: Cf,
    useLayoutEffect: Nf,
    useMemo: Bf,
    useReducer: js,
    useRef: Rf,
    useState: function() {
      return js(fo);
    },
    useDebugValue: mu,
    useDeferredValue: function(t, e) {
      var a = De();
      return Vf(
        a,
        le.memoizedState,
        t,
        e
      );
    },
    useTransition: function() {
      var t = js(fo)[0], e = De().memoizedState;
      return [
        typeof t == "boolean" ? t : xr(t),
        e
      ];
    },
    useSyncExternalStore: cf,
    useId: qf,
    useHostTransitionStatus: yu,
    useFormState: Mf,
    useActionState: Mf,
    useOptimistic: function(t, e) {
      var a = De();
      return gf(a, le, t, e);
    },
    useMemoCache: hu,
    useCacheRefresh: Qf
  }, Gp = {
    readContext: N,
    use: Us,
    useCallback: kf,
    useContext: N,
    useEffect: Tf,
    useImperativeHandle: jf,
    useInsertionEffect: Cf,
    useLayoutEffect: Nf,
    useMemo: Bf,
    useReducer: du,
    useRef: Rf,
    useState: function() {
      return du(fo);
    },
    useDebugValue: mu,
    useDeferredValue: function(t, e) {
      var a = De();
      return le === null ? bu(a, t, e) : Vf(
        a,
        le.memoizedState,
        t,
        e
      );
    },
    useTransition: function() {
      var t = du(fo)[0], e = De().memoizedState;
      return [
        typeof t == "boolean" ? t : xr(t),
        e
      ];
    },
    useSyncExternalStore: cf,
    useId: qf,
    useHostTransitionStatus: yu,
    useFormState: Ef,
    useActionState: Ef,
    useOptimistic: function(t, e) {
      var a = De();
      return le !== null ? gf(a, le, t, e) : (a.baseState = t, [t, a.queue.dispatch]);
    },
    useMemoCache: hu,
    useCacheRefresh: Qf
  }, vl = null, vr = 0;
  function Ys(t) {
    var e = vr;
    return vr += 1, vl === null && (vl = []), tf(vl, t, e);
  }
  function Mr(t, e) {
    e = e.props.ref, t.ref = e !== void 0 ? e : null;
  }
  function zs(t, e) {
    throw e.$$typeof === C ? Error(c(525)) : (t = Object.prototype.toString.call(e), Error(
      c(
        31,
        t === "[object Object]" ? "object with keys {" + Object.keys(e).join(", ") + "}" : t
      )
    ));
  }
  function Wf(t) {
    var e = t._init;
    return e(t._payload);
  }
  function Ff(t) {
    function e(U, T) {
      if (t) {
        var B = U.deletions;
        B === null ? (U.deletions = [T], U.flags |= 16) : B.push(T);
      }
    }
    function a(U, T) {
      if (!t) return null;
      for (; T !== null; )
        e(U, T), T = T.sibling;
      return null;
    }
    function n(U) {
      for (var T = /* @__PURE__ */ new Map(); U !== null; )
        U.key !== null ? T.set(U.key, U) : T.set(U.index, U), U = U.sibling;
      return T;
    }
    function o(U, T) {
      return U = Pa(U, T), U.index = 0, U.sibling = null, U;
    }
    function i(U, T, B) {
      return U.index = B, t ? (B = U.alternate, B !== null ? (B = B.index, B < T ? (U.flags |= 67108866, T) : B) : (U.flags |= 67108866, T)) : (U.flags |= 1048576, T);
    }
    function f(U) {
      return t && U.alternate === null && (U.flags |= 67108866), U;
    }
    function d(U, T, B, I) {
      return T === null || T.tag !== 6 ? (T = dl(B, U.mode, I), T.return = U, T) : (T = o(T, B), T.return = U, T);
    }
    function E(U, T, B, I) {
      var gt = B.type;
      return gt === L ? F(
        U,
        T,
        B.props.children,
        I,
        B.key
      ) : T !== null && (T.elementType === gt || typeof gt == "object" && gt !== null && gt.$$typeof === J && Wf(gt) === T.type) ? (T = o(T, B.props), Mr(T, B), T.return = U, T) : (T = fl(
        B.type,
        B.key,
        B.props,
        null,
        U.mode,
        I
      ), Mr(T, B), T.return = U, T);
    }
    function V(U, T, B, I) {
      return T === null || T.tag !== 4 || T.stateNode.containerInfo !== B.containerInfo || T.stateNode.implementation !== B.implementation ? (T = ir(B, U.mode, I), T.return = U, T) : (T = o(T, B.children || []), T.return = U, T);
    }
    function F(U, T, B, I, gt) {
      return T === null || T.tag !== 7 ? (T = ro(
        B,
        U.mode,
        I,
        gt
      ), T.return = U, T) : (T = o(T, B), T.return = U, T);
    }
    function X(U, T, B) {
      if (typeof T == "string" && T !== "" || typeof T == "number" || typeof T == "bigint")
        return T = dl(
          "" + T,
          U.mode,
          B
        ), T.return = U, T;
      if (typeof T == "object" && T !== null) {
        switch (T.$$typeof) {
          case k:
            return B = fl(
              T.type,
              T.key,
              T.props,
              null,
              U.mode,
              B
            ), Mr(B, T), B.return = U, B;
          case j:
            return T = ir(
              T,
              U.mode,
              B
            ), T.return = U, T;
          case J:
            var I = T._init;
            return T = I(T._payload), X(U, T, B);
        }
        if (Et(T) || Yt(T))
          return T = ro(
            T,
            U.mode,
            B,
            null
          ), T.return = U, T;
        if (typeof T.then == "function")
          return X(U, Ys(T), B);
        if (T.$$typeof === Y)
          return X(
            U,
            H(U, T),
            B
          );
        zs(U, T);
      }
      return null;
    }
    function D(U, T, B, I) {
      var gt = T !== null ? T.key : null;
      if (typeof B == "string" && B !== "" || typeof B == "number" || typeof B == "bigint")
        return gt !== null ? null : d(U, T, "" + B, I);
      if (typeof B == "object" && B !== null) {
        switch (B.$$typeof) {
          case k:
            return B.key === gt ? E(U, T, B, I) : null;
          case j:
            return B.key === gt ? V(U, T, B, I) : null;
          case J:
            return gt = B._init, B = gt(B._payload), D(U, T, B, I);
        }
        if (Et(B) || Yt(B))
          return gt !== null ? null : F(U, T, B, I, null);
        if (typeof B.then == "function")
          return D(
            U,
            T,
            Ys(B),
            I
          );
        if (B.$$typeof === Y)
          return D(
            U,
            T,
            H(U, B),
            I
          );
        zs(U, B);
      }
      return null;
    }
    function z(U, T, B, I, gt) {
      if (typeof I == "string" && I !== "" || typeof I == "number" || typeof I == "bigint")
        return U = U.get(B) || null, d(T, U, "" + I, gt);
      if (typeof I == "object" && I !== null) {
        switch (I.$$typeof) {
          case k:
            return U = U.get(
              I.key === null ? B : I.key
            ) || null, E(T, U, I, gt);
          case j:
            return U = U.get(
              I.key === null ? B : I.key
            ) || null, V(T, U, I, gt);
          case J:
            var Gt = I._init;
            return I = Gt(I._payload), z(
              U,
              T,
              B,
              I,
              gt
            );
        }
        if (Et(I) || Yt(I))
          return U = U.get(B) || null, F(T, U, I, gt, null);
        if (typeof I.then == "function")
          return z(
            U,
            T,
            B,
            Ys(I),
            gt
          );
        if (I.$$typeof === Y)
          return z(
            U,
            T,
            B,
            H(T, I),
            gt
          );
        zs(T, I);
      }
      return null;
    }
    function Dt(U, T, B, I) {
      for (var gt = null, Gt = null, At = T, jt = T = 0, Fe = null; At !== null && jt < B.length; jt++) {
        At.index > jt ? (Fe = At, At = null) : Fe = At.sibling;
        var ae = D(
          U,
          At,
          B[jt],
          I
        );
        if (ae === null) {
          At === null && (At = Fe);
          break;
        }
        t && At && ae.alternate === null && e(U, At), T = i(ae, T, jt), Gt === null ? gt = ae : Gt.sibling = ae, Gt = ae, At = Fe;
      }
      if (jt === B.length)
        return a(U, At), Ft && qo(U, jt), gt;
      if (At === null) {
        for (; jt < B.length; jt++)
          At = X(U, B[jt], I), At !== null && (T = i(
            At,
            T,
            jt
          ), Gt === null ? gt = At : Gt.sibling = At, Gt = At);
        return Ft && qo(U, jt), gt;
      }
      for (At = n(At); jt < B.length; jt++)
        Fe = z(
          At,
          U,
          jt,
          B[jt],
          I
        ), Fe !== null && (t && Fe.alternate !== null && At.delete(
          Fe.key === null ? jt : Fe.key
        ), T = i(
          Fe,
          T,
          jt
        ), Gt === null ? gt = Fe : Gt.sibling = Fe, Gt = Fe);
      return t && At.forEach(function(ii) {
        return e(U, ii);
      }), Ft && qo(U, jt), gt;
    }
    function St(U, T, B, I) {
      if (B == null) throw Error(c(151));
      for (var gt = null, Gt = null, At = T, jt = T = 0, Fe = null, ae = B.next(); At !== null && !ae.done; jt++, ae = B.next()) {
        At.index > jt ? (Fe = At, At = null) : Fe = At.sibling;
        var ii = D(U, At, ae.value, I);
        if (ii === null) {
          At === null && (At = Fe);
          break;
        }
        t && At && ii.alternate === null && e(U, At), T = i(ii, T, jt), Gt === null ? gt = ii : Gt.sibling = ii, Gt = ii, At = Fe;
      }
      if (ae.done)
        return a(U, At), Ft && qo(U, jt), gt;
      if (At === null) {
        for (; !ae.done; jt++, ae = B.next())
          ae = X(U, ae.value, I), ae !== null && (T = i(ae, T, jt), Gt === null ? gt = ae : Gt.sibling = ae, Gt = ae);
        return Ft && qo(U, jt), gt;
      }
      for (At = n(At); !ae.done; jt++, ae = B.next())
        ae = z(At, U, jt, ae.value, I), ae !== null && (t && ae.alternate !== null && At.delete(ae.key === null ? jt : ae.key), T = i(ae, T, jt), Gt === null ? gt = ae : Gt.sibling = ae, Gt = ae);
      return t && At.forEach(function(Ig) {
        return e(U, Ig);
      }), Ft && qo(U, jt), gt;
    }
    function se(U, T, B, I) {
      if (typeof B == "object" && B !== null && B.type === L && B.key === null && (B = B.props.children), typeof B == "object" && B !== null) {
        switch (B.$$typeof) {
          case k:
            t: {
              for (var gt = B.key; T !== null; ) {
                if (T.key === gt) {
                  if (gt = B.type, gt === L) {
                    if (T.tag === 7) {
                      a(
                        U,
                        T.sibling
                      ), I = o(
                        T,
                        B.props.children
                      ), I.return = U, U = I;
                      break t;
                    }
                  } else if (T.elementType === gt || typeof gt == "object" && gt !== null && gt.$$typeof === J && Wf(gt) === T.type) {
                    a(
                      U,
                      T.sibling
                    ), I = o(T, B.props), Mr(I, B), I.return = U, U = I;
                    break t;
                  }
                  a(U, T);
                  break;
                } else e(U, T);
                T = T.sibling;
              }
              B.type === L ? (I = ro(
                B.props.children,
                U.mode,
                I,
                B.key
              ), I.return = U, U = I) : (I = fl(
                B.type,
                B.key,
                B.props,
                null,
                U.mode,
                I
              ), Mr(I, B), I.return = U, U = I);
            }
            return f(U);
          case j:
            t: {
              for (gt = B.key; T !== null; ) {
                if (T.key === gt)
                  if (T.tag === 4 && T.stateNode.containerInfo === B.containerInfo && T.stateNode.implementation === B.implementation) {
                    a(
                      U,
                      T.sibling
                    ), I = o(T, B.children || []), I.return = U, U = I;
                    break t;
                  } else {
                    a(U, T);
                    break;
                  }
                else e(U, T);
                T = T.sibling;
              }
              I = ir(B, U.mode, I), I.return = U, U = I;
            }
            return f(U);
          case J:
            return gt = B._init, B = gt(B._payload), se(
              U,
              T,
              B,
              I
            );
        }
        if (Et(B))
          return Dt(
            U,
            T,
            B,
            I
          );
        if (Yt(B)) {
          if (gt = Yt(B), typeof gt != "function") throw Error(c(150));
          return B = gt.call(B), St(
            U,
            T,
            B,
            I
          );
        }
        if (typeof B.then == "function")
          return se(
            U,
            T,
            Ys(B),
            I
          );
        if (B.$$typeof === Y)
          return se(
            U,
            T,
            H(U, B),
            I
          );
        zs(U, B);
      }
      return typeof B == "string" && B !== "" || typeof B == "number" || typeof B == "bigint" ? (B = "" + B, T !== null && T.tag === 6 ? (a(U, T.sibling), I = o(T, B), I.return = U, U = I) : (a(U, T), I = dl(B, U.mode, I), I.return = U, U = I), f(U)) : a(U, T);
    }
    return function(U, T, B, I) {
      try {
        vr = 0;
        var gt = se(
          U,
          T,
          B,
          I
        );
        return vl = null, gt;
      } catch (At) {
        if (At === fr || At === Rs) throw At;
        var Gt = ma(29, At, null, U.mode);
        return Gt.lanes = I, Gt.return = U, Gt;
      }
    };
  }
  var Ml = Ff(!0), Gf = Ff(!1), $a = Q(null), Yn = null;
  function Zo(t) {
    var e = t.alternate;
    $(Le, Le.current & 1), $($a, t), Yn === null && (e === null || bl.current !== null || e.memoizedState !== null) && (Yn = t);
  }
  function If(t) {
    if (t.tag === 22) {
      if ($(Le, Le.current), $($a, t), Yn === null) {
        var e = t.alternate;
        e !== null && e.memoizedState !== null && (Yn = t);
      }
    } else Wo();
  }
  function Wo() {
    $(Le, Le.current), $($a, $a.current);
  }
  function po(t) {
    nt($a), Yn === t && (Yn = null), nt(Le);
  }
  var Le = Q(0);
  function qs(t) {
    for (var e = t; e !== null; ) {
      if (e.tag === 13) {
        var a = e.memoizedState;
        if (a !== null && (a = a.dehydrated, a === null || a.data === "$?" || uh(a)))
          return e;
      } else if (e.tag === 19 && e.memoizedProps.revealOrder !== void 0) {
        if ((e.flags & 128) !== 0) return e;
      } else if (e.child !== null) {
        e.child.return = e, e = e.child;
        continue;
      }
      if (e === t) break;
      for (; e.sibling === null; ) {
        if (e.return === null || e.return === t) return null;
        e = e.return;
      }
      e.sibling.return = e.return, e = e.sibling;
    }
    return null;
  }
  function vu(t, e, a, n) {
    e = t.memoizedState, a = a(n, e), a = a == null ? e : S({}, e, a), t.memoizedState = a, t.lanes === 0 && (t.updateQueue.baseState = a);
  }
  var Mu = {
    enqueueSetState: function(t, e, a) {
      t = t._reactInternals;
      var n = Oa(), o = Oo(n);
      o.payload = e, a != null && (o.callback = a), e = Ko(t, o, n), e !== null && (Ka(e, t, n), pr(e, t, n));
    },
    enqueueReplaceState: function(t, e, a) {
      t = t._reactInternals;
      var n = Oa(), o = Oo(n);
      o.tag = 1, o.payload = e, a != null && (o.callback = a), e = Ko(t, o, n), e !== null && (Ka(e, t, n), pr(e, t, n));
    },
    enqueueForceUpdate: function(t, e) {
      t = t._reactInternals;
      var a = Oa(), n = Oo(a);
      n.tag = 2, e != null && (n.callback = e), e = Ko(t, n, a), e !== null && (Ka(e, t, a), pr(e, t, a));
    }
  };
  function Xf(t, e, a, n, o, i, f) {
    return t = t.stateNode, typeof t.shouldComponentUpdate == "function" ? t.shouldComponentUpdate(n, i, f) : e.prototype && e.prototype.isPureReactComponent ? !Si(a, n) || !Si(o, i) : !0;
  }
  function Jf(t, e, a, n) {
    t = e.state, typeof e.componentWillReceiveProps == "function" && e.componentWillReceiveProps(a, n), typeof e.UNSAFE_componentWillReceiveProps == "function" && e.UNSAFE_componentWillReceiveProps(a, n), e.state !== t && Mu.enqueueReplaceState(e, e.state, null);
  }
  function Vi(t, e) {
    var a = e;
    if ("ref" in e) {
      a = {};
      for (var n in e)
        n !== "ref" && (a[n] = e[n]);
    }
    if (t = t.defaultProps) {
      a === e && (a = S({}, a));
      for (var o in t)
        a[o] === void 0 && (a[o] = t[o]);
    }
    return a;
  }
  var Qs = typeof reportError == "function" ? reportError : function(t) {
    if (typeof window == "object" && typeof window.ErrorEvent == "function") {
      var e = new window.ErrorEvent("error", {
        bubbles: !0,
        cancelable: !0,
        message: typeof t == "object" && t !== null && typeof t.message == "string" ? String(t.message) : String(t),
        error: t
      });
      if (!window.dispatchEvent(e)) return;
    } else if (typeof process == "object" && typeof process.emit == "function") {
      process.emit("uncaughtException", t);
      return;
    }
    console.error(t);
  };
  function Pf(t) {
    Qs(t);
  }
  function _f(t) {
    console.error(t);
  }
  function $f(t) {
    Qs(t);
  }
  function Ls(t, e) {
    try {
      var a = t.onUncaughtError;
      a(e.value, { componentStack: e.stack });
    } catch (n) {
      setTimeout(function() {
        throw n;
      });
    }
  }
  function td(t, e, a) {
    try {
      var n = t.onCaughtError;
      n(a.value, {
        componentStack: a.stack,
        errorBoundary: e.tag === 1 ? e.stateNode : null
      });
    } catch (o) {
      setTimeout(function() {
        throw o;
      });
    }
  }
  function wu(t, e, a) {
    return a = Oo(a), a.tag = 3, a.payload = { element: null }, a.callback = function() {
      Ls(t, e);
    }, a;
  }
  function ed(t) {
    return t = Oo(t), t.tag = 3, t;
  }
  function ad(t, e, a, n) {
    var o = a.type.getDerivedStateFromError;
    if (typeof o == "function") {
      var i = n.value;
      t.payload = function() {
        return o(i);
      }, t.callback = function() {
        td(e, a, n);
      };
    }
    var f = a.stateNode;
    f !== null && typeof f.componentDidCatch == "function" && (t.callback = function() {
      td(e, a, n), typeof o != "function" && (Po === null ? Po = /* @__PURE__ */ new Set([this]) : Po.add(this));
      var d = n.stack;
      this.componentDidCatch(n.value, {
        componentStack: d !== null ? d : ""
      });
    });
  }
  function Ip(t, e, a, n, o) {
    if (a.flags |= 32768, n !== null && typeof n == "object" && typeof n.then == "function") {
      if (e = a.alternate, e !== null && p(
        e,
        a,
        o,
        !0
      ), a = $a.current, a !== null) {
        switch (a.tag) {
          case 13:
            return Yn === null ? Gu() : a.alternate === null && Re === 0 && (Re = 3), a.flags &= -257, a.flags |= 65536, a.lanes = o, n === _c ? a.flags |= 16384 : (e = a.updateQueue, e === null ? a.updateQueue = /* @__PURE__ */ new Set([n]) : e.add(n), Xu(t, n, o)), !1;
          case 22:
            return a.flags |= 65536, n === _c ? a.flags |= 16384 : (e = a.updateQueue, e === null ? (e = {
              transitions: null,
              markerInstances: null,
              retryQueue: /* @__PURE__ */ new Set([n])
            }, a.updateQueue = e) : (a = e.retryQueue, a === null ? e.retryQueue = /* @__PURE__ */ new Set([n]) : a.add(n)), Xu(t, n, o)), !1;
        }
        throw Error(c(435, a.tag));
      }
      return Xu(t, n, o), Gu(), !1;
    }
    if (Ft)
      return e = $a.current, e !== null ? ((e.flags & 65536) === 0 && (e.flags |= 256), e.flags |= 65536, e.lanes = o, n !== rr && (t = Error(c(422), { cause: n }), ji(ga(t, a)))) : (n !== rr && (e = Error(c(423), {
        cause: n
      }), ji(
        ga(e, a)
      )), t = t.current.alternate, t.flags |= 65536, o &= -o, t.lanes |= o, n = ga(n, a), o = wu(
        t.stateNode,
        n,
        o
      ), eu(t, o), Re !== 4 && (Re = 2)), !1;
    var i = Error(c(520), { cause: n });
    if (i = ga(i, a), Nr === null ? Nr = [i] : Nr.push(i), Re !== 4 && (Re = 2), e === null) return !0;
    n = ga(n, a), a = e;
    do {
      switch (a.tag) {
        case 3:
          return a.flags |= 65536, t = o & -o, a.lanes |= t, t = wu(a.stateNode, n, t), eu(a, t), !1;
        case 1:
          if (e = a.type, i = a.stateNode, (a.flags & 128) === 0 && (typeof e.getDerivedStateFromError == "function" || i !== null && typeof i.componentDidCatch == "function" && (Po === null || !Po.has(i))))
            return a.flags |= 65536, o &= -o, a.lanes |= o, o = ed(o), ad(
              o,
              t,
              a,
              n
            ), eu(a, o), !1;
      }
      a = a.return;
    } while (a !== null);
    return !1;
  }
  var nd = Error(c(461)), Ze = !1;
  function Pe(t, e, a, n) {
    e.child = t === null ? Gf(e, null, a, n) : Ml(
      e,
      t.child,
      a,
      n
    );
  }
  function od(t, e, a, n, o) {
    a = a.render;
    var i = e.ref;
    if ("ref" in n) {
      var f = {};
      for (var d in n)
        d !== "ref" && (f[d] = n[d]);
    } else f = n;
    return w(e), n = lu(
      t,
      e,
      a,
      f,
      i,
      o
    ), d = ru(), t !== null && !Ze ? (su(t, e, o), go(t, e, o)) : (Ft && d && pl(e), e.flags |= 1, Pe(t, e, n, o), e.child);
  }
  function id(t, e, a, n, o) {
    if (t === null) {
      var i = a.type;
      return typeof i == "function" && !or(i) && i.defaultProps === void 0 && a.compare === null ? (e.tag = 15, e.type = i, ld(
        t,
        e,
        i,
        n,
        o
      )) : (t = fl(
        a.type,
        null,
        n,
        e,
        e.mode,
        o
      ), t.ref = e.ref, t.return = e, e.child = t);
    }
    if (i = t.child, !ju(t, o)) {
      var f = i.memoizedProps;
      if (a = a.compare, a = a !== null ? a : Si, a(f, n) && t.ref === e.ref)
        return go(t, e, o);
    }
    return e.flags |= 1, t = Pa(i, n), t.ref = e.ref, t.return = e, e.child = t;
  }
  function ld(t, e, a, n, o) {
    if (t !== null) {
      var i = t.memoizedProps;
      if (Si(i, n) && t.ref === e.ref)
        if (Ze = !1, e.pendingProps = n = i, ju(t, o))
          (t.flags & 131072) !== 0 && (Ze = !0);
        else
          return e.lanes = t.lanes, go(t, e, o);
    }
    return Eu(
      t,
      e,
      a,
      n,
      o
    );
  }
  function rd(t, e, a) {
    var n = e.pendingProps, o = n.children, i = t !== null ? t.memoizedState : null;
    if (n.mode === "hidden") {
      if ((e.flags & 128) !== 0) {
        if (n = i !== null ? i.baseLanes | a : a, t !== null) {
          for (o = e.child = t.child, i = 0; o !== null; )
            i = i | o.lanes | o.childLanes, o = o.sibling;
          e.childLanes = i & ~n;
        } else e.childLanes = 0, e.child = null;
        return sd(
          t,
          e,
          n,
          a
        );
      }
      if ((a & 536870912) !== 0)
        e.memoizedState = { baseLanes: 0, cachePool: null }, t !== null && Es(
          e,
          i !== null ? i.cachePool : null
        ), i !== null ? lf(e, i) : nu(), If(e);
      else
        return e.lanes = e.childLanes = 536870912, sd(
          t,
          e,
          i !== null ? i.baseLanes | a : a,
          a
        );
    } else
      i !== null ? (Es(e, i.cachePool), lf(e, i), Wo(), e.memoizedState = null) : (t !== null && Es(e, null), nu(), Wo());
    return Pe(t, e, o, a), e.child;
  }
  function sd(t, e, a, n) {
    var o = Pc();
    return o = o === null ? null : { parent: Bt._currentValue, pool: o }, e.memoizedState = {
      baseLanes: a,
      cachePool: o
    }, t !== null && Es(e, null), nu(), If(e), t !== null && p(t, e, n, !0), null;
  }
  function Os(t, e) {
    var a = e.ref;
    if (a === null)
      t !== null && t.ref !== null && (e.flags |= 4194816);
    else {
      if (typeof a != "function" && typeof a != "object")
        throw Error(c(284));
      (t === null || t.ref !== a) && (e.flags |= 4194816);
    }
  }
  function Eu(t, e, a, n, o) {
    return w(e), a = lu(
      t,
      e,
      a,
      n,
      void 0,
      o
    ), n = ru(), t !== null && !Ze ? (su(t, e, o), go(t, e, o)) : (Ft && n && pl(e), e.flags |= 1, Pe(t, e, a, o), e.child);
  }
  function cd(t, e, a, n, o, i) {
    return w(e), e.updateQueue = null, a = sf(
      e,
      n,
      a,
      o
    ), rf(t), n = ru(), t !== null && !Ze ? (su(t, e, i), go(t, e, i)) : (Ft && n && pl(e), e.flags |= 1, Pe(t, e, a, i), e.child);
  }
  function ud(t, e, a, n, o) {
    if (w(e), e.stateNode === null) {
      var i = Do, f = a.contextType;
      typeof f == "object" && f !== null && (i = N(f)), i = new a(n, i), e.memoizedState = i.state !== null && i.state !== void 0 ? i.state : null, i.updater = Mu, e.stateNode = i, i._reactInternals = e, i = e.stateNode, i.props = n, i.state = e.memoizedState, i.refs = {}, $c(e), f = a.contextType, i.context = typeof f == "object" && f !== null ? N(f) : Do, i.state = e.memoizedState, f = a.getDerivedStateFromProps, typeof f == "function" && (vu(
        e,
        a,
        f,
        n
      ), i.state = e.memoizedState), typeof a.getDerivedStateFromProps == "function" || typeof i.getSnapshotBeforeUpdate == "function" || typeof i.UNSAFE_componentWillMount != "function" && typeof i.componentWillMount != "function" || (f = i.state, typeof i.componentWillMount == "function" && i.componentWillMount(), typeof i.UNSAFE_componentWillMount == "function" && i.UNSAFE_componentWillMount(), f !== i.state && Mu.enqueueReplaceState(i, i.state, null), mr(e, n, i, o), gr(), i.state = e.memoizedState), typeof i.componentDidMount == "function" && (e.flags |= 4194308), n = !0;
    } else if (t === null) {
      i = e.stateNode;
      var d = e.memoizedProps, E = Vi(a, d);
      i.props = E;
      var V = i.context, F = a.contextType;
      f = Do, typeof F == "object" && F !== null && (f = N(F));
      var X = a.getDerivedStateFromProps;
      F = typeof X == "function" || typeof i.getSnapshotBeforeUpdate == "function", d = e.pendingProps !== d, F || typeof i.UNSAFE_componentWillReceiveProps != "function" && typeof i.componentWillReceiveProps != "function" || (d || V !== f) && Jf(
        e,
        i,
        n,
        f
      ), Lo = !1;
      var D = e.memoizedState;
      i.state = D, mr(e, n, i, o), gr(), V = e.memoizedState, d || D !== V || Lo ? (typeof X == "function" && (vu(
        e,
        a,
        X,
        n
      ), V = e.memoizedState), (E = Lo || Xf(
        e,
        a,
        E,
        n,
        D,
        V,
        f
      )) ? (F || typeof i.UNSAFE_componentWillMount != "function" && typeof i.componentWillMount != "function" || (typeof i.componentWillMount == "function" && i.componentWillMount(), typeof i.UNSAFE_componentWillMount == "function" && i.UNSAFE_componentWillMount()), typeof i.componentDidMount == "function" && (e.flags |= 4194308)) : (typeof i.componentDidMount == "function" && (e.flags |= 4194308), e.memoizedProps = n, e.memoizedState = V), i.props = n, i.state = V, i.context = f, n = E) : (typeof i.componentDidMount == "function" && (e.flags |= 4194308), n = !1);
    } else {
      i = e.stateNode, tu(t, e), f = e.memoizedProps, F = Vi(a, f), i.props = F, X = e.pendingProps, D = i.context, V = a.contextType, E = Do, typeof V == "object" && V !== null && (E = N(V)), d = a.getDerivedStateFromProps, (V = typeof d == "function" || typeof i.getSnapshotBeforeUpdate == "function") || typeof i.UNSAFE_componentWillReceiveProps != "function" && typeof i.componentWillReceiveProps != "function" || (f !== X || D !== E) && Jf(
        e,
        i,
        n,
        E
      ), Lo = !1, D = e.memoizedState, i.state = D, mr(e, n, i, o), gr();
      var z = e.memoizedState;
      f !== X || D !== z || Lo || t !== null && t.dependencies !== null && x(t.dependencies) ? (typeof d == "function" && (vu(
        e,
        a,
        d,
        n
      ), z = e.memoizedState), (F = Lo || Xf(
        e,
        a,
        F,
        n,
        D,
        z,
        E
      ) || t !== null && t.dependencies !== null && x(t.dependencies)) ? (V || typeof i.UNSAFE_componentWillUpdate != "function" && typeof i.componentWillUpdate != "function" || (typeof i.componentWillUpdate == "function" && i.componentWillUpdate(n, z, E), typeof i.UNSAFE_componentWillUpdate == "function" && i.UNSAFE_componentWillUpdate(
        n,
        z,
        E
      )), typeof i.componentDidUpdate == "function" && (e.flags |= 4), typeof i.getSnapshotBeforeUpdate == "function" && (e.flags |= 1024)) : (typeof i.componentDidUpdate != "function" || f === t.memoizedProps && D === t.memoizedState || (e.flags |= 4), typeof i.getSnapshotBeforeUpdate != "function" || f === t.memoizedProps && D === t.memoizedState || (e.flags |= 1024), e.memoizedProps = n, e.memoizedState = z), i.props = n, i.state = z, i.context = E, n = F) : (typeof i.componentDidUpdate != "function" || f === t.memoizedProps && D === t.memoizedState || (e.flags |= 4), typeof i.getSnapshotBeforeUpdate != "function" || f === t.memoizedProps && D === t.memoizedState || (e.flags |= 1024), n = !1);
    }
    return i = n, Os(t, e), n = (e.flags & 128) !== 0, i || n ? (i = e.stateNode, a = n && typeof a.getDerivedStateFromError != "function" ? null : i.render(), e.flags |= 1, t !== null && n ? (e.child = Ml(
      e,
      t.child,
      null,
      o
    ), e.child = Ml(
      e,
      null,
      a,
      o
    )) : Pe(t, e, a, o), e.memoizedState = i.state, t = e.child) : t = go(
      t,
      e,
      o
    ), t;
  }
  function hd(t, e, a, n) {
    return Ui(), e.flags |= 256, Pe(t, e, a, n), e.child;
  }
  var Ru = {
    dehydrated: null,
    treeContext: null,
    retryLane: 0,
    hydrationErrors: null
  };
  function Su(t) {
    return { baseLanes: t, cachePool: Ph() };
  }
  function Tu(t, e, a) {
    return t = t !== null ? t.childLanes & ~a : 0, e && (t |= tn), t;
  }
  function fd(t, e, a) {
    var n = e.pendingProps, o = !1, i = (e.flags & 128) !== 0, f;
    if ((f = i) || (f = t !== null && t.memoizedState === null ? !1 : (Le.current & 2) !== 0), f && (o = !0, e.flags &= -129), f = (e.flags & 32) !== 0, e.flags &= -33, t === null) {
      if (Ft) {
        if (o ? Zo(e) : Wo(), Ft) {
          var d = pt, E;
          if (E = d) {
            t: {
              for (E = d, d = _a; E.nodeType !== 8; ) {
                if (!d) {
                  d = null;
                  break t;
                }
                if (E = gn(
                  E.nextSibling
                ), E === null) {
                  d = null;
                  break t;
                }
              }
              d = E;
            }
            d !== null ? (e.memoizedState = {
              dehydrated: d,
              treeContext: so !== null ? { id: fn, overflow: G } : null,
              retryLane: 536870912,
              hydrationErrors: null
            }, E = ma(
              18,
              null,
              null,
              0
            ), E.stateNode = d, E.return = e, e.child = E, Je = e, pt = null, E = !0) : E = !1;
          }
          E || co(e);
        }
        if (d = e.memoizedState, d !== null && (d = d.dehydrated, d !== null))
          return uh(d) ? e.lanes = 32 : e.lanes = 536870912, null;
        po(e);
      }
      return d = n.children, n = n.fallback, o ? (Wo(), o = e.mode, d = Ks(
        { mode: "hidden", children: d },
        o
      ), n = ro(
        n,
        o,
        a,
        null
      ), d.return = e, n.return = e, d.sibling = n, e.child = d, o = e.child, o.memoizedState = Su(a), o.childLanes = Tu(
        t,
        f,
        a
      ), e.memoizedState = Ru, n) : (Zo(e), Cu(e, d));
    }
    if (E = t.memoizedState, E !== null && (d = E.dehydrated, d !== null)) {
      if (i)
        e.flags & 256 ? (Zo(e), e.flags &= -257, e = Nu(
          t,
          e,
          a
        )) : e.memoizedState !== null ? (Wo(), e.child = t.child, e.flags |= 128, e = null) : (Wo(), o = n.fallback, d = e.mode, n = Ks(
          { mode: "visible", children: n.children },
          d
        ), o = ro(
          o,
          d,
          a,
          null
        ), o.flags |= 2, n.return = e, o.return = e, n.sibling = o, e.child = n, Ml(
          e,
          t.child,
          null,
          a
        ), n = e.child, n.memoizedState = Su(a), n.childLanes = Tu(
          t,
          f,
          a
        ), e.memoizedState = Ru, e = o);
      else if (Zo(e), uh(d)) {
        if (f = d.nextSibling && d.nextSibling.dataset, f) var V = f.dgst;
        f = V, n = Error(c(419)), n.stack = "", n.digest = f, ji({ value: n, source: null, stack: null }), e = Nu(
          t,
          e,
          a
        );
      } else if (Ze || p(t, e, a, !1), f = (a & t.childLanes) !== 0, Ze || f) {
        if (f = fe, f !== null && (n = a & -a, n = (n & 42) !== 0 ? 1 : ce(n), n = (n & (f.suspendedLanes | a)) !== 0 ? 0 : n, n !== 0 && n !== E.retryLane))
          throw E.retryLane = n, Vo(t, n), Ka(f, t, n), nd;
        d.data === "$?" || Gu(), e = Nu(
          t,
          e,
          a
        );
      } else
        d.data === "$?" ? (e.flags |= 192, e.child = t.child, e = null) : (t = E.treeContext, pt = gn(
          d.nextSibling
        ), Je = e, Ft = !0, Bn = null, _a = !1, t !== null && (Sa[Ta++] = fn, Sa[Ta++] = G, Sa[Ta++] = so, fn = t.id, G = t.overflow, so = e), e = Cu(
          e,
          n.children
        ), e.flags |= 4096);
      return e;
    }
    return o ? (Wo(), o = n.fallback, d = e.mode, E = t.child, V = E.sibling, n = Pa(E, {
      mode: "hidden",
      children: n.children
    }), n.subtreeFlags = E.subtreeFlags & 65011712, V !== null ? o = Pa(V, o) : (o = ro(
      o,
      d,
      a,
      null
    ), o.flags |= 2), o.return = e, n.return = e, n.sibling = o, e.child = n, n = o, o = e.child, d = t.child.memoizedState, d === null ? d = Su(a) : (E = d.cachePool, E !== null ? (V = Bt._currentValue, E = E.parent !== V ? { parent: V, pool: V } : E) : E = Ph(), d = {
      baseLanes: d.baseLanes | a,
      cachePool: E
    }), o.memoizedState = d, o.childLanes = Tu(
      t,
      f,
      a
    ), e.memoizedState = Ru, n) : (Zo(e), a = t.child, t = a.sibling, a = Pa(a, {
      mode: "visible",
      children: n.children
    }), a.return = e, a.sibling = null, t !== null && (f = e.deletions, f === null ? (e.deletions = [t], e.flags |= 16) : f.push(t)), e.child = a, e.memoizedState = null, a);
  }
  function Cu(t, e) {
    return e = Ks(
      { mode: "visible", children: e },
      t.mode
    ), e.return = t, t.child = e;
  }
  function Ks(t, e) {
    return t = ma(22, t, null, e), t.lanes = 0, t.stateNode = {
      _visibility: 1,
      _pendingMarkers: null,
      _retryCache: null,
      _transitions: null
    }, t;
  }
  function Nu(t, e, a) {
    return Ml(e, t.child, null, a), t = Cu(
      e,
      e.pendingProps.children
    ), t.flags |= 2, e.memoizedState = null, t;
  }
  function dd(t, e, a) {
    t.lanes |= e;
    var n = t.alternate;
    n !== null && (n.lanes |= e), ur(t.return, e, a);
  }
  function Uu(t, e, a, n, o) {
    var i = t.memoizedState;
    i === null ? t.memoizedState = {
      isBackwards: e,
      rendering: null,
      renderingStartTime: 0,
      last: n,
      tail: a,
      tailMode: o
    } : (i.isBackwards = e, i.rendering = null, i.renderingStartTime = 0, i.last = n, i.tail = a, i.tailMode = o);
  }
  function pd(t, e, a) {
    var n = e.pendingProps, o = n.revealOrder, i = n.tail;
    if (Pe(t, e, n.children, a), n = Le.current, (n & 2) !== 0)
      n = n & 1 | 2, e.flags |= 128;
    else {
      if (t !== null && (t.flags & 128) !== 0)
        t: for (t = e.child; t !== null; ) {
          if (t.tag === 13)
            t.memoizedState !== null && dd(t, a, e);
          else if (t.tag === 19)
            dd(t, a, e);
          else if (t.child !== null) {
            t.child.return = t, t = t.child;
            continue;
          }
          if (t === e) break t;
          for (; t.sibling === null; ) {
            if (t.return === null || t.return === e)
              break t;
            t = t.return;
          }
          t.sibling.return = t.return, t = t.sibling;
        }
      n &= 1;
    }
    switch ($(Le, n), o) {
      case "forwards":
        for (a = e.child, o = null; a !== null; )
          t = a.alternate, t !== null && qs(t) === null && (o = a), a = a.sibling;
        a = o, a === null ? (o = e.child, e.child = null) : (o = a.sibling, a.sibling = null), Uu(
          e,
          !1,
          o,
          a,
          i
        );
        break;
      case "backwards":
        for (a = null, o = e.child, e.child = null; o !== null; ) {
          if (t = o.alternate, t !== null && qs(t) === null) {
            e.child = o;
            break;
          }
          t = o.sibling, o.sibling = a, a = o, o = t;
        }
        Uu(
          e,
          !0,
          a,
          null,
          i
        );
        break;
      case "together":
        Uu(e, !1, null, null, void 0);
        break;
      default:
        e.memoizedState = null;
    }
    return e.child;
  }
  function go(t, e, a) {
    if (t !== null && (e.dependencies = t.dependencies), Jo |= e.lanes, (a & e.childLanes) === 0)
      if (t !== null) {
        if (p(
          t,
          e,
          a,
          !1
        ), (a & e.childLanes) === 0)
          return null;
      } else return null;
    if (t !== null && e.child !== t.child)
      throw Error(c(153));
    if (e.child !== null) {
      for (t = e.child, a = Pa(t, t.pendingProps), e.child = a, a.return = e; t.sibling !== null; )
        t = t.sibling, a = a.sibling = Pa(t, t.pendingProps), a.return = e;
      a.sibling = null;
    }
    return e.child;
  }
  function ju(t, e) {
    return (t.lanes & e) !== 0 ? !0 : (t = t.dependencies, !!(t !== null && x(t)));
  }
  function Xp(t, e, a) {
    switch (e.tag) {
      case 3:
        ne(e, e.stateNode.containerInfo), Vn(e, Bt, t.memoizedState.cache), Ui();
        break;
      case 27:
      case 5:
        mn(e);
        break;
      case 4:
        ne(e, e.stateNode.containerInfo);
        break;
      case 10:
        Vn(
          e,
          e.type,
          e.memoizedProps.value
        );
        break;
      case 13:
        var n = e.memoizedState;
        if (n !== null)
          return n.dehydrated !== null ? (Zo(e), e.flags |= 128, null) : (a & e.child.childLanes) !== 0 ? fd(t, e, a) : (Zo(e), t = go(
            t,
            e,
            a
          ), t !== null ? t.sibling : null);
        Zo(e);
        break;
      case 19:
        var o = (t.flags & 128) !== 0;
        if (n = (a & e.childLanes) !== 0, n || (p(
          t,
          e,
          a,
          !1
        ), n = (a & e.childLanes) !== 0), o) {
          if (n)
            return pd(
              t,
              e,
              a
            );
          e.flags |= 128;
        }
        if (o = e.memoizedState, o !== null && (o.rendering = null, o.tail = null, o.lastEffect = null), $(Le, Le.current), n) break;
        return null;
      case 22:
      case 23:
        return e.lanes = 0, rd(t, e, a);
      case 24:
        Vn(e, Bt, t.memoizedState.cache);
    }
    return go(t, e, a);
  }
  function gd(t, e, a) {
    if (t !== null)
      if (t.memoizedProps !== e.pendingProps)
        Ze = !0;
      else {
        if (!ju(t, a) && (e.flags & 128) === 0)
          return Ze = !1, Xp(
            t,
            e,
            a
          );
        Ze = (t.flags & 131072) !== 0;
      }
    else
      Ze = !1, Ft && (e.flags & 1048576) !== 0 && Qo(e, kn, e.index);
    switch (e.lanes = 0, e.tag) {
      case 16:
        t: {
          t = e.pendingProps;
          var n = e.elementType, o = n._init;
          if (n = o(n._payload), e.type = n, typeof n == "function")
            or(n) ? (t = Vi(n, t), e.tag = 1, e = ud(
              null,
              e,
              n,
              t,
              a
            )) : (e.tag = 0, e = Eu(
              null,
              e,
              n,
              t,
              a
            ));
          else {
            if (n != null) {
              if (o = n.$$typeof, o === W) {
                e.tag = 11, e = od(
                  null,
                  e,
                  n,
                  t,
                  a
                );
                break t;
              } else if (o === Mt) {
                e.tag = 14, e = id(
                  null,
                  e,
                  n,
                  t,
                  a
                );
                break t;
              }
            }
            throw e = Lt(n) || n, Error(c(306, e, ""));
          }
        }
        return e;
      case 0:
        return Eu(
          t,
          e,
          e.type,
          e.pendingProps,
          a
        );
      case 1:
        return n = e.type, o = Vi(
          n,
          e.pendingProps
        ), ud(
          t,
          e,
          n,
          o,
          a
        );
      case 3:
        t: {
          if (ne(
            e,
            e.stateNode.containerInfo
          ), t === null) throw Error(c(387));
          n = e.pendingProps;
          var i = e.memoizedState;
          o = i.element, tu(t, e), mr(e, n, null, a);
          var f = e.memoizedState;
          if (n = f.cache, Vn(e, Bt, n), n !== i.cache && l(
            e,
            [Bt],
            a,
            !0
          ), gr(), n = f.element, i.isDehydrated)
            if (i = {
              element: n,
              isDehydrated: !1,
              cache: f.cache
            }, e.updateQueue.baseState = i, e.memoizedState = i, e.flags & 256) {
              e = hd(
                t,
                e,
                n,
                a
              );
              break t;
            } else if (n !== o) {
              o = ga(
                Error(c(424)),
                e
              ), ji(o), e = hd(
                t,
                e,
                n,
                a
              );
              break t;
            } else
              for (t = e.stateNode.containerInfo, t.nodeType === 9 ? t = t.body : t = t.nodeName === "HTML" ? t.ownerDocument.body : t, pt = gn(t.firstChild), Je = e, Ft = !0, Bn = null, _a = !0, a = Gf(
                e,
                null,
                n,
                a
              ), e.child = a; a; )
                a.flags = a.flags & -3 | 4096, a = a.sibling;
          else {
            if (Ui(), n === o) {
              e = go(
                t,
                e,
                a
              );
              break t;
            }
            Pe(
              t,
              e,
              n,
              a
            );
          }
          e = e.child;
        }
        return e;
      case 26:
        return Os(t, e), t === null ? (a = y0(
          e.type,
          null,
          e.pendingProps,
          null
        )) ? e.memoizedState = a : Ft || (a = e.type, t = e.pendingProps, n = ac(
          Nt.current
        ).createElement(a), n[Rt] = e, n[dt] = t, $e(n, a, t), xe(n), e.stateNode = n) : e.memoizedState = y0(
          e.type,
          t.memoizedProps,
          e.pendingProps,
          t.memoizedState
        ), null;
      case 27:
        return mn(e), t === null && Ft && (n = e.stateNode = m0(
          e.type,
          e.pendingProps,
          Nt.current
        ), Je = e, _a = !0, o = pt, ti(e.type) ? (hh = o, pt = gn(
          n.firstChild
        )) : pt = o), Pe(
          t,
          e,
          e.pendingProps.children,
          a
        ), Os(t, e), t === null && (e.flags |= 4194304), e.child;
      case 5:
        return t === null && Ft && ((o = n = pt) && (n = wg(
          n,
          e.type,
          e.pendingProps,
          _a
        ), n !== null ? (e.stateNode = n, Je = e, pt = gn(
          n.firstChild
        ), _a = !1, o = !0) : o = !1), o || co(e)), mn(e), o = e.type, i = e.pendingProps, f = t !== null ? t.memoizedProps : null, n = i.children, rh(o, i) ? n = null : f !== null && rh(o, f) && (e.flags |= 32), e.memoizedState !== null && (o = lu(
          t,
          e,
          Op,
          null,
          null,
          a
        ), qr._currentValue = o), Os(t, e), Pe(t, e, n, a), e.child;
      case 6:
        return t === null && Ft && ((t = a = pt) && (a = Eg(
          a,
          e.pendingProps,
          _a
        ), a !== null ? (e.stateNode = a, Je = e, pt = null, t = !0) : t = !1), t || co(e)), null;
      case 13:
        return fd(t, e, a);
      case 4:
        return ne(
          e,
          e.stateNode.containerInfo
        ), n = e.pendingProps, t === null ? e.child = Ml(
          e,
          null,
          n,
          a
        ) : Pe(
          t,
          e,
          n,
          a
        ), e.child;
      case 11:
        return od(
          t,
          e,
          e.type,
          e.pendingProps,
          a
        );
      case 7:
        return Pe(
          t,
          e,
          e.pendingProps,
          a
        ), e.child;
      case 8:
        return Pe(
          t,
          e,
          e.pendingProps.children,
          a
        ), e.child;
      case 12:
        return Pe(
          t,
          e,
          e.pendingProps.children,
          a
        ), e.child;
      case 10:
        return n = e.pendingProps, Vn(e, e.type, n.value), Pe(
          t,
          e,
          n.children,
          a
        ), e.child;
      case 9:
        return o = e.type._context, n = e.pendingProps.children, w(e), o = N(o), n = n(o), e.flags |= 1, Pe(t, e, n, a), e.child;
      case 14:
        return id(
          t,
          e,
          e.type,
          e.pendingProps,
          a
        );
      case 15:
        return ld(
          t,
          e,
          e.type,
          e.pendingProps,
          a
        );
      case 19:
        return pd(t, e, a);
      case 31:
        return n = e.pendingProps, a = e.mode, n = {
          mode: n.mode,
          children: n.children
        }, t === null ? (a = Ks(
          n,
          a
        ), a.ref = e.ref, e.child = a, a.return = e, e = a) : (a = Pa(t.child, n), a.ref = e.ref, e.child = a, a.return = e, e = a), e;
      case 22:
        return rd(t, e, a);
      case 24:
        return w(e), n = N(Bt), t === null ? (o = Pc(), o === null && (o = fe, i = ee(), o.pooledCache = i, i.refCount++, i !== null && (o.pooledCacheLanes |= a), o = i), e.memoizedState = {
          parent: n,
          cache: o
        }, $c(e), Vn(e, Bt, o)) : ((t.lanes & a) !== 0 && (tu(t, e), mr(e, null, null, a), gr()), o = t.memoizedState, i = e.memoizedState, o.parent !== n ? (o = { parent: n, cache: n }, e.memoizedState = o, e.lanes === 0 && (e.memoizedState = e.updateQueue.baseState = o), Vn(e, Bt, n)) : (n = i.cache, Vn(e, Bt, n), n !== o.cache && l(
          e,
          [Bt],
          a,
          !0
        ))), Pe(
          t,
          e,
          e.pendingProps.children,
          a
        ), e.child;
      case 29:
        throw e.pendingProps;
    }
    throw Error(c(156, e.tag));
  }
  function mo(t) {
    t.flags |= 4;
  }
  function md(t, e) {
    if (e.type !== "stylesheet" || (e.state.loading & 4) !== 0)
      t.flags &= -16777217;
    else if (t.flags |= 16777216, !E0(e)) {
      if (e = $a.current, e !== null && ((te & 4194048) === te ? Yn !== null : (te & 62914560) !== te && (te & 536870912) === 0 || e !== Yn))
        throw dr = _c, _h;
      t.flags |= 8192;
    }
  }
  function Hs(t, e) {
    e !== null && (t.flags |= 4), t.flags & 16384 && (e = t.tag !== 22 ? Ge() : 536870912, t.lanes |= e, Sl |= e);
  }
  function wr(t, e) {
    if (!Ft)
      switch (t.tailMode) {
        case "hidden":
          e = t.tail;
          for (var a = null; e !== null; )
            e.alternate !== null && (a = e), e = e.sibling;
          a === null ? t.tail = null : a.sibling = null;
          break;
        case "collapsed":
          a = t.tail;
          for (var n = null; a !== null; )
            a.alternate !== null && (n = a), a = a.sibling;
          n === null ? e || t.tail === null ? t.tail = null : t.tail.sibling = null : n.sibling = null;
      }
  }
  function Me(t) {
    var e = t.alternate !== null && t.alternate.child === t.child, a = 0, n = 0;
    if (e)
      for (var o = t.child; o !== null; )
        a |= o.lanes | o.childLanes, n |= o.subtreeFlags & 65011712, n |= o.flags & 65011712, o.return = t, o = o.sibling;
    else
      for (o = t.child; o !== null; )
        a |= o.lanes | o.childLanes, n |= o.subtreeFlags, n |= o.flags, o.return = t, o = o.sibling;
    return t.subtreeFlags |= n, t.childLanes = a, e;
  }
  function Jp(t, e, a) {
    var n = e.pendingProps;
    switch (lr(e), e.tag) {
      case 31:
      case 16:
      case 15:
      case 0:
      case 11:
      case 7:
      case 8:
      case 12:
      case 9:
      case 14:
        return Me(e), null;
      case 1:
        return Me(e), null;
      case 3:
        return a = e.stateNode, n = null, t !== null && (n = t.memoizedState.cache), e.memoizedState.cache !== n && (e.flags |= 2048), ra(Bt), ct(), a.pendingContext && (a.context = a.pendingContext, a.pendingContext = null), (t === null || t.child === null) && (Ni(e) ? mo(e) : t === null || t.memoizedState.isDehydrated && (e.flags & 256) === 0 || (e.flags |= 1024, ws())), Me(e), null;
      case 26:
        return a = e.memoizedState, t === null ? (mo(e), a !== null ? (Me(e), md(e, a)) : (Me(e), e.flags &= -16777217)) : a ? a !== t.memoizedState ? (mo(e), Me(e), md(e, a)) : (Me(e), e.flags &= -16777217) : (t.memoizedProps !== n && mo(e), Me(e), e.flags &= -16777217), null;
      case 27:
        an(e), a = Nt.current;
        var o = e.type;
        if (t !== null && e.stateNode != null)
          t.memoizedProps !== n && mo(e);
        else {
          if (!n) {
            if (e.stateNode === null)
              throw Error(c(166));
            return Me(e), null;
          }
          t = ft.current, Ni(e) ? Ms(e) : (t = m0(o, n, a), e.stateNode = t, mo(e));
        }
        return Me(e), null;
      case 5:
        if (an(e), a = e.type, t !== null && e.stateNode != null)
          t.memoizedProps !== n && mo(e);
        else {
          if (!n) {
            if (e.stateNode === null)
              throw Error(c(166));
            return Me(e), null;
          }
          if (t = ft.current, Ni(e))
            Ms(e);
          else {
            switch (o = ac(
              Nt.current
            ), t) {
              case 1:
                t = o.createElementNS(
                  "http://www.w3.org/2000/svg",
                  a
                );
                break;
              case 2:
                t = o.createElementNS(
                  "http://www.w3.org/1998/Math/MathML",
                  a
                );
                break;
              default:
                switch (a) {
                  case "svg":
                    t = o.createElementNS(
                      "http://www.w3.org/2000/svg",
                      a
                    );
                    break;
                  case "math":
                    t = o.createElementNS(
                      "http://www.w3.org/1998/Math/MathML",
                      a
                    );
                    break;
                  case "script":
                    t = o.createElement("div"), t.innerHTML = "<script><\/script>", t = t.removeChild(t.firstChild);
                    break;
                  case "select":
                    t = typeof n.is == "string" ? o.createElement("select", { is: n.is }) : o.createElement("select"), n.multiple ? t.multiple = !0 : n.size && (t.size = n.size);
                    break;
                  default:
                    t = typeof n.is == "string" ? o.createElement(a, { is: n.is }) : o.createElement(a);
                }
            }
            t[Rt] = e, t[dt] = n;
            t: for (o = e.child; o !== null; ) {
              if (o.tag === 5 || o.tag === 6)
                t.appendChild(o.stateNode);
              else if (o.tag !== 4 && o.tag !== 27 && o.child !== null) {
                o.child.return = o, o = o.child;
                continue;
              }
              if (o === e) break t;
              for (; o.sibling === null; ) {
                if (o.return === null || o.return === e)
                  break t;
                o = o.return;
              }
              o.sibling.return = o.return, o = o.sibling;
            }
            e.stateNode = t;
            t: switch ($e(t, a, n), a) {
              case "button":
              case "input":
              case "select":
              case "textarea":
                t = !!n.autoFocus;
                break t;
              case "img":
                t = !0;
                break t;
              default:
                t = !1;
            }
            t && mo(e);
          }
        }
        return Me(e), e.flags &= -16777217, null;
      case 6:
        if (t && e.stateNode != null)
          t.memoizedProps !== n && mo(e);
        else {
          if (typeof n != "string" && e.stateNode === null)
            throw Error(c(166));
          if (t = Nt.current, Ni(e)) {
            if (t = e.stateNode, a = e.memoizedProps, n = null, o = Je, o !== null)
              switch (o.tag) {
                case 27:
                case 5:
                  n = o.memoizedProps;
              }
            t[Rt] = e, t = !!(t.nodeValue === a || n !== null && n.suppressHydrationWarning === !0 || c0(t.nodeValue, a)), t || co(e);
          } else
            t = ac(t).createTextNode(
              n
            ), t[Rt] = e, e.stateNode = t;
        }
        return Me(e), null;
      case 13:
        if (n = e.memoizedState, t === null || t.memoizedState !== null && t.memoizedState.dehydrated !== null) {
          if (o = Ni(e), n !== null && n.dehydrated !== null) {
            if (t === null) {
              if (!o) throw Error(c(318));
              if (o = e.memoizedState, o = o !== null ? o.dehydrated : null, !o) throw Error(c(317));
              o[Rt] = e;
            } else
              Ui(), (e.flags & 128) === 0 && (e.memoizedState = null), e.flags |= 4;
            Me(e), o = !1;
          } else
            o = ws(), t !== null && t.memoizedState !== null && (t.memoizedState.hydrationErrors = o), o = !0;
          if (!o)
            return e.flags & 256 ? (po(e), e) : (po(e), null);
        }
        if (po(e), (e.flags & 128) !== 0)
          return e.lanes = a, e;
        if (a = n !== null, t = t !== null && t.memoizedState !== null, a) {
          n = e.child, o = null, n.alternate !== null && n.alternate.memoizedState !== null && n.alternate.memoizedState.cachePool !== null && (o = n.alternate.memoizedState.cachePool.pool);
          var i = null;
          n.memoizedState !== null && n.memoizedState.cachePool !== null && (i = n.memoizedState.cachePool.pool), i !== o && (n.flags |= 2048);
        }
        return a !== t && a && (e.child.flags |= 8192), Hs(e, e.updateQueue), Me(e), null;
      case 4:
        return ct(), t === null && ah(e.stateNode.containerInfo), Me(e), null;
      case 10:
        return ra(e.type), Me(e), null;
      case 19:
        if (nt(Le), o = e.memoizedState, o === null) return Me(e), null;
        if (n = (e.flags & 128) !== 0, i = o.rendering, i === null)
          if (n) wr(o, !1);
          else {
            if (Re !== 0 || t !== null && (t.flags & 128) !== 0)
              for (t = e.child; t !== null; ) {
                if (i = qs(t), i !== null) {
                  for (e.flags |= 128, wr(o, !1), t = i.updateQueue, e.updateQueue = t, Hs(e, t), e.subtreeFlags = 0, t = a, a = e.child; a !== null; )
                    vs(a, t), a = a.sibling;
                  return $(
                    Le,
                    Le.current & 1 | 2
                  ), e.child;
                }
                t = t.sibling;
              }
            o.tail !== null && ea() > Fs && (e.flags |= 128, n = !0, wr(o, !1), e.lanes = 4194304);
          }
        else {
          if (!n)
            if (t = qs(i), t !== null) {
              if (e.flags |= 128, n = !0, t = t.updateQueue, e.updateQueue = t, Hs(e, t), wr(o, !0), o.tail === null && o.tailMode === "hidden" && !i.alternate && !Ft)
                return Me(e), null;
            } else
              2 * ea() - o.renderingStartTime > Fs && a !== 536870912 && (e.flags |= 128, n = !0, wr(o, !1), e.lanes = 4194304);
          o.isBackwards ? (i.sibling = e.child, e.child = i) : (t = o.last, t !== null ? t.sibling = i : e.child = i, o.last = i);
        }
        return o.tail !== null ? (e = o.tail, o.rendering = e, o.tail = e.sibling, o.renderingStartTime = ea(), e.sibling = null, t = Le.current, $(Le, n ? t & 1 | 2 : t & 1), e) : (Me(e), null);
      case 22:
      case 23:
        return po(e), ou(), n = e.memoizedState !== null, t !== null ? t.memoizedState !== null !== n && (e.flags |= 8192) : n && (e.flags |= 8192), n ? (a & 536870912) !== 0 && (e.flags & 128) === 0 && (Me(e), e.subtreeFlags & 6 && (e.flags |= 8192)) : Me(e), a = e.updateQueue, a !== null && Hs(e, a.retryQueue), a = null, t !== null && t.memoizedState !== null && t.memoizedState.cachePool !== null && (a = t.memoizedState.cachePool.pool), n = null, e.memoizedState !== null && e.memoizedState.cachePool !== null && (n = e.memoizedState.cachePool.pool), n !== a && (e.flags |= 2048), t !== null && nt(ki), null;
      case 24:
        return a = null, t !== null && (a = t.memoizedState.cache), e.memoizedState.cache !== a && (e.flags |= 2048), ra(Bt), Me(e), null;
      case 25:
        return null;
      case 30:
        return null;
    }
    throw Error(c(156, e.tag));
  }
  function Pp(t, e) {
    switch (lr(e), e.tag) {
      case 1:
        return t = e.flags, t & 65536 ? (e.flags = t & -65537 | 128, e) : null;
      case 3:
        return ra(Bt), ct(), t = e.flags, (t & 65536) !== 0 && (t & 128) === 0 ? (e.flags = t & -65537 | 128, e) : null;
      case 26:
      case 27:
      case 5:
        return an(e), null;
      case 13:
        if (po(e), t = e.memoizedState, t !== null && t.dehydrated !== null) {
          if (e.alternate === null)
            throw Error(c(340));
          Ui();
        }
        return t = e.flags, t & 65536 ? (e.flags = t & -65537 | 128, e) : null;
      case 19:
        return nt(Le), null;
      case 4:
        return ct(), null;
      case 10:
        return ra(e.type), null;
      case 22:
      case 23:
        return po(e), ou(), t !== null && nt(ki), t = e.flags, t & 65536 ? (e.flags = t & -65537 | 128, e) : null;
      case 24:
        return ra(Bt), null;
      case 25:
        return null;
      default:
        return null;
    }
  }
  function bd(t, e) {
    switch (lr(e), e.tag) {
      case 3:
        ra(Bt), ct();
        break;
      case 26:
      case 27:
      case 5:
        an(e);
        break;
      case 4:
        ct();
        break;
      case 13:
        po(e);
        break;
      case 19:
        nt(Le);
        break;
      case 10:
        ra(e.type);
        break;
      case 22:
      case 23:
        po(e), ou(), t !== null && nt(ki);
        break;
      case 24:
        ra(Bt);
    }
  }
  function Er(t, e) {
    try {
      var a = e.updateQueue, n = a !== null ? a.lastEffect : null;
      if (n !== null) {
        var o = n.next;
        a = o;
        do {
          if ((a.tag & t) === t) {
            n = void 0;
            var i = a.create, f = a.inst;
            n = i(), f.destroy = n;
          }
          a = a.next;
        } while (a !== o);
      }
    } catch (d) {
      he(e, e.return, d);
    }
  }
  function Fo(t, e, a) {
    try {
      var n = e.updateQueue, o = n !== null ? n.lastEffect : null;
      if (o !== null) {
        var i = o.next;
        n = i;
        do {
          if ((n.tag & t) === t) {
            var f = n.inst, d = f.destroy;
            if (d !== void 0) {
              f.destroy = void 0, o = e;
              var E = a, V = d;
              try {
                V();
              } catch (F) {
                he(
                  o,
                  E,
                  F
                );
              }
            }
          }
          n = n.next;
        } while (n !== i);
      }
    } catch (F) {
      he(e, e.return, F);
    }
  }
  function xd(t) {
    var e = t.updateQueue;
    if (e !== null) {
      var a = t.stateNode;
      try {
        of(e, a);
      } catch (n) {
        he(t, t.return, n);
      }
    }
  }
  function yd(t, e, a) {
    a.props = Vi(
      t.type,
      t.memoizedProps
    ), a.state = t.memoizedState;
    try {
      a.componentWillUnmount();
    } catch (n) {
      he(t, e, n);
    }
  }
  function Rr(t, e) {
    try {
      var a = t.ref;
      if (a !== null) {
        switch (t.tag) {
          case 26:
          case 27:
          case 5:
            var n = t.stateNode;
            break;
          case 30:
            n = t.stateNode;
            break;
          default:
            n = t.stateNode;
        }
        typeof a == "function" ? t.refCleanup = a(n) : a.current = n;
      }
    } catch (o) {
      he(t, e, o);
    }
  }
  function zn(t, e) {
    var a = t.ref, n = t.refCleanup;
    if (a !== null)
      if (typeof n == "function")
        try {
          n();
        } catch (o) {
          he(t, e, o);
        } finally {
          t.refCleanup = null, t = t.alternate, t != null && (t.refCleanup = null);
        }
      else if (typeof a == "function")
        try {
          a(null);
        } catch (o) {
          he(t, e, o);
        }
      else a.current = null;
  }
  function Ad(t) {
    var e = t.type, a = t.memoizedProps, n = t.stateNode;
    try {
      t: switch (e) {
        case "button":
        case "input":
        case "select":
        case "textarea":
          a.autoFocus && n.focus();
          break t;
        case "img":
          a.src ? n.src = a.src : a.srcSet && (n.srcset = a.srcSet);
      }
    } catch (o) {
      he(t, t.return, o);
    }
  }
  function ku(t, e, a) {
    try {
      var n = t.stateNode;
      xg(n, t.type, a, e), n[dt] = e;
    } catch (o) {
      he(t, t.return, o);
    }
  }
  function vd(t) {
    return t.tag === 5 || t.tag === 3 || t.tag === 26 || t.tag === 27 && ti(t.type) || t.tag === 4;
  }
  function Bu(t) {
    t: for (; ; ) {
      for (; t.sibling === null; ) {
        if (t.return === null || vd(t.return)) return null;
        t = t.return;
      }
      for (t.sibling.return = t.return, t = t.sibling; t.tag !== 5 && t.tag !== 6 && t.tag !== 18; ) {
        if (t.tag === 27 && ti(t.type) || t.flags & 2 || t.child === null || t.tag === 4) continue t;
        t.child.return = t, t = t.child;
      }
      if (!(t.flags & 2)) return t.stateNode;
    }
  }
  function Vu(t, e, a) {
    var n = t.tag;
    if (n === 5 || n === 6)
      t = t.stateNode, e ? (a.nodeType === 9 ? a.body : a.nodeName === "HTML" ? a.ownerDocument.body : a).insertBefore(t, e) : (e = a.nodeType === 9 ? a.body : a.nodeName === "HTML" ? a.ownerDocument.body : a, e.appendChild(t), a = a._reactRootContainer, a != null || e.onclick !== null || (e.onclick = ec));
    else if (n !== 4 && (n === 27 && ti(t.type) && (a = t.stateNode, e = null), t = t.child, t !== null))
      for (Vu(t, e, a), t = t.sibling; t !== null; )
        Vu(t, e, a), t = t.sibling;
  }
  function Zs(t, e, a) {
    var n = t.tag;
    if (n === 5 || n === 6)
      t = t.stateNode, e ? a.insertBefore(t, e) : a.appendChild(t);
    else if (n !== 4 && (n === 27 && ti(t.type) && (a = t.stateNode), t = t.child, t !== null))
      for (Zs(t, e, a), t = t.sibling; t !== null; )
        Zs(t, e, a), t = t.sibling;
  }
  function Md(t) {
    var e = t.stateNode, a = t.memoizedProps;
    try {
      for (var n = t.type, o = e.attributes; o.length; )
        e.removeAttributeNode(o[0]);
      $e(e, n, a), e[Rt] = t, e[dt] = a;
    } catch (i) {
      he(t, t.return, i);
    }
  }
  var bo = !1, Ue = !1, Du = !1, wd = typeof WeakSet == "function" ? WeakSet : Set, We = null;
  function _p(t, e) {
    if (t = t.containerInfo, ih = sc, t = _l(t), Ti(t)) {
      if ("selectionStart" in t)
        var a = {
          start: t.selectionStart,
          end: t.selectionEnd
        };
      else
        t: {
          a = (a = t.ownerDocument) && a.defaultView || window;
          var n = a.getSelection && a.getSelection();
          if (n && n.rangeCount !== 0) {
            a = n.anchorNode;
            var o = n.anchorOffset, i = n.focusNode;
            n = n.focusOffset;
            try {
              a.nodeType, i.nodeType;
            } catch {
              a = null;
              break t;
            }
            var f = 0, d = -1, E = -1, V = 0, F = 0, X = t, D = null;
            e: for (; ; ) {
              for (var z; X !== a || o !== 0 && X.nodeType !== 3 || (d = f + o), X !== i || n !== 0 && X.nodeType !== 3 || (E = f + n), X.nodeType === 3 && (f += X.nodeValue.length), (z = X.firstChild) !== null; )
                D = X, X = z;
              for (; ; ) {
                if (X === t) break e;
                if (D === a && ++V === o && (d = f), D === i && ++F === n && (E = f), (z = X.nextSibling) !== null) break;
                X = D, D = X.parentNode;
              }
              X = z;
            }
            a = d === -1 || E === -1 ? null : { start: d, end: E };
          } else a = null;
        }
      a = a || { start: 0, end: 0 };
    } else a = null;
    for (lh = { focusedElem: t, selectionRange: a }, sc = !1, We = e; We !== null; )
      if (e = We, t = e.child, (e.subtreeFlags & 1024) !== 0 && t !== null)
        t.return = e, We = t;
      else
        for (; We !== null; ) {
          switch (e = We, i = e.alternate, t = e.flags, e.tag) {
            case 0:
              break;
            case 11:
            case 15:
              break;
            case 1:
              if ((t & 1024) !== 0 && i !== null) {
                t = void 0, a = e, o = i.memoizedProps, i = i.memoizedState, n = a.stateNode;
                try {
                  var Dt = Vi(
                    a.type,
                    o,
                    a.elementType === a.type
                  );
                  t = n.getSnapshotBeforeUpdate(
                    Dt,
                    i
                  ), n.__reactInternalSnapshotBeforeUpdate = t;
                } catch (St) {
                  he(
                    a,
                    a.return,
                    St
                  );
                }
              }
              break;
            case 3:
              if ((t & 1024) !== 0) {
                if (t = e.stateNode.containerInfo, a = t.nodeType, a === 9)
                  ch(t);
                else if (a === 1)
                  switch (t.nodeName) {
                    case "HEAD":
                    case "HTML":
                    case "BODY":
                      ch(t);
                      break;
                    default:
                      t.textContent = "";
                  }
              }
              break;
            case 5:
            case 26:
            case 27:
            case 6:
            case 4:
            case 17:
              break;
            default:
              if ((t & 1024) !== 0) throw Error(c(163));
          }
          if (t = e.sibling, t !== null) {
            t.return = e.return, We = t;
            break;
          }
          We = e.return;
        }
  }
  function Ed(t, e, a) {
    var n = a.flags;
    switch (a.tag) {
      case 0:
      case 11:
      case 15:
        Go(t, a), n & 4 && Er(5, a);
        break;
      case 1:
        if (Go(t, a), n & 4)
          if (t = a.stateNode, e === null)
            try {
              t.componentDidMount();
            } catch (f) {
              he(a, a.return, f);
            }
          else {
            var o = Vi(
              a.type,
              e.memoizedProps
            );
            e = e.memoizedState;
            try {
              t.componentDidUpdate(
                o,
                e,
                t.__reactInternalSnapshotBeforeUpdate
              );
            } catch (f) {
              he(
                a,
                a.return,
                f
              );
            }
          }
        n & 64 && xd(a), n & 512 && Rr(a, a.return);
        break;
      case 3:
        if (Go(t, a), n & 64 && (t = a.updateQueue, t !== null)) {
          if (e = null, a.child !== null)
            switch (a.child.tag) {
              case 27:
              case 5:
                e = a.child.stateNode;
                break;
              case 1:
                e = a.child.stateNode;
            }
          try {
            of(t, e);
          } catch (f) {
            he(a, a.return, f);
          }
        }
        break;
      case 27:
        e === null && n & 4 && Md(a);
      case 26:
      case 5:
        Go(t, a), e === null && n & 4 && Ad(a), n & 512 && Rr(a, a.return);
        break;
      case 12:
        Go(t, a);
        break;
      case 13:
        Go(t, a), n & 4 && Td(t, a), n & 64 && (t = a.memoizedState, t !== null && (t = t.dehydrated, t !== null && (a = rg.bind(
          null,
          a
        ), Rg(t, a))));
        break;
      case 22:
        if (n = a.memoizedState !== null || bo, !n) {
          e = e !== null && e.memoizedState !== null || Ue, o = bo;
          var i = Ue;
          bo = n, (Ue = e) && !i ? Io(
            t,
            a,
            (a.subtreeFlags & 8772) !== 0
          ) : Go(t, a), bo = o, Ue = i;
        }
        break;
      case 30:
        break;
      default:
        Go(t, a);
    }
  }
  function Rd(t) {
    var e = t.alternate;
    e !== null && (t.alternate = null, Rd(e)), t.child = null, t.deletions = null, t.sibling = null, t.tag === 5 && (e = t.stateNode, e !== null && Ke(e)), t.stateNode = null, t.return = null, t.dependencies = null, t.memoizedProps = null, t.memoizedState = null, t.pendingProps = null, t.stateNode = null, t.updateQueue = null;
  }
  var Ae = null, Ua = !1;
  function xo(t, e, a) {
    for (a = a.child; a !== null; )
      Sd(t, e, a), a = a.sibling;
  }
  function Sd(t, e, a) {
    if (Se && typeof Se.onCommitFiberUnmount == "function")
      try {
        Se.onCommitFiberUnmount(Za, a);
      } catch {
      }
    switch (a.tag) {
      case 26:
        Ue || zn(a, e), xo(
          t,
          e,
          a
        ), a.memoizedState ? a.memoizedState.count-- : a.stateNode && (a = a.stateNode, a.parentNode.removeChild(a));
        break;
      case 27:
        Ue || zn(a, e);
        var n = Ae, o = Ua;
        ti(a.type) && (Ae = a.stateNode, Ua = !1), xo(
          t,
          e,
          a
        ), Vr(a.stateNode), Ae = n, Ua = o;
        break;
      case 5:
        Ue || zn(a, e);
      case 6:
        if (n = Ae, o = Ua, Ae = null, xo(
          t,
          e,
          a
        ), Ae = n, Ua = o, Ae !== null)
          if (Ua)
            try {
              (Ae.nodeType === 9 ? Ae.body : Ae.nodeName === "HTML" ? Ae.ownerDocument.body : Ae).removeChild(a.stateNode);
            } catch (i) {
              he(
                a,
                e,
                i
              );
            }
          else
            try {
              Ae.removeChild(a.stateNode);
            } catch (i) {
              he(
                a,
                e,
                i
              );
            }
        break;
      case 18:
        Ae !== null && (Ua ? (t = Ae, p0(
          t.nodeType === 9 ? t.body : t.nodeName === "HTML" ? t.ownerDocument.body : t,
          a.stateNode
        ), Kr(t)) : p0(Ae, a.stateNode));
        break;
      case 4:
        n = Ae, o = Ua, Ae = a.stateNode.containerInfo, Ua = !0, xo(
          t,
          e,
          a
        ), Ae = n, Ua = o;
        break;
      case 0:
      case 11:
      case 14:
      case 15:
        Ue || Fo(2, a, e), Ue || Fo(4, a, e), xo(
          t,
          e,
          a
        );
        break;
      case 1:
        Ue || (zn(a, e), n = a.stateNode, typeof n.componentWillUnmount == "function" && yd(
          a,
          e,
          n
        )), xo(
          t,
          e,
          a
        );
        break;
      case 21:
        xo(
          t,
          e,
          a
        );
        break;
      case 22:
        Ue = (n = Ue) || a.memoizedState !== null, xo(
          t,
          e,
          a
        ), Ue = n;
        break;
      default:
        xo(
          t,
          e,
          a
        );
    }
  }
  function Td(t, e) {
    if (e.memoizedState === null && (t = e.alternate, t !== null && (t = t.memoizedState, t !== null && (t = t.dehydrated, t !== null))))
      try {
        Kr(t);
      } catch (a) {
        he(e, e.return, a);
      }
  }
  function $p(t) {
    switch (t.tag) {
      case 13:
      case 19:
        var e = t.stateNode;
        return e === null && (e = t.stateNode = new wd()), e;
      case 22:
        return t = t.stateNode, e = t._retryCache, e === null && (e = t._retryCache = new wd()), e;
      default:
        throw Error(c(435, t.tag));
    }
  }
  function Yu(t, e) {
    var a = $p(t);
    e.forEach(function(n) {
      var o = sg.bind(null, t, n);
      a.has(n) || (a.add(n), n.then(o, o));
    });
  }
  function qa(t, e) {
    var a = e.deletions;
    if (a !== null)
      for (var n = 0; n < a.length; n++) {
        var o = a[n], i = t, f = e, d = f;
        t: for (; d !== null; ) {
          switch (d.tag) {
            case 27:
              if (ti(d.type)) {
                Ae = d.stateNode, Ua = !1;
                break t;
              }
              break;
            case 5:
              Ae = d.stateNode, Ua = !1;
              break t;
            case 3:
            case 4:
              Ae = d.stateNode.containerInfo, Ua = !0;
              break t;
          }
          d = d.return;
        }
        if (Ae === null) throw Error(c(160));
        Sd(i, f, o), Ae = null, Ua = !1, i = o.alternate, i !== null && (i.return = null), o.return = null;
      }
    if (e.subtreeFlags & 13878)
      for (e = e.child; e !== null; )
        Cd(e, t), e = e.sibling;
  }
  var pn = null;
  function Cd(t, e) {
    var a = t.alternate, n = t.flags;
    switch (t.tag) {
      case 0:
      case 11:
      case 14:
      case 15:
        qa(e, t), Qa(t), n & 4 && (Fo(3, t, t.return), Er(3, t), Fo(5, t, t.return));
        break;
      case 1:
        qa(e, t), Qa(t), n & 512 && (Ue || a === null || zn(a, a.return)), n & 64 && bo && (t = t.updateQueue, t !== null && (n = t.callbacks, n !== null && (a = t.shared.hiddenCallbacks, t.shared.hiddenCallbacks = a === null ? n : a.concat(n))));
        break;
      case 26:
        var o = pn;
        if (qa(e, t), Qa(t), n & 512 && (Ue || a === null || zn(a, a.return)), n & 4) {
          var i = a !== null ? a.memoizedState : null;
          if (n = t.memoizedState, a === null)
            if (n === null)
              if (t.stateNode === null) {
                t: {
                  n = t.type, a = t.memoizedProps, o = o.ownerDocument || o;
                  e: switch (n) {
                    case "title":
                      i = o.getElementsByTagName("title")[0], (!i || i[ke] || i[Rt] || i.namespaceURI === "http://www.w3.org/2000/svg" || i.hasAttribute("itemprop")) && (i = o.createElement(n), o.head.insertBefore(
                        i,
                        o.querySelector("head > title")
                      )), $e(i, n, a), i[Rt] = t, xe(i), n = i;
                      break t;
                    case "link":
                      var f = M0(
                        "link",
                        "href",
                        o
                      ).get(n + (a.href || ""));
                      if (f) {
                        for (var d = 0; d < f.length; d++)
                          if (i = f[d], i.getAttribute("href") === (a.href == null || a.href === "" ? null : a.href) && i.getAttribute("rel") === (a.rel == null ? null : a.rel) && i.getAttribute("title") === (a.title == null ? null : a.title) && i.getAttribute("crossorigin") === (a.crossOrigin == null ? null : a.crossOrigin)) {
                            f.splice(d, 1);
                            break e;
                          }
                      }
                      i = o.createElement(n), $e(i, n, a), o.head.appendChild(i);
                      break;
                    case "meta":
                      if (f = M0(
                        "meta",
                        "content",
                        o
                      ).get(n + (a.content || ""))) {
                        for (d = 0; d < f.length; d++)
                          if (i = f[d], i.getAttribute("content") === (a.content == null ? null : "" + a.content) && i.getAttribute("name") === (a.name == null ? null : a.name) && i.getAttribute("property") === (a.property == null ? null : a.property) && i.getAttribute("http-equiv") === (a.httpEquiv == null ? null : a.httpEquiv) && i.getAttribute("charset") === (a.charSet == null ? null : a.charSet)) {
                            f.splice(d, 1);
                            break e;
                          }
                      }
                      i = o.createElement(n), $e(i, n, a), o.head.appendChild(i);
                      break;
                    default:
                      throw Error(c(468, n));
                  }
                  i[Rt] = t, xe(i), n = i;
                }
                t.stateNode = n;
              } else
                w0(
                  o,
                  t.type,
                  t.stateNode
                );
            else
              t.stateNode = v0(
                o,
                n,
                t.memoizedProps
              );
          else
            i !== n ? (i === null ? a.stateNode !== null && (a = a.stateNode, a.parentNode.removeChild(a)) : i.count--, n === null ? w0(
              o,
              t.type,
              t.stateNode
            ) : v0(
              o,
              n,
              t.memoizedProps
            )) : n === null && t.stateNode !== null && ku(
              t,
              t.memoizedProps,
              a.memoizedProps
            );
        }
        break;
      case 27:
        qa(e, t), Qa(t), n & 512 && (Ue || a === null || zn(a, a.return)), a !== null && n & 4 && ku(
          t,
          t.memoizedProps,
          a.memoizedProps
        );
        break;
      case 5:
        if (qa(e, t), Qa(t), n & 512 && (Ue || a === null || zn(a, a.return)), t.flags & 32) {
          o = t.stateNode;
          try {
            Ro(o, "");
          } catch (z) {
            he(t, t.return, z);
          }
        }
        n & 4 && t.stateNode != null && (o = t.memoizedProps, ku(
          t,
          o,
          a !== null ? a.memoizedProps : o
        )), n & 1024 && (Du = !0);
        break;
      case 6:
        if (qa(e, t), Qa(t), n & 4) {
          if (t.stateNode === null)
            throw Error(c(162));
          n = t.memoizedProps, a = t.stateNode;
          try {
            a.nodeValue = n;
          } catch (z) {
            he(t, t.return, z);
          }
        }
        break;
      case 3:
        if (ic = null, o = pn, pn = nc(e.containerInfo), qa(e, t), pn = o, Qa(t), n & 4 && a !== null && a.memoizedState.isDehydrated)
          try {
            Kr(e.containerInfo);
          } catch (z) {
            he(t, t.return, z);
          }
        Du && (Du = !1, Nd(t));
        break;
      case 4:
        n = pn, pn = nc(
          t.stateNode.containerInfo
        ), qa(e, t), Qa(t), pn = n;
        break;
      case 12:
        qa(e, t), Qa(t);
        break;
      case 13:
        qa(e, t), Qa(t), t.child.flags & 8192 && t.memoizedState !== null != (a !== null && a.memoizedState !== null) && (Ku = ea()), n & 4 && (n = t.updateQueue, n !== null && (t.updateQueue = null, Yu(t, n)));
        break;
      case 22:
        o = t.memoizedState !== null;
        var E = a !== null && a.memoizedState !== null, V = bo, F = Ue;
        if (bo = V || o, Ue = F || E, qa(e, t), Ue = F, bo = V, Qa(t), n & 8192)
          t: for (e = t.stateNode, e._visibility = o ? e._visibility & -2 : e._visibility | 1, o && (a === null || E || bo || Ue || Di(t)), a = null, e = t; ; ) {
            if (e.tag === 5 || e.tag === 26) {
              if (a === null) {
                E = a = e;
                try {
                  if (i = E.stateNode, o)
                    f = i.style, typeof f.setProperty == "function" ? f.setProperty("display", "none", "important") : f.display = "none";
                  else {
                    d = E.stateNode;
                    var X = E.memoizedProps.style, D = X != null && X.hasOwnProperty("display") ? X.display : null;
                    d.style.display = D == null || typeof D == "boolean" ? "" : ("" + D).trim();
                  }
                } catch (z) {
                  he(E, E.return, z);
                }
              }
            } else if (e.tag === 6) {
              if (a === null) {
                E = e;
                try {
                  E.stateNode.nodeValue = o ? "" : E.memoizedProps;
                } catch (z) {
                  he(E, E.return, z);
                }
              }
            } else if ((e.tag !== 22 && e.tag !== 23 || e.memoizedState === null || e === t) && e.child !== null) {
              e.child.return = e, e = e.child;
              continue;
            }
            if (e === t) break t;
            for (; e.sibling === null; ) {
              if (e.return === null || e.return === t) break t;
              a === e && (a = null), e = e.return;
            }
            a === e && (a = null), e.sibling.return = e.return, e = e.sibling;
          }
        n & 4 && (n = t.updateQueue, n !== null && (a = n.retryQueue, a !== null && (n.retryQueue = null, Yu(t, a))));
        break;
      case 19:
        qa(e, t), Qa(t), n & 4 && (n = t.updateQueue, n !== null && (t.updateQueue = null, Yu(t, n)));
        break;
      case 30:
        break;
      case 21:
        break;
      default:
        qa(e, t), Qa(t);
    }
  }
  function Qa(t) {
    var e = t.flags;
    if (e & 2) {
      try {
        for (var a, n = t.return; n !== null; ) {
          if (vd(n)) {
            a = n;
            break;
          }
          n = n.return;
        }
        if (a == null) throw Error(c(160));
        switch (a.tag) {
          case 27:
            var o = a.stateNode, i = Bu(t);
            Zs(t, i, o);
            break;
          case 5:
            var f = a.stateNode;
            a.flags & 32 && (Ro(f, ""), a.flags &= -33);
            var d = Bu(t);
            Zs(t, d, f);
            break;
          case 3:
          case 4:
            var E = a.stateNode.containerInfo, V = Bu(t);
            Vu(
              t,
              V,
              E
            );
            break;
          default:
            throw Error(c(161));
        }
      } catch (F) {
        he(t, t.return, F);
      }
      t.flags &= -3;
    }
    e & 4096 && (t.flags &= -4097);
  }
  function Nd(t) {
    if (t.subtreeFlags & 1024)
      for (t = t.child; t !== null; ) {
        var e = t;
        Nd(e), e.tag === 5 && e.flags & 1024 && e.stateNode.reset(), t = t.sibling;
      }
  }
  function Go(t, e) {
    if (e.subtreeFlags & 8772)
      for (e = e.child; e !== null; )
        Ed(t, e.alternate, e), e = e.sibling;
  }
  function Di(t) {
    for (t = t.child; t !== null; ) {
      var e = t;
      switch (e.tag) {
        case 0:
        case 11:
        case 14:
        case 15:
          Fo(4, e, e.return), Di(e);
          break;
        case 1:
          zn(e, e.return);
          var a = e.stateNode;
          typeof a.componentWillUnmount == "function" && yd(
            e,
            e.return,
            a
          ), Di(e);
          break;
        case 27:
          Vr(e.stateNode);
        case 26:
        case 5:
          zn(e, e.return), Di(e);
          break;
        case 22:
          e.memoizedState === null && Di(e);
          break;
        case 30:
          Di(e);
          break;
        default:
          Di(e);
      }
      t = t.sibling;
    }
  }
  function Io(t, e, a) {
    for (a = a && (e.subtreeFlags & 8772) !== 0, e = e.child; e !== null; ) {
      var n = e.alternate, o = t, i = e, f = i.flags;
      switch (i.tag) {
        case 0:
        case 11:
        case 15:
          Io(
            o,
            i,
            a
          ), Er(4, i);
          break;
        case 1:
          if (Io(
            o,
            i,
            a
          ), n = i, o = n.stateNode, typeof o.componentDidMount == "function")
            try {
              o.componentDidMount();
            } catch (V) {
              he(n, n.return, V);
            }
          if (n = i, o = n.updateQueue, o !== null) {
            var d = n.stateNode;
            try {
              var E = o.shared.hiddenCallbacks;
              if (E !== null)
                for (o.shared.hiddenCallbacks = null, o = 0; o < E.length; o++)
                  nf(E[o], d);
            } catch (V) {
              he(n, n.return, V);
            }
          }
          a && f & 64 && xd(i), Rr(i, i.return);
          break;
        case 27:
          Md(i);
        case 26:
        case 5:
          Io(
            o,
            i,
            a
          ), a && n === null && f & 4 && Ad(i), Rr(i, i.return);
          break;
        case 12:
          Io(
            o,
            i,
            a
          );
          break;
        case 13:
          Io(
            o,
            i,
            a
          ), a && f & 4 && Td(o, i);
          break;
        case 22:
          i.memoizedState === null && Io(
            o,
            i,
            a
          ), Rr(i, i.return);
          break;
        case 30:
          break;
        default:
          Io(
            o,
            i,
            a
          );
      }
      e = e.sibling;
    }
  }
  function zu(t, e) {
    var a = null;
    t !== null && t.memoizedState !== null && t.memoizedState.cachePool !== null && (a = t.memoizedState.cachePool.pool), t = null, e.memoizedState !== null && e.memoizedState.cachePool !== null && (t = e.memoizedState.cachePool.pool), t !== a && (t != null && t.refCount++, a != null && Zt(a));
  }
  function qu(t, e) {
    t = null, e.alternate !== null && (t = e.alternate.memoizedState.cache), e = e.memoizedState.cache, e !== t && (e.refCount++, t != null && Zt(t));
  }
  function qn(t, e, a, n) {
    if (e.subtreeFlags & 10256)
      for (e = e.child; e !== null; )
        Ud(
          t,
          e,
          a,
          n
        ), e = e.sibling;
  }
  function Ud(t, e, a, n) {
    var o = e.flags;
    switch (e.tag) {
      case 0:
      case 11:
      case 15:
        qn(
          t,
          e,
          a,
          n
        ), o & 2048 && Er(9, e);
        break;
      case 1:
        qn(
          t,
          e,
          a,
          n
        );
        break;
      case 3:
        qn(
          t,
          e,
          a,
          n
        ), o & 2048 && (t = null, e.alternate !== null && (t = e.alternate.memoizedState.cache), e = e.memoizedState.cache, e !== t && (e.refCount++, t != null && Zt(t)));
        break;
      case 12:
        if (o & 2048) {
          qn(
            t,
            e,
            a,
            n
          ), t = e.stateNode;
          try {
            var i = e.memoizedProps, f = i.id, d = i.onPostCommit;
            typeof d == "function" && d(
              f,
              e.alternate === null ? "mount" : "update",
              t.passiveEffectDuration,
              -0
            );
          } catch (E) {
            he(e, e.return, E);
          }
        } else
          qn(
            t,
            e,
            a,
            n
          );
        break;
      case 13:
        qn(
          t,
          e,
          a,
          n
        );
        break;
      case 23:
        break;
      case 22:
        i = e.stateNode, f = e.alternate, e.memoizedState !== null ? i._visibility & 2 ? qn(
          t,
          e,
          a,
          n
        ) : Sr(t, e) : i._visibility & 2 ? qn(
          t,
          e,
          a,
          n
        ) : (i._visibility |= 2, wl(
          t,
          e,
          a,
          n,
          (e.subtreeFlags & 10256) !== 0
        )), o & 2048 && zu(f, e);
        break;
      case 24:
        qn(
          t,
          e,
          a,
          n
        ), o & 2048 && qu(e.alternate, e);
        break;
      default:
        qn(
          t,
          e,
          a,
          n
        );
    }
  }
  function wl(t, e, a, n, o) {
    for (o = o && (e.subtreeFlags & 10256) !== 0, e = e.child; e !== null; ) {
      var i = t, f = e, d = a, E = n, V = f.flags;
      switch (f.tag) {
        case 0:
        case 11:
        case 15:
          wl(
            i,
            f,
            d,
            E,
            o
          ), Er(8, f);
          break;
        case 23:
          break;
        case 22:
          var F = f.stateNode;
          f.memoizedState !== null ? F._visibility & 2 ? wl(
            i,
            f,
            d,
            E,
            o
          ) : Sr(
            i,
            f
          ) : (F._visibility |= 2, wl(
            i,
            f,
            d,
            E,
            o
          )), o && V & 2048 && zu(
            f.alternate,
            f
          );
          break;
        case 24:
          wl(
            i,
            f,
            d,
            E,
            o
          ), o && V & 2048 && qu(f.alternate, f);
          break;
        default:
          wl(
            i,
            f,
            d,
            E,
            o
          );
      }
      e = e.sibling;
    }
  }
  function Sr(t, e) {
    if (e.subtreeFlags & 10256)
      for (e = e.child; e !== null; ) {
        var a = t, n = e, o = n.flags;
        switch (n.tag) {
          case 22:
            Sr(a, n), o & 2048 && zu(
              n.alternate,
              n
            );
            break;
          case 24:
            Sr(a, n), o & 2048 && qu(n.alternate, n);
            break;
          default:
            Sr(a, n);
        }
        e = e.sibling;
      }
  }
  var Tr = 8192;
  function El(t) {
    if (t.subtreeFlags & Tr)
      for (t = t.child; t !== null; )
        jd(t), t = t.sibling;
  }
  function jd(t) {
    switch (t.tag) {
      case 26:
        El(t), t.flags & Tr && t.memoizedState !== null && qg(
          pn,
          t.memoizedState,
          t.memoizedProps
        );
        break;
      case 5:
        El(t);
        break;
      case 3:
      case 4:
        var e = pn;
        pn = nc(t.stateNode.containerInfo), El(t), pn = e;
        break;
      case 22:
        t.memoizedState === null && (e = t.alternate, e !== null && e.memoizedState !== null ? (e = Tr, Tr = 16777216, El(t), Tr = e) : El(t));
        break;
      default:
        El(t);
    }
  }
  function kd(t) {
    var e = t.alternate;
    if (e !== null && (t = e.child, t !== null)) {
      e.child = null;
      do
        e = t.sibling, t.sibling = null, t = e;
      while (t !== null);
    }
  }
  function Cr(t) {
    var e = t.deletions;
    if ((t.flags & 16) !== 0) {
      if (e !== null)
        for (var a = 0; a < e.length; a++) {
          var n = e[a];
          We = n, Vd(
            n,
            t
          );
        }
      kd(t);
    }
    if (t.subtreeFlags & 10256)
      for (t = t.child; t !== null; )
        Bd(t), t = t.sibling;
  }
  function Bd(t) {
    switch (t.tag) {
      case 0:
      case 11:
      case 15:
        Cr(t), t.flags & 2048 && Fo(9, t, t.return);
        break;
      case 3:
        Cr(t);
        break;
      case 12:
        Cr(t);
        break;
      case 22:
        var e = t.stateNode;
        t.memoizedState !== null && e._visibility & 2 && (t.return === null || t.return.tag !== 13) ? (e._visibility &= -3, Ws(t)) : Cr(t);
        break;
      default:
        Cr(t);
    }
  }
  function Ws(t) {
    var e = t.deletions;
    if ((t.flags & 16) !== 0) {
      if (e !== null)
        for (var a = 0; a < e.length; a++) {
          var n = e[a];
          We = n, Vd(
            n,
            t
          );
        }
      kd(t);
    }
    for (t = t.child; t !== null; ) {
      switch (e = t, e.tag) {
        case 0:
        case 11:
        case 15:
          Fo(8, e, e.return), Ws(e);
          break;
        case 22:
          a = e.stateNode, a._visibility & 2 && (a._visibility &= -3, Ws(e));
          break;
        default:
          Ws(e);
      }
      t = t.sibling;
    }
  }
  function Vd(t, e) {
    for (; We !== null; ) {
      var a = We;
      switch (a.tag) {
        case 0:
        case 11:
        case 15:
          Fo(8, a, e);
          break;
        case 23:
        case 22:
          if (a.memoizedState !== null && a.memoizedState.cachePool !== null) {
            var n = a.memoizedState.cachePool.pool;
            n != null && n.refCount++;
          }
          break;
        case 24:
          Zt(a.memoizedState.cache);
      }
      if (n = a.child, n !== null) n.return = a, We = n;
      else
        t: for (a = t; We !== null; ) {
          n = We;
          var o = n.sibling, i = n.return;
          if (Rd(n), n === a) {
            We = null;
            break t;
          }
          if (o !== null) {
            o.return = i, We = o;
            break t;
          }
          We = i;
        }
    }
  }
  var tg = {
    getCacheForType: function(t) {
      var e = N(Bt), a = e.data.get(t);
      return a === void 0 && (a = t(), e.data.set(t, a)), a;
    }
  }, eg = typeof WeakMap == "function" ? WeakMap : Map, oe = 0, fe = null, Xt = null, te = 0, ie = 0, La = null, Xo = !1, Rl = !1, Qu = !1, yo = 0, Re = 0, Jo = 0, Yi = 0, Lu = 0, tn = 0, Sl = 0, Nr = null, ja = null, Ou = !1, Ku = 0, Fs = 1 / 0, Gs = null, Po = null, _e = 0, _o = null, Tl = null, Cl = 0, Hu = 0, Zu = null, Dd = null, Ur = 0, Wu = null;
  function Oa() {
    if ((oe & 2) !== 0 && te !== 0)
      return te & -te;
    if (q.T !== null) {
      var t = Ca;
      return t !== 0 ? t : _u();
    }
    return yt();
  }
  function Yd() {
    tn === 0 && (tn = (te & 536870912) === 0 || Ft ? Hn() : 536870912);
    var t = $a.current;
    return t !== null && (t.flags |= 32), tn;
  }
  function Ka(t, e, a) {
    (t === fe && (ie === 2 || ie === 9) || t.cancelPendingCommit !== null) && (Nl(t, 0), $o(
      t,
      te,
      tn,
      !1
    )), An(t, a), ((oe & 2) === 0 || t !== fe) && (t === fe && ((oe & 2) === 0 && (Yi |= a), Re === 4 && $o(
      t,
      te,
      tn,
      !1
    )), Qn(t));
  }
  function zd(t, e, a) {
    if ((oe & 6) !== 0) throw Error(c(327));
    var n = !a && (e & 124) === 0 && (e & t.expiredLanes) === 0 || oa(t, e), o = n ? og(t, e) : Iu(t, e, !0), i = n;
    do {
      if (o === 0) {
        Rl && !n && $o(t, e, 0, !1);
        break;
      } else {
        if (a = t.current.alternate, i && !ag(a)) {
          o = Iu(t, e, !1), i = !1;
          continue;
        }
        if (o === 2) {
          if (i = e, t.errorRecoveryDisabledLanes & i)
            var f = 0;
          else
            f = t.pendingLanes & -536870913, f = f !== 0 ? f : f & 536870912 ? 536870912 : 0;
          if (f !== 0) {
            e = f;
            t: {
              var d = t;
              o = Nr;
              var E = d.current.memoizedState.isDehydrated;
              if (E && (Nl(d, f).flags |= 256), f = Iu(
                d,
                f,
                !1
              ), f !== 2) {
                if (Qu && !E) {
                  d.errorRecoveryDisabledLanes |= i, Yi |= i, o = 4;
                  break t;
                }
                i = ja, ja = o, i !== null && (ja === null ? ja = i : ja.push.apply(
                  ja,
                  i
                ));
              }
              o = f;
            }
            if (i = !1, o !== 2) continue;
          }
        }
        if (o === 1) {
          Nl(t, 0), $o(t, e, 0, !0);
          break;
        }
        t: {
          switch (n = t, i = o, i) {
            case 0:
            case 1:
              throw Error(c(345));
            case 4:
              if ((e & 4194048) !== e) break;
            case 6:
              $o(
                n,
                e,
                tn,
                !Xo
              );
              break t;
            case 2:
              ja = null;
              break;
            case 3:
            case 5:
              break;
            default:
              throw Error(c(329));
          }
          if ((e & 62914560) === e && (o = Ku + 300 - ea(), 10 < o)) {
            if ($o(
              n,
              e,
              tn,
              !Xo
            ), Fa(n, 0, !0) !== 0) break t;
            n.timeoutHandle = f0(
              qd.bind(
                null,
                n,
                a,
                ja,
                Gs,
                Ou,
                e,
                tn,
                Yi,
                Sl,
                Xo,
                i,
                2,
                -0,
                0
              ),
              o
            );
            break t;
          }
          qd(
            n,
            a,
            ja,
            Gs,
            Ou,
            e,
            tn,
            Yi,
            Sl,
            Xo,
            i,
            0,
            -0,
            0
          );
        }
      }
      break;
    } while (!0);
    Qn(t);
  }
  function qd(t, e, a, n, o, i, f, d, E, V, F, X, D, z) {
    if (t.timeoutHandle = -1, X = e.subtreeFlags, (X & 8192 || (X & 16785408) === 16785408) && (zr = { stylesheets: null, count: 0, unsuspend: zg }, jd(e), X = Qg(), X !== null)) {
      t.cancelPendingCommit = X(
        Wd.bind(
          null,
          t,
          e,
          i,
          a,
          n,
          o,
          f,
          d,
          E,
          F,
          1,
          D,
          z
        )
      ), $o(t, i, f, !V);
      return;
    }
    Wd(
      t,
      e,
      i,
      a,
      n,
      o,
      f,
      d,
      E
    );
  }
  function ag(t) {
    for (var e = t; ; ) {
      var a = e.tag;
      if ((a === 0 || a === 11 || a === 15) && e.flags & 16384 && (a = e.updateQueue, a !== null && (a = a.stores, a !== null)))
        for (var n = 0; n < a.length; n++) {
          var o = a[n], i = o.getSnapshot;
          o = o.value;
          try {
            if (!da(i(), o)) return !1;
          } catch {
            return !1;
          }
        }
      if (a = e.child, e.subtreeFlags & 16384 && a !== null)
        a.return = e, e = a;
      else {
        if (e === t) break;
        for (; e.sibling === null; ) {
          if (e.return === null || e.return === t) return !0;
          e = e.return;
        }
        e.sibling.return = e.return, e = e.sibling;
      }
    }
    return !0;
  }
  function $o(t, e, a, n) {
    e &= ~Lu, e &= ~Yi, t.suspendedLanes |= e, t.pingedLanes &= ~e, n && (t.warmLanes |= e), n = t.expirationTimes;
    for (var o = e; 0 < o; ) {
      var i = 31 - be(o), f = 1 << i;
      n[i] = -1, o &= ~f;
    }
    a !== 0 && Vt(t, a, e);
  }
  function Is() {
    return (oe & 6) === 0 ? (jr(0), !1) : !0;
  }
  function Fu() {
    if (Xt !== null) {
      if (ie === 0)
        var t = Xt.return;
      else
        t = Xt, dn = uo = null, cu(t), vl = null, vr = 0, t = Xt;
      for (; t !== null; )
        bd(t.alternate, t), t = t.return;
      Xt = null;
    }
  }
  function Nl(t, e) {
    var a = t.timeoutHandle;
    a !== -1 && (t.timeoutHandle = -1, Ag(a)), a = t.cancelPendingCommit, a !== null && (t.cancelPendingCommit = null, a()), Fu(), fe = t, Xt = a = Pa(t.current, null), te = e, ie = 0, La = null, Xo = !1, Rl = oa(t, e), Qu = !1, Sl = tn = Lu = Yi = Jo = Re = 0, ja = Nr = null, Ou = !1, (e & 8) !== 0 && (e |= e & 32);
    var n = t.entangledLanes;
    if (n !== 0)
      for (t = t.entanglements, n &= e; 0 < n; ) {
        var o = 31 - be(n), i = 1 << o;
        e |= t[o], n &= ~i;
      }
    return yo = e, cl(), a;
  }
  function Qd(t, e) {
    Wt = null, q.H = Ds, e === fr || e === Rs ? (e = ef(), ie = 3) : e === _h ? (e = ef(), ie = 4) : ie = e === nd ? 8 : e !== null && typeof e == "object" && typeof e.then == "function" ? 6 : 1, La = e, Xt === null && (Re = 1, Ls(
      t,
      ga(e, t.current)
    ));
  }
  function Ld() {
    var t = q.H;
    return q.H = Ds, t === null ? Ds : t;
  }
  function Od() {
    var t = q.A;
    return q.A = tg, t;
  }
  function Gu() {
    Re = 4, Xo || (te & 4194048) !== te && $a.current !== null || (Rl = !0), (Jo & 134217727) === 0 && (Yi & 134217727) === 0 || fe === null || $o(
      fe,
      te,
      tn,
      !1
    );
  }
  function Iu(t, e, a) {
    var n = oe;
    oe |= 2;
    var o = Ld(), i = Od();
    (fe !== t || te !== e) && (Gs = null, Nl(t, e)), e = !1;
    var f = Re;
    t: do
      try {
        if (ie !== 0 && Xt !== null) {
          var d = Xt, E = La;
          switch (ie) {
            case 8:
              Fu(), f = 6;
              break t;
            case 3:
            case 2:
            case 9:
            case 6:
              $a.current === null && (e = !0);
              var V = ie;
              if (ie = 0, La = null, Ul(t, d, E, V), a && Rl) {
                f = 0;
                break t;
              }
              break;
            default:
              V = ie, ie = 0, La = null, Ul(t, d, E, V);
          }
        }
        ng(), f = Re;
        break;
      } catch (F) {
        Qd(t, F);
      }
    while (!0);
    return e && t.shellSuspendCounter++, dn = uo = null, oe = n, q.H = o, q.A = i, Xt === null && (fe = null, te = 0, cl()), f;
  }
  function ng() {
    for (; Xt !== null; ) Kd(Xt);
  }
  function og(t, e) {
    var a = oe;
    oe |= 2;
    var n = Ld(), o = Od();
    fe !== t || te !== e ? (Gs = null, Fs = ea() + 500, Nl(t, e)) : Rl = oa(
      t,
      e
    );
    t: do
      try {
        if (ie !== 0 && Xt !== null) {
          e = Xt;
          var i = La;
          e: switch (ie) {
            case 1:
              ie = 0, La = null, Ul(t, e, i, 1);
              break;
            case 2:
            case 9:
              if ($h(i)) {
                ie = 0, La = null, Hd(e);
                break;
              }
              e = function() {
                ie !== 2 && ie !== 9 || fe !== t || (ie = 7), Qn(t);
              }, i.then(e, e);
              break t;
            case 3:
              ie = 7;
              break t;
            case 4:
              ie = 5;
              break t;
            case 7:
              $h(i) ? (ie = 0, La = null, Hd(e)) : (ie = 0, La = null, Ul(t, e, i, 7));
              break;
            case 5:
              var f = null;
              switch (Xt.tag) {
                case 26:
                  f = Xt.memoizedState;
                case 5:
                case 27:
                  var d = Xt;
                  if (!f || E0(f)) {
                    ie = 0, La = null;
                    var E = d.sibling;
                    if (E !== null) Xt = E;
                    else {
                      var V = d.return;
                      V !== null ? (Xt = V, Xs(V)) : Xt = null;
                    }
                    break e;
                  }
              }
              ie = 0, La = null, Ul(t, e, i, 5);
              break;
            case 6:
              ie = 0, La = null, Ul(t, e, i, 6);
              break;
            case 8:
              Fu(), Re = 6;
              break t;
            default:
              throw Error(c(462));
          }
        }
        ig();
        break;
      } catch (F) {
        Qd(t, F);
      }
    while (!0);
    return dn = uo = null, q.H = n, q.A = o, oe = a, Xt !== null ? 0 : (fe = null, te = 0, cl(), Re);
  }
  function ig() {
    for (; Xt !== null && !Hi(); )
      Kd(Xt);
  }
  function Kd(t) {
    var e = gd(t.alternate, t, yo);
    t.memoizedProps = t.pendingProps, e === null ? Xs(t) : Xt = e;
  }
  function Hd(t) {
    var e = t, a = e.alternate;
    switch (e.tag) {
      case 15:
      case 0:
        e = cd(
          a,
          e,
          e.pendingProps,
          e.type,
          void 0,
          te
        );
        break;
      case 11:
        e = cd(
          a,
          e,
          e.pendingProps,
          e.type.render,
          e.ref,
          te
        );
        break;
      case 5:
        cu(e);
      default:
        bd(a, e), e = Xt = vs(e, yo), e = gd(a, e, yo);
    }
    t.memoizedProps = t.pendingProps, e === null ? Xs(t) : Xt = e;
  }
  function Ul(t, e, a, n) {
    dn = uo = null, cu(e), vl = null, vr = 0;
    var o = e.return;
    try {
      if (Ip(
        t,
        o,
        e,
        a,
        te
      )) {
        Re = 1, Ls(
          t,
          ga(a, t.current)
        ), Xt = null;
        return;
      }
    } catch (i) {
      if (o !== null) throw Xt = o, i;
      Re = 1, Ls(
        t,
        ga(a, t.current)
      ), Xt = null;
      return;
    }
    e.flags & 32768 ? (Ft || n === 1 ? t = !0 : Rl || (te & 536870912) !== 0 ? t = !1 : (Xo = t = !0, (n === 2 || n === 9 || n === 3 || n === 6) && (n = $a.current, n !== null && n.tag === 13 && (n.flags |= 16384))), Zd(e, t)) : Xs(e);
  }
  function Xs(t) {
    var e = t;
    do {
      if ((e.flags & 32768) !== 0) {
        Zd(
          e,
          Xo
        );
        return;
      }
      t = e.return;
      var a = Jp(
        e.alternate,
        e,
        yo
      );
      if (a !== null) {
        Xt = a;
        return;
      }
      if (e = e.sibling, e !== null) {
        Xt = e;
        return;
      }
      Xt = e = t;
    } while (e !== null);
    Re === 0 && (Re = 5);
  }
  function Zd(t, e) {
    do {
      var a = Pp(t.alternate, t);
      if (a !== null) {
        a.flags &= 32767, Xt = a;
        return;
      }
      if (a = t.return, a !== null && (a.flags |= 32768, a.subtreeFlags = 0, a.deletions = null), !e && (t = t.sibling, t !== null)) {
        Xt = t;
        return;
      }
      Xt = t = a;
    } while (t !== null);
    Re = 6, Xt = null;
  }
  function Wd(t, e, a, n, o, i, f, d, E) {
    t.cancelPendingCommit = null;
    do
      Js();
    while (_e !== 0);
    if ((oe & 6) !== 0) throw Error(c(327));
    if (e !== null) {
      if (e === t.current) throw Error(c(177));
      if (i = e.lanes | e.childLanes, i |= ar, ui(
        t,
        a,
        i,
        f,
        d,
        E
      ), t === fe && (Xt = fe = null, te = 0), Tl = e, _o = t, Cl = a, Hu = i, Zu = o, Dd = n, (e.subtreeFlags & 10256) !== 0 || (e.flags & 10256) !== 0 ? (t.callbackNode = null, t.callbackPriority = 0, cg(nn, function() {
        return Jd(), null;
      })) : (t.callbackNode = null, t.callbackPriority = 0), n = (e.flags & 13878) !== 0, (e.subtreeFlags & 13878) !== 0 || n) {
        n = q.T, q.T = null, o = O.p, O.p = 2, f = oe, oe |= 4;
        try {
          _p(t, e, a);
        } finally {
          oe = f, O.p = o, q.T = n;
        }
      }
      _e = 1, Fd(), Gd(), Id();
    }
  }
  function Fd() {
    if (_e === 1) {
      _e = 0;
      var t = _o, e = Tl, a = (e.flags & 13878) !== 0;
      if ((e.subtreeFlags & 13878) !== 0 || a) {
        a = q.T, q.T = null;
        var n = O.p;
        O.p = 2;
        var o = oe;
        oe |= 4;
        try {
          Cd(e, t);
          var i = lh, f = _l(t.containerInfo), d = i.focusedElem, E = i.selectionRange;
          if (f !== d && d && d.ownerDocument && st(
            d.ownerDocument.documentElement,
            d
          )) {
            if (E !== null && Ti(d)) {
              var V = E.start, F = E.end;
              if (F === void 0 && (F = V), "selectionStart" in d)
                d.selectionStart = V, d.selectionEnd = Math.min(
                  F,
                  d.value.length
                );
              else {
                var X = d.ownerDocument || document, D = X && X.defaultView || window;
                if (D.getSelection) {
                  var z = D.getSelection(), Dt = d.textContent.length, St = Math.min(E.start, Dt), se = E.end === void 0 ? St : Math.min(E.end, Dt);
                  !z.extend && St > se && (f = se, se = St, St = f);
                  var U = hs(
                    d,
                    St
                  ), T = hs(
                    d,
                    se
                  );
                  if (U && T && (z.rangeCount !== 1 || z.anchorNode !== U.node || z.anchorOffset !== U.offset || z.focusNode !== T.node || z.focusOffset !== T.offset)) {
                    var B = X.createRange();
                    B.setStart(U.node, U.offset), z.removeAllRanges(), St > se ? (z.addRange(B), z.extend(T.node, T.offset)) : (B.setEnd(T.node, T.offset), z.addRange(B));
                  }
                }
              }
            }
            for (X = [], z = d; z = z.parentNode; )
              z.nodeType === 1 && X.push({
                element: z,
                left: z.scrollLeft,
                top: z.scrollTop
              });
            for (typeof d.focus == "function" && d.focus(), d = 0; d < X.length; d++) {
              var I = X[d];
              I.element.scrollLeft = I.left, I.element.scrollTop = I.top;
            }
          }
          sc = !!ih, lh = ih = null;
        } finally {
          oe = o, O.p = n, q.T = a;
        }
      }
      t.current = e, _e = 2;
    }
  }
  function Gd() {
    if (_e === 2) {
      _e = 0;
      var t = _o, e = Tl, a = (e.flags & 8772) !== 0;
      if ((e.subtreeFlags & 8772) !== 0 || a) {
        a = q.T, q.T = null;
        var n = O.p;
        O.p = 2;
        var o = oe;
        oe |= 4;
        try {
          Ed(t, e.alternate, e);
        } finally {
          oe = o, O.p = n, q.T = a;
        }
      }
      _e = 3;
    }
  }
  function Id() {
    if (_e === 4 || _e === 3) {
      _e = 0, Zi();
      var t = _o, e = Tl, a = Cl, n = Dd;
      (e.subtreeFlags & 10256) !== 0 || (e.flags & 10256) !== 0 ? _e = 5 : (_e = 0, Tl = _o = null, Xd(t, t.pendingLanes));
      var o = t.pendingLanes;
      if (o === 0 && (Po = null), bt(a), e = e.stateNode, Se && typeof Se.onCommitFiberRoot == "function")
        try {
          Se.onCommitFiberRoot(
            Za,
            e,
            void 0,
            (e.current.flags & 128) === 128
          );
        } catch {
        }
      if (n !== null) {
        e = q.T, o = O.p, O.p = 2, q.T = null;
        try {
          for (var i = t.onRecoverableError, f = 0; f < n.length; f++) {
            var d = n[f];
            i(d.value, {
              componentStack: d.stack
            });
          }
        } finally {
          q.T = e, O.p = o;
        }
      }
      (Cl & 3) !== 0 && Js(), Qn(t), o = t.pendingLanes, (a & 4194090) !== 0 && (o & 42) !== 0 ? t === Wu ? Ur++ : (Ur = 0, Wu = t) : Ur = 0, jr(0);
    }
  }
  function Xd(t, e) {
    (t.pooledCacheLanes &= e) === 0 && (e = t.pooledCache, e != null && (t.pooledCache = null, Zt(e)));
  }
  function Js(t) {
    return Fd(), Gd(), Id(), Jd();
  }
  function Jd() {
    if (_e !== 5) return !1;
    var t = _o, e = Hu;
    Hu = 0;
    var a = bt(Cl), n = q.T, o = O.p;
    try {
      O.p = 32 > a ? 32 : a, q.T = null, a = Zu, Zu = null;
      var i = _o, f = Cl;
      if (_e = 0, Tl = _o = null, Cl = 0, (oe & 6) !== 0) throw Error(c(331));
      var d = oe;
      if (oe |= 4, Bd(i.current), Ud(
        i,
        i.current,
        f,
        a
      ), oe = d, jr(0, !1), Se && typeof Se.onPostCommitFiberRoot == "function")
        try {
          Se.onPostCommitFiberRoot(Za, i);
        } catch {
        }
      return !0;
    } finally {
      O.p = o, q.T = n, Xd(t, e);
    }
  }
  function Pd(t, e, a) {
    e = ga(a, e), e = wu(t.stateNode, e, 2), t = Ko(t, e, 2), t !== null && (An(t, 2), Qn(t));
  }
  function he(t, e, a) {
    if (t.tag === 3)
      Pd(t, t, a);
    else
      for (; e !== null; ) {
        if (e.tag === 3) {
          Pd(
            e,
            t,
            a
          );
          break;
        } else if (e.tag === 1) {
          var n = e.stateNode;
          if (typeof e.type.getDerivedStateFromError == "function" || typeof n.componentDidCatch == "function" && (Po === null || !Po.has(n))) {
            t = ga(a, t), a = ed(2), n = Ko(e, a, 2), n !== null && (ad(
              a,
              n,
              e,
              t
            ), An(n, 2), Qn(n));
            break;
          }
        }
        e = e.return;
      }
  }
  function Xu(t, e, a) {
    var n = t.pingCache;
    if (n === null) {
      n = t.pingCache = new eg();
      var o = /* @__PURE__ */ new Set();
      n.set(e, o);
    } else
      o = n.get(e), o === void 0 && (o = /* @__PURE__ */ new Set(), n.set(e, o));
    o.has(a) || (Qu = !0, o.add(a), t = lg.bind(null, t, e, a), e.then(t, t));
  }
  function lg(t, e, a) {
    var n = t.pingCache;
    n !== null && n.delete(e), t.pingedLanes |= t.suspendedLanes & a, t.warmLanes &= ~a, fe === t && (te & a) === a && (Re === 4 || Re === 3 && (te & 62914560) === te && 300 > ea() - Ku ? (oe & 2) === 0 && Nl(t, 0) : Lu |= a, Sl === te && (Sl = 0)), Qn(t);
  }
  function _d(t, e) {
    e === 0 && (e = Ge()), t = Vo(t, e), t !== null && (An(t, e), Qn(t));
  }
  function rg(t) {
    var e = t.memoizedState, a = 0;
    e !== null && (a = e.retryLane), _d(t, a);
  }
  function sg(t, e) {
    var a = 0;
    switch (t.tag) {
      case 13:
        var n = t.stateNode, o = t.memoizedState;
        o !== null && (a = o.retryLane);
        break;
      case 19:
        n = t.stateNode;
        break;
      case 22:
        n = t.stateNode._retryCache;
        break;
      default:
        throw Error(c(314));
    }
    n !== null && n.delete(e), _d(t, a);
  }
  function cg(t, e) {
    return Oe(t, e);
  }
  var Ps = null, jl = null, Ju = !1, _s = !1, Pu = !1, zi = 0;
  function Qn(t) {
    t !== jl && t.next === null && (jl === null ? Ps = jl = t : jl = jl.next = t), _s = !0, Ju || (Ju = !0, hg());
  }
  function jr(t, e) {
    if (!Pu && _s) {
      Pu = !0;
      do
        for (var a = !1, n = Ps; n !== null; ) {
          if (t !== 0) {
            var o = n.pendingLanes;
            if (o === 0) var i = 0;
            else {
              var f = n.suspendedLanes, d = n.pingedLanes;
              i = (1 << 31 - be(42 | t) + 1) - 1, i &= o & ~(f & ~d), i = i & 201326741 ? i & 201326741 | 1 : i ? i | 2 : 0;
            }
            i !== 0 && (a = !0, a0(n, i));
          } else
            i = te, i = Fa(
              n,
              n === fe ? i : 0,
              n.cancelPendingCommit !== null || n.timeoutHandle !== -1
            ), (i & 3) === 0 || oa(n, i) || (a = !0, a0(n, i));
          n = n.next;
        }
      while (a);
      Pu = !1;
    }
  }
  function ug() {
    $d();
  }
  function $d() {
    _s = Ju = !1;
    var t = 0;
    zi !== 0 && (yg() && (t = zi), zi = 0);
    for (var e = ea(), a = null, n = Ps; n !== null; ) {
      var o = n.next, i = t0(n, e);
      i === 0 ? (n.next = null, a === null ? Ps = o : a.next = o, o === null && (jl = a)) : (a = n, (t !== 0 || (i & 3) !== 0) && (_s = !0)), n = o;
    }
    jr(t);
  }
  function t0(t, e) {
    for (var a = t.suspendedLanes, n = t.pingedLanes, o = t.expirationTimes, i = t.pendingLanes & -62914561; 0 < i; ) {
      var f = 31 - be(i), d = 1 << f, E = o[f];
      E === -1 ? ((d & a) === 0 || (d & n) !== 0) && (o[f] = yn(d, e)) : E <= e && (t.expiredLanes |= d), i &= ~d;
    }
    if (e = fe, a = te, a = Fa(
      t,
      t === e ? a : 0,
      t.cancelPendingCommit !== null || t.timeoutHandle !== -1
    ), n = t.callbackNode, a === 0 || t === e && (ie === 2 || ie === 9) || t.cancelPendingCommit !== null)
      return n !== null && n !== null && bn(n), t.callbackNode = null, t.callbackPriority = 0;
    if ((a & 3) === 0 || oa(t, a)) {
      if (e = a & -a, e === t.callbackPriority) return e;
      switch (n !== null && bn(n), bt(a)) {
        case 2:
        case 8:
          a = On;
          break;
        case 32:
          a = nn;
          break;
        case 268435456:
          a = ri;
          break;
        default:
          a = nn;
      }
      return n = e0.bind(null, t), a = Oe(a, n), t.callbackPriority = e, t.callbackNode = a, e;
    }
    return n !== null && n !== null && bn(n), t.callbackPriority = 2, t.callbackNode = null, 2;
  }
  function e0(t, e) {
    if (_e !== 0 && _e !== 5)
      return t.callbackNode = null, t.callbackPriority = 0, null;
    var a = t.callbackNode;
    if (Js() && t.callbackNode !== a)
      return null;
    var n = te;
    return n = Fa(
      t,
      t === fe ? n : 0,
      t.cancelPendingCommit !== null || t.timeoutHandle !== -1
    ), n === 0 ? null : (zd(t, n, e), t0(t, ea()), t.callbackNode != null && t.callbackNode === a ? e0.bind(null, t) : null);
  }
  function a0(t, e) {
    if (Js()) return null;
    zd(t, e, !0);
  }
  function hg() {
    vg(function() {
      (oe & 6) !== 0 ? Oe(
        aa,
        ug
      ) : $d();
    });
  }
  function _u() {
    return zi === 0 && (zi = Hn()), zi;
  }
  function n0(t) {
    return t == null || typeof t == "symbol" || typeof t == "boolean" ? null : typeof t == "function" ? t : yi("" + t);
  }
  function o0(t, e) {
    var a = e.ownerDocument.createElement("input");
    return a.name = e.name, a.value = e.value, t.id && a.setAttribute("form", t.id), e.parentNode.insertBefore(a, e), t = new FormData(t), a.parentNode.removeChild(a), t;
  }
  function fg(t, e, a, n, o) {
    if (e === "submit" && a && a.stateNode === o) {
      var i = n0(
        (o[dt] || null).action
      ), f = n.submitter;
      f && (e = (e = f[dt] || null) ? n0(e.formAction) : f.getAttribute("formAction"), e !== null && (i = e, f = null));
      var d = new En(
        "action",
        "action",
        null,
        n,
        o
      );
      t.push({
        event: d,
        listeners: [
          {
            instance: null,
            listener: function() {
              if (n.defaultPrevented) {
                if (zi !== 0) {
                  var E = f ? o0(o, f) : new FormData(o);
                  xu(
                    a,
                    {
                      pending: !0,
                      data: E,
                      method: o.method,
                      action: i
                    },
                    null,
                    E
                  );
                }
              } else
                typeof i == "function" && (d.preventDefault(), E = f ? o0(o, f) : new FormData(o), xu(
                  a,
                  {
                    pending: !0,
                    data: E,
                    method: o.method,
                    action: i
                  },
                  i,
                  E
                ));
            },
            currentTarget: o
          }
        ]
      });
    }
  }
  for (var $u = 0; $u < io.length; $u++) {
    var th = io[$u], dg = th.toLowerCase(), pg = th[0].toUpperCase() + th.slice(1);
    pa(
      dg,
      "on" + pg
    );
  }
  pa(gs, "onAnimationEnd"), pa(ms, "onAnimationIteration"), pa(bs, "onAnimationStart"), pa("dblclick", "onDoubleClick"), pa("focusin", "onFocus"), pa("focusout", "onBlur"), pa(Xc, "onTransitionRun"), pa(jn, "onTransitionStart"), pa(xs, "onTransitionCancel"), pa(er, "onTransitionEnd"), vn("onMouseEnter", ["mouseout", "mouseover"]), vn("onMouseLeave", ["mouseout", "mouseover"]), vn("onPointerEnter", ["pointerout", "pointerover"]), vn("onPointerLeave", ["pointerout", "pointerover"]), ln(
    "onChange",
    "change click focusin focusout input keydown keyup selectionchange".split(" ")
  ), ln(
    "onSelect",
    "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(
      " "
    )
  ), ln("onBeforeInput", [
    "compositionend",
    "keypress",
    "textInput",
    "paste"
  ]), ln(
    "onCompositionEnd",
    "compositionend focusout keydown keypress keyup mousedown".split(" ")
  ), ln(
    "onCompositionStart",
    "compositionstart focusout keydown keypress keyup mousedown".split(" ")
  ), ln(
    "onCompositionUpdate",
    "compositionupdate focusout keydown keypress keyup mousedown".split(" ")
  );
  var kr = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(
    " "
  ), gg = new Set(
    "beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(kr)
  );
  function i0(t, e) {
    e = (e & 4) !== 0;
    for (var a = 0; a < t.length; a++) {
      var n = t[a], o = n.event;
      n = n.listeners;
      t: {
        var i = void 0;
        if (e)
          for (var f = n.length - 1; 0 <= f; f--) {
            var d = n[f], E = d.instance, V = d.currentTarget;
            if (d = d.listener, E !== i && o.isPropagationStopped())
              break t;
            i = d, o.currentTarget = V;
            try {
              i(o);
            } catch (F) {
              Qs(F);
            }
            o.currentTarget = null, i = E;
          }
        else
          for (f = 0; f < n.length; f++) {
            if (d = n[f], E = d.instance, V = d.currentTarget, d = d.listener, E !== i && o.isPropagationStopped())
              break t;
            i = d, o.currentTarget = V;
            try {
              i(o);
            } catch (F) {
              Qs(F);
            }
            o.currentTarget = null, i = E;
          }
      }
    }
  }
  function Jt(t, e) {
    var a = e[Ht];
    a === void 0 && (a = e[Ht] = /* @__PURE__ */ new Set());
    var n = t + "__bubble";
    a.has(n) || (l0(e, t, 2, !1), a.add(n));
  }
  function eh(t, e, a) {
    var n = 0;
    e && (n |= 4), l0(
      a,
      t,
      n,
      e
    );
  }
  var $s = "_reactListening" + Math.random().toString(36).slice(2);
  function ah(t) {
    if (!t[$s]) {
      t[$s] = !0, Ql.forEach(function(a) {
        a !== "selectionchange" && (gg.has(a) || eh(a, !1, t), eh(a, !0, t));
      });
      var e = t.nodeType === 9 ? t : t.ownerDocument;
      e === null || e[$s] || (e[$s] = !0, eh("selectionchange", !1, e));
    }
  }
  function l0(t, e, a, n) {
    switch (U0(e)) {
      case 2:
        var o = Kg;
        break;
      case 8:
        o = Hg;
        break;
      default:
        o = mh;
    }
    a = o.bind(
      null,
      e,
      a,
      t
    ), o = void 0, !Da || e !== "touchstart" && e !== "touchmove" && e !== "wheel" || (o = !0), n ? o !== void 0 ? t.addEventListener(e, a, {
      capture: !0,
      passive: o
    }) : t.addEventListener(e, a, !0) : o !== void 0 ? t.addEventListener(e, a, {
      passive: o
    }) : t.addEventListener(e, a, !1);
  }
  function nh(t, e, a, n, o) {
    var i = n;
    if ((e & 1) === 0 && (e & 2) === 0 && n !== null)
      t: for (; ; ) {
        if (n === null) return;
        var f = n.tag;
        if (f === 3 || f === 4) {
          var d = n.stateNode.containerInfo;
          if (d === o) break;
          if (f === 4)
            for (f = n.return; f !== null; ) {
              var E = f.tag;
              if ((E === 3 || E === 4) && f.stateNode.containerInfo === o)
                return;
              f = f.return;
            }
          for (; d !== null; ) {
            if (f = Aa(d), f === null) return;
            if (E = f.tag, E === 5 || E === 6 || E === 26 || E === 27) {
              n = i = f;
              continue t;
            }
            d = d.parentNode;
          }
        }
        n = n.return;
      }
    qe(function() {
      var V = i, F = rn(a), X = [];
      t: {
        var D = ys.get(t);
        if (D !== void 0) {
          var z = En, Dt = t;
          switch (t) {
            case "keypress":
              if (Pn(a) === 0) break t;
            case "keydown":
            case "keyup":
              z = Wl;
              break;
            case "focusin":
              Dt = "focus", z = Sn;
              break;
            case "focusout":
              Dt = "blur", z = Sn;
              break;
            case "beforeblur":
            case "afterblur":
              z = Sn;
              break;
            case "click":
              if (a.button === 2) break t;
            case "auxclick":
            case "dblclick":
            case "mousedown":
            case "mousemove":
            case "mouseup":
            case "mouseout":
            case "mouseover":
            case "contextmenu":
              z = os;
              break;
            case "drag":
            case "dragend":
            case "dragenter":
            case "dragexit":
            case "dragleave":
            case "dragover":
            case "dragstart":
            case "drop":
              z = to;
              break;
            case "touchcancel":
            case "touchend":
            case "touchmove":
            case "touchstart":
              z = fa;
              break;
            case gs:
            case ms:
            case bs:
              z = $i;
              break;
            case er:
              z = _;
              break;
            case "scroll":
            case "scrollend":
              z = $n;
              break;
            case "wheel":
              z = ls;
              break;
            case "copy":
            case "cut":
            case "paste":
              z = Zc;
              break;
            case "gotpointercapture":
            case "lostpointercapture":
            case "pointercancel":
            case "pointerdown":
            case "pointermove":
            case "pointerout":
            case "pointerover":
            case "pointerup":
              z = el;
              break;
            case "toggle":
            case "beforetoggle":
              z = al;
          }
          var St = (e & 4) !== 0, se = !St && (t === "scroll" || t === "scrollend"), U = St ? D !== null ? D + "Capture" : null : D;
          St = [];
          for (var T = V, B; T !== null; ) {
            var I = T;
            if (B = I.stateNode, I = I.tag, I !== 5 && I !== 26 && I !== 27 || B === null || U === null || (I = ua(T, U), I != null && St.push(
              Br(T, I, B)
            )), se) break;
            T = T.return;
          }
          0 < St.length && (D = new z(
            D,
            Dt,
            null,
            a,
            F
          ), X.push({ event: D, listeners: St }));
        }
      }
      if ((e & 7) === 0) {
        t: {
          if (D = t === "mouseover" || t === "pointerover", z = t === "mouseout" || t === "pointerout", D && a !== Ai && (Dt = a.relatedTarget || a.fromElement) && (Aa(Dt) || Dt[Ot]))
            break t;
          if ((z || D) && (D = F.window === F ? F : (D = F.ownerDocument) ? D.defaultView || D.parentWindow : window, z ? (Dt = a.relatedTarget || a.toElement, z = V, Dt = Dt ? Aa(Dt) : null, Dt !== null && (se = m(Dt), St = Dt.tag, Dt !== se || St !== 5 && St !== 27 && St !== 6) && (Dt = null)) : (z = null, Dt = V), z !== Dt)) {
            if (St = os, I = "onMouseLeave", U = "onMouseEnter", T = "mouse", (t === "pointerout" || t === "pointerover") && (St = el, I = "onPointerLeave", U = "onPointerEnter", T = "pointer"), se = z == null ? D : hi(z), B = Dt == null ? D : hi(Dt), D = new St(
              I,
              T + "leave",
              z,
              a,
              F
            ), D.target = se, D.relatedTarget = B, I = null, Aa(F) === V && (St = new St(
              U,
              T + "enter",
              Dt,
              a,
              F
            ), St.target = B, St.relatedTarget = se, I = St), se = I, z && Dt)
              e: {
                for (St = z, U = Dt, T = 0, B = St; B; B = kl(B))
                  T++;
                for (B = 0, I = U; I; I = kl(I))
                  B++;
                for (; 0 < T - B; )
                  St = kl(St), T--;
                for (; 0 < B - T; )
                  U = kl(U), B--;
                for (; T--; ) {
                  if (St === U || U !== null && St === U.alternate)
                    break e;
                  St = kl(St), U = kl(U);
                }
                St = null;
              }
            else St = null;
            z !== null && r0(
              X,
              D,
              z,
              St,
              !1
            ), Dt !== null && se !== null && r0(
              X,
              se,
              Dt,
              St,
              !0
            );
          }
        }
        t: {
          if (D = V ? hi(V) : window, z = D.nodeName && D.nodeName.toLowerCase(), z === "select" || z === "input" && D.type === "file")
            var gt = Ja;
          else if (jo(D))
            if (ll)
              gt = Gc;
            else {
              gt = cs;
              var Gt = Wc;
            }
          else
            z = D.nodeName, !z || z.toLowerCase() !== "input" || D.type !== "checkbox" && D.type !== "radio" ? V && Pi(V.elementType) && (gt = Ja) : gt = Fc;
          if (gt && (gt = gt(t, V))) {
            Ce(
              X,
              gt,
              a,
              F
            );
            break t;
          }
          Gt && Gt(t, D, V), t === "focusout" && V && D.type === "number" && V.memoizedProps.value != null && Xi(D, "number", D.value);
        }
        switch (Gt = V ? hi(V) : window, t) {
          case "focusin":
            (jo(Gt) || Gt.contentEditable === "true") && (ko = Gt, $l = V, Ci = null);
            break;
          case "focusout":
            Ci = $l = ko = null;
            break;
          case "mousedown":
            tr = !0;
            break;
          case "contextmenu":
          case "mouseup":
          case "dragend":
            tr = !1, ds(X, a, F);
            break;
          case "selectionchange":
            if (fs) break;
          case "keydown":
          case "keyup":
            ds(X, a, F);
        }
        var At;
        if (Xl)
          t: {
            switch (t) {
              case "compositionstart":
                var jt = "onCompositionStart";
                break t;
              case "compositionend":
                jt = "onCompositionEnd";
                break t;
              case "compositionupdate":
                jt = "onCompositionUpdate";
                break t;
            }
            jt = void 0;
          }
        else
          Ut ? nl(t, a) && (jt = "onCompositionEnd") : t === "keydown" && a.keyCode === 229 && (jt = "onCompositionStart");
        jt && (Uo && a.locale !== "ko" && (Ut || jt !== "onCompositionStart" ? jt === "onCompositionEnd" && Ut && (At = ns()) : (va = F, Jn = "value" in va ? va.value : va.textContent, Ut = !0)), Gt = tc(V, jt), 0 < Gt.length && (jt = new Qe(
          jt,
          t,
          null,
          a,
          F
        ), X.push({ event: jt, listeners: Gt }), At ? jt.data = At : (At = Jl(a), At !== null && (jt.data = At)))), (At = Be ? ye(t, a) : ol(t, a)) && (jt = tc(V, "onBeforeInput"), 0 < jt.length && (Gt = new Qe(
          "onBeforeInput",
          "beforeinput",
          null,
          a,
          F
        ), X.push({
          event: Gt,
          listeners: jt
        }), Gt.data = At)), fg(
          X,
          t,
          V,
          a,
          F
        );
      }
      i0(X, e);
    });
  }
  function Br(t, e, a) {
    return {
      instance: t,
      listener: e,
      currentTarget: a
    };
  }
  function tc(t, e) {
    for (var a = e + "Capture", n = []; t !== null; ) {
      var o = t, i = o.stateNode;
      if (o = o.tag, o !== 5 && o !== 26 && o !== 27 || i === null || (o = ua(t, a), o != null && n.unshift(
        Br(t, o, i)
      ), o = ua(t, e), o != null && n.push(
        Br(t, o, i)
      )), t.tag === 3) return n;
      t = t.return;
    }
    return [];
  }
  function kl(t) {
    if (t === null) return null;
    do
      t = t.return;
    while (t && t.tag !== 5 && t.tag !== 27);
    return t || null;
  }
  function r0(t, e, a, n, o) {
    for (var i = e._reactName, f = []; a !== null && a !== n; ) {
      var d = a, E = d.alternate, V = d.stateNode;
      if (d = d.tag, E !== null && E === n) break;
      d !== 5 && d !== 26 && d !== 27 || V === null || (E = V, o ? (V = ua(a, i), V != null && f.unshift(
        Br(a, V, E)
      )) : o || (V = ua(a, i), V != null && f.push(
        Br(a, V, E)
      ))), a = a.return;
    }
    f.length !== 0 && t.push({ event: e, listeners: f });
  }
  var mg = /\r\n?/g, bg = /\u0000|\uFFFD/g;
  function s0(t) {
    return (typeof t == "string" ? t : "" + t).replace(mg, `
`).replace(bg, "");
  }
  function c0(t, e) {
    return e = s0(e), s0(t) === e;
  }
  function ec() {
  }
  function re(t, e, a, n, o, i) {
    switch (a) {
      case "children":
        typeof n == "string" ? e === "body" || e === "textarea" && n === "" || Ro(t, n) : (typeof n == "number" || typeof n == "bigint") && e !== "body" && Ro(t, "" + n);
        break;
      case "className":
        pi(t, "class", n);
        break;
      case "tabIndex":
        pi(t, "tabindex", n);
        break;
      case "dir":
      case "role":
      case "viewBox":
      case "width":
      case "height":
        pi(t, a, n);
        break;
      case "style":
        xi(t, n, i);
        break;
      case "data":
        if (e !== "object") {
          pi(t, "data", n);
          break;
        }
      case "src":
      case "href":
        if (n === "" && (e !== "a" || a !== "href")) {
          t.removeAttribute(a);
          break;
        }
        if (n == null || typeof n == "function" || typeof n == "symbol" || typeof n == "boolean") {
          t.removeAttribute(a);
          break;
        }
        n = yi("" + n), t.setAttribute(a, n);
        break;
      case "action":
      case "formAction":
        if (typeof n == "function") {
          t.setAttribute(
            a,
            "javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')"
          );
          break;
        } else
          typeof i == "function" && (a === "formAction" ? (e !== "input" && re(t, e, "name", o.name, o, null), re(
            t,
            e,
            "formEncType",
            o.formEncType,
            o,
            null
          ), re(
            t,
            e,
            "formMethod",
            o.formMethod,
            o,
            null
          ), re(
            t,
            e,
            "formTarget",
            o.formTarget,
            o,
            null
          )) : (re(t, e, "encType", o.encType, o, null), re(t, e, "method", o.method, o, null), re(t, e, "target", o.target, o, null)));
        if (n == null || typeof n == "symbol" || typeof n == "boolean") {
          t.removeAttribute(a);
          break;
        }
        n = yi("" + n), t.setAttribute(a, n);
        break;
      case "onClick":
        n != null && (t.onclick = ec);
        break;
      case "onScroll":
        n != null && Jt("scroll", t);
        break;
      case "onScrollEnd":
        n != null && Jt("scrollend", t);
        break;
      case "dangerouslySetInnerHTML":
        if (n != null) {
          if (typeof n != "object" || !("__html" in n))
            throw Error(c(61));
          if (a = n.__html, a != null) {
            if (o.children != null) throw Error(c(60));
            t.innerHTML = a;
          }
        }
        break;
      case "multiple":
        t.multiple = n && typeof n != "function" && typeof n != "symbol";
        break;
      case "muted":
        t.muted = n && typeof n != "function" && typeof n != "symbol";
        break;
      case "suppressContentEditableWarning":
      case "suppressHydrationWarning":
      case "defaultValue":
      case "defaultChecked":
      case "innerHTML":
      case "ref":
        break;
      case "autoFocus":
        break;
      case "xlinkHref":
        if (n == null || typeof n == "function" || typeof n == "boolean" || typeof n == "symbol") {
          t.removeAttribute("xlink:href");
          break;
        }
        a = yi("" + n), t.setAttributeNS(
          "http://www.w3.org/1999/xlink",
          "xlink:href",
          a
        );
        break;
      case "contentEditable":
      case "spellCheck":
      case "draggable":
      case "value":
      case "autoReverse":
      case "externalResourcesRequired":
      case "focusable":
      case "preserveAlpha":
        n != null && typeof n != "function" && typeof n != "symbol" ? t.setAttribute(a, "" + n) : t.removeAttribute(a);
        break;
      case "inert":
      case "allowFullScreen":
      case "async":
      case "autoPlay":
      case "controls":
      case "default":
      case "defer":
      case "disabled":
      case "disablePictureInPicture":
      case "disableRemotePlayback":
      case "formNoValidate":
      case "hidden":
      case "loop":
      case "noModule":
      case "noValidate":
      case "open":
      case "playsInline":
      case "readOnly":
      case "required":
      case "reversed":
      case "scoped":
      case "seamless":
      case "itemScope":
        n && typeof n != "function" && typeof n != "symbol" ? t.setAttribute(a, "") : t.removeAttribute(a);
        break;
      case "capture":
      case "download":
        n === !0 ? t.setAttribute(a, "") : n !== !1 && n != null && typeof n != "function" && typeof n != "symbol" ? t.setAttribute(a, n) : t.removeAttribute(a);
        break;
      case "cols":
      case "rows":
      case "size":
      case "span":
        n != null && typeof n != "function" && typeof n != "symbol" && !isNaN(n) && 1 <= n ? t.setAttribute(a, n) : t.removeAttribute(a);
        break;
      case "rowSpan":
      case "start":
        n == null || typeof n == "function" || typeof n == "symbol" || isNaN(n) ? t.removeAttribute(a) : t.setAttribute(a, n);
        break;
      case "popover":
        Jt("beforetoggle", t), Jt("toggle", t), wo(t, "popover", n);
        break;
      case "xlinkActuate":
        ia(
          t,
          "http://www.w3.org/1999/xlink",
          "xlink:actuate",
          n
        );
        break;
      case "xlinkArcrole":
        ia(
          t,
          "http://www.w3.org/1999/xlink",
          "xlink:arcrole",
          n
        );
        break;
      case "xlinkRole":
        ia(
          t,
          "http://www.w3.org/1999/xlink",
          "xlink:role",
          n
        );
        break;
      case "xlinkShow":
        ia(
          t,
          "http://www.w3.org/1999/xlink",
          "xlink:show",
          n
        );
        break;
      case "xlinkTitle":
        ia(
          t,
          "http://www.w3.org/1999/xlink",
          "xlink:title",
          n
        );
        break;
      case "xlinkType":
        ia(
          t,
          "http://www.w3.org/1999/xlink",
          "xlink:type",
          n
        );
        break;
      case "xmlBase":
        ia(
          t,
          "http://www.w3.org/XML/1998/namespace",
          "xml:base",
          n
        );
        break;
      case "xmlLang":
        ia(
          t,
          "http://www.w3.org/XML/1998/namespace",
          "xml:lang",
          n
        );
        break;
      case "xmlSpace":
        ia(
          t,
          "http://www.w3.org/XML/1998/namespace",
          "xml:space",
          n
        );
        break;
      case "is":
        wo(t, "is", n);
        break;
      case "innerText":
      case "textContent":
        break;
      default:
        (!(2 < a.length) || a[0] !== "o" && a[0] !== "O" || a[1] !== "n" && a[1] !== "N") && (a = _i.get(a) || a, wo(t, a, n));
    }
  }
  function oh(t, e, a, n, o, i) {
    switch (a) {
      case "style":
        xi(t, n, i);
        break;
      case "dangerouslySetInnerHTML":
        if (n != null) {
          if (typeof n != "object" || !("__html" in n))
            throw Error(c(61));
          if (a = n.__html, a != null) {
            if (o.children != null) throw Error(c(60));
            t.innerHTML = a;
          }
        }
        break;
      case "children":
        typeof n == "string" ? Ro(t, n) : (typeof n == "number" || typeof n == "bigint") && Ro(t, "" + n);
        break;
      case "onScroll":
        n != null && Jt("scroll", t);
        break;
      case "onScrollEnd":
        n != null && Jt("scrollend", t);
        break;
      case "onClick":
        n != null && (t.onclick = ec);
        break;
      case "suppressContentEditableWarning":
      case "suppressHydrationWarning":
      case "innerHTML":
      case "ref":
        break;
      case "innerText":
      case "textContent":
        break;
      default:
        if (!Ga.hasOwnProperty(a))
          t: {
            if (a[0] === "o" && a[1] === "n" && (o = a.endsWith("Capture"), e = a.slice(2, o ? a.length - 7 : void 0), i = t[dt] || null, i = i != null ? i[a] : null, typeof i == "function" && t.removeEventListener(e, i, o), typeof n == "function")) {
              typeof i != "function" && i !== null && (a in t ? t[a] = null : t.hasAttribute(a) && t.removeAttribute(a)), t.addEventListener(e, n, o);
              break t;
            }
            a in t ? t[a] = n : n === !0 ? t.setAttribute(a, "") : wo(t, a, n);
          }
    }
  }
  function $e(t, e, a) {
    switch (e) {
      case "div":
      case "span":
      case "svg":
      case "path":
      case "a":
      case "g":
      case "p":
      case "li":
        break;
      case "img":
        Jt("error", t), Jt("load", t);
        var n = !1, o = !1, i;
        for (i in a)
          if (a.hasOwnProperty(i)) {
            var f = a[i];
            if (f != null)
              switch (i) {
                case "src":
                  n = !0;
                  break;
                case "srcSet":
                  o = !0;
                  break;
                case "children":
                case "dangerouslySetInnerHTML":
                  throw Error(c(137, e));
                default:
                  re(t, e, i, f, a, null);
              }
          }
        o && re(t, e, "srcSet", a.srcSet, a, null), n && re(t, e, "src", a.src, a, null);
        return;
      case "input":
        Jt("invalid", t);
        var d = i = f = o = null, E = null, V = null;
        for (n in a)
          if (a.hasOwnProperty(n)) {
            var F = a[n];
            if (F != null)
              switch (n) {
                case "name":
                  o = F;
                  break;
                case "type":
                  f = F;
                  break;
                case "checked":
                  E = F;
                  break;
                case "defaultChecked":
                  V = F;
                  break;
                case "value":
                  i = F;
                  break;
                case "defaultValue":
                  d = F;
                  break;
                case "children":
                case "dangerouslySetInnerHTML":
                  if (F != null)
                    throw Error(c(137, e));
                  break;
                default:
                  re(t, e, n, F, a, null);
              }
          }
        Ie(
          t,
          i,
          d,
          E,
          V,
          f,
          o,
          !1
        ), Gn(t);
        return;
      case "select":
        Jt("invalid", t), n = f = i = null;
        for (o in a)
          if (a.hasOwnProperty(o) && (d = a[o], d != null))
            switch (o) {
              case "value":
                i = d;
                break;
              case "defaultValue":
                f = d;
                break;
              case "multiple":
                n = d;
              default:
                re(t, e, o, d, a, null);
            }
        e = i, a = f, t.multiple = !!n, e != null ? In(t, !!n, e, !1) : a != null && In(t, !!n, a, !0);
        return;
      case "textarea":
        Jt("invalid", t), i = o = n = null;
        for (f in a)
          if (a.hasOwnProperty(f) && (d = a[f], d != null))
            switch (f) {
              case "value":
                n = d;
                break;
              case "defaultValue":
                o = d;
                break;
              case "children":
                i = d;
                break;
              case "dangerouslySetInnerHTML":
                if (d != null) throw Error(c(91));
                break;
              default:
                re(t, e, f, d, a, null);
            }
        Ji(t, n, o, i), Gn(t);
        return;
      case "option":
        for (E in a)
          a.hasOwnProperty(E) && (n = a[E], n != null) && (E === "selected" ? t.selected = n && typeof n != "function" && typeof n != "symbol" : re(t, e, E, n, a, null));
        return;
      case "dialog":
        Jt("beforetoggle", t), Jt("toggle", t), Jt("cancel", t), Jt("close", t);
        break;
      case "iframe":
      case "object":
        Jt("load", t);
        break;
      case "video":
      case "audio":
        for (n = 0; n < kr.length; n++)
          Jt(kr[n], t);
        break;
      case "image":
        Jt("error", t), Jt("load", t);
        break;
      case "details":
        Jt("toggle", t);
        break;
      case "embed":
      case "source":
      case "link":
        Jt("error", t), Jt("load", t);
      case "area":
      case "base":
      case "br":
      case "col":
      case "hr":
      case "keygen":
      case "meta":
      case "param":
      case "track":
      case "wbr":
      case "menuitem":
        for (V in a)
          if (a.hasOwnProperty(V) && (n = a[V], n != null))
            switch (V) {
              case "children":
              case "dangerouslySetInnerHTML":
                throw Error(c(137, e));
              default:
                re(t, e, V, n, a, null);
            }
        return;
      default:
        if (Pi(e)) {
          for (F in a)
            a.hasOwnProperty(F) && (n = a[F], n !== void 0 && oh(
              t,
              e,
              F,
              n,
              a,
              void 0
            ));
          return;
        }
    }
    for (d in a)
      a.hasOwnProperty(d) && (n = a[d], n != null && re(t, e, d, n, a, null));
  }
  function xg(t, e, a, n) {
    switch (e) {
      case "div":
      case "span":
      case "svg":
      case "path":
      case "a":
      case "g":
      case "p":
      case "li":
        break;
      case "input":
        var o = null, i = null, f = null, d = null, E = null, V = null, F = null;
        for (z in a) {
          var X = a[z];
          if (a.hasOwnProperty(z) && X != null)
            switch (z) {
              case "checked":
                break;
              case "value":
                break;
              case "defaultValue":
                E = X;
              default:
                n.hasOwnProperty(z) || re(t, e, z, null, n, X);
            }
        }
        for (var D in n) {
          var z = n[D];
          if (X = a[D], n.hasOwnProperty(D) && (z != null || X != null))
            switch (D) {
              case "type":
                i = z;
                break;
              case "name":
                o = z;
                break;
              case "checked":
                V = z;
                break;
              case "defaultChecked":
                F = z;
                break;
              case "value":
                f = z;
                break;
              case "defaultValue":
                d = z;
                break;
              case "children":
              case "dangerouslySetInnerHTML":
                if (z != null)
                  throw Error(c(137, e));
                break;
              default:
                z !== X && re(
                  t,
                  e,
                  D,
                  z,
                  n,
                  X
                );
            }
        }
        Kl(
          t,
          f,
          d,
          E,
          V,
          F,
          i,
          o
        );
        return;
      case "select":
        z = f = d = D = null;
        for (i in a)
          if (E = a[i], a.hasOwnProperty(i) && E != null)
            switch (i) {
              case "value":
                break;
              case "multiple":
                z = E;
              default:
                n.hasOwnProperty(i) || re(
                  t,
                  e,
                  i,
                  null,
                  n,
                  E
                );
            }
        for (o in n)
          if (i = n[o], E = a[o], n.hasOwnProperty(o) && (i != null || E != null))
            switch (o) {
              case "value":
                D = i;
                break;
              case "defaultValue":
                d = i;
                break;
              case "multiple":
                f = i;
              default:
                i !== E && re(
                  t,
                  e,
                  o,
                  i,
                  n,
                  E
                );
            }
        e = d, a = f, n = z, D != null ? In(t, !!a, D, !1) : !!n != !!a && (e != null ? In(t, !!a, e, !0) : In(t, !!a, a ? [] : "", !1));
        return;
      case "textarea":
        z = D = null;
        for (d in a)
          if (o = a[d], a.hasOwnProperty(d) && o != null && !n.hasOwnProperty(d))
            switch (d) {
              case "value":
                break;
              case "children":
                break;
              default:
                re(t, e, d, null, n, o);
            }
        for (f in n)
          if (o = n[f], i = a[f], n.hasOwnProperty(f) && (o != null || i != null))
            switch (f) {
              case "value":
                D = o;
                break;
              case "defaultValue":
                z = o;
                break;
              case "children":
                break;
              case "dangerouslySetInnerHTML":
                if (o != null) throw Error(c(91));
                break;
              default:
                o !== i && re(t, e, f, o, n, i);
            }
        Mn(t, D, z);
        return;
      case "option":
        for (var Dt in a)
          D = a[Dt], a.hasOwnProperty(Dt) && D != null && !n.hasOwnProperty(Dt) && (Dt === "selected" ? t.selected = !1 : re(
            t,
            e,
            Dt,
            null,
            n,
            D
          ));
        for (E in n)
          D = n[E], z = a[E], n.hasOwnProperty(E) && D !== z && (D != null || z != null) && (E === "selected" ? t.selected = D && typeof D != "function" && typeof D != "symbol" : re(
            t,
            e,
            E,
            D,
            n,
            z
          ));
        return;
      case "img":
      case "link":
      case "area":
      case "base":
      case "br":
      case "col":
      case "embed":
      case "hr":
      case "keygen":
      case "meta":
      case "param":
      case "source":
      case "track":
      case "wbr":
      case "menuitem":
        for (var St in a)
          D = a[St], a.hasOwnProperty(St) && D != null && !n.hasOwnProperty(St) && re(t, e, St, null, n, D);
        for (V in n)
          if (D = n[V], z = a[V], n.hasOwnProperty(V) && D !== z && (D != null || z != null))
            switch (V) {
              case "children":
              case "dangerouslySetInnerHTML":
                if (D != null)
                  throw Error(c(137, e));
                break;
              default:
                re(
                  t,
                  e,
                  V,
                  D,
                  n,
                  z
                );
            }
        return;
      default:
        if (Pi(e)) {
          for (var se in a)
            D = a[se], a.hasOwnProperty(se) && D !== void 0 && !n.hasOwnProperty(se) && oh(
              t,
              e,
              se,
              void 0,
              n,
              D
            );
          for (F in n)
            D = n[F], z = a[F], !n.hasOwnProperty(F) || D === z || D === void 0 && z === void 0 || oh(
              t,
              e,
              F,
              D,
              n,
              z
            );
          return;
        }
    }
    for (var U in a)
      D = a[U], a.hasOwnProperty(U) && D != null && !n.hasOwnProperty(U) && re(t, e, U, null, n, D);
    for (X in n)
      D = n[X], z = a[X], !n.hasOwnProperty(X) || D === z || D == null && z == null || re(t, e, X, D, n, z);
  }
  var ih = null, lh = null;
  function ac(t) {
    return t.nodeType === 9 ? t : t.ownerDocument;
  }
  function u0(t) {
    switch (t) {
      case "http://www.w3.org/2000/svg":
        return 1;
      case "http://www.w3.org/1998/Math/MathML":
        return 2;
      default:
        return 0;
    }
  }
  function h0(t, e) {
    if (t === 0)
      switch (e) {
        case "svg":
          return 1;
        case "math":
          return 2;
        default:
          return 0;
      }
    return t === 1 && e === "foreignObject" ? 0 : t;
  }
  function rh(t, e) {
    return t === "textarea" || t === "noscript" || typeof e.children == "string" || typeof e.children == "number" || typeof e.children == "bigint" || typeof e.dangerouslySetInnerHTML == "object" && e.dangerouslySetInnerHTML !== null && e.dangerouslySetInnerHTML.__html != null;
  }
  var sh = null;
  function yg() {
    var t = window.event;
    return t && t.type === "popstate" ? t === sh ? !1 : (sh = t, !0) : (sh = null, !1);
  }
  var f0 = typeof setTimeout == "function" ? setTimeout : void 0, Ag = typeof clearTimeout == "function" ? clearTimeout : void 0, d0 = typeof Promise == "function" ? Promise : void 0, vg = typeof queueMicrotask == "function" ? queueMicrotask : typeof d0 < "u" ? function(t) {
    return d0.resolve(null).then(t).catch(Mg);
  } : f0;
  function Mg(t) {
    setTimeout(function() {
      throw t;
    });
  }
  function ti(t) {
    return t === "head";
  }
  function p0(t, e) {
    var a = e, n = 0, o = 0;
    do {
      var i = a.nextSibling;
      if (t.removeChild(a), i && i.nodeType === 8)
        if (a = i.data, a === "/$") {
          if (0 < n && 8 > n) {
            a = n;
            var f = t.ownerDocument;
            if (a & 1 && Vr(f.documentElement), a & 2 && Vr(f.body), a & 4)
              for (a = f.head, Vr(a), f = a.firstChild; f; ) {
                var d = f.nextSibling, E = f.nodeName;
                f[ke] || E === "SCRIPT" || E === "STYLE" || E === "LINK" && f.rel.toLowerCase() === "stylesheet" || a.removeChild(f), f = d;
              }
          }
          if (o === 0) {
            t.removeChild(i), Kr(e);
            return;
          }
          o--;
        } else
          a === "$" || a === "$?" || a === "$!" ? o++ : n = a.charCodeAt(0) - 48;
      else n = 0;
      a = i;
    } while (a);
    Kr(e);
  }
  function ch(t) {
    var e = t.firstChild;
    for (e && e.nodeType === 10 && (e = e.nextSibling); e; ) {
      var a = e;
      switch (e = e.nextSibling, a.nodeName) {
        case "HTML":
        case "HEAD":
        case "BODY":
          ch(a), Ke(a);
          continue;
        case "SCRIPT":
        case "STYLE":
          continue;
        case "LINK":
          if (a.rel.toLowerCase() === "stylesheet") continue;
      }
      t.removeChild(a);
    }
  }
  function wg(t, e, a, n) {
    for (; t.nodeType === 1; ) {
      var o = a;
      if (t.nodeName.toLowerCase() !== e.toLowerCase()) {
        if (!n && (t.nodeName !== "INPUT" || t.type !== "hidden"))
          break;
      } else if (n) {
        if (!t[ke])
          switch (e) {
            case "meta":
              if (!t.hasAttribute("itemprop")) break;
              return t;
            case "link":
              if (i = t.getAttribute("rel"), i === "stylesheet" && t.hasAttribute("data-precedence"))
                break;
              if (i !== o.rel || t.getAttribute("href") !== (o.href == null || o.href === "" ? null : o.href) || t.getAttribute("crossorigin") !== (o.crossOrigin == null ? null : o.crossOrigin) || t.getAttribute("title") !== (o.title == null ? null : o.title))
                break;
              return t;
            case "style":
              if (t.hasAttribute("data-precedence")) break;
              return t;
            case "script":
              if (i = t.getAttribute("src"), (i !== (o.src == null ? null : o.src) || t.getAttribute("type") !== (o.type == null ? null : o.type) || t.getAttribute("crossorigin") !== (o.crossOrigin == null ? null : o.crossOrigin)) && i && t.hasAttribute("async") && !t.hasAttribute("itemprop"))
                break;
              return t;
            default:
              return t;
          }
      } else if (e === "input" && t.type === "hidden") {
        var i = o.name == null ? null : "" + o.name;
        if (o.type === "hidden" && t.getAttribute("name") === i)
          return t;
      } else return t;
      if (t = gn(t.nextSibling), t === null) break;
    }
    return null;
  }
  function Eg(t, e, a) {
    if (e === "") return null;
    for (; t.nodeType !== 3; )
      if ((t.nodeType !== 1 || t.nodeName !== "INPUT" || t.type !== "hidden") && !a || (t = gn(t.nextSibling), t === null)) return null;
    return t;
  }
  function uh(t) {
    return t.data === "$!" || t.data === "$?" && t.ownerDocument.readyState === "complete";
  }
  function Rg(t, e) {
    var a = t.ownerDocument;
    if (t.data !== "$?" || a.readyState === "complete")
      e();
    else {
      var n = function() {
        e(), a.removeEventListener("DOMContentLoaded", n);
      };
      a.addEventListener("DOMContentLoaded", n), t._reactRetry = n;
    }
  }
  function gn(t) {
    for (; t != null; t = t.nextSibling) {
      var e = t.nodeType;
      if (e === 1 || e === 3) break;
      if (e === 8) {
        if (e = t.data, e === "$" || e === "$!" || e === "$?" || e === "F!" || e === "F")
          break;
        if (e === "/$") return null;
      }
    }
    return t;
  }
  var hh = null;
  function g0(t) {
    t = t.previousSibling;
    for (var e = 0; t; ) {
      if (t.nodeType === 8) {
        var a = t.data;
        if (a === "$" || a === "$!" || a === "$?") {
          if (e === 0) return t;
          e--;
        } else a === "/$" && e++;
      }
      t = t.previousSibling;
    }
    return null;
  }
  function m0(t, e, a) {
    switch (e = ac(a), t) {
      case "html":
        if (t = e.documentElement, !t) throw Error(c(452));
        return t;
      case "head":
        if (t = e.head, !t) throw Error(c(453));
        return t;
      case "body":
        if (t = e.body, !t) throw Error(c(454));
        return t;
      default:
        throw Error(c(451));
    }
  }
  function Vr(t) {
    for (var e = t.attributes; e.length; )
      t.removeAttributeNode(e[0]);
    Ke(t);
  }
  var en = /* @__PURE__ */ new Map(), b0 = /* @__PURE__ */ new Set();
  function nc(t) {
    return typeof t.getRootNode == "function" ? t.getRootNode() : t.nodeType === 9 ? t : t.ownerDocument;
  }
  var Ao = O.d;
  O.d = {
    f: Sg,
    r: Tg,
    D: Cg,
    C: Ng,
    L: Ug,
    m: jg,
    X: Bg,
    S: kg,
    M: Vg
  };
  function Sg() {
    var t = Ao.f(), e = Is();
    return t || e;
  }
  function Tg(t) {
    var e = Wn(t);
    e !== null && e.tag === 5 && e.type === "form" ? zf(e) : Ao.r(t);
  }
  var Bl = typeof document > "u" ? null : document;
  function x0(t, e, a) {
    var n = Bl;
    if (n && typeof e == "string" && e) {
      var o = ca(e);
      o = 'link[rel="' + t + '"][href="' + o + '"]', typeof a == "string" && (o += '[crossorigin="' + a + '"]'), b0.has(o) || (b0.add(o), t = { rel: t, crossOrigin: a, href: e }, n.querySelector(o) === null && (e = n.createElement("link"), $e(e, "link", t), xe(e), n.head.appendChild(e)));
    }
  }
  function Cg(t) {
    Ao.D(t), x0("dns-prefetch", t, null);
  }
  function Ng(t, e) {
    Ao.C(t, e), x0("preconnect", t, e);
  }
  function Ug(t, e, a) {
    Ao.L(t, e, a);
    var n = Bl;
    if (n && t && e) {
      var o = 'link[rel="preload"][as="' + ca(e) + '"]';
      e === "image" && a && a.imageSrcSet ? (o += '[imagesrcset="' + ca(
        a.imageSrcSet
      ) + '"]', typeof a.imageSizes == "string" && (o += '[imagesizes="' + ca(
        a.imageSizes
      ) + '"]')) : o += '[href="' + ca(t) + '"]';
      var i = o;
      switch (e) {
        case "style":
          i = Vl(t);
          break;
        case "script":
          i = Dl(t);
      }
      en.has(i) || (t = S(
        {
          rel: "preload",
          href: e === "image" && a && a.imageSrcSet ? void 0 : t,
          as: e
        },
        a
      ), en.set(i, t), n.querySelector(o) !== null || e === "style" && n.querySelector(Dr(i)) || e === "script" && n.querySelector(Yr(i)) || (e = n.createElement("link"), $e(e, "link", t), xe(e), n.head.appendChild(e)));
    }
  }
  function jg(t, e) {
    Ao.m(t, e);
    var a = Bl;
    if (a && t) {
      var n = e && typeof e.as == "string" ? e.as : "script", o = 'link[rel="modulepreload"][as="' + ca(n) + '"][href="' + ca(t) + '"]', i = o;
      switch (n) {
        case "audioworklet":
        case "paintworklet":
        case "serviceworker":
        case "sharedworker":
        case "worker":
        case "script":
          i = Dl(t);
      }
      if (!en.has(i) && (t = S({ rel: "modulepreload", href: t }, e), en.set(i, t), a.querySelector(o) === null)) {
        switch (n) {
          case "audioworklet":
          case "paintworklet":
          case "serviceworker":
          case "sharedworker":
          case "worker":
          case "script":
            if (a.querySelector(Yr(i)))
              return;
        }
        n = a.createElement("link"), $e(n, "link", t), xe(n), a.head.appendChild(n);
      }
    }
  }
  function kg(t, e, a) {
    Ao.S(t, e, a);
    var n = Bl;
    if (n && t) {
      var o = on(n).hoistableStyles, i = Vl(t);
      e = e || "default";
      var f = o.get(i);
      if (!f) {
        var d = { loading: 0, preload: null };
        if (f = n.querySelector(
          Dr(i)
        ))
          d.loading = 5;
        else {
          t = S(
            { rel: "stylesheet", href: t, "data-precedence": e },
            a
          ), (a = en.get(i)) && fh(t, a);
          var E = f = n.createElement("link");
          xe(E), $e(E, "link", t), E._p = new Promise(function(V, F) {
            E.onload = V, E.onerror = F;
          }), E.addEventListener("load", function() {
            d.loading |= 1;
          }), E.addEventListener("error", function() {
            d.loading |= 2;
          }), d.loading |= 4, oc(f, e, n);
        }
        f = {
          type: "stylesheet",
          instance: f,
          count: 1,
          state: d
        }, o.set(i, f);
      }
    }
  }
  function Bg(t, e) {
    Ao.X(t, e);
    var a = Bl;
    if (a && t) {
      var n = on(a).hoistableScripts, o = Dl(t), i = n.get(o);
      i || (i = a.querySelector(Yr(o)), i || (t = S({ src: t, async: !0 }, e), (e = en.get(o)) && dh(t, e), i = a.createElement("script"), xe(i), $e(i, "link", t), a.head.appendChild(i)), i = {
        type: "script",
        instance: i,
        count: 1,
        state: null
      }, n.set(o, i));
    }
  }
  function Vg(t, e) {
    Ao.M(t, e);
    var a = Bl;
    if (a && t) {
      var n = on(a).hoistableScripts, o = Dl(t), i = n.get(o);
      i || (i = a.querySelector(Yr(o)), i || (t = S({ src: t, async: !0, type: "module" }, e), (e = en.get(o)) && dh(t, e), i = a.createElement("script"), xe(i), $e(i, "link", t), a.head.appendChild(i)), i = {
        type: "script",
        instance: i,
        count: 1,
        state: null
      }, n.set(o, i));
    }
  }
  function y0(t, e, a, n) {
    var o = (o = Nt.current) ? nc(o) : null;
    if (!o) throw Error(c(446));
    switch (t) {
      case "meta":
      case "title":
        return null;
      case "style":
        return typeof a.precedence == "string" && typeof a.href == "string" ? (e = Vl(a.href), a = on(
          o
        ).hoistableStyles, n = a.get(e), n || (n = {
          type: "style",
          instance: null,
          count: 0,
          state: null
        }, a.set(e, n)), n) : { type: "void", instance: null, count: 0, state: null };
      case "link":
        if (a.rel === "stylesheet" && typeof a.href == "string" && typeof a.precedence == "string") {
          t = Vl(a.href);
          var i = on(
            o
          ).hoistableStyles, f = i.get(t);
          if (f || (o = o.ownerDocument || o, f = {
            type: "stylesheet",
            instance: null,
            count: 0,
            state: { loading: 0, preload: null }
          }, i.set(t, f), (i = o.querySelector(
            Dr(t)
          )) && !i._p && (f.instance = i, f.state.loading = 5), en.has(t) || (a = {
            rel: "preload",
            as: "style",
            href: a.href,
            crossOrigin: a.crossOrigin,
            integrity: a.integrity,
            media: a.media,
            hrefLang: a.hrefLang,
            referrerPolicy: a.referrerPolicy
          }, en.set(t, a), i || Dg(
            o,
            t,
            a,
            f.state
          ))), e && n === null)
            throw Error(c(528, ""));
          return f;
        }
        if (e && n !== null)
          throw Error(c(529, ""));
        return null;
      case "script":
        return e = a.async, a = a.src, typeof a == "string" && e && typeof e != "function" && typeof e != "symbol" ? (e = Dl(a), a = on(
          o
        ).hoistableScripts, n = a.get(e), n || (n = {
          type: "script",
          instance: null,
          count: 0,
          state: null
        }, a.set(e, n)), n) : { type: "void", instance: null, count: 0, state: null };
      default:
        throw Error(c(444, t));
    }
  }
  function Vl(t) {
    return 'href="' + ca(t) + '"';
  }
  function Dr(t) {
    return 'link[rel="stylesheet"][' + t + "]";
  }
  function A0(t) {
    return S({}, t, {
      "data-precedence": t.precedence,
      precedence: null
    });
  }
  function Dg(t, e, a, n) {
    t.querySelector('link[rel="preload"][as="style"][' + e + "]") ? n.loading = 1 : (e = t.createElement("link"), n.preload = e, e.addEventListener("load", function() {
      return n.loading |= 1;
    }), e.addEventListener("error", function() {
      return n.loading |= 2;
    }), $e(e, "link", a), xe(e), t.head.appendChild(e));
  }
  function Dl(t) {
    return '[src="' + ca(t) + '"]';
  }
  function Yr(t) {
    return "script[async]" + t;
  }
  function v0(t, e, a) {
    if (e.count++, e.instance === null)
      switch (e.type) {
        case "style":
          var n = t.querySelector(
            'style[data-href~="' + ca(a.href) + '"]'
          );
          if (n)
            return e.instance = n, xe(n), n;
          var o = S({}, a, {
            "data-href": a.href,
            "data-precedence": a.precedence,
            href: null,
            precedence: null
          });
          return n = (t.ownerDocument || t).createElement(
            "style"
          ), xe(n), $e(n, "style", o), oc(n, a.precedence, t), e.instance = n;
        case "stylesheet":
          o = Vl(a.href);
          var i = t.querySelector(
            Dr(o)
          );
          if (i)
            return e.state.loading |= 4, e.instance = i, xe(i), i;
          n = A0(a), (o = en.get(o)) && fh(n, o), i = (t.ownerDocument || t).createElement("link"), xe(i);
          var f = i;
          return f._p = new Promise(function(d, E) {
            f.onload = d, f.onerror = E;
          }), $e(i, "link", n), e.state.loading |= 4, oc(i, a.precedence, t), e.instance = i;
        case "script":
          return i = Dl(a.src), (o = t.querySelector(
            Yr(i)
          )) ? (e.instance = o, xe(o), o) : (n = a, (o = en.get(i)) && (n = S({}, a), dh(n, o)), t = t.ownerDocument || t, o = t.createElement("script"), xe(o), $e(o, "link", n), t.head.appendChild(o), e.instance = o);
        case "void":
          return null;
        default:
          throw Error(c(443, e.type));
      }
    else
      e.type === "stylesheet" && (e.state.loading & 4) === 0 && (n = e.instance, e.state.loading |= 4, oc(n, a.precedence, t));
    return e.instance;
  }
  function oc(t, e, a) {
    for (var n = a.querySelectorAll(
      'link[rel="stylesheet"][data-precedence],style[data-precedence]'
    ), o = n.length ? n[n.length - 1] : null, i = o, f = 0; f < n.length; f++) {
      var d = n[f];
      if (d.dataset.precedence === e) i = d;
      else if (i !== o) break;
    }
    i ? i.parentNode.insertBefore(t, i.nextSibling) : (e = a.nodeType === 9 ? a.head : a, e.insertBefore(t, e.firstChild));
  }
  function fh(t, e) {
    t.crossOrigin == null && (t.crossOrigin = e.crossOrigin), t.referrerPolicy == null && (t.referrerPolicy = e.referrerPolicy), t.title == null && (t.title = e.title);
  }
  function dh(t, e) {
    t.crossOrigin == null && (t.crossOrigin = e.crossOrigin), t.referrerPolicy == null && (t.referrerPolicy = e.referrerPolicy), t.integrity == null && (t.integrity = e.integrity);
  }
  var ic = null;
  function M0(t, e, a) {
    if (ic === null) {
      var n = /* @__PURE__ */ new Map(), o = ic = /* @__PURE__ */ new Map();
      o.set(a, n);
    } else
      o = ic, n = o.get(a), n || (n = /* @__PURE__ */ new Map(), o.set(a, n));
    if (n.has(t)) return n;
    for (n.set(t, null), a = a.getElementsByTagName(t), o = 0; o < a.length; o++) {
      var i = a[o];
      if (!(i[ke] || i[Rt] || t === "link" && i.getAttribute("rel") === "stylesheet") && i.namespaceURI !== "http://www.w3.org/2000/svg") {
        var f = i.getAttribute(e) || "";
        f = t + f;
        var d = n.get(f);
        d ? d.push(i) : n.set(f, [i]);
      }
    }
    return n;
  }
  function w0(t, e, a) {
    t = t.ownerDocument || t, t.head.insertBefore(
      a,
      e === "title" ? t.querySelector("head > title") : null
    );
  }
  function Yg(t, e, a) {
    if (a === 1 || e.itemProp != null) return !1;
    switch (t) {
      case "meta":
      case "title":
        return !0;
      case "style":
        if (typeof e.precedence != "string" || typeof e.href != "string" || e.href === "")
          break;
        return !0;
      case "link":
        if (typeof e.rel != "string" || typeof e.href != "string" || e.href === "" || e.onLoad || e.onError)
          break;
        return e.rel === "stylesheet" ? (t = e.disabled, typeof e.precedence == "string" && t == null) : !0;
      case "script":
        if (e.async && typeof e.async != "function" && typeof e.async != "symbol" && !e.onLoad && !e.onError && e.src && typeof e.src == "string")
          return !0;
    }
    return !1;
  }
  function E0(t) {
    return !(t.type === "stylesheet" && (t.state.loading & 3) === 0);
  }
  var zr = null;
  function zg() {
  }
  function qg(t, e, a) {
    if (zr === null) throw Error(c(475));
    var n = zr;
    if (e.type === "stylesheet" && (typeof a.media != "string" || matchMedia(a.media).matches !== !1) && (e.state.loading & 4) === 0) {
      if (e.instance === null) {
        var o = Vl(a.href), i = t.querySelector(
          Dr(o)
        );
        if (i) {
          t = i._p, t !== null && typeof t == "object" && typeof t.then == "function" && (n.count++, n = lc.bind(n), t.then(n, n)), e.state.loading |= 4, e.instance = i, xe(i);
          return;
        }
        i = t.ownerDocument || t, a = A0(a), (o = en.get(o)) && fh(a, o), i = i.createElement("link"), xe(i);
        var f = i;
        f._p = new Promise(function(d, E) {
          f.onload = d, f.onerror = E;
        }), $e(i, "link", a), e.instance = i;
      }
      n.stylesheets === null && (n.stylesheets = /* @__PURE__ */ new Map()), n.stylesheets.set(e, t), (t = e.state.preload) && (e.state.loading & 3) === 0 && (n.count++, e = lc.bind(n), t.addEventListener("load", e), t.addEventListener("error", e));
    }
  }
  function Qg() {
    if (zr === null) throw Error(c(475));
    var t = zr;
    return t.stylesheets && t.count === 0 && ph(t, t.stylesheets), 0 < t.count ? function(e) {
      var a = setTimeout(function() {
        if (t.stylesheets && ph(t, t.stylesheets), t.unsuspend) {
          var n = t.unsuspend;
          t.unsuspend = null, n();
        }
      }, 6e4);
      return t.unsuspend = e, function() {
        t.unsuspend = null, clearTimeout(a);
      };
    } : null;
  }
  function lc() {
    if (this.count--, this.count === 0) {
      if (this.stylesheets) ph(this, this.stylesheets);
      else if (this.unsuspend) {
        var t = this.unsuspend;
        this.unsuspend = null, t();
      }
    }
  }
  var rc = null;
  function ph(t, e) {
    t.stylesheets = null, t.unsuspend !== null && (t.count++, rc = /* @__PURE__ */ new Map(), e.forEach(Lg, t), rc = null, lc.call(t));
  }
  function Lg(t, e) {
    if (!(e.state.loading & 4)) {
      var a = rc.get(t);
      if (a) var n = a.get(null);
      else {
        a = /* @__PURE__ */ new Map(), rc.set(t, a);
        for (var o = t.querySelectorAll(
          "link[data-precedence],style[data-precedence]"
        ), i = 0; i < o.length; i++) {
          var f = o[i];
          (f.nodeName === "LINK" || f.getAttribute("media") !== "not all") && (a.set(f.dataset.precedence, f), n = f);
        }
        n && a.set(null, n);
      }
      o = e.instance, f = o.getAttribute("data-precedence"), i = a.get(f) || n, i === n && a.set(null, o), a.set(f, o), this.count++, n = lc.bind(this), o.addEventListener("load", n), o.addEventListener("error", n), i ? i.parentNode.insertBefore(o, i.nextSibling) : (t = t.nodeType === 9 ? t.head : t, t.insertBefore(o, t.firstChild)), e.state.loading |= 4;
    }
  }
  var qr = {
    $$typeof: Y,
    Provider: null,
    Consumer: null,
    _currentValue: K,
    _currentValue2: K,
    _threadCount: 0
  };
  function Og(t, e, a, n, o, i, f, d) {
    this.tag = 1, this.containerInfo = t, this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.next = this.pendingContext = this.context = this.cancelPendingCommit = null, this.callbackPriority = 0, this.expirationTimes = Zn(-1), this.entangledLanes = this.shellSuspendCounter = this.errorRecoveryDisabledLanes = this.expiredLanes = this.warmLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = Zn(0), this.hiddenUpdates = Zn(null), this.identifierPrefix = n, this.onUncaughtError = o, this.onCaughtError = i, this.onRecoverableError = f, this.pooledCache = null, this.pooledCacheLanes = 0, this.formState = d, this.incompleteTransitions = /* @__PURE__ */ new Map();
  }
  function R0(t, e, a, n, o, i, f, d, E, V, F, X) {
    return t = new Og(
      t,
      e,
      a,
      f,
      d,
      E,
      V,
      X
    ), e = 1, i === !0 && (e |= 24), i = ma(3, null, null, e), t.current = i, i.stateNode = t, e = ee(), e.refCount++, t.pooledCache = e, e.refCount++, i.memoizedState = {
      element: n,
      isDehydrated: a,
      cache: e
    }, $c(i), t;
  }
  function S0(t) {
    return t ? (t = Do, t) : Do;
  }
  function T0(t, e, a, n, o, i) {
    o = S0(o), n.context === null ? n.context = o : n.pendingContext = o, n = Oo(e), n.payload = { element: a }, i = i === void 0 ? null : i, i !== null && (n.callback = i), a = Ko(t, n, e), a !== null && (Ka(a, t, e), pr(a, t, e));
  }
  function C0(t, e) {
    if (t = t.memoizedState, t !== null && t.dehydrated !== null) {
      var a = t.retryLane;
      t.retryLane = a !== 0 && a < e ? a : e;
    }
  }
  function gh(t, e) {
    C0(t, e), (t = t.alternate) && C0(t, e);
  }
  function N0(t) {
    if (t.tag === 13) {
      var e = Vo(t, 67108864);
      e !== null && Ka(e, t, 67108864), gh(t, 67108864);
    }
  }
  var sc = !0;
  function Kg(t, e, a, n) {
    var o = q.T;
    q.T = null;
    var i = O.p;
    try {
      O.p = 2, mh(t, e, a, n);
    } finally {
      O.p = i, q.T = o;
    }
  }
  function Hg(t, e, a, n) {
    var o = q.T;
    q.T = null;
    var i = O.p;
    try {
      O.p = 8, mh(t, e, a, n);
    } finally {
      O.p = i, q.T = o;
    }
  }
  function mh(t, e, a, n) {
    if (sc) {
      var o = bh(n);
      if (o === null)
        nh(
          t,
          e,
          n,
          cc,
          a
        ), j0(t, n);
      else if (Wg(
        o,
        t,
        e,
        a,
        n
      ))
        n.stopPropagation();
      else if (j0(t, n), e & 4 && -1 < Zg.indexOf(t)) {
        for (; o !== null; ) {
          var i = Wn(o);
          if (i !== null)
            switch (i.tag) {
              case 3:
                if (i = i.stateNode, i.current.memoizedState.isDehydrated) {
                  var f = na(i.pendingLanes);
                  if (f !== 0) {
                    var d = i;
                    for (d.pendingLanes |= 2, d.entangledLanes |= 2; f; ) {
                      var E = 1 << 31 - be(f);
                      d.entanglements[1] |= E, f &= ~E;
                    }
                    Qn(i), (oe & 6) === 0 && (Fs = ea() + 500, jr(0));
                  }
                }
                break;
              case 13:
                d = Vo(i, 2), d !== null && Ka(d, i, 2), Is(), gh(i, 2);
            }
          if (i = bh(n), i === null && nh(
            t,
            e,
            n,
            cc,
            a
          ), i === o) break;
          o = i;
        }
        o !== null && n.stopPropagation();
      } else
        nh(
          t,
          e,
          n,
          null,
          a
        );
    }
  }
  function bh(t) {
    return t = rn(t), xh(t);
  }
  var cc = null;
  function xh(t) {
    if (cc = null, t = Aa(t), t !== null) {
      var e = m(t);
      if (e === null) t = null;
      else {
        var a = e.tag;
        if (a === 13) {
          if (t = b(e), t !== null) return t;
          t = null;
        } else if (a === 3) {
          if (e.stateNode.current.memoizedState.isDehydrated)
            return e.tag === 3 ? e.stateNode.containerInfo : null;
          t = null;
        } else e !== t && (t = null);
      }
    }
    return cc = t, null;
  }
  function U0(t) {
    switch (t) {
      case "beforetoggle":
      case "cancel":
      case "click":
      case "close":
      case "contextmenu":
      case "copy":
      case "cut":
      case "auxclick":
      case "dblclick":
      case "dragend":
      case "dragstart":
      case "drop":
      case "focusin":
      case "focusout":
      case "input":
      case "invalid":
      case "keydown":
      case "keypress":
      case "keyup":
      case "mousedown":
      case "mouseup":
      case "paste":
      case "pause":
      case "play":
      case "pointercancel":
      case "pointerdown":
      case "pointerup":
      case "ratechange":
      case "reset":
      case "resize":
      case "seeked":
      case "submit":
      case "toggle":
      case "touchcancel":
      case "touchend":
      case "touchstart":
      case "volumechange":
      case "change":
      case "selectionchange":
      case "textInput":
      case "compositionstart":
      case "compositionend":
      case "compositionupdate":
      case "beforeblur":
      case "afterblur":
      case "beforeinput":
      case "blur":
      case "fullscreenchange":
      case "focus":
      case "hashchange":
      case "popstate":
      case "select":
      case "selectstart":
        return 2;
      case "drag":
      case "dragenter":
      case "dragexit":
      case "dragleave":
      case "dragover":
      case "mousemove":
      case "mouseout":
      case "mouseover":
      case "pointermove":
      case "pointerout":
      case "pointerover":
      case "scroll":
      case "touchmove":
      case "wheel":
      case "mouseenter":
      case "mouseleave":
      case "pointerenter":
      case "pointerleave":
        return 8;
      case "message":
        switch (xn()) {
          case aa:
            return 2;
          case On:
            return 8;
          case nn:
          case vo:
            return 32;
          case ri:
            return 268435456;
          default:
            return 32;
        }
      default:
        return 32;
    }
  }
  var yh = !1, ei = null, ai = null, ni = null, Qr = /* @__PURE__ */ new Map(), Lr = /* @__PURE__ */ new Map(), oi = [], Zg = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(
    " "
  );
  function j0(t, e) {
    switch (t) {
      case "focusin":
      case "focusout":
        ei = null;
        break;
      case "dragenter":
      case "dragleave":
        ai = null;
        break;
      case "mouseover":
      case "mouseout":
        ni = null;
        break;
      case "pointerover":
      case "pointerout":
        Qr.delete(e.pointerId);
        break;
      case "gotpointercapture":
      case "lostpointercapture":
        Lr.delete(e.pointerId);
    }
  }
  function Or(t, e, a, n, o, i) {
    return t === null || t.nativeEvent !== i ? (t = {
      blockedOn: e,
      domEventName: a,
      eventSystemFlags: n,
      nativeEvent: i,
      targetContainers: [o]
    }, e !== null && (e = Wn(e), e !== null && N0(e)), t) : (t.eventSystemFlags |= n, e = t.targetContainers, o !== null && e.indexOf(o) === -1 && e.push(o), t);
  }
  function Wg(t, e, a, n, o) {
    switch (e) {
      case "focusin":
        return ei = Or(
          ei,
          t,
          e,
          a,
          n,
          o
        ), !0;
      case "dragenter":
        return ai = Or(
          ai,
          t,
          e,
          a,
          n,
          o
        ), !0;
      case "mouseover":
        return ni = Or(
          ni,
          t,
          e,
          a,
          n,
          o
        ), !0;
      case "pointerover":
        var i = o.pointerId;
        return Qr.set(
          i,
          Or(
            Qr.get(i) || null,
            t,
            e,
            a,
            n,
            o
          )
        ), !0;
      case "gotpointercapture":
        return i = o.pointerId, Lr.set(
          i,
          Or(
            Lr.get(i) || null,
            t,
            e,
            a,
            n,
            o
          )
        ), !0;
    }
    return !1;
  }
  function k0(t) {
    var e = Aa(t.target);
    if (e !== null) {
      var a = m(e);
      if (a !== null) {
        if (e = a.tag, e === 13) {
          if (e = b(a), e !== null) {
            t.blockedOn = e, xt(t.priority, function() {
              if (a.tag === 13) {
                var n = Oa();
                n = ce(n);
                var o = Vo(a, n);
                o !== null && Ka(o, a, n), gh(a, n);
              }
            });
            return;
          }
        } else if (e === 3 && a.stateNode.current.memoizedState.isDehydrated) {
          t.blockedOn = a.tag === 3 ? a.stateNode.containerInfo : null;
          return;
        }
      }
    }
    t.blockedOn = null;
  }
  function uc(t) {
    if (t.blockedOn !== null) return !1;
    for (var e = t.targetContainers; 0 < e.length; ) {
      var a = bh(t.nativeEvent);
      if (a === null) {
        a = t.nativeEvent;
        var n = new a.constructor(
          a.type,
          a
        );
        Ai = n, a.target.dispatchEvent(n), Ai = null;
      } else
        return e = Wn(a), e !== null && N0(e), t.blockedOn = a, !1;
      e.shift();
    }
    return !0;
  }
  function B0(t, e, a) {
    uc(t) && a.delete(e);
  }
  function Fg() {
    yh = !1, ei !== null && uc(ei) && (ei = null), ai !== null && uc(ai) && (ai = null), ni !== null && uc(ni) && (ni = null), Qr.forEach(B0), Lr.forEach(B0);
  }
  function hc(t, e) {
    t.blockedOn === e && (t.blockedOn = null, yh || (yh = !0, r.unstable_scheduleCallback(
      r.unstable_NormalPriority,
      Fg
    )));
  }
  var fc = null;
  function V0(t) {
    fc !== t && (fc = t, r.unstable_scheduleCallback(
      r.unstable_NormalPriority,
      function() {
        fc === t && (fc = null);
        for (var e = 0; e < t.length; e += 3) {
          var a = t[e], n = t[e + 1], o = t[e + 2];
          if (typeof n != "function") {
            if (xh(n || a) === null)
              continue;
            break;
          }
          var i = Wn(a);
          i !== null && (t.splice(e, 3), e -= 3, xu(
            i,
            {
              pending: !0,
              data: o,
              method: a.method,
              action: n
            },
            n,
            o
          ));
        }
      }
    ));
  }
  function Kr(t) {
    function e(E) {
      return hc(E, t);
    }
    ei !== null && hc(ei, t), ai !== null && hc(ai, t), ni !== null && hc(ni, t), Qr.forEach(e), Lr.forEach(e);
    for (var a = 0; a < oi.length; a++) {
      var n = oi[a];
      n.blockedOn === t && (n.blockedOn = null);
    }
    for (; 0 < oi.length && (a = oi[0], a.blockedOn === null); )
      k0(a), a.blockedOn === null && oi.shift();
    if (a = (t.ownerDocument || t).$$reactFormReplay, a != null)
      for (n = 0; n < a.length; n += 3) {
        var o = a[n], i = a[n + 1], f = o[dt] || null;
        if (typeof i == "function")
          f || V0(a);
        else if (f) {
          var d = null;
          if (i && i.hasAttribute("formAction")) {
            if (o = i, f = i[dt] || null)
              d = f.formAction;
            else if (xh(o) !== null) continue;
          } else d = f.action;
          typeof d == "function" ? a[n + 1] = d : (a.splice(n, 3), n -= 3), V0(a);
        }
      }
  }
  function Ah(t) {
    this._internalRoot = t;
  }
  dc.prototype.render = Ah.prototype.render = function(t) {
    var e = this._internalRoot;
    if (e === null) throw Error(c(409));
    var a = e.current, n = Oa();
    T0(a, n, t, e, null, null);
  }, dc.prototype.unmount = Ah.prototype.unmount = function() {
    var t = this._internalRoot;
    if (t !== null) {
      this._internalRoot = null;
      var e = t.containerInfo;
      T0(t.current, 2, null, t, null, null), Is(), e[Ot] = null;
    }
  };
  function dc(t) {
    this._internalRoot = t;
  }
  dc.prototype.unstable_scheduleHydration = function(t) {
    if (t) {
      var e = yt();
      t = { blockedOn: null, target: t, priority: e };
      for (var a = 0; a < oi.length && e !== 0 && e < oi[a].priority; a++) ;
      oi.splice(a, 0, t), a === 0 && k0(t);
    }
  };
  var D0 = h.version;
  if (D0 !== "19.1.0")
    throw Error(
      c(
        527,
        D0,
        "19.1.0"
      )
    );
  O.findDOMNode = function(t) {
    var e = t._reactInternals;
    if (e === void 0)
      throw typeof t.render == "function" ? Error(c(188)) : (t = Object.keys(t).join(","), Error(c(268, t)));
    return t = v(e), t = t !== null ? y(t) : null, t = t === null ? null : t.stateNode, t;
  };
  var Gg = {
    bundleType: 0,
    version: "19.1.0",
    rendererPackageName: "react-dom",
    currentDispatcherRef: q,
    reconcilerVersion: "19.1.0"
  };
  if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
    var pc = __REACT_DEVTOOLS_GLOBAL_HOOK__;
    if (!pc.isDisabled && pc.supportsFiber)
      try {
        Za = pc.inject(
          Gg
        ), Se = pc;
      } catch {
      }
  }
  return Zr.createRoot = function(t, e) {
    if (!g(t)) throw Error(c(299));
    var a = !1, n = "", o = Pf, i = _f, f = $f, d = null;
    return e != null && (e.unstable_strictMode === !0 && (a = !0), e.identifierPrefix !== void 0 && (n = e.identifierPrefix), e.onUncaughtError !== void 0 && (o = e.onUncaughtError), e.onCaughtError !== void 0 && (i = e.onCaughtError), e.onRecoverableError !== void 0 && (f = e.onRecoverableError), e.unstable_transitionCallbacks !== void 0 && (d = e.unstable_transitionCallbacks)), e = R0(
      t,
      1,
      !1,
      null,
      null,
      a,
      n,
      o,
      i,
      f,
      d,
      null
    ), t[Ot] = e.current, ah(t), new Ah(e);
  }, Zr.hydrateRoot = function(t, e, a) {
    if (!g(t)) throw Error(c(299));
    var n = !1, o = "", i = Pf, f = _f, d = $f, E = null, V = null;
    return a != null && (a.unstable_strictMode === !0 && (n = !0), a.identifierPrefix !== void 0 && (o = a.identifierPrefix), a.onUncaughtError !== void 0 && (i = a.onUncaughtError), a.onCaughtError !== void 0 && (f = a.onCaughtError), a.onRecoverableError !== void 0 && (d = a.onRecoverableError), a.unstable_transitionCallbacks !== void 0 && (E = a.unstable_transitionCallbacks), a.formState !== void 0 && (V = a.formState)), e = R0(
      t,
      1,
      !0,
      e,
      a ?? null,
      n,
      o,
      i,
      f,
      d,
      E,
      V
    ), e.context = S0(null), a = e.current, n = Oa(), n = ce(n), o = Oo(n), o.callback = null, Ko(a, o, n), a = n, e.current.lanes = a, An(e, a), Qn(e), t[Ot] = e.current, ah(t), new dc(e);
  }, Zr.version = "19.1.0", Zr;
}
var W0;
function nm() {
  if (W0) return Mh.exports;
  W0 = 1;
  function r() {
    if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function"))
      try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(r);
      } catch (h) {
        console.error(h);
      }
  }
  return r(), Mh.exports = am(), Mh.exports;
}
var om = nm(), M = Ih();
const im = (r) => r.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase(), lm = (r) => r.replace(
  /^([A-Z])|[\s-_]+(\w)/g,
  (h, u, c) => c ? c.toUpperCase() : u.toLowerCase()
), F0 = (r) => {
  const h = lm(r);
  return h.charAt(0).toUpperCase() + h.slice(1);
}, Mp = (...r) => r.filter((h, u, c) => !!h && h.trim() !== "" && c.indexOf(h) === u).join(" ").trim(), rm = (r) => {
  for (const h in r)
    if (h.startsWith("aria-") || h === "role" || h === "title")
      return !0;
};
var sm = {
  xmlns: "http://www.w3.org/2000/svg",
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round"
};
const cm = M.forwardRef(
  ({
    color: r = "currentColor",
    size: h = 24,
    strokeWidth: u = 2,
    absoluteStrokeWidth: c,
    className: g = "",
    children: m,
    iconNode: b,
    ...A
  }, v) => M.createElement(
    "svg",
    {
      ref: v,
      ...sm,
      width: h,
      height: h,
      stroke: r,
      strokeWidth: c ? Number(u) * 24 / Number(h) : u,
      className: Mp("lucide", g),
      ...!m && !rm(A) && { "aria-hidden": "true" },
      ...A
    },
    [
      ...b.map(([y, S]) => M.createElement(y, S)),
      ...Array.isArray(m) ? m : [m]
    ]
  )
);
const $t = (r, h) => {
  const u = M.forwardRef(
    ({ className: c, ...g }, m) => M.createElement(cm, {
      ref: m,
      iconNode: h,
      className: Mp(
        `lucide-${im(F0(r))}`,
        `lucide-${r}`,
        c
      ),
      ...g
    })
  );
  return u.displayName = F0(r), u;
};
const um = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "m14.31 8 5.74 9.94", key: "1y6ab4" }],
  ["path", { d: "M9.69 8h11.48", key: "1wxppr" }],
  ["path", { d: "m7.38 12 5.74-9.94", key: "1grp0k" }],
  ["path", { d: "M9.69 16 3.95 6.06", key: "libnyf" }],
  ["path", { d: "M14.31 16H2.83", key: "x5fava" }],
  ["path", { d: "m16.62 12-5.74 9.94", key: "1vwawt" }]
], hm = $t("aperture", um);
const fm = [
  [
    "path",
    {
      d: "M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",
      key: "3c2336"
    }
  ],
  ["path", { d: "m9 12 2 2 4-4", key: "dzmm74" }]
], dm = $t("badge-check", fm);
const pm = [
  ["path", { d: "m11 10 3 3", key: "fzmg1i" }],
  [
    "path",
    { d: "M6.5 21A3.5 3.5 0 1 0 3 17.5a2.62 2.62 0 0 1-.708 1.792A1 1 0 0 0 3 21z", key: "p4q2r7" }
  ],
  ["path", { d: "M9.969 17.031 21.378 5.624a1 1 0 0 0-3.002-3.002L6.967 14.031", key: "wy6l02" }]
], gc = $t("brush", pm);
const gm = [["path", { d: "m6 9 6 6 6-6", key: "qrunsl" }]], mm = $t("chevron-down", gm);
const bm = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3", key: "1u773s" }],
  ["path", { d: "M12 17h.01", key: "p32p05" }]
], G0 = $t("circle-question-mark", bm);
const xm = [["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }]], I0 = $t("circle", xm);
const ym = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M12 18a6 6 0 0 0 0-12v12z", key: "j4l70d" }]
], Am = $t("contrast", ym);
const vm = [
  ["rect", { width: "14", height: "14", x: "8", y: "8", rx: "2", ry: "2", key: "17jyea" }],
  ["path", { d: "M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2", key: "zix9uf" }]
], Mm = $t("copy", vm);
const wm = [
  ["path", { d: "M6 2v14a2 2 0 0 0 2 2h14", key: "ron5a4" }],
  ["path", { d: "M18 22V8a2 2 0 0 0-2-2H2", key: "7s9ehn" }]
], X0 = $t("crop", wm);
const Em = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["line", { x1: "22", x2: "18", y1: "12", y2: "12", key: "l9bcsi" }],
  ["line", { x1: "6", x2: "2", y1: "12", y2: "12", key: "13hhkx" }],
  ["line", { x1: "12", x2: "12", y1: "6", y2: "2", key: "10w3f3" }],
  ["line", { x1: "12", x2: "12", y1: "22", y2: "18", key: "15g9kq" }]
], Rm = $t("crosshair", Em);
const Sm = [
  [
    "path",
    {
      d: "M21 21H8a2 2 0 0 1-1.42-.587l-3.994-3.999a2 2 0 0 1 0-2.828l10-10a2 2 0 0 1 2.829 0l5.999 6a2 2 0 0 1 0 2.828L12.834 21",
      key: "g5wo59"
    }
  ],
  ["path", { d: "m5.082 11.09 8.828 8.828", key: "1wx5vj" }]
], mc = $t("eraser", Sm);
const Tm = [
  [
    "path",
    {
      d: "M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49",
      key: "ct8e1f"
    }
  ],
  ["path", { d: "M14.084 14.158a3 3 0 0 1-4.242-4.242", key: "151rxh" }],
  [
    "path",
    {
      d: "M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143",
      key: "13bj9a"
    }
  ],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }]
], J0 = $t("eye-off", Tm);
const Cm = [
  [
    "path",
    {
      d: "M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0",
      key: "1nclc0"
    }
  ],
  ["circle", { cx: "12", cy: "12", r: "3", key: "1v7zrd" }]
], P0 = $t("eye", Cm);
const Nm = [
  ["path", { d: "M8 3H5a2 2 0 0 0-2 2v14c0 1.1.9 2 2 2h3", key: "1i73f7" }],
  ["path", { d: "M16 3h3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-3", key: "saxlbk" }],
  ["path", { d: "M12 20v2", key: "1lh1kg" }],
  ["path", { d: "M12 14v2", key: "8jcxud" }],
  ["path", { d: "M12 8v2", key: "1woqiv" }],
  ["path", { d: "M12 2v2", key: "tus03m" }]
], Um = $t("flip-horizontal", Nm);
const jm = [
  ["path", { d: "M21 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v3", key: "14bfxa" }],
  ["path", { d: "M21 16v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-3", key: "14rx03" }],
  ["path", { d: "M4 12H2", key: "rhcxmi" }],
  ["path", { d: "M10 12H8", key: "s88cx1" }],
  ["path", { d: "M16 12h-2", key: "10asgb" }],
  ["path", { d: "M22 12h-2", key: "14jgyd" }]
], km = $t("flip-vertical", jm);
const Bm = [
  [
    "path",
    {
      d: "m6 14 1.5-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.54 6a2 2 0 0 1-1.95 1.5H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H18a2 2 0 0 1 2 2v2",
      key: "usdka0"
    }
  ]
], Vm = $t("folder-open", Bm);
const Dm = [
  ["path", { d: "M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8", key: "1357e3" }],
  ["path", { d: "M3 3v5h5", key: "1xhq8a" }],
  ["path", { d: "M12 7v5l4 2", key: "1fdv2h" }]
], Ym = $t("history", Dm);
const zm = [
  ["path", { d: "M16 5h6", key: "1vod17" }],
  ["path", { d: "M19 2v6", key: "4bpg5p" }],
  ["path", { d: "M21 11.5V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7.5", key: "1ue2ih" }],
  ["path", { d: "m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21", key: "1xmnt7" }],
  ["circle", { cx: "9", cy: "9", r: "2", key: "af1f0g" }]
], _0 = $t("image-plus", zm);
const qm = [
  [
    "path",
    {
      d: "M2.586 17.414A2 2 0 0 0 2 18.828V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.172a2 2 0 0 0 1.414-.586l.814-.814a6.5 6.5 0 1 0-4-4z",
      key: "1s6t7t"
    }
  ],
  ["circle", { cx: "16.5", cy: "7.5", r: ".5", fill: "currentColor", key: "w0ekpg" }]
], Th = $t("key-round", qm);
const Qm = [
  ["rect", { width: "18", height: "11", x: "3", y: "11", rx: "2", ry: "2", key: "1w4ew1" }],
  ["path", { d: "M7 11V7a5 5 0 0 1 10 0v4", key: "fwvmzm" }]
], Lm = $t("lock", Qm);
const Om = [["path", { d: "M5 12h14", key: "1ays0h" }]], Km = $t("minus", Om);
const Hm = [
  [
    "path",
    {
      d: "m12 9-8.414 8.414A2 2 0 0 0 3 18.828v1.344a2 2 0 0 1-.586 1.414A2 2 0 0 1 3.828 21h1.344a2 2 0 0 0 1.414-.586L15 12",
      key: "1y3wsu"
    }
  ],
  [
    "path",
    {
      d: "m18 9 .4.4a1 1 0 1 1-3 3l-3.8-3.8a1 1 0 1 1 3-3l.4.4 3.4-3.4a1 1 0 1 1 3 3z",
      key: "110lr1"
    }
  ],
  ["path", { d: "m2 22 .414-.414", key: "jhxm08" }]
], Zm = $t("pipette", Hm);
const Wm = [
  ["path", { d: "M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8", key: "1357e3" }],
  ["path", { d: "M3 3v5h5", key: "1xhq8a" }]
], Qc = $t("rotate-ccw", Wm);
const Fm = [
  ["path", { d: "M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8", key: "1p45f6" }],
  ["path", { d: "M21 3v5h-5", key: "1q7to0" }]
], Gm = $t("rotate-cw", Fm);
const Im = [
  [
    "path",
    {
      d: "M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z",
      key: "1c8476"
    }
  ],
  ["path", { d: "M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7", key: "1ydtos" }],
  ["path", { d: "M7 3v4a1 1 0 0 0 1 1h7", key: "t51u73" }]
], Xm = $t("save", Im);
const Jm = [["path", { d: "M22 2 2 22", key: "y4kqgn" }]], $0 = $t("slash", Jm);
const Pm = [
  ["line", { x1: "21", x2: "14", y1: "4", y2: "4", key: "obuewd" }],
  ["line", { x1: "10", x2: "3", y1: "4", y2: "4", key: "1q6298" }],
  ["line", { x1: "21", x2: "12", y1: "12", y2: "12", key: "1iu8h1" }],
  ["line", { x1: "8", x2: "3", y1: "12", y2: "12", key: "ntss68" }],
  ["line", { x1: "21", x2: "16", y1: "20", y2: "20", key: "14d8ph" }],
  ["line", { x1: "12", x2: "3", y1: "20", y2: "20", key: "m0wm8r" }],
  ["line", { x1: "14", x2: "14", y1: "2", y2: "6", key: "14e1ph" }],
  ["line", { x1: "8", x2: "8", y1: "10", y2: "14", key: "1i6ji0" }],
  ["line", { x1: "16", x2: "16", y1: "18", y2: "22", key: "1lctlv" }]
], _m = $t("sliders-horizontal", Pm);
const $m = [
  [
    "path",
    {
      d: "M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z",
      key: "4pj2yx"
    }
  ],
  ["path", { d: "M20 3v4", key: "1olli1" }],
  ["path", { d: "M22 5h-4", key: "1gvqau" }],
  ["path", { d: "M4 17v2", key: "vumght" }],
  ["path", { d: "M5 18H3", key: "zchphs" }]
], Ch = $t("sparkles", $m);
const t1 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }]
], e1 = $t("square", t1);
const a1 = [
  ["circle", { cx: "12", cy: "12", r: "4", key: "4exip2" }],
  ["path", { d: "M12 3v1", key: "1asbbs" }],
  ["path", { d: "M12 20v1", key: "1wcdkc" }],
  ["path", { d: "M3 12h1", key: "lp3yf2" }],
  ["path", { d: "M20 12h1", key: "1vloll" }],
  ["path", { d: "m18.364 5.636-.707.707", key: "1hakh0" }],
  ["path", { d: "m6.343 17.657-.707.707", key: "18m9nf" }],
  ["path", { d: "m5.636 5.636.707.707", key: "1xv1c5" }],
  ["path", { d: "m17.657 17.657.707.707", key: "vl76zb" }]
], tp = $t("sun-medium", a1);
const n1 = [
  ["path", { d: "M3 6h18", key: "d0wm0j" }],
  ["path", { d: "M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6", key: "4alrt4" }],
  ["path", { d: "M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2", key: "v07s0e" }],
  ["line", { x1: "10", x2: "10", y1: "11", y2: "17", key: "1uufr5" }],
  ["line", { x1: "14", x2: "14", y1: "11", y2: "17", key: "xtxkd" }]
], o1 = $t("trash-2", n1);
const i1 = [
  ["circle", { cx: "12", cy: "8", r: "5", key: "1hypcn" }],
  ["path", { d: "M20 21a8 8 0 0 0-16 0", key: "rfgkzh" }]
], bc = $t("user-round", i1);
const l1 = [
  [
    "path",
    {
      d: "m21.64 3.64-1.28-1.28a1.21 1.21 0 0 0-1.72 0L2.36 18.64a1.21 1.21 0 0 0 0 1.72l1.28 1.28a1.2 1.2 0 0 0 1.72 0L21.64 5.36a1.2 1.2 0 0 0 0-1.72",
      key: "ul74o6"
    }
  ],
  ["path", { d: "m14 7 3 3", key: "1r5n42" }],
  ["path", { d: "M5 6v4", key: "ilb8ba" }],
  ["path", { d: "M19 14v4", key: "blhpug" }],
  ["path", { d: "M10 2v2", key: "7u0qdc" }],
  ["path", { d: "M7 8H3", key: "zfb6yr" }],
  ["path", { d: "M21 16h-4", key: "1cnmox" }],
  ["path", { d: "M11 3H9", key: "1obp7u" }]
], Nh = $t("wand-sparkles", l1);
const r1 = [
  [
    "path",
    {
      d: "M2 6c.6.5 1.2 1 2.5 1C7 7 7 5 9.5 5c2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1",
      key: "knzxuh"
    }
  ],
  [
    "path",
    {
      d: "M2 12c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1",
      key: "2jd2cc"
    }
  ],
  [
    "path",
    {
      d: "M2 18c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1",
      key: "rd2r6e"
    }
  ]
], Uh = $t("waves", r1);
const s1 = [
  ["path", { d: "M18 6 6 18", key: "1bl5f8" }],
  ["path", { d: "m6 6 12 12", key: "d8bk6v" }]
], xc = $t("x", s1), Lc = [
  "red",
  "orange",
  "yellow",
  "green",
  "aqua",
  "blue",
  "purple",
  "magenta"
], c1 = [0, 30, 60, 120, 180, 240, 270, 300];
function u1() {
  return { hue: 0, saturation: 0, luminance: 0 };
}
function jh() {
  return { hue: 0, saturation: 0, luminance: 0 };
}
function h1() {
  return {
    shadows: 0,
    redHue: 0,
    redSaturation: 0,
    greenHue: 0,
    greenSaturation: 0,
    blueHue: 0,
    blueSaturation: 0
  };
}
function f1() {
  return {
    crop: { x: 0, y: 0, width: 1, height: 1 },
    quarterTurns: 0,
    straighten: 0,
    flipH: !1,
    flipV: !1
  };
}
const d1 = [
  { x: 0, y: 0 },
  { x: 1, y: 1 }
], p1 = ["rgb", "red", "green", "blue"];
function g1() {
  return Object.fromEntries(
    p1.map((r) => [r, d1.map((h) => ({ ...h }))])
  );
}
function ba() {
  return {
    exposure: 0,
    contrast: 0,
    highlights: 0,
    shadows: 0,
    whites: 0,
    blacks: 0,
    temperature: 0,
    tint: 0,
    texture: 0,
    clarity: 0,
    dehaze: 0,
    vibrance: 0,
    saturation: 0,
    hsl: Object.fromEntries(
      Lc.map((r) => [r, u1()])
    ),
    grading: {
      shadows: jh(),
      midtones: jh(),
      highlights: jh(),
      blending: 50,
      balance: 0
    },
    curves: g1(),
    sharpening: 0,
    sharpenRadius: 1,
    sharpenDetail: 25,
    sharpenMasking: 0,
    noiseReduction: 0,
    noiseDetail: 50,
    colorNoiseReduction: 0,
    vignette: 0,
    vignetteMidpoint: 50,
    vignetteFeather: 50,
    vignetteRoundness: 50,
    vignetteHighlights: 0,
    skinSmooth: 0,
    skinPreserve: 60,
    warps: [],
    skyReplacement: { enabled: !1, preset: "blue", strength: 85, texture: 30 },
    grain: 0,
    grainSize: 1,
    grainRoughness: 50,
    calibration: h1(),
    masks: [],
    spots: [],
    geometry: f1()
  };
}
function wp(r, h, u, c) {
  if (r.semanticMask) return 1;
  const g = Ep(r.feather), m = (h - r.x) * c, b = u - r.y;
  let A;
  if (r.kind === "radial") {
    const v = Math.max(1e-3, (r.sizeX ?? r.size) * c), y = Math.max(1e-3, (r.sizeY ?? r.size) * c), S = r.angle * Math.PI / 180, C = m * Math.cos(S) + b * Math.sin(S), k = -m * Math.sin(S) + b * Math.cos(S), j = Math.hypot(C / v, k / y);
    A = 1 - xa(1 - g, 1, j);
  } else {
    const v = r.angle * Math.PI / 180, y = m * Math.cos(v) + b * Math.sin(v), S = Math.abs(y) / Math.max(1e-3, r.size * c);
    A = 1 - xa(1 - g, 1, S);
  }
  return r.invert ? 1 - A : A;
}
function Ep(r) {
  return 0.02 + lt(r, 0, 100) / 100 * 0.98;
}
function m1(r, h, u) {
  const c = Tp(r / 255, h / 255, u / 255);
  return {
    hue: (c.hue + 360) % 360,
    saturation: lt(c.saturation * 100, 0, 100),
    luminance: lt((r / 255 * 0.2126 + h / 255 * 0.7152 + u / 255 * 0.0722) * 100, 0, 100)
  };
}
function Rp(r, h) {
  const u = lt(r, 0, 100) / 100;
  if (u <= 0) return h >= 0.5 ? 1 : 0;
  const c = 0.02 + u * 0.48;
  return xa(0.5 - c, 0.5 + c, h);
}
function b1(r, h, u) {
  const { x: c, y: g, width: m, height: b } = u.crop;
  return [
    r,
    h,
    Math.round(u.quarterTurns),
    Number(u.straighten.toFixed(2)),
    u.flipH ? 1 : 0,
    u.flipV ? 1 : 0,
    [c, g, m, b].map((A) => Number(A.toFixed(4))).join(",")
  ].join("|");
}
function lt(r, h, u) {
  return Math.min(u, Math.max(h, r));
}
function li(r) {
  return r <= 0.04045 ? r / 12.92 : Math.pow((r + 0.055) / 1.055, 2.4);
}
function x1(r) {
  const h = lt(r, 0, 1);
  return h <= 31308e-7 ? h * 12.92 : 1.055 * Math.pow(h, 1 / 2.4) - 0.055;
}
const ql = 4096, y1 = Float32Array.from(
  { length: ql },
  (r, h) => li(h / (ql - 1))
), A1 = Float32Array.from(
  { length: ql },
  (r, h) => x1(h / (ql - 1))
);
function Sp(r, h) {
  const u = lt(h, 0, 1) * (ql - 1), c = Math.floor(u), g = u - c;
  return r[c] + (r[Math.min(c + 1, ql - 1)] - r[c]) * g;
}
function Bc(r) {
  return r < 0 || r > 1 ? li(r) : Sp(y1, r);
}
function Qi(r) {
  return Sp(A1, r);
}
function v1(r, h, u) {
  if (!h || !u || r.length < h * u * 4) return 0;
  const c = h * u, g = Math.max(1, Math.ceil(c / 6e4)), m = new Float32Array(Math.ceil(c / g));
  let b = 0;
  for (let k = 0; k < c; k += g) {
    const j = k * 4;
    if (r[j + 3] === 0) continue;
    const L = li(r[j] / 255), Z = li(r[j + 1] / 255), it = li(r[j + 2] / 255);
    m[b] = L * 0.2126 + Z * 0.7152 + it * 0.0722, b += 1;
  }
  if (!b) return 0;
  const A = m.subarray(0, b).sort(), v = A[Math.floor((b - 1) * 0.5)], y = A[Math.floor((b - 1) * 0.98)], S = Math.log2(0.18 / Math.max(1e-3, v)), C = Math.log2(0.82 / Math.max(1e-3, y));
  return lt(Math.min(S, C), -1.5, 1.5);
}
function ep(r, h, u) {
  if (!h || !u || r.length < h * u * 4)
    return { temperature: 0, tint: 0 };
  const c = h * u, g = Math.max(1, Math.ceil(c / 6e4));
  let m = 0, b = 0, A = 0, v = 0;
  for (let k = 0; k < c; k += g) {
    const j = k * 4;
    r[j + 3] !== 0 && (m += r[j], b += r[j + 1], A += r[j + 2], v += 1);
  }
  if (!v) return { temperature: 0, tint: 0 };
  const y = m / v, S = b / v, C = A / v;
  return {
    // 将 8 位通道差异缩放到便于操作的 Camera Raw 风格范围。
    temperature: lt((C - y) * 1.4, -50, 50),
    // 绿偏需要正向洋红校正；此前的内联实现符号相反，会让绿偏继续变绿。
    tint: lt((S - (y + C) / 2) * 1.2, -50, 50)
  };
}
const Wr = {
  all: "整体",
  shadows: "阴影",
  midtones: "中间调",
  highlights: "高光"
}, yc = { shadowMax: 0.28, midtoneMax: 0.72 };
function M1() {
  return { exposure: 0, contrast: 0, temperature: 0, tint: 0, saturation: 0 };
}
function w1(r, h) {
  const u = lt(h, 0, 100) / 100;
  return {
    exposure: Number((r.exposure * u).toFixed(2)),
    contrast: Number((r.contrast * u).toFixed(1)),
    temperature: Number((r.temperature * u).toFixed(1)),
    tint: Number((r.tint * u).toFixed(1)),
    saturation: Number((r.saturation * u).toFixed(1))
  };
}
function E1(r, h, u) {
  const c = (g) => Math.max(-100, Math.min(100, Number(g.toFixed(1))));
  return {
    ...r,
    exposure: Number((r.exposure - h.exposure + u.exposure).toFixed(2)),
    contrast: c(r.contrast - h.contrast + u.contrast),
    temperature: c(r.temperature - h.temperature + u.temperature),
    tint: c(r.tint - h.tint + u.tint),
    saturation: c(r.saturation - h.saturation + u.saturation)
  };
}
function ap(r, h, u, c) {
  if (!h || !u || r.length < h * u * 4) return null;
  const g = h * u, m = Math.max(1, Math.ceil(g / 6e4)), b = new Float32Array(Math.ceil(g / m));
  let A = 0, v = 0, y = 0, S = 0, C = 0, k = 0;
  for (let Z = 0; Z < g; Z += m) {
    const it = Z * 4;
    if (r[it + 3] === 0) continue;
    const mt = r[it] / 255, tt = r[it + 1] / 255, Y = r[it + 2] / 255, W = li(mt) * 0.2126 + li(tt) * 0.7152 + li(Y) * 0.0722;
    k += 1, !(c && c !== "all" && (c === "shadows" && W > yc.shadowMax || c === "midtones" && (W <= yc.shadowMax || W > yc.midtoneMax) || c === "highlights" && W <= yc.midtoneMax)) && (b[C] = W, A += mt, v += tt, y += Y, S += Math.max(mt, tt, Y) - Math.min(mt, tt, Y), C += 1);
  }
  if (!C || C / Math.max(1, k) < 0.06) return null;
  const j = b.subarray(0, C).sort(), L = (Z) => j[Math.floor((C - 1) * Z)];
  return {
    luma10: L(0.1),
    luma50: L(0.5),
    luma90: L(0.9),
    meanR: A / C,
    meanG: v / C,
    meanB: y / C,
    chroma: S / C
  };
}
function R1(r, h, u, c, g, m, b) {
  const A = ap(r, h, u, b), v = ap(c, g, m, b);
  if (!A || !v) return null;
  const y = Math.max(1e-3, v.luma50), S = Math.max(0.05, v.luma90 - v.luma10), C = Math.max(0.05, A.luma90 - A.luma10), k = v.meanG - (v.meanR + v.meanB) / 2, j = A.meanG - (A.meanR + A.meanB) / 2, L = v.meanB - v.meanR, Z = A.meanB - A.meanR, it = Math.max(0.01, v.chroma), mt = Math.max(0.01, A.chroma), tt = Math.max(0.25, Math.min(4, A.luma50 / y)), Y = Math.max(0.5, Math.min(1.8, C / S)), W = lt(
    1 - Math.abs(Math.log2(tt)) * 0.12 - Math.abs(Y - 1) * 0.18,
    0.45,
    1
  );
  return {
    exposure: lt(Math.log2(tt), -2, 2),
    contrast: lt((Y - 1) * 100, -35, 35),
    // 当前渲染管线中，色温正值使画面变暖，色调正值抑制绿色。
    temperature: lt((L - Z) * 430, -45, 45),
    tint: lt((k - j) * 430, -45, 45),
    saturation: lt((mt / it - 1) * 55, -35, 35),
    confidence: W
  };
}
const Xr = 0.82, Fr = 4096, kh = (() => {
  const r = new Float64Array(256);
  for (let h = 0; h < 256; h += 1) r[h] = h / 255;
  return r;
})();
function S1(r, h, u, c, g) {
  if (c === 1) {
    g[0] = r, g[1] = h, g[2] = u;
    return;
  }
  let m = Bc(r) * c, b = Bc(h) * c, A = Bc(u) * c;
  const v = Math.max(m, b, A), y = Xr;
  if (v > y) {
    const S = 1 - y, k = (y + S * (1 - Math.exp(-(v - y) / S))) / v;
    m *= k, b *= k, A *= k;
  }
  g[0] = Qi(m), g[1] = Qi(b), g[2] = Qi(A);
}
function xa(r, h, u) {
  const c = lt((u - r) / (h - r), 0, 1);
  return c * c * (3 - 2 * c);
}
function T1(r, h) {
  return Math.abs((r - h + 540) % 360 - 180);
}
function Tp(r, h, u) {
  const c = Math.max(r, h, u), g = Math.min(r, h, u), m = c - g, b = (c + g) / 2;
  let A = 0, v = 0;
  return m > 0 && (v = m / (1 - Math.abs(2 * b - 1)), c === r ? A = 60 * ((h - u) / m % 6) : c === h ? A = 60 * ((u - r) / m + 2) : A = 60 * ((r - h) / m + 4)), { hue: (A + 360) % 360, saturation: v, lightness: b };
}
function Cp(r, h, u) {
  const c = (1 - Math.abs(2 * u - 1)) * h, g = r / 60, m = c * (1 - Math.abs(g % 2 - 1));
  let b = 0, A = 0, v = 0;
  g < 1 ? (b = c, A = m) : g < 2 ? (b = m, A = c) : g < 3 ? (A = c, v = m) : g < 4 ? (A = m, v = c) : g < 5 ? (b = m, v = c) : (b = c, v = m);
  const y = u - c / 2;
  return [b + y, A + y, v + y];
}
function C1(r, h, u, c) {
  const g = Tp(r, h, u);
  if (g.saturation < 0.015) return [r, h, u];
  let m = g.hue, b = g.saturation, A = g.lightness;
  for (let v = 0; v < Lc.length; v += 1) {
    const y = Lc[v], S = c[y], C = T1(g.hue, c1[v]), k = Math.pow(Math.max(0, 1 - C / 52), 2);
    k < 1e-3 || (m += S.hue * k, b *= Math.max(0, 1 + S.saturation / 100 * k), A += S.luminance / 100 * 0.35 * k);
  }
  return Cp((m + 360) % 360, lt(b, 0, 1), lt(A, 0, 1));
}
function Vc(r, h, u, c = 1) {
  if (c <= 1) {
    const b = new Uint8ClampedArray(h * u * 4);
    return np(r, b, h, u), b;
  }
  const g = new Uint8ClampedArray(h * u * 4), m = new Uint8ClampedArray(h * u * 4);
  for (let b = 0; b < c; b += 1) {
    const A = b === 0 ? r : b % 2 === 1 ? g : m, v = b % 2 === 0 ? g : m;
    np(A, v, h, u);
  }
  return c % 2 === 1 ? g : m;
}
function np(r, h, u, c) {
  for (let g = 0; g < c; g += 1) {
    const m = g * u;
    for (let b = 0; b < u; b += 1) {
      const A = (m + b) * 4, v = (m + (b > 0 ? b - 1 : b)) * 4, y = (m + (b < u - 1 ? b + 1 : b)) * 4, S = ((g > 0 ? g - 1 : g) * u + b) * 4, C = ((g < c - 1 ? g + 1 : g) * u + b) * 4;
      h[A] = (r[A] * 4 + r[v] + r[y] + r[S] + r[C]) / 8, h[A + 1] = (r[A + 1] * 4 + r[v + 1] + r[y + 1] + r[S + 1] + r[C + 1]) / 8, h[A + 2] = (r[A + 2] * 4 + r[v + 2] + r[y + 2] + r[S + 2] + r[C + 2]) / 8, h[A + 3] = r[A + 3];
    }
  }
}
function qi(r, h, u) {
  return r * 0.2126 + h * 0.7152 + u * 0.0722;
}
function N1(r, h, u, c, g) {
  const m = Math.cos(g), b = Math.sin(g);
  for (const [A, v] of [
    [-r / 2, -h / 2],
    [r / 2, -h / 2],
    [-r / 2, h / 2],
    [r / 2, h / 2]
  ]) {
    const y = A * m + v * b, S = -A * b + v * m;
    if (Math.abs(y) > u / 2 + 1e-3 || Math.abs(S) > c / 2 + 1e-3)
      return !1;
  }
  return !0;
}
function U1(r, h, u) {
  const c = Math.abs(Math.round(u.quarterTurns)) % 2 === 1, g = c ? h : r, m = c ? r : h, b = lt(u.straighten, -15, 15);
  let A = null, v = g, y = m;
  if (Math.abs(b) > 0.01 && g > 0 && m > 0) {
    const Z = Math.abs(b) * Math.PI / 180, it = Math.cos(Z), mt = Math.sin(Z), tt = g * it + m * mt, Y = g * mt + m * it, W = g / m;
    let et = 0, rt = Math.min(tt, Y * W);
    for (let ht = 0; ht < 28; ht += 1) {
      const Tt = (et + rt) / 2;
      N1(Tt, Tt / W, g, m, Z) ? et = Tt : rt = Tt;
    }
    const Mt = Math.max(1, et), J = Math.max(1, Mt / W);
    A = {
      bboxWidth: tt,
      bboxHeight: Y,
      cropX: (tt - Mt) / 2,
      cropY: (Y - J) / 2,
      cropWidth: Mt,
      cropHeight: J
    }, v = Mt, y = J;
  }
  const S = lt(u.crop.width, 0.02, 1), C = lt(u.crop.height, 0.02, 1), k = lt(u.crop.x, 0, 1 - S), j = lt(u.crop.y, 0, 1 - C), L = {
    x: Math.round(k * v),
    y: Math.round(j * y),
    width: Math.max(1, Math.round(S * v)),
    height: Math.max(1, Math.round(C * y))
  };
  return L.width = Math.max(1, Math.min(L.width, Math.floor(v - L.x))), L.height = Math.max(1, Math.min(L.height, Math.floor(y - L.y))), {
    oriented: { width: g, height: m },
    straighten: A,
    cropped: { width: v, height: y },
    userCrop: L,
    final: { width: L.width, height: L.height }
  };
}
function Np(r) {
  const h = [];
  for (let u = 1; u < r.length; u += 1) {
    const c = r[u - 1], g = r[u];
    h.push((g.y - c.y) / Math.max(1e-4, g.x - c.x));
  }
  return r.map((u, c) => {
    if (c === 0) return h[0];
    if (c === r.length - 1) return h[h.length - 1];
    const g = h[c - 1], m = h[c];
    if (g * m <= 0) return 0;
    const b = (g + m) / 2, A = 3 * Math.min(Math.abs(g), Math.abs(m));
    return Math.sign(b) * Math.min(Math.abs(b), A);
  });
}
function Up(r, h, u) {
  if (!h.length) return r;
  if (h.length === 1) return h[0].y;
  const c = lt(r, 0, 1);
  if (c <= h[0].x) return h[0].y;
  const g = h[h.length - 1];
  if (c >= g.x) return g.y;
  for (let m = 1; m < h.length; m += 1) {
    const b = h[m];
    if (c > b.x) continue;
    const A = h[m - 1], v = Math.max(1e-4, b.x - A.x), y = (c - A.x) / v, S = y * y, C = S * y, k = 2 * C - 3 * S + 1, j = C - 2 * S + y, L = -2 * C + 3 * S, Z = C - S, it = k * A.y + j * v * u[m - 1] + L * b.y + Z * v * u[m];
    return lt(it, 0, 1);
  }
  return g.y;
}
function j1(r, h) {
  return h.length <= 1 ? h.length ? h[0].y : r : Up(r, h, Np(h));
}
const Ki = 4096;
function Ln(r) {
  const h = new Float32Array(Ki);
  if (r.length <= 1)
    return h.fill(r.length ? r[0].y : 0), h;
  const u = Np(r);
  for (let c = 0; c < Ki; c += 1)
    h[c] = Up(c / (Ki - 1), r, u);
  return h;
}
function Dc(r, h) {
  const u = lt(h, 0, 1) * (Ki - 1), c = Math.floor(u), g = u - c, m = Math.min(c + 1, Ki - 1);
  return r[c] + (r[m] - r[c]) * g;
}
function zl(r, h) {
  const u = new Float32Array(Ki);
  for (let c = 0; c < Ki; c += 1)
    u[c] = Dc(h, r[c]);
  return u;
}
const _r = 256;
function Oc(r, h, u, c) {
  const g = new Float32Array(_r), m = lt(r - u, 0, 1), b = lt(m - h, 0, 1), A = lt(r + u, 0, 1), v = lt(A + h, 0, 1);
  for (let y = 0; y < _r; y += 1) {
    const S = y / (_r - 1);
    g[y] = c === "shadows" ? 1 - xa(b, m, S) : xa(A, v, S);
  }
  return g;
}
function k1(r, h, u, c, g) {
  if (r.length < h * u * 4) return r;
  const m = Math.pow(2, lt(c.exposure, -5, 5)), b = new Float64Array(3), A = new Float64Array(256);
  for (let Vt = 0; Vt < 256; Vt += 1)
    A[Vt] = Bc(Vt / 255) * m;
  const v = new Float64Array(256);
  for (let Vt = 0; Vt < 256; Vt += 1)
    v[Vt] = Qi(A[Vt]);
  const y = Math.max(0, 1 + lt(c.contrast, -100, 100) / 100), S = lt(c.vibrance, -100, 100) / 100, C = 1 + lt(c.saturation, -100, 100) / 100, k = lt(c.temperature, -100, 100) / 100, j = lt(c.tint, -100, 100) / 100, L = lt(c.vignette, -100, 100) / 100, Z = lt(c.grain, 0, 100) / 100, it = lt(c.noiseReduction, 0, 100) / 100 * 0.65, mt = lt(c.sharpening, 0, 100) / 100 * 1.15, tt = lt(c.colorNoiseReduction, 0, 100) / 100 * 0.8, Y = Math.max(1, h - 1), W = Math.max(1, u - 1), et = Math.max(1, Math.round(lt(c.sharpenRadius, 0.5, 3))), rt = it || mt || tt ? Vc(r, h, u, et) : null, Mt = m !== 1 && !rt, J = lt(c.sharpenMasking, 0, 100) / 100, ht = rt && mt && J > 0 ? Vc(r, h, u, et + 2) : null, kt = (1 - lt(c.sharpenDetail, 0, 100) / 100) * 0.07 * 0.5, Yt = kt + 0.018, Lt = 0.025 + lt(c.noiseDetail, 0, 100) / 100 * 0.1, Et = Lt + 0.135, q = lt(c.vignetteMidpoint, 0, 100) / 100, O = lt(c.vignetteFeather, 0, 100) / 100, Ct = 0.6 + lt(c.vignetteRoundness ?? 50, 0, 100) / 100 * 0.9, R = 0.34 + q * 0.4, Q = Math.min(1.3, R + 0.25 + O * 0.55), nt = (Vt, we) => {
    const ce = Vt / Y * 2 - 1, bt = we / W * 2 - 1, yt = Math.sqrt(ce * ce + bt * bt) / 1.18;
    return xa(
      R,
      Q,
      Math.pow(yt, Ct)
    );
  }, $ = Math.max(1, Math.round(lt(c.grainSize, 1, 3))), ft = c.shadows !== 0 || c.highlights !== 0 || c.whites !== 0 || c.blacks !== 0, qt = lt(c.shadows, -100, 100) / 100 * 0.28, Nt = lt(c.highlights, -100, 100) / 100 * 0.24, me = lt(c.whites, -100, 100) / 100 * 0.18, ne = lt(c.blacks, -100, 100) / 100 * 0.22, ct = ft ? new Float32Array(Fr) : null;
  if (ct)
    for (let Vt = 0; Vt < Fr; Vt += 1) {
      const we = Vt / (Fr - 1);
      ct[Vt] = qt * (1 - xa(0.035, 0.52, we)) + Nt * xa(0.48, 0.94, we) + me * xa(0.78, 1, we) + ne * (1 - xa(0, 0.44, we));
    }
  const mn = lt(c.texture, -100, 100) / 100, an = lt(c.clarity, -100, 100) / 100, Ha = lt(c.dehaze, -100, 100) / 100, Oe = mn !== 0 ? Vc(r, h, u, 2) : null, bn = 1 + Ha * 0.35, Hi = 1 + Ha * 0.25, Zi = S !== 0 || C !== 1 || Ha !== 0, ea = Lc.some((Vt) => {
    const we = c.hsl[Vt];
    return we.hue !== 0 || we.saturation !== 0 || we.luminance !== 0;
  }), xn = [
    c.grading.shadows,
    c.grading.midtones,
    c.grading.highlights
  ], aa = xn.some(
    (Vt) => Vt.saturation !== 0 || Vt.luminance !== 0
  ), On = aa ? xn.map((Vt) => Cp((Vt.hue + 360) % 360, 1, 0.5)) : null, nn = lt(c.grading.balance, -100, 100) / 100, vo = lt(c.grading.blending, 0, 100) / 100, ri = lt(0.5 - nn * 0.3, 0.1, 0.9), Kn = 0.16 + vo * 0.34, Mo = Kn * Math.max(0.12, 1 - vo * 1.5), Za = lt(c.calibration?.shadows ?? 0, -100, 100), Se = lt(c.calibration?.redHue ?? 0, -100, 100), ya = lt(c.calibration?.redSaturation ?? 0, -100, 100), be = lt(c.calibration?.greenHue ?? 0, -100, 100), si = lt(c.calibration?.greenSaturation ?? 0, -100, 100), ci = lt(c.calibration?.blueHue ?? 0, -100, 100), Wa = lt(c.calibration?.blueSaturation ?? 0, -100, 100), je = Za !== 0 || Se !== 0 || ya !== 0 || be !== 0 || si !== 0 || ci !== 0 || Wa !== 0, Va = lt(c.vignetteHighlights ?? 0, 0, 100) / 100, na = lt(c.grainRoughness ?? 50, 0, 100) / 100, Fa = (Vt) => Vt.length === 2 && Vt[0].x === 0 && Vt[0].y === 0 && Vt[1].x === 1 && Vt[1].y === 1, yn = !(Fa(c.curves.rgb) && Fa(c.curves.red) && Fa(c.curves.green) && Fa(c.curves.blue)) ? {
    red: zl(
      Ln(c.curves.rgb),
      Ln(c.curves.red)
    ),
    green: zl(
      Ln(c.curves.rgb),
      Ln(c.curves.green)
    ),
    blue: zl(
      Ln(c.curves.rgb),
      Ln(c.curves.blue)
    )
  } : null, Hn = aa ? Oc(ri, Kn, Mo, "shadows") : null, Ge = aa ? Oc(ri, Kn, Mo, "highlights") : null, Zn = On ? On.map((Vt) => [Vt[0] - 0.5, Vt[1] - 0.5, Vt[2] - 0.5]) : null, An = xn.map((Vt) => Vt.saturation / 100 * 0.65), ui = xn.map((Vt) => Vt.luminance / 100 * 0.16);
  for (let Vt = 0; Vt < u; Vt += 1)
    for (let we = 0; we < h; we += 1) {
      const ce = (Vt * h + we) * 4;
      let bt = kh[r[ce]], yt = kh[r[ce + 1]], xt = kh[r[ce + 2]];
      if (rt) {
        const Rt = rt[ce] / 255, dt = rt[ce + 1] / 255, Ot = rt[ce + 2] / 255, Ht = qi(Rt, dt, Ot), ue = qi(bt, yt, xt);
        if (it) {
          const It = it * (1 - xa(Lt, Et, Math.abs(ue - Ht)));
          bt += (Rt - bt) * It, yt += (dt - yt) * It, xt += (Ot - xt) * It;
        }
        if (mt) {
          let It = (qi(bt, yt, xt) - Ht) * mt;
          if (It *= xa(kt, Yt, Math.abs(It)), ht) {
            const ve = ht[ce] / 255, ke = ht[ce + 1] / 255, Ke = ht[ce + 2] / 255, Aa = Math.abs(ue - qi(ve, ke, Ke));
            It *= 1 - J + J * xa(0.012, 0.09, Aa);
          }
          It = lt(It, -0.3, 0.3), bt += It, yt += It, xt += It;
        }
        if (tt) {
          const It = bt * 0.299 + yt * 0.587 + xt * 0.114;
          bt += (It - bt) * tt, yt += (It - yt) * tt, xt += (It - xt) * tt;
        }
      }
      if (m !== 1)
        if (Mt) {
          const Rt = r[ce], dt = r[ce + 1], Ot = r[ce + 2];
          let Ht = A[Rt], ue = A[dt], It = A[Ot];
          const ve = Ht > ue ? Ht > It ? Ht : It : ue > It ? ue : It;
          if (ve <= Xr)
            bt = v[Rt], yt = v[dt], xt = v[Ot];
          else {
            const ke = 1 - Xr, Aa = (Xr + ke * (1 - Math.exp(-(ve - Xr) / ke))) / ve;
            Ht *= Aa, ue *= Aa, It *= Aa, bt = Qi(Ht), yt = Qi(ue), xt = Qi(It);
          }
        } else
          S1(bt, yt, xt, m, b), bt = b[0], yt = b[1], xt = b[2];
      bt = (bt - 0.5) * y + 0.5, yt = (yt - 0.5) * y + 0.5, xt = (xt - 0.5) * y + 0.5;
      let de = lt(bt * 0.2126 + yt * 0.7152 + xt * 0.0722, 0, 1);
      if (ct) {
        const Rt = de * (Fr - 1), dt = Rt | 0, Ot = Rt - dt, Ht = dt + 1 < Fr ? dt + 1 : dt, ue = ct[dt] + (ct[Ht] - ct[dt]) * Ot;
        bt += ue, yt += ue, xt += ue;
      }
      if (bt += k * 0.11 + j * 0.025, yt -= j * 0.08, xt -= k * 0.11 + j * 0.025, Oe) {
        const Rt = Oe[ce] / 255, dt = Oe[ce + 1] / 255, Ot = Oe[ce + 2] / 255, Ht = lt((qi(bt, yt, xt) - qi(Rt, dt, Ot)) * mn * 1.6, -0.25, 0.25);
        bt += Ht, yt += Ht, xt += Ht;
      }
      if (an) {
        const Rt = 4 * de * (1 - de), dt = an * 0.55 * (de - 0.5) * Rt;
        bt += dt, yt += dt, xt += dt;
      }
      if (Ha && (bt = (bt - 0.5) * bn + 0.5, yt = (yt - 0.5) * bn + 0.5, xt = (xt - 0.5) * bn + 0.5), de = lt(bt * 0.2126 + yt * 0.7152 + xt * 0.0722, 0, 1), Zi) {
        const Rt = bt * 0.2126 + yt * 0.7152 + xt * 0.0722, dt = Math.max(bt, yt, xt) - Math.min(bt, yt, xt), Ot = 1 + S * (1 - lt(dt * 1.8, 0, 1)), Ht = C * (Ha ? Hi : 1);
        bt = Rt + (bt - Rt) * Ht * Ot, yt = Rt + (yt - Rt) * Ht * Ot, xt = Rt + (xt - Rt) * Ht * Ot;
      }
      if (ea && ([bt, yt, xt] = C1(bt, yt, xt, c.hsl)), aa && On) {
        const Rt = Math.min(_r - 1, Math.max(0, Math.round(de * (_r - 1)))), dt = Hn[Rt], Ot = Ge[Rt], Ht = Math.max(0, 1 - dt - Ot);
        for (let ue = 0; ue < 3; ue += 1) {
          const It = ue === 0 ? dt : ue === 1 ? Ht : Ot, ve = An[ue] * It;
          if (ve > 0) {
            const Ke = Zn[ue];
            bt += Ke[0] * ve, yt += Ke[1] * ve, xt += Ke[2] * ve;
          }
          const ke = ui[ue] * It;
          ke && (bt += ke, yt += ke, xt += ke);
        }
      }
      if (je) {
        const Rt = Za / 100 * 0.8 * (1 - xa(0, 0.45, de));
        if (Rt && (bt += Rt * 0.025, yt -= Rt * 0.08, xt += Rt * 0.025), Se || ya) {
          const dt = lt((bt - Math.max(yt, xt)) * 4, 0, 1);
          if (dt > 0) {
            const Ot = Se * 18e-4 * dt;
            yt += Ot * bt, xt -= Ot * bt;
            const Ht = ya * 5e-3 * dt;
            bt += (bt - (yt + xt) / 2) * Ht;
          }
        }
        if (be || si) {
          const dt = lt((yt - Math.max(bt, xt)) * 4, 0, 1);
          if (dt > 0) {
            const Ot = be * 18e-4 * dt;
            xt += Ot * yt, bt -= Ot * yt;
            const Ht = si * 5e-3 * dt;
            yt += (yt - (bt + xt) / 2) * Ht;
          }
        }
        if (ci || Wa) {
          const dt = lt((xt - Math.max(bt, yt)) * 4, 0, 1);
          if (dt > 0) {
            const Ot = ci * 18e-4 * dt;
            bt += Ot * xt, yt -= Ot * xt;
            const Ht = Wa * 5e-3 * dt;
            xt += (xt - (bt + yt) / 2) * Ht;
          }
        }
      }
      if (yn && (bt = Dc(yn.red, bt), yt = Dc(yn.green, yt), xt = Dc(yn.blue, xt)), L) {
        const Rt = nt(we, Vt);
        let dt = 1 - L * 0.34 * Rt;
        if (Va > 0) {
          const Ot = xa(0.62, 1, de);
          dt += (1 - dt) * Ot * Va;
        }
        bt *= dt, yt *= dt, xt *= dt;
      }
      if (Z) {
        const Rt = Math.floor(we / $), dt = Math.floor(Vt / $), Ot = Math.sin(Rt * 12.9898 + dt * 78.233) * 43758.5453, Ht = (Ot - Math.floor(Ot)) * 2 - 1, ue = Math.sin(Rt * 7.7 + dt * 3.3) * 26544.5769, It = 1 - na * 0.5 + na * (ue - Math.floor(ue)) * 1.5, ve = qi(bt, yt, xt), ke = 4 * ve * (1 - ve), Ke = Ht * Z * 0.09 * It * (0.35 + 0.65 * ke);
        bt += Ke, yt += Ke, xt += Ke;
      }
      r[ce] = Math.round(lt(bt, 0, 1) * 255), r[ce + 1] = Math.round(lt(yt, 0, 1) * 255), r[ce + 2] = Math.round(lt(xt, 0, 1) * 255);
    }
  return r;
}
const B1 = "data:image/jpeg;base64,/9j/2wBDAAUFBQUFBQYGBgYICQgJCAwLCgoLDBINDg0ODRIbERQRERQRGxgdGBYYHRgrIh4eIisyKigqMjw2NjxMSExkZIb/2wBDAQUFBQUFBQYGBgYICQgJCAwLCgoLDBINDg0ODRIbERQRERQRGxgdGBYYHRgrIh4eIisyKigqMjw2NjxMSExkZIb/wgARCAGrAoADASIAAhEBAxEB/8QAHAAAAQUBAQEAAAAAAAAAAAAAAQACAwQFBgcI/8QAGQEBAQEBAQEAAAAAAAAAAAAAAAECAwQF/9oADAMBAAIQAxAAAADwQp2hcHSkpykoqXIhILKScyE5ARTaSdKkiEhwEUJJAY5EeKzm7LpjhuZsixUiF00cJqJGzR0ZeeHT1o5+TSpVE8Gxr4TE01Ny6uhzc69Xe47ZOhloWalDgAFDSlQBFMThebE4I0OCNa9srQ4DA5DGvFllydnqnJ0qJKpySFwKkpI5IqikJIiSIiCEgiSQQmwsHR88sN+JusvebRUm0G1ls13nMM6CPLDl3GSwXK9TOusqZ3VY3jZ/pmpnfiWd7XmJ4630HmN4x0hvnNNUmXf3uK2ToZqtmkElQKACEAcNGteGGAploIAHNQIgYHtq25Ox2RJVFEJRA4OEQ4RREkRJESREQRFISShRSYtczTrW7gzRWalIp1q1aLI3Zsd9aEOJr5Pir6GOmbt9V1nHvyHRdx0PH0cVv9W/j6OJx/SVL5dJ6arj5/8AMfsHmOnL5Fd6d5r7fnu1cW3c9Vr8ruW6DmGwpEAcAAjUALblocGGoiA1wpocBoeNS4UeXoJDhORRFFUUREOEkQEEKBCgRFIckhJNhnAdh5xcy24zZO+oqjZA2JJqyi/SF005Jt/n3j7fX63zezN37l3l2g0X3s2OzNMtNXwUH2Vm0aO3Xl47wr6Ywd5+H3+keY/R+Ru63Mb9nQS52iOJGokUBrxY1j1rnGnBI04DWvaAFU1E7zbKPD0FwcJwcqKICiJFCSQikIpCcCIoiKQopKhx2A51xZljgBSlqD3skiSFso/ezuux1td/yfrnm9mxs1dfzeuvNYNy69BduZr0N/pzhZoRVnC3Hz6Vo7Eed08vcp5vnXyV9x+C9/N4Jr4t33fO6Te5joMbspzd4SRoNe3WAirlocBjZGjA8EaeLGpx3m0SeHoRTlRREUhOBEnIanIaSgEoRRCQRJyI+Y6jzpMl0E9zezdXCIkJZJGKNXTwbUutuUbeO3oPdc513l9uxq5erx72p4bdwLbLGsz6FS315TtSsqxWIOfSBshxuvWuQZ3k8p2uUfEmN758++75m3vczo7x2MU8CpJdOaSNwEUjU4DBI2mB4Gpx1I1ItZnKdw9KKIiiJIiKIiiBFAKQiiAlCckFJFPy/vfO7ll2htJBjWKqKaF4CHSydBibctvufN/Vcde06XB6Hy+7X1crR5d9SzSq9OW1Nzdzpz6e5g2evHoI8UZ1ox1peXZIjGooJqM03Mr8xrJ+Rvobyf0eThZ6Fjr5vSm1dHn2pFL0edFJgpECIAiqYnhGpy1GpxskcDx9JKQSkIoiRQiiJIgJSBEqCSIoga+ucjxnR8zcT6tC6YASkcgRPZIt2WAS9P6vhd/5vbpadS7w9V27l8zZ1fMcr0fXnLJvbXXlxNXu6kctt31y67HV8d0uN6gY2I8LS52b4DlfRZunLyHN+hM7WPjM7nP+nw9r1nD93y7Ypc30+dFFhEFAUqCKACrAitZSJHOa7j6SURIoTgROBEUQIoKSEURFESKFRvZRweBp0mLb2qspBISDBmhcTdrzXsvH0dFq0dLyfQ0JYHxnjcvaM6Ctda1NHDZcbVLOzsb1Ymyc+g0s+7c68Uo6c8bF18Dl1l0mcPXZY/i1TeOf869B899vzd71PyT1SzMg1MvryRDtYBSRIoCc2wAixFKikUcQ7j6SQQkERREUgkESREkROSEURFIGLr4CecPrXWLFDQybYkUgc0hmivy9f6d5n6D5/V02plbnl91q0b2d0LE2eugznOZzvqeDr6fr8XNZnNdl283b+pQ+c+H6fsWhW0szXmoavXhxmL0mdx9HDfPn0x5J7/B5v2nR6VvgfOdrw+/Lo+xeKeuVp4HZ8b25NKMBFMgpCBFiaRqIhIUkPc13H0kpDkHCKQSkEhBSQiiJzXBSIkgM5bqONueGu07qX8HoPWuPo8NrfVflHPt5SrTfR4madewdF3Hnfd8u/ddDyvT+T6HQbORucuk2X0L7OHyPRazpx+xrW9PP9TtYuvDmLm7rcujVfpXiy9nSZ6S4PT4JQzOmja5Wj1cGenj/AM2fcPzJ6vn+deied7nr8XufC91xXXlXKWSSQklYAW6iSWspAiIUSlruPpJBC4EKKEQ4SSEihEOEQhxBE0og4nueAs5ezXmZ6/0XnPUPB9ryDG9pdz35G/L1evl4tjZPX8/U7jjej59e76ngup8vu7ne4/f49+juZOjLfc3Q3hlm5a9HmyYtGGWndktFHL3MLNqR1W8u3Q1m2bMS9Qu51DDfhazfLvXOWT4gsyw/V+H7tzk1TctVJ68OSSIFDQ4by1JagSSFJRKQ7j6SQQuBCkREOEkRJEBSEUglISkiIvOvR/Obnnp616T1b1/5s+gPm/fgOjz2deRcn3/Aev5rZuswrykv5Z1nt+l876Lh6fTuj886vl37PZ5Td59+i0sDR1no7mJpenyyRWCzBNHEO5TZ4Xj2bJHNy77OxznT655cd/DNRkkTVLmek42vkrC18j6fw/Wd3zv030csOibfLdMhQUkAObYARuBIWFAyTOa7j6S5rgkEJREUhFIRSEQRFIJDgJzRnmnpvmTODdo3kteleZP5en6F0fOOy8X1eJ4zvbvby83zkUuGbNFa7+VmhCJrtez8v7Pl29C6HjOg5enrdXl9qa3dbntHfPojlz9uEtV9fnul5d6x4pz79XlVvNMPUOs+aPT69Lwsnp2eqqWqltHyz03wHty8WoaWZ7vlbnsninfdeZCGNFBIUkIJagBCIEagKEk7mu5elyRC5pHEOEkgkESSCkgua4RBCCYj8v8ATPPNTm7tS9MsEVxdju/HNzz+33ijqbnj+jJ5N7HjTHzudjE9Ph1dLJ3LId5szfX9NxnU8u3QbGHrc+25p4ulZrWsy5vnaa+S4XP7tWuLv7kXLpkct6FHLye8+pLoV2Qrm/L30j8oevxc9Sv5/p8d/u+A9FmngrrxSShEIISsCQsQKoBBmw4Hl6XEEcgRxa4JaQkIKREQQkEKREC2D556JwdnIXKegzSs17SxR3LZB6v41Q4en6R77wIcu/W+SQVt8trouQ3U7bT5/p8db+5nbGOurrZOrnepo4G1LpXc2wayzhrF+CjCxbo4vJY9feM86bn2divPBM+qsxbW/BjfKP0V84+/51Olp0d8drtcXcmk1LrxSSEEkRCEkhADUQQZtEO5elFIcQQkEJBEQQoEJRE4ERRgBGlxfZ8qnDzwTMxziVaWrkzkNSWFLzKjYbPXla0tXBv8uvddR591XHv3+3xvRY79Jo42hnepo497N1ZqM2d2I4KzMHEdPxl74EHdaGfqeVs9jhx6fK4PWsrfli6WvodvheYeAel+afT+NkaWT3HLrsXI1qNSW+QRAkkIECBFgBFBpalxzXcvQSCEpBIISCFAiII4ghIIXAw1pQuY6bnq4G0pmIG2s8mztzAWSCZkk1K7FVaxWt5ps1Js72Om4jW59fSOl836fn377Y4va59uqv8ANXsdOisYlrF1IoHxNlaFK6zBHiXv1MXGROnVZtforxlu5vIez5PheLo0fR5JO6qaGdyNc3WGojWQkrlAoCSACLGgixoc2W6QefYlFSkglrhFIKBCQRxaR5a4JCC17AYO9iHCTmNizm6ddX4ll5ngKSV0E5TtxPWaHfpce1WatZq/03Jz8+vpvQ+X9Rjr6Bo8hucuvS6fPbWN6Usc2bLYboVFY0tDrzwI9apneVjb+TGb80++/Iv1vi6zdDR5denoWa/TBQSIJawEQqSSIOUrARctBFga5q3HMdz7vIISCIgiIIiCIh0J7XUSCEhBa5DcjZyzisza5hndNeQxp44YjbNCKSJySxyhexv5/ZeH38Nj+pYmpxF2fP1nQu5VvHTp+k89tS+r9D410U16/p+ZdHz33FvkL+d9ZNyi26SLmaq9HR5zG9Hk828qsWPZ87e6QqdYnhrLE5lyklrKSSJICSEAEIGltAEWWnxv5+h5a4cWuCgREEKREUROBCWkJaYKDSTOu1K5DjO44ZjaiqyzUdWxUSaMgEkasmfG+Xq/SfMPT/B9HYg6DR5d/MOZ9kwenPxmp6Zz3TjzM7s/WdaxzgrttjzGY9m1fDZc79yh8Lq7x7nR8Ti3y9c4nndftwz9vK72tutc0tuVsV1g1JIglcpBWFBSprmgSbYgWyJjm1Zex2O73Mehc0q4ghIIUiIghIIiCIgwkm0ak9ZOT4breRSearZg07tIe6N6Ap4yxWsLd9i8R73zev23f5jrvD9CWhvP6Z84wPWef3jyjC9OxenLzah6NR6cvP13MVzx463mzkWI+nxq5S0ZXbORoTS9A4vrG9jpcfc3OJg0aWMwpLUAI1hIIKAkITQtQC1AQLEtPa7PdzgUcQ5S5rhOBEUgpIKSCQQpIQTB2fZyjhsOzVYke1sWq72LHJFJY5qQ8tdLNepR539BeofN/u/z/qdxLDdmqNHYq6nM4HcZ28ef0+4obxxVbtKCcX596p5F18+AnL0eSPSztGWS9Qu53c7Xie95drurUs9uWpxHb5fPpyqdH14kJABGsoAXJASAICCUJqFl1wdjuXNcOII4ghc0jk0hIQS0jk0ji0wY3xWN4no+CMdzJWYEUKSKSASAItp7gYmZJHN6HuPge/x7/XO95d6L4/fdimZVWloV9zLpadTeMrP3cqXiPC/avCPR4WlSdvPVtVnmjaqTZ6aHpHnHd8+ulTld057kvJ9PjWZj9NhJQEjOnMNc3UDSLkAgCSUBBloLbL7mux2eWuHFpHlpHEEJBCkhJIJYCVrBZJSkz4zOP28Jmg9sgYrqKDrlIKEkrEFYUnkiDZZJ67876/3/AOZ+i4en6vn4jqfL7btcx6kFOzR3mDm9jmbOP8T9j8d9Pz3TwW+vGk9zh9irNnpodhw+lnXsXM9dkNZTYHb5dHkU78tSG7SuYgRSCQ0ObYEkBpaBjm3F9zHZ6vcxw5zHDixw5zCOcxw4tI4JAChJo6caWMM4JFh2HyRa7BRaxWUK9urBBilKRsSc0sRubK9zxNWdnNfz69R9A/MnY8+30RHjX/L7X0309KmDrZ++XAeOe0ePenwKaNdeMimo6yLEM+dunp2Jr0ruvFPX50r85uUrjJKFw98ACkKQIAEBBIDXNsa1zS65j5pzmvEWuC5jhxa4Ja4LmkckBmZdxkq4Qwk0KsV9Kuner6ijr7S5tavFBDDEUijJWSRBBsKIpGyzOjUvbVLUvm9mXT6rjuvH2P0XwT2HzezeqOj59qisT6z5t4/7d5P6fDzD22e3nVZ5uYJ6psvGB83e63lbMvbTc7F5+/QV8rU6c45K0O86Sik1hAigHNGpIAIVoIT/xAAkEAACAwACAgIDAQEBAAAAAAABAgADBAUREBITUAYUIEAVMP/aAAgBAQABAgH/AHMXsa0j5WfvqepXo+R4bz37reun2rdX+1uv9ixDQzrrqBgrJ+s+b19f57DrZXaCGP2evQPCgAhamhQ1+nQI1Va/kfK/HnG2Nqup33FZLgVJH2F1ruIg6aBYoYBJ+t8ZUmuVGuz4Ls92O/irshHj3Vqrff7AnZegJCrPZnLAtZ6HWofQqU46sSZKqRTZQcgz/qaeG1YICCj1MD9fqtQIa4xLC3sEP8hZEdqMlGOnNXlrzrUaDm/W/W/WOXVx/I8MyRGBDH6/dcIZ3XPZIbBPcmisnLipx0Z1RQo6A69evUo9d+bmeHYA1FGVh9YZptEqiF2tYFik77qTqijNnqqCKAqqF9fUrOumDLoz85xYiMrKR9byFsaNFLuCQxE6rWtONy1VhSoAixQJ69EdeGV15LJvy91GqD6syxyUlcsdmg8GLKUqSqnKqeCOgFgAhhnRh8sLU/JOOEQ+1Z6+pM5GzsRQ8Pgg+AtNaNgrpFcWCdRYpU+DD46MYONtHKZUiHO7Q/VbXc9WRjEhPihS9K1rXK4kEE6WDyY0MM6hjC1fyXjx4qdYfqbWsaVDS5/kSiM/F10yuLEizsEFQJ038mGGWTYnI5wVbKxH1GuyLKha38oFYGgZ1QrFIZrxqXWNyciN37Qfs+CXN2m7lLOX5kIROPtt+oM3Mxrlf91xm46rNSkAUg3bX1o40tr8fKmhXhLHRbtseuyq7IVWYjYfp7DuLlf7EBUcXmqVQD3r5ESjEvGf8xuMbGM7UV1oRDHbRDkXMufTRydXeOWD6e07jGl/9DxxmWuLFndrpgpoVEEIKlOhK4IZZGKr6M1r/kaGZjkSz6e06mrizU39ZaciJFEZVCQRWFp1/vNyC3dyuLGF07qnJc+3Pf8AU5u0TGcM2J9NYbSkQXH+VGJaCkWddQOLG027dPOV6sO+nbn0LBKpYuqdc5rp5HjJz1OtllUyJyS/SmaC3hQ5/msZZQ9crigKyPH037K+P5rjUt/HMXJ5MNlYcVM7aVoW86fxzjOM2WcnnXxxFnLfTE6zDF8Gk+QK1rfM1TVysKvpbnOO3LSqo/4/lxmpMFSGAq1qrLFYfHbXuwOk4GbgfpTN7LBKV4vjbl5DG9XxqqlGzmo1GuJBOmrNQqUdlRVVWQfCky1Vj1+hrer8kwTHdqHr9I85A1hJgS7S+Znrd8VsWVilqWqapkYEHr0FYq+Mr6BGDQkMhvVDGXpl5/HFmK73sT6IxpyBTxwlezNlXkOPtz/suwlIoel6nrdHRlKlYqdNOgAHjx3VkJLQeDGmxdSVN+Pwj6MwzfE8cC+6cemm3kbfdV6rNT12VW1WVvWyMpQo0I68Ob3d1NZAuRPBjzVOQUTgTylddn0I8NN8BaZdWu7jzpHIVKqUMixSltdtNtdlbo6MrIVM6haxr7lgivRZY1bmNHm59TTjDyQjJ9E05CL4I4rdwV14uTXXibWHhAlVtFtNlb1ujKVKEHskmwtaj6eTq3V3G/JcY0sPOX2hpgfXo+kYchB4rlN2LZyj4bNnGWU2NZBOitLUPU6PW6FGUh+yTHXUtUf8TfiKNVbcfV2Tafyi+xzMbV3fSNN87lZuXBr2zjU9nm/E4ErgHpSaXrKFCpVlIPnVkHHJXqwJxP6yQF5c35JdYBMco+laciCBENksWvfxen0aaqNdIitW3rWKpUUKxSpUiCCEtDO2dGugbt20Nyr3tM4RfozDORE7lktCrVt4/mX0TnVJRkNRVUVIkSAggqQxPsS7M/7Ad9lV/uz77bZZGmMfTbo4c2xp1UmqA8VuHP38gH7qalqisQJBGdSD37+/u1t2u3b+0upr69NN3f5G9sSdYFP03IB40sCyso+nxQ1FoikGpqXpetkgilYsB79i92nRyL6gevX9RpjlQ/NX0J7VpWp+jPgzkBYOnlJeezkTtnHhSjU2VPVZXYjqRAwPZLHTkXjFzrS2UUvWHLZp+V6dJAy1L9Pul8UWATSO4PDAeBAa7KbarEsSxbFdWDAkwtZabC3zm971YTLZZfqamjofT7xqFYXw/kwRvA8CA12VXU3VulodLFcMD7EullL53yjj6uNShj+Q7MhAyVD6XrxvmqZ4geK9g8CNDK4ywQSu2m+u5LVdWRlIMACikZ/g+Jq7QifkG3OaFz/TdwzbNgyMRYimwee3FcCPT0D0rU6Kr67UdHRgQREKGMxLMZzGxiK8lCfU7JeMsdrYYCfIhCzODVbmatSCAllWqrSmivQlodWDrZ83yGxrPf8AK9/Weposb6jSLlqLk2OO38D+MRCNRbmsoisHEV01U7K9lepdHz/P8/7J02atXJ3tWnHrbFPZ+ntliNLCC/8ABh85Zngqai3NdlensOLPmFqXpsTkF3fvnkW5I8lZy1uqyLXxx0L3d9N3LprhiEGz+exO8b5Sk+J6Lc1ua3K9BXv39xcNf7j7jtOr37SNMufGOTrYdfT3TUTF8P8AwYYPFDZHpKqa7M9ueyi3M+Zsxz/B8HwGtjBB47acZWZsQzv6d5vbw0JP8DwCJxejO1YCstlV2eyl6mpNJoNJr1nwIsXxUMptGWzTS4+m7c7GHgEwj+DFjTPbx2mpk8EOttVlD0GooVccgfAixYxrFfgtoqYfTGXtYwjQQ+B5Pg+BON047hBDGDK9bVlDW6XjkSIfCeDKTRVqFdjNsqK/SEzdc0UGCd+D5Ig8U28RrocM8MIYFWrKOuubWWMIpE7rlKxmpt9rU9fpL7b26Jh/vvtYYJh1YORR+zDGjAwy06ntILgeOxAOPa9HgNVtsc/R2WWs3nrr/wAFjeFOLbx/JK/sS0JYtND62gjeDBFYNx1mqtoZ2LbBD/u779pYb5a3gVkFT/awwwT04/dh3e3fsxaO185OL5MZUgCzNbntvQjsxntrP0HbM40aIq1p17MPDfysPgRGsTBvy6/YkljYXnJeABLAHjQHvjdbJcpHjv3/ANhhY3Na9l13qCtjHss7/wAiGL4WVAqhM4vdRf7EsznraLQnglSYhgOPSdV6tX333/tJe1tjaWu+ZVWvsQl4Z7GBj/HRiys6q1l2etsGtbCXLT11rtRY0U2AFGMUAY9hvZ/lcew/2tNEvHaz1zLYe/V/PRPgwxPJiTPGlMvnGTCy+XGqciFhlcaDxXDKzpiN7uao5Qj/ANP/xAA/EAABAwIDBQYDBgQHAAMBAAABAAIRAyESMUEEECJRYRMgMlBxgSORsRRCUqHB0QVicvAkMDNAQ4LhY5Kisv/aAAgBAQADPwH/AHsqAhnNk6r4RZdmLp0eKAibyiV1TfxIHJ24rkid30O7Xn3CMnFPEjFmnAeNvyhNMAjD1CJkAggLQx5rCHNOrHosDbCAjhxP+Sc/i/JEnJQE52QsuoTfxfkmmR+aovboOsqhg4fmruwaXlOZojukd58RKjRQLaoOAGunNHIrr5mGCE6s+6wDC3NEjE7IZJ1YkxZE5D++aa2AfUlY+PCMIyCeWYnWHLmiDf5Ln8guiPNYGjMnrCoy7ExoWy7Q2zA0c5Qc44DrrYp0Yo1hYXQ7kn2gZpzd3Ld1RXWFof790HACy0Juo8xFNhTqz1gbhCLjhHuUaj4aLSoZhZkg1pe+505FEycQ0TTJAkA8IP6p2HGXZan9EGiDYk/3PVPd4fmdV+KSRfouQnqmAZn0yTRkPzVoaXXzh+arlgAqtcBo439U8ANqNa3W85+6pF0mHR1THuDqbsOeK3NMc2mbDhzTyZYLKow3aozCHNHmjqo0UCAbfRTHpZa+YQJRe7CCsI6qwaFbAM1wCOdkCbjhb+blIxOi2SxQ3rdYgfwtUMwNhZPqWHLmh4aTQnOu45XvYLFwsb8v3KLzotSY9kDe4IGYCcACMR6pwEYZGoKY8QWJn4JTW6VPYwniQ3I801zA0tGLkg9vCFVoaI7yL/mpstc/MMFM81il3JZuOQX39SbBBtm2JXZ35WCjL2To+n7o3A9ypGFtgEKd3XJzVStcnhQYJcIATqpvlyCL82wOajoOqcR4Z91YYx+v1QbeV1QKYYlqpcgm8k3khFhCbUaQWhGnLmBFhg57tDksvqs3aa9FYenl0rtKuEL7oXhpAayUATyai7HVKJOazcUSZ1RaI5rQRAuT+qxHogAH1PCE6scXyXanIQ27icgpwmIaNSg0A4fmozJ9MlcJqKOiuNw3g5prwRool7Ai0wVF1MNmAVib1FlIw6geXdjSJUuJK+8cgjD6sXJgIBvZjmsDGsGtysxzsuWSzKOQU8M9SViIA+aNQta3wNy9SjVcABH7JrWhoEgZdTzWGHOBJ0/8UaXWE9fzUf8AvclW7gQ5JtRpBCNBxqNFt0WRjHqDcJvDESbhcQ0BVz5XJWKpgnJWDeZUNFManNRgbo259SsdQuP9gLG4uUK8DRYR1UD13FrcA8TtUGhx/Dp10XDjdrYfumtgBqgyibyoAAXJdFG+e6Fmm7RRc2E7Za7mqwKm3NOwRB4bhCWm0TIVz5X2dNxRqPc5S4u5LtKpOg/ROufxFRIHKN0yVClXui9wJXE7lojWqspt04nepyQs0ZAQr79TuK13D/JxM7RoUSFEIgYr9Vwt/Div7qTbyuGYOawMWFnssGzzGcfmofffh33hYWj0TWMvoEaVLE7xvuVhbbldCBvBUd3PvarNCtTc0jRHZdpcOq/NcRBRAIOYtdCGOac239VHlXaVoUwEXkDmnYGDndEmd3FPK/cFSr0lWn1hHaK1NnWXLw9fosOi+aCjuZd23eEXWNhqtCi3JXn+7rA/mEajIHIEfTyrCxxWKoSpJWIk/L6LjjKG74b69zDTJ1dksDLckAzG7P8ARE1MWsfJX7g3fRfJaq6hTKy70plWk9hKOzbS5ukrhTjBlYmNMgSwx7qGiQbzHz8pimVqjHqUC8RaP0WJ7jOvekgIQfkAu0rCL3C7NjWAeGMXryWFsnNCRbTNTut6po1TFTFi6CtnAN/urZoA7RqoPc5oeJb1THgQczCBusu6yn43ZCSqTLa69E1xIA99F247QNyK4YUH81m1hi8hHg6N+vlEBfDPyXDC6f2VIdhtbvnTVZx6BEuxxfT1XGAcgJ9SmgD07lNnCDxIk5iVVJx+ARmVSPE1+Mt5eG/MranRcUzpcaLaX4pfnYzcfmqthjjBkf70VSImzmhw/qROCDm2fmVI07mFpRfF8zdGoYvhnJVZIB/KVU7NxLcNsuawvcFkeSJe0Tm7CI5G4WZizqY8osjwM91dYWTkUGbM48+/A9UXHLosFPG9Q72QULhlYQWU/mq1R2RVZ5EMgcynVM+P+oyqX/IxvyhbJf4eH8vomNGQWUow2LQsvl3cSa4idEycrKk2waFSLCIF12G2FQVD6Zd4Q6/si6lSdnIP18pHbRyClyuAMgoZhi+Lvkldq8O0Fh+pTRhaBAark9VYKAqlbgZZvNMa4Odf1TQ3wt90z/40PwtXT9UITYQGSKAUjulyDc0IlAgdQorB24GJMcQBdyX+ELs8FSfzXxH/ANR8nmoFNZ56rixclxt6fopwTmZJPr3zVfGmpQYyw9AhG+SgMkAggoCpMMF9+SYW2ZUymYVIUwXYhoJGqa/wuB3T3IV1hbK2TZCWYxiVTa3ObSY4+pVXFxywnWZAQq06ZVgh2gaRMnnCEVadpLy7/wCq7PaXtt5OJJUvcuA+q+sfqvid6UBHLUoYbLJW3lQgNUGBG+N4YP71Qpf6Fuq/im2bPtNegx5ZS8XEB/Mtt2mvSpB8EmGmciVtGx1uyrMLH68nJtdgc0q6jNB1lZQphVdk2R4oji58lSp7Dtuy19mFR9W7KuoKc3a6BGeMKKzSxmYuvhUwTuvEtBLhnoiKrHCoCKjJk6Y7H6It2n/qPJrLxq5UMaPU/orUxrBKl7vXvyRy5IOA3zG/Cms1W0OBFGmfUraNprf4omFg2Sm6jT4WZx1W10G1GUaz2NqCHgHNPr7dTEWaQ4+yoV2YajfQ8ltH8N2qlRriKdbwO9clJQBhQsTVIQxBMr9tSfScZcQUYxUXnPIhUNif2td2J+lk17HhtMmRElOYxrotvmk3F908LuhvCaaxcDixCZjyeGu9Vqo4fQLjJGgACLnZaqsBJpP+Xd1KnK11DR3QQpsqbcwhyT2WGSqOEOA6rYHlxNAAnkSF9gaWbOwMBOcXTnn4jnH3VCphxMUOU75CwuTmu4U7VNTYNl22yvbHojTqOYc8lZdpVdSxwTceyLWbO5wxTTBP7K/kuq4fZS66xO9ynOmPvOVCgwOwy7mVs5bgMKhVM2B5pzDCdyQClXurDdYLJW3TvI+6nN+6n/hhOduhQO5KhyBEFBBBCDZfZ9oFZos7caG00XtJbeCVi2Zj2PxS10+ycW44tlPkllw+yPF6Bcai/RFxpWsCSqjBgoj3W01iXuc4lV6Jh8kDmmbRmAeYIWFpwlw6Efuo1U2U4F+R78oE7hqhyQ3ZKO5ZS3dI7g2jY6g1FwtEXOAFvonbV/BjiaOA5p5a1pdYZBNaxjg65zHLyOyzCzXi/pXBPVNqPAdpCYxgLeSY5sKhWp2Giq7JUmLIOo3PBCL3kqAuKn0gr6qYWW7LfKC+SshF+5ZR3JCwv7odTcOi7Paarf5iocJiNbSi87TSflhMSi1xadCpZPLyPJXRxulcL/RWYE37UxvMT8l/hpUsLiFEwVVrPM+EJxGDQXRNguS8Z5MQgDqst0gLLvDffdayjcZ3W3SO5Yo/a6pAtiJRxWVXt2iTxDDP5oUtteAQbaIMZVaR4h5J9FxE6YkcL0cTLXgL7LtNB+mRQdsOIa3TfsLSEYLosEWsbTA+I+/zUGSJA/NMbsgdq78/RYRCgnqPqst17LTflvnvy+FKugmRdNdkh2zmdzDTeehWOHXzKuE6ntAAOZv0Ke5mz1HDTDPONw7BlTrHkcpsiM5KsRzhfFb6oPpEahfaNgfszzxtWPZX0vvCUx04vC0SU/a6tR8WePFPhZ+7lheBhwgCwTH0Gt1Gah8KHNV1+ShdVlKPcy3ZdzhKl5nmhC2PZ7VKzGnqVSrcVN4cOi4c0IldttltDfc6Wxlru7PYq7v5YXwWG6GEKHRzXa7OKbrYSC1vr5LwyvB7yvqviei4X35L7JtTXtNtV9j2vtf+Op9UW7A51OCH2T6zhIjDdw5vP7BO2kYmRK2jZXcTXN6rt2h+ozVm+qmELEaogz0UEDRaSpUd3r3MTSCnUKzmO5p9VsMziy2p9Z9TaKuKdVtOxVZoVsJCqCmMZujWaSTACDAXxmrbrKKLaQ+876L/AAzGRqhgCMVGCJzBXaUadrhsHyXgKONvojM9Vx1JUON9FOGOSaQKFYSJTqOy0+xqEgjI3jVYv4e0lsOMk+q2ihUsJBKobRS+JSCFEuwCy4XDdkgW+yh0i0hGFkr/AORfdR2gRUb+6bR8D3e6OqoVm3aE0u6JjC1sWQGW8arFtjWfhb9UBSbzQ7MoCrJEhAU7eS/JRWHov0R7Vw5yEAZ6q7IyWF0jlKqYMDyYghUvslGnOTf1TXEE8/oqbYBMJtZhI6o0ahB1UQtVwqQosjYjmgYR78b5QUthNhNOShRu4ShV2qs/+eB7IdnTbC+GiXBYAB5LYqatP0V/ZHtOuILDVI6qGs9VMeilVtkfDTaUyphBOQVTb6jezA7NlRuM/wBWSYGNHS6pEYmaK/vu6ZKRG63I7rKDKEd/KVZdVRFoJVOp4XKJaEHWUqybT2eo7kFibi1xfVF5HosgiXZeTjtqYNlDj7qHmMrfRQ6V8NSyVOIj8K+M/wDqTmwQYTaX8J/iRd/qh9BzPQEyq9RhayncNJ+S2naTxOtyU7p+S+ikBXVt0JzAMLMV+9z3U2IvOaxWT280cRV81jaPRXC7DYT/AD2CgD0X+IotdlKiqRycUAcT1fyYY6JKGOD1Vv8Aq0qC7o6y4DI0RiOShripeCNWhSEQypTnxBPpMrFpjEwsPod9lCEKC1Zb53W3xuwjNAWlOebqu4Q2m6Qc4X8Q4vgH8l/EnH/SjqttI48J9CqlOGOY4eoTxRErE4WsmtZsVLW7vkix1PqJRx4uqNSv1JlQmwIz18mGGkeqirCGFv8AQr2++xA2cVheVeyljeihEGQi7uwoVldTvhDuP2mkWsdBVFj29qHnOZVJtJga0B2H9U0kgHIH8k5piyumgXQlY1chfaP4v2Q/4WBiJeJ0bCkqJefKPhM/qRDxZcI9HL4dNw0Cw1M+oUw75qFNt1gVf/JyXVBQgrQN8K11T5JmYKtdBNI8QQeeH5rC1CmKlV2TQSfQI7Vt1Sufv1C5YqrvVHG3qhAA8nKmj8lheD0sppM9wh2IkZG5Qy5FCpRBi4VyFqroX327kWVlkuqn17/NAlFVNJC2w+F5C213iquTh4pKFIIuMBfZf4Z2QMVKxw/9RmgHoVK5xWklONDGfu28p+Ar/wDWymmbZOlDjYfCf1WHC6NL+yBm8LXfy+W66nfKhYVkrIQO7eL7uu4FDkmjRDkgNxbzC+1/xF4aZZS4G/qoY8whUgRk7NdkHsizmeTWjfNE+i4KZ/kRAf0hOZViztfWF/8AoSFkPZDxDVEb+FQVdYgiERvLUbIHffTfpvam5oIIFAuQ2HYa1QSDk31KM9U0ihBs/P1RZj6EqTHyUHyj4J9EHUWc8K+JH4mriBmYP1WJsgC1vVQVLcM9yFaFBQe1WuuiLVCB3OYuq0QUqUO+FisE6ttY2YOOCln1cpLUWENfzBV+Hmjitmp4vn5RNIiE11GmNYKw1G3hEGI1Q9nKRPzCKPi3ab7rRSN3REIt3gp7ckRmv5twKHNDd13DnuZsWzOqn/UMhjeZRdUJOZMn3WJrrcQv7KaTxhxEi5TW1DgnD1RBxNUHyjNQGk6yocpIcMjkrIjF633WjeLEe+/7zSgQIUocl0UaJzURu6rmE3mQjo5PGcrmU3mo1Q5oc03nJVOjd3Efwj9Sq21udWq+g5AdFxEozRJPibeOSrdsxgdwk4ITmVHNdoUQITSWuBzbfyjgUtbH4VdDA3oVBMq/djeAY0KFhHosp3dF03dFCcEd9RuTiqvQqpyCqi0BViNFXcfEqhmXFWK+DkrN6oVtia6k/wCLTN+idn2gxYzilRtTHRaqwFYSQdFafKJYQvg20G+6FvTu678Dwg9o5i4TXCQo9E1wgoRK6ILp3CjuwqXE7rqY9V9VGzojszogGlzmlwfp1RpuIFu0dbUrt9iDw4YqToLdYTXMB+8M/KOW4DhVlw+43WHvvsrL5HdIC05I2Zyy/ZCWxGFwkL1TeqAvHugcwrZb+m4b8LD3LsX1R7OFJFImzvqn0jgGYdI5rtQ1+Q/PEi0A9m2KgIic/VHZa5YYPpyUQRkfJ4RMrFVK0Vp6qwVmjuQoMLUK6uCuzqArtODI5j1WIA91pXVFEadzIcz3PCo+a4G+quTyQqYcNnhAva087KJa1vC4CPUclTr08DQMYuD+iNMwY9PKOzplS4ndkN093JQtVI3ERAlyba/CYj3WRgLmFdSugXRRnuHJdFAK+MB03QVdeH1R4lwM9SodKc0trQcHNB+AsEA+H9kx+DSLR15oUXOcwjATDuQ6hYhjMX1Cw5+TQsRICEK07rb/AJq+7msl9FYbnU3AsdCZWaYsfw6FDDYzZAgFWHQoLp7IahfzKeS6bgBCxbQ/umXL4Y6FBjx6rFRJp+HNEsDCRfJRBI4gbqiTgqUwZ1mycxrmhrezJiToiA4U57PPDyWIw35eSdFHC3NXIUlcMc91t1pQ3Tushy0WaIc4dVqFU2eoHNd88iqNdoe3h0PKf/U22iBFtxR6LouiHVAKS88gsT3Hqsu5xeoXwyhDCMiL9Fm0OlqwutkhUALbuAv6Iua1vLJGozC7xDSbKuxvBHZh31WI2AlNOvkYaLZrs2knxFF0vOSuskeWaOff+m84r8go3PY9sODSMnfumbRFN9nj+7LLC5SG4hdDmgjzQO6AsOz1HKe5K4R0USokhFtUt5pz2tcBcWITqTuRCDrtz1H7I5ts7VYmYmVQ3FZ7SuLwx/ehTTylDQ+QdEdU1nE5PcJdrkrYBvdnhK559FAsuXdsVbdO/tm4m/6nLn/6sJLahhzcn8vVDaWdcroFoiROm7oug3yo2cjfMKCo91mFb0RNhyRp1WXQqWdfEECXh5OPQpzTdTmhNj81VwtLowOtZUgYpvDxFjkoAaWQefkMZpzjjNgr2RKlWsz30X4ngf3yX4KfuUTuJ70/NQpG5zckamHaKRwnWeifSeCIuYc1DaKV4nKf3VlofnvssTlMhQ477IvYGnRXstQvmLq+JOwBrYhNrsBAOMKnVBw+JvPVEbypif8AfEaJmqabByYzmT8lVqawENSheLpwbw0gOpunnxOkJoHWITRrKJ/yLbrKXNB5rBUc2LdVUouxMuqdXjpjDy6H9k+nFxEw4dU2o21xyUqde5JcsNVysVdS1YStQpEFa8locivs9YQgA2o0xObkZ7Sm+V2tPtG2IzRFj5C4GzZXouSnIe6fe6LrmYTQ3kifCIHLVFon80x2cD0VLl7pqb+HdAiAQm/3fcN1lmrt9UBUB6oOqhw/CWn/AK6qBHJVKYxs8LhdqFN4LbMd+JHDE8bOerUHsDx7hXWqlQ0ndhq7rKyi6iywTaybEhA2mxyWMQBcIFopVphfZ/Bdh1XCCz3TXthwvzRZ4l0/3+SDQIRU5puMCLQg+qGuyXG7obIh7UOwPTJRO+yJ13fQKwV/fdb5K3usvXdj7MOvZ3/8r4w9Ar1Kf3YyWGsWDw5wuFjtcZb7QiWX/BKkN9Cp3fCKsEMQXGvErLh33VkW9mRqsNW3JEtAOWBObkUcKmldEBH/ADf/xAAqEAEAAgICAQMDBQEBAQEAAAABABEhMUFRYRBxgSAwkUChscHR4fDxUP/aAAgBAQABPxAzKh6VK9T9JqVswJOFUG2OVQWZJFvEWtQT8xtCruK63BXSCU/8izkD8VEDdwFrVwBi3lgCnQvwem9//SoNgc5qblMG/wDSDmNjh4gKg1ADunZAQZQOOJXH2G5PLK9QKWlPfbOHQLuJoHWbI2cS/WvV+w/SkSV6kr016EP0jlqKBXUzMAm3aPENAuzzChccSwtQB8CbILWjHywuOitypanGVNkdFsLZVUAUFJhFVDN3BvQUjyptukYcRuqseDqo0DR5Pi5VeNRRT+0R9hjZFwYzAl5OWC6CA4N3Uva+cXDzdNYfibSr2F6mKuDnX5JQ19gyo7lP2GPofZP0S0Qios8c/YijlbIdY4jCrgaB0TVr0edW/qIIG/ceIVqLGmD3jivAFqfAIYDbV14PLxGlXq3GyYFjc86mE0scVlI4DIRrSmAAhL7FODcWQVS7DMDbbRQ3JmncfYyknu3fiJXIaM5uU46ruViiCYjnUvcXqlJTWEGl0J4YRpW3eSIhT7uw8coxrUWMQvEcJErdaut1f2m/ofpYyvU+mvoPvuWMi5qK3zgl2AW/yy5mVzTBYqAuVugTT5lcaFcuACNCAWGjBfBMKgmAXu1zLURu8t9CBrLAF577fwgumBdXZT0ErloFlQHxArrVs4vwf4MyTG6Vf8xZoo5yfyVL0KLFUBxEbTYzINBpsgGmyxJ2SkdZQqj3aUxZbULIrpfJHYYh0TV+JwWLx/UXCYeCO9UvhT3JfCDGETyf2QLVhWDZfsxBQdFgSDWqzm5dgNM16v6Kv1QNDHGNwXayI1YCteV7Zhaj+WcS5Qr35CAZTjTbIVVUAGhY+RrI8DCrNFV7C+vPmVQYl377z35gRQaUZV1/yES35dnvcyoUWcT2uazAwvJ7hTkFebfyxFMty2uCNKxaKgI8tLC+8w9ZwPYwaMp0lhXVw5qzm0PmJKXO7g/lYiysxitndOJYMpoa91g5EVqKtuomjdxTnErw6ipdwVyoePJCJfHUMNbb/wBll1GjT9bH66+g/VLRL5dLBEb6UNoYLPLLUtGghfzDKqFPdd+7KwqsXnfL8TAqCFdi9/LF86u6813Gs2zxVCxShvRfb4OpWutYcnn3jDWtt1CZNIrL8MdljjnflYHY86br5aIQGhDDQuvi4YPaXT9o4wieEP4Q/T7FZiVgJfNQGlx0Rk4vHiG4/HOfn0xQR/LcYDAwRZQ4xxGsUOyNRrTOmY4107GU/wDgR2jYGPDq6leAVQdZbgDbeV9nf11H6n6ahK/UudcG4jaBolg4OYwN4PZ4god1FcvLLObyPS6hVqQt+NzIRG2FsHg8TNHAzTt8+IIBx/0j+iJdTlgcwU+gvF+f6IgrjRd4jAABb03Kv8EsodIaX2OJSUc31hEz3QgU3PK1eveb4PwUMGbA9zMpUK8y+TpMxK5AgXTEVqeDZLKkXoWI3zmovKkxMC0JtZBbmq4ZmQ207Ob9oZJr+R145iaq8V9aR9E+0Q/TqjzA5ZJdl5XqaK4OZbA+MrCIuRa7wSt6GFcAC3T2DlYetGCApfgl1ha4iiDl5HmcWrwjR2+Zd4/cci8rL1S6uuEFGqz+Rd1KSxaSDTvDll621sF3V/yysppvBeETJKW7VbNPtlgGDBDliogCmSBoSlsplqjhQUxTdSlikLdr0uRU0xLdq/4wlPA8wblROxl48SjSlEuJQDYKX9T619w+iq/RbHqGRVcCaJhze0rgGZ8CEStHaQPV1X2giHdEoLyywNZs9vLAGqLMsnYr4f8AZgV22+xolBTQjglGcC/JYEepcS7eYyiUVj+IoOrOf6CWaoXjxABNbXuVK08sqnsm0lGKuBeGgjUw1UoLD9oPmMNXqPtES8BHAWzEQIheIYCACzYT54jo4W40LUZAJAnPuMd3a/S+r6V9NfRUr0r79fSqFhOuiLXNsY9pUQhVU86rJjgClLDWZT1qfHbOIVdBDEqJdvFH+EA20LWamrC6guLZPHR/ULppeDgPsQCW6SIHRrg5YZSjRD2/BUuU1DoIGKB4mjJ1Ca4aPENo3RCtLCeTGIs6puDMFTG9RLNQ2yEmoDZpLJZUpwxqRRwL6/xlaoiOHWWJZTKy/u1K+mvQ/S5ISvDnaAVLtMe7CD3ZYaLOhe3L+IksWhcN5Yli4qaWGsNNixW0S+tRqaYF+cx8OlV35wEyA0dmnlfzcrA3OHV7/wAJir3S3VSogo/d8yriZcXRqYxV1VwGFhIC1RV7gI+TL3cw76jVZWd+m0VqbAEF3ipY8Eg5AdsvqWpRKhsRW1wJkrCWj5MytcAAOrlbqgOHlAqk9c/azKlSvv19B9XK9R2vi6Jc4biC1dA+YgrAlHh/4S9HKXLmIp7njU5CWspSZV2PxEyZC1DrBLsYbftr4xcQqYc/IP7YsQGM15mAXlECRsqpic4jprgbIWSj5gOrrcNl6hWG+YJS774grN6z7SlNnEDSuYCKQj5PaAzKJeeU2okarcoOI1/5/MXHkMr085hGtgb5u8Sqv2X1r0qVK/UjP6GvEKXesEXICmvK4QFjCoN8VOHt6BR5fsRh6QIak9nL+0xCbqU7f/tzR9brrj96is/6bd+0SWB0hfPn5l6B+fdmFfipnmYLJSY5jtF0iTzUZq21LWKqNfmoEsicPUy5qOVMGYrUIdcwb0T+Ew1MyVNeMwWSJUVxSVS4HNUP7kdPLWZfNAUHNm4bwI/BT7qSpUqH6j2qMuhgLHdEPghWW4oYj5Ze3oZj6VMOeWORKKzOD/ZsGnyV/wBhWM/4Ag2FtLqULhl/iMQrVcwSoIjhFnkl+OTwdQzVnuuI3VRrzSeYSZJZvCm/YjKJirvnr3nIFwgb+eImRH4L173AMsOg/ErUK5ZxAOqggt4M3BFAKyWKRpeKkWowcDMYOXwYmTDNtXQ95myq8g0XdTGW6NDoa/bfpr9Q7WMEavLzGBAaEyD98CWUCirnZRmLbfoepAClTg+zDOkKIUyBw/AfiUh2ZvbCNqrfLzK6XVgHmLoc1MZXDmEtjoTPLt0bT2ODyxAirNw9stB8Sy4GCgVtal8tU0q8PLFyPMXOO9/yQVlVZ1wnF7gWpXBejiKoAX95KItNEvGNrUyeJQUzJeEqV5RsDoMSvuYHTevmCJpyWFnDqNzNyY8qbiJ7IsYM7+HDLnxDKvgJySqtORfxM6ftv6xAHzLaOLXLKTW3wPd4IvJMfbj6hLsN4+xzDVJLPcsOh+TmYdAoa82xmVKFqIjBzUK2IS0JWnz8R43uJteY3kZbmt76uI3VW0on2BJSbaYM5RVZUgEBdVYCx5jHKlcBQX47i1TYYF3494MtwDwDAMltC1cnUrxz3EVeCiIzcKK1haf3iNV6GuyK0kEgHmoLrQ5q2DQMLAZtW37MzvoNyN70ZqmNVOEbpthOGeH7V/raB84jnlglJBtambQpiirrAxh1go94PqR1qDSNuAj0NAr3f/xIAwgxXJxMfwHtiVQLLuXo6z7RM0lX5hQFazgXB1icvKASy1FYlwv494hrACg3+GYFBy5Y6mDMSfK3mOS47f2uAyJc0ee61OcwEvc3XmO0EqpwhUjXM76RIJ8/pLWJKVaLpfOGI1apa7pnGsowHi/0J98+py1KnwNsZjcYvDFfnRBSXVrvxGTBuzLbn6rli4/bQ20tARoiFQb3ffmIBRC8F0rcxFJCChYw5GvfcbSzzbuUv9hUcMPHtoZb9iIC4SMBuuYfCqpgbIZIUJFGRsmeLlmFGtsZRxHZUoCICTNbiE0WAiv8vwSyo3mlrwEEpeKzA6CVCyFTP2ICjgK5OIEe2oUV5YViNqqrTTjj7T+sHKwzhwLFc9sIOhkxmrSk/iWjK8AfU6hQqgikAOyZ5Y0207I8WkqB4bExLtMM7e4Ayxa45ovRDiI8Dl94sUUyY7mUqTKBtRtrdEfHYax7juAjhu2LuXy9y+dw+HkmeX4jEUr9oNj+4Z7uYIMQMrFUNQR2xcRKdirXKucViIR0K7tmnbXNMbFK7ixu8wqDUBw919Ql9WllTn8MV90ADsCNYo++fpdCzCkpfEqK2OWNtVVxKAoSPmXCMoEqvUuC7Q8sVFKtin7sqKIruy5RA0sNUl5YFiTJZU2XCkbPRuBN8SLUfbhgAAi0ccphXEsHWYdnbNaJVgX5LckRuoGxei9mVrUUM0fv4j5uyAItzMRN0KPGFYrRC0C1a8HGZZwFhHRL9Z0KCG/ITlGDi1rQaMinOeY1dhMDu7riET6mPpz+mPodhMxHv7tKrI8hCpSeHzllmsZBsUlVglPA7XE3VV6tjiag5xNR0aW7qWuqvMspdPBNBgNXsTENt+LnEYlGwS0M/jURaXzoJT61qbv3uN2CmlYb/aoLcHIV9gWRs9GzrpVj21znT8Sjm1VWZK1UN1DC1KtRmD8MvKWA5En1cYqoW7jmioeY9MpQczHGwUQcaCwZgN8INd9kqBjs/pbGAWorLR9h39g/SXlWYA+50ctvzMIW0mCrtn5aIasmk+Iug4KUfibIpBTekx1Y6eGGG1LFbXiPjeOWFkvBXnc09l5L60S8E4qMlEgGq1EUuzMrEHUsorjcsQAtamWC/wCQ7jnDLaxh5/mo5hlklucvMda7Z5Zl3MHxC8TK7JBbjkwRpqIDpMETZnT2SocC15zAf6bqCwj5iSnl4Fm42alvUzz9D6P6m6zLhUvEVKcB8RkVWM/iLZnh8npgArydX4nfRKzNvtKNrfFVjfdkJROwKfmFZFPBDyATicIvtbUK7HKRcZ0zVmABCU7IbCrUOsqF29ZZdiinROmjxwBxdQslQgw/7K/VwQwYS1LYtk4lT7TAXBiYHUrVhYZMuMQOJZEtoMarDpzbsSXKLrwFwTrb20//AAksgAeYsdkbF8Q7dKVQ5LPgI1VWIeGoOAQRVCtTOcfCozso77Ip3Atvf/JS+s4OiAUrMpCshDxuIhnar33BQede81Fh0KzcllZiOWpiQ2DjuJQ1Q+WWMHmobVY2sSUylCDCCcXcd084gMNfMtqWBXEGLhlWmNMJnxKVGGbc6ZKvzOTDCcA8yxQOmHfgm1RB+Ij53639ZpAv4Rq5pAiTpoPyyn2V17wlzKt6bFS6EGqh4luh9p1SHcPBTYO/eXJXIDge2XuXlWN7pQQjs/CgExNyb8ahKL5x/MqrI+YGRKcmDgulbq+4CXcNqiBinTFALmWeKn5JpDa/Nyyr8WemHhfiKqDjif3kBrMuFdSwsKdkQcZkUeilzumPW2E+zmXAFriu4IR5nArC4acQ3BlErPD9l+vH6Jg56YzBx0lhFW19oQgw1cSMAAx7zMqfgqxW1gBOUSUe7AOBci/zGuqZO+R+2XohsSwA8oCS8y1lPAjO8OViedgr2yunIWfLGHJss8TGF1Ux5a1CsvDLZiAT4BmgvMGlM4bvxBvue3cXIczzRUfaA9zcNKgCjV8MO1cy3SKMEs7bPeGsvoZUtB00ypsrnVLxNMWdMScoDM3NXAliN0yua+lIJd2fTj6H9Q69Fh3UVjso14aD+YrYbB80zKh0PXMyYDR5IT93j2CUmhdHVn+R20KuCzPxR+ItzyjsPMcaUOW74J19uV4dpn5uOJNnXGZantfFRsF1s/slgJy55hpB1NmpbVM47x6dirz3HxMOkdCqAqXzjCVOvCy5rcH34zFBSNCMp0x2h/cldoE7USkM7bexK9R4AycthXEqGVQ03Hu4gbpurfEJUG+YzEsrgFVJbhWBkAZp9FdfRfpf0P6g/iY/mkQpDOUXMXWEFskZDS6UuAvUEZf4oQ4dt77mCc7hgGH2ICMHJzV3cO2nHBi0+GvfMm8IlYN0HvLqGBTAQWFMbpTTHpVGtxdqvniaiVZUDBBoblhuGhfDCq7fi4Xz1zPJKKwQTScQH6pfI6ZfsDVnVxKLSq5gdjpUZiD7x5YoXBeB4I2DMUz6iLc/txfxjblqF3m5iQR2BOoQKgGOa5+k+2fpHGYijm8QDFy/mUInBhSVrzXvMBRbgJ8niF8pVfUKr9vEFWjV8bm2240uCq8M0IQzKjhVYTIthj4l6M5G4tlhjHUf6YICRQj3Udk5DD2S6l5zBtx4mAzM+YbNXoHrEF8YxAvK5RXhh8LWnQ9mNL7QXXiFw7OfBLze7qJDNZeprxANYQ6mEoNsSunCvyoFbbc3Zm8MRMIcTCGs5l//AInlpqPRul1E1wXfnEL5CT5J3ua+OYC4FBJRYbAjLcAJ5mMiqXGOnA9oblcs8vEMDmDIxCRXqoFHyhNK4v3IZXFWQb0z12MAxE4bIbl8dMU33H1xNTNdTKXLtOpXr8yoYgVcTaMph+JShUGpDZJ5lq3iVsNzVA4eJYJmWhVV7WEq2qGXuUCzm8QaLzMCU0XH9cfSuCaXiIIecu6GLJ8kQvTRsc1EtTBN0OKWI1+OBHshiiMbJWITk0sYhUcTfCn4lXvh8ILqFSlB2lBVxtiyKmbLha/yYyvaI4YKWJATFbqWQmC+OIqPCHFtZh2Ea8wbIYE21EOb5h5QJYdQAFAHK1G6l93Q11AhYenzrJA6CbVTdkBXPGoTSXPyrLsltavEHrNCZYZQwbIquX9Lcv7xlWOoHzjL4ZVumGRSi7g02uzL5JndLd54gDIqVKOAYPvUJgKya8MVSRyRO788C/zj6lSrxFwr6JivME0XVkrU8TS57PhqCSGycVTNDk4mxKrvEeWaRBMDtzL61TC7heFJ0umo51Ao57qCcKccS3uNh4iUCrpz7YlApTCR7LQtsfPCEq+ULhV47jEcLo947N5aVM2SwG2jMXj2h+GUs3KXzL+1cv7Z9xwMNVFw+0XoHcsSb/8AmZhzTWrGpUy7u9jG8i4XBDsv4jYAERL8RmnO+YB8UOTBRO5xKCLvaeihl9JZL0jEGrTY+Z4RyeOyEUXGrmScNSqCbqUA8birFxUC55YYRQamx86hZqYl4Npa21ho2jyRe3gammJNMlgrygcAHKYVisbyZ/MaoPDgXw8w5Bk5iXBZNtTKu/4BUPGdQ3yBPiXwlXfYhK29Ar0z9T6vofpuj7RDizCAK3iCKCpw4RqaTQN91/pCFpWsXqIMamNB3M92UjsTg1MzHtB0evBKE4yRKl1Y42RajoITuP8ATBoJ89M7AIxdR5MwrMcXPGceY/Gu3zHBtzzG6hb3+IeGJfCgIWi0e9JgRZr31/sIZgEy/vFOF1kgytNbuUBvFaCMb3FRyvT5ZywxTUjVRmLOiYBH7b6sPor7R9W1g8RmYXgN/MCTlUJYS9VebqCoq/AVmPEWFuO4LPdUqoYUeLEYiHygmKm9MoU29FT6SlW51Bouj/GcZhj2NYl21m7h0VbqVstDLHdytXEMGiCick0lRSV+JeirfZFUUKKjESbaSZ0V6zcEqszMPNwoCyy4QA7iQU1vAWx91fhlxMKuuEp1YFjAB6ozNvR+zcfR+g+8fRyscxoPMQRayoPgkXXq/wDqLdw3o4SGXBavJslYKkH2jj8ODVW4mFu4LAcVZDd1CC7ejuISvlcNFuYGyGc+RluMHZEANASaamjO4kW5lc1ED4uUqW8R1XHHiOXFjL7f2moFQXvAA/PoYiLU7VmqFyjd9EC3imnMNmQc/wARBQMhlyLvQ6GbQ5h9p9WP6VQD36OptxnEzFuhbuFHRoGLWziVNySnimGaLQFO8GBVGVFecjKGlWM3rnJLgHK07bqCk8zdMFRdwsYwRMJQgYDxUxs1Khb4YqGZcmYOIbhStkOiKVjVRXFw+FjcuICWLUXS4j+IkeERsNIBglShVsEUURGvOpjtHuptL4PVxHbthFDXh7wwEvD6v0blfQ+jH9ONGFRYVGW8ysDlPxQy0gEKOAYJczNhwTqbzYQ8owN+eZVI8RLupdl8Mu0c13OOwx6QwEjDiWZdAuotnMBtKLi4dFoxsZxMKA45YSVpmpVcq1jJiBZdSwWBKHBfEuY5m94hGGW1tVLo4YjOsYoNqm17Y1ZuvCKi1pTUoqQjQ4Rpm/ox9L9T6H3j6skURzKLs9QE/ARtjm0fxcoGDRfiLEBmE3Thjz1hiMtHF6SWFItUzA1w5IrZ1EV0l4iSpegSjUJ6ixjGdLK6FgaQyk2TGBshCGBoIzNcQWAdeFim2e+NLLh9whUKnO7lOIJnhNwIioyFhiZ83KCVYJfmVBtyKmenP7vot+p9L9F9GEP0qDPAhhj3d+COselsQmwFiGgoCw1YVcIjQmNH4gAVGkRhY0iHxFZaGswWvbEAcOYiW2TPB7kJNYr8S24dsJTZPR8UXNUyCv2iAWJwNOlhUZIAFxlVSHIwFVcTV0qo1wuJeqAMDljk2ei4L9iNirEeVWw6Tw3hTEpTwEC50fLkg/g/aWYreyU4cfVf1P0n3T7NUNwnWlCWxcZIeOjb9pYL7zXA7lkNNZN60w2nEteh1LxBmzTmYNZKHmHTDHuMFJgYUgeyxkgjBCFOH8Q836EcaJbzBlDiC2phX/RA1U1wMNoiuYeChqmUjD8x5MJ/sJB4IYlKFglRY1rT8EVwvBnwoC+VcNWCxclACRQ0KSrZXda3XjEGA4dxCpQocJMfafRj6MIeh+hup4Eb5hVNUVKB4tY1D4igBvIwhUEfzClzCmu4PJxLK6nv7MHhgEiWR2eY0R/Ms15Du+psQstdSqUU6uISkuVFPth1/CG8bgQ6aPRU5aWefTkGrxdkAuv3o7SF1wlKXS8EeUbW5peah49mCxC7NyqxTuaL5h2xiwz3H5gY/gLZbiLtSpiqei4y/S/ssfS4el/orj8oMCiqaYsCdpHVjpcRQD2n7y4ybcveXplXqImzc3uCykdUxaCLnVyMxUFScJCyYqUKQ/pBPRd7I3irGdRryyWsBBbYLqZ3Er0RKHRBdQAqaJ7kR1EgSBV9scOsqHJzUHUsagYpSjWEyEIio6A8ZgNDMmFMyprsrqnDLBX2bl36X9D6n6NruXwLgUqABnLwws4YQmNF3HT3mk2SDiC4xzc4lcG8HzKqyEJidtwPMC3ffcMSzpDfJBaqnZcILdHi2KBDjZuFWD5uJfGpVf8AZN2IHFiZ/HmcCp0FwgcfE6K1COj0fvps4gbLYWUalOXjhB2q+QRN63QNAbWL5MBLBhhNgMirFQbmys8ePV+xcv6T6j76EQJThqHU4ma9iW3rvH4JWT/68St1NLfuxlPMPQeXWfZmWWf7h1mNe3vFSJjZvhjcRZfjpPJMFtpnMJ2Eqjr/AMRWGvZiBhKH9odd1i6gp4/MFbCbbFGsSxo94xvczaLgjdTG4lZyQDMYszJX4ibKazlGTC4NxuxHdsnfLHNrdr4W4jLMsxSZfYyhiJo2/wBmW6V7hT62W+i+ly/UhD9FZMuiOijLM8oUiXEtd9SoBwX+dy6B2pH+3HxNnibRxnwTS+80UtYjhw+SVsBUcic5iqoOTJMaWtJFF7Ck4glEg4S5RK+GYir1VQdCu+IBdIQUar7ZIFqKOaSBkLqXdYOan2mT2XG0J2kwKoyjiATUza/iHOmFI9Gl4HmGK65HfRD8xm7dJtMZNCNq0Cxl5i6R7i+iSmVVRxe50xLfg8Mo+h9Fl/Tfow9D9FicJKBNiKi9xmUiwRf6Irn8kVY+f3mG6jkc/wCpjQ8E4llVpKgvI54Y2Ndhj1cMLFJieHb4zLJUOW4HLXTcSSg6DfyRwZE3MkHR7wqlCuIQDhCiqPZhNgXxDGlFrh7R6oxiEJ5li6agtqXA+mSMFqyH8mjUbay9nqJdw1nsGUAFrXTwss1NIuk8wSysi9wS4qK3hfh5DhlrrZt7oVMq/KU/ZfRzLiy4Qh9y5frcUitxX3LcY5DGmRQDSv8AGLicEAe7UWVQFN4h3Gpe2oCgsz20enC6I2Dh4MQArkqBJhFZLDwL+GAaNWfuJVda+UeZxBAYQAjjPmNQs8lWksNAU5zKMWD7WQLV4vvlzD8oqtkBM6NaL27lSiWDOTBqUAlMbIGrzLb3QBlRCC/cXXEa61iFc0gNjl8ktRv+LDdKJkMO/fxM4mvNFKO917wGRchw3GgpD06ixj6vo+q+j6H1X9zNxo2zKVuDmcS9zJpgWmXanqVFgrR9tz9xRK45mqJow7ZwxmP2i7YrB4GZEAOWUL6qWqxq4l4Kl+rZLr28GAB0Eqw8rkiuAOi2y+mZBD3Y63AYx8RdxYflXXMUpE8spW4DgS2tozIZxnC4mMbirdR2xtSoOHMsIou8dzER7nmCGKIAWxVLhj26HuEm6vQxcMHAz9B58MExougNMKxKLZvCf0wXcx5izP1sY+h9R639dkpPCK4hd4McjWCKpVehMN7DcC8GuYNt9BUIKQMvH5Y+0YYOEElBZuWcCVMVMLfo5T2i0fDMbHhqPlsJo+0dZ8EamABQ/eQeJYkZpxBfA2t2TX54g6QjPRuLMWDfxG7QGu4Gb96LxVSq2sxJzGg8k2phzKbPENbGq1QLjLTklj8q/MQOx09os2HFMGNZztuI1FtM3KsEbnMbezcCCetCoq6ZhTCbalnIDko8jKiFi75mPtMceh9i/qya1NzEwRa4wQgv4Epz0ktz3RR4lLdVcGw4rjuPcsBysD3dvxELVdw8ewmoBenP+AmTbac9Sq4JsvMwKOYYPTZR3HRXsSuRixZCrJxNJ4i0S1vyQDFq7F0feM8dAWz446lRqskNjWvBgKilPLu/MPHwcozige4Bd1Usgwx9JEodMst4jszwzcqIp44gI3hOGp3HMnAI1A5zLBUG0zmEgbO5Rt0NKY0hBeYNalTdxQAsDBcav7LH0PW5cPW5cuX6X6XMq1Nzh3uAawfbE0Y8pNs7wxdm1iGwCndLLZLU3ohMWaKLfEIVWXBghjirUBSeYEWgHi5bF0Tm6l1FucQLlKyxWicXMEkVBBxnEyRRxTADKYUb3xFtVuOQxc2BergA3PKzmHpcdSolu1xX+GWNiGenCRo3YmIwzp/MKqrMSZKy3SseYythg9MSt4l+MKjqJdwbKG/4SpNZZG0I1hyRRmMQlkbvXJGTgA7mma4Y2bqpSoNzVfS+lxfR9CXD7rKIis9miOCVLjVaTKCxhQI8v6uYKOtWbiBuMcs8iOL/AJhg5HOCnzW4CIvgDi+rlhUDkVdSwebTRYti5ZQclsyxDgi27C6TJ7O4hWz8f4m+ce1EunzKoIAzSyUtnCExK+P+S4CAMm6uLKvHe+L4qNm8IL/XcX15GJEMsMhw1yxp1yR2SPkyUxmtnmXw99DAcM2DAMIFZ3H2pOXuWbW2b1BT8MPLhJaBKytQUGyllrI5PEQHTYeGKVLr5qbGmqeIlxmFhFWPIiFUOjKW2Ese4NMRfb9D9V+jDRD0Po5Izn6D0Zg0YtzMQGCVtqyZnPE5csxauyNQ+rya1r2jHnDwCVAeLiiJnPLTEoGpRHOaICzUyCm+2cRDrVX4mPkJn80A0p3+xctbvJb8soz7X7EwKyCvmJtEFF+XAFHNnyTN+S0gmKp8F9xLYaifO1RNa7C96MzccftMcG4AuYWniE+GalzP5Jk36mThFTVg4mFYCx5l4adpkOLDfXkrzFYOYPMFYY72j7kE01FOX6HDDUV+hjGf/8QAKBEAAgIBAwQCAgMBAQAAAAAAAAECESEDEEESIDFAMFETcQQiYUIy/9oACAECAQE/AO17rvrtssvsz3X7NFFFDSGOVci1BTi912+S/TXZZY2OVEpkpkpNik0fkkQ12mQnGa2vsTKvsqxV6kpcEpjYyit4TcJEJKcb2T3oXYsepJmo6VDdvZISHEa2o0J9Mq2eBbLtz8y7WMnndJiRRJFFbacuqBJYIPHevnQ92PwTKyJCgKFDHvGLZpxcWNYZpOpSQu5fOuxk5l2xISSFRLUSHOJYzkWtGJ+ZMT6lYrjNSX6EvZ1JYpDEXR1n5UTb80xNMUmcEmKFpJK2LQmuUaV9CKzJUr8oV1lZ7EserPkluk2zS0FTkVouMOm3LnJrxUJ3HxyJXGxU4n/SNGcdJdcXFtrKY5r8dWr6rxwQdxG0nF1ySVSfavQ1NWOn58kf5Kk/BaPJMnsmjPBCck7yPUfF2dHU/wCw10xSENCyqsakaE6l0/Zim2rX0Ty7SpVuhfv0dd3P9EKE6I4RqeCSHtESGxImqLL2bZF00xU2h9SXKTwXfFbqvR101rO/DWCKpIiqWRTtksokhraJFlWXROVjohTdDWyW0lemsGWv12L0NWCnFPlCj4XKZKcbWSOJWJ4Q6Y0NCIujqJMmqSIpPzdforODwWaSucSx6nTBRvz2Iv5uN56VTUksDrqbvkVkHa2ZJDQhMofgpJ4Q6ctkaC5OF+z/AL7ld+hRqaEZZWGT0JpQpXjP7shpyj5JLZ72JljdmPoUWJW0iKcVVUVUUyHLEq7r+Nd7Ghoez2uj9j6uEf3TzEi3yjQTnrRX+mpXUyXEURVezIZJDQx7pmfsdkaXJ/Eh/frfhIk+SKf/AKey7LEzPpS8CmvGzpjQ0NbIUExpEIdU0hRUIKKG7pCukvr4F873fgliRHUodSyh2jyONjiZQmymz+NBudknbY4pU0/Oy779PVTUhOhMUvtCjFn4x6bPxP6Fov6Fo/YqiqWCCUrJJuEW7eRP4F5+ddmvC1ZyIQmJnUyLbe7ISUZf7WB5jheEWX7TVqmakOmQtkWWaflbMZTc1Qn/AKdXTJp+G917OpDqRTT2W3Jpdj6k6X2J3knGlhY5IyePNFiH6L7uXtOCksDtPIixZZpeH2Um8icbkub2avKKatX3L5a7udv0akFJWllHgQmaRzs9nG0pdWUKfX4XqJfBwSbi0RdujVik7F52g6kjkvbwcWvslcJNrBpz6sFi7v/EAC4RAAICAQMDAwMDBAMAAAAAAAABAhEDECExEiBBBDBRIkBhE3GBFDKRsSNC4f/aAAgBAwEBPwCtK12L6tivYb7aOkprWzbvpple3SXst99sSsULHiHjkvBv59hpv7N98Y2RxWRxIjGCHCDP0oGT00ZIyYpY3uLt3HLx2u/HvPujAhi23ElpaosvTJCM4tMyQeOVdrdDpv7iETFG3ZVIsZJilsJ6I9Rj64iFvrL7N9qI+DFstWxvSJYhmWHRk/DFs2TW4y19m+1EeTGix8jkOTfgjYtETkl5M0lNbCfBkVxix9z9l9r7UYsXDYlSLG2+Big2KMkVsLSWGU2PBSJLobRtLG4v4sY0+fuMMd7Yh7oqzoHiZCPgcaGkLkgr5HOrt0kf1OOuGZ6eR18EXtF3zsSpPZ7G7vf7R9mLlEBoQ3SszZ5dShVWXnUp9VKK4dHpnLLit/wSf1JDTU0RdRZnxTzvonGSSezSsjifXdNJRpt+TIumdP4IJu43tQncVaLr7J6YcE83Gy8sn6JwW0hxknwVRj5RjGJtCnF8k1GSqov9xY4+VGh5OlVDahfVKyVUJifS+DqR6vHceteBX1KnT23Fa5ds/P2T09FD/i/cycu9icES3kzHyQdUIokhyFY5GNlHSLSSTi01yh2kzZ1w3yVX2T09DKLwxSe6dMlUnIybyqP8jx0iOxGRCWkkTiXRVmOG+k20rExDdI/JF/W0bb/ZMRgyvHk52ezOtVL4ashBtNvyTjsNfUxWiMiMhk1Z00JGJpuRO1xX8sfG499M8unFP9iv9Cx9U3Ojx2v3Xp4MXqF+m4Se/wDsS+iKrwiSRkVSEIixMkNF0R2Z1yezF1KOlnqpbJfkfP8AAtsfc/dfGnzph9XPHUZbxMfqscpZXJ0upJX8UjJmhN/TZF7i3EJjKHHyUYsD5eyI4VXNMywx00lQ9jLJSlyPdv8AJN7JD39i/afGnnsXAmRYtFo1Zhxpsx48X/ZihgatZFVHqMcKuLPUtY8cmvBitxt+WQ8yZJ97XuPuiL4IsjITEXpF0R9S4+Gf1iraBm9TkyKkqPW5KxdCe7pEY1FRX4Q6SpaNd7vTj2X3R5HB8iI2iMhSE70Y5tCbJy6YtkpPJlcn4Iqtx+WN7djSr7JD0XKIK4ksaFcRdLN0KVCkKmUjZHqsqjjZCNJfPkvata+zej2Y9EYacUdNkoDj8HVKJ+r8iyr4P1UP1C+WP1Hwh3OVyd/A30m29UV7TsXtM8D1R6edPpFuhoaQ4jj8oUYkkopvRERxbj+L3FzTa3Koor2F7bOGPsTadmKfUh6NFblGZ/S9FyI2UHY1TQ11Rtcpf5WrPH2D7/gw5HFlqSvsf9pnfGi0jTQ14IT33e/gmlrVlUUbFbe6h9vhC5MeRwdMTTVoaKJbKjP/AHpardIi2iUXSeil8l3TXa1Y1/j3b1fGvhC8HGzMORwdN7PWaM/h/k8FC8oRGfKrklDo5f8A731ovYZfbeq3GLkglNSJqtzDJtJHgkjKrizlUVtenJdOhVKKsyR6Su//2Q==", V1 = "data:image/jpeg;base64,/9j/2wBDAAYGBgYHBgcICAcKCwoLCg8ODAwODxYQERAREBYiFRkVFRkVIh4kHhweJB42KiYmKjY+NDI0PkxERExfWl98fKf/2wBDAQYGBgYHBgcICAcKCwoLCg8ODAwODxYQERAREBYiFRkVFRkVIh4kHhweJB42KiYmKjY+NDI0PkxERExfWl98fKf/wgARCAFAAeADASIAAhEBAxEB/8QAGwAAAgMBAQEAAAAAAAAAAAAAAwQAAQIFBgf/xAAaAQADAQEBAQAAAAAAAAAAAAAAAQIDBAUG/9oADAMBAAIQAxAAAADgzdfZfNYrdOcXcJqtQM5JBDm4LM1YZmrEOagsXqBmagsXLZK1AFNwWL3QZrdNVLgStwB3umsy41iajVTVhUvU6YolDHCQQ7JB4vUHm9QeZuKszcGSbmeo8lpyObhOISAO92IULAHNwWL3HI8moQ8loMXqwHCQQoWiRUWNCm6Fmb0UKyQQr3TWKJGh3eh5oloxCQBwmixQsVDm4GJuDxCQY73YxwkHibgy0as7FC0IUJGhwkAcJCRwtgKyWIULEhQtMDDQAw1CFC5AdFjQcljgOWI0Gy2mKFgCpigBDU0KGsBWW0w2aDFCxMULBgh4AYaFAhYzEJZQ6LBjhNDJCTLQULBAho0Gy2SKy2kGHgBhoINGy0GFgYhLAWGKEvTFNAh4IMNADDQA2WxhstoDDRgIeCBZoMUNADD0AoaDDDRMVGoBUamxQtlBhbAVGgxWWD3CzPQVFghQ1iDokEOEghwliFRqaDDRAqPBBs0EHLOQBDUAqNABZYAoWAKFgChYA4SwDDUAoWMxCWMcJYCssTDDWC8PGAhoMMNYwQ8GGGoBQtj3C1loOEjQ4SxCstJDhLaFCwAwsEOEsQ7K7Nc6/Seu5un5bPW9MXz7H0/wtTyYeunmBDwF4bLQ4SDHCQBwkAcJBjolixCWMcJAzCaTHpj3+HR84z7TzTEIetcgQ1AKEgDosAVktvULWdjhYArJAHZLEKy2gNMFTSrrhT50vd5D+vfPvb+X6nUc5LHn97osxCXz/wCiea6ef57ufR/V8nxfofoS/m+n8XW+qfMvR81eEvq5B6J0J05cfANamKcr2aMDZIA73YYLnvZ6+x9Jz2vn/fpUOE/maryXv+FnJJcihY0KFgC0SIuFuNAzvdjDfxMfU2wwafQuffyHR9kPi7fmXvnOgmAIefz7+Iv3vnPS831DHmPYef38foX0JrBU3Yc5Z1Ga6CbIXvnc0XV8J6nwHZxo2bHreO39W+Veu831PSrUzw9/hFfok6uX5LPoddGHzmvVcno5+XPSc9pD1qHZ5OzuM+bPwd/a3y2k3vP9F2l43ifU974fLOZ9R8H18vKmtdfHmbhRuil63i7ensyXmejweZ7TidXN5PuL9/fm6OMXwehTWUkE7PDdQVjz74eh566Sb5uP6IXPf4HYCc5ygS6nPcBE50g4PIY5vdwAF1nOjlSv33I4+5XrAPh0c3pcNhrrI7wmrOd63SOZruJZbCwAoeWx7jWufA6b/KinGuV3ppra4oqec7fF1nyIXb9Xyo+Tn8/V0/Vcw3D1swFRY0jguH75uwePzVxO0mYOryBcpy/6DyZmvS9Hx4or2O/GLC9GTxO9I+hA8eeK+hKeQWT7GvJnvPsvcoqps4m89HW/GqNesV84rcHxynN8OlgmJo3qfHvRfo+U1wc9un3vHNNeib8OqH0FbwrDXcX8+jrHvOZwn5phXANczNcwtyV/nanRuJEx01ira0JgQslAKoOrbTSHWRMggGZIrOlidElOgaoTU6mk+VO7afJF0CVinNbvNMHS01zXmHMt8rdJfLciR1wwOG1xVJ0QuRj1oApdoYJH0Eb+udSpanyWhrnw1lgMG5E7nRrSWWtrMN3nzISXlqctrl7Hc5mkkMvpIg8bDWx6FZAZTPWYhxTQ1VML6c1JCZrNK9bERGa1HE3mwze9iDW8jq6oes3pPWNwea3TWaJHOJrI4IlNbg8lMhqwHdylKuhzWctFBqBZF4V8X2Sviusr/OwzuE8wTWfSN+Qhn7XXj73XtieHPqvZK+dKHoN+fJodi+SSm7FCqXbV3YY6t2ndIYZ1NcnaOpjnZtdScvQn5zsB1y+fyHWLw4Hoq89E+4HkWHUrmQfYrj6l9PHPqX0c8ypfWxy8Q+njmizfSrjgh9wHDzkdZVbeVpk6xE+OXrbk5ddW4XKrq7Zxr7MHx67hRedr0dJ8Q/W2HKnV03yb6uoOUTqQOZt6UI7ct1z66OofP09YkiNQEaduhLTEpLZdlNCnlRDuTFaW2RNOODEvhmmLRnAKDbykphwTBYLaAQ+W1rPchNVrWrvFi1BXQwHESPtWA/lPSTdqaG3a2kiazJCQWZTdqbTYi9NODFpkrQ4CbAVvOaoCQFMateIZyrrN7u5TIPMpb2vkTUSqm7lOCdtPTHBp2xga22b0C4ZM4zUkoeBqaXJrOt5XQ3AwTNgHm+iVC1TFolhGvnnJ6O+XNDobUIjU3bVZ2GHptJeX0CKRJoa1kl2leVMjXdapga9W5gb1tY5eYjWZcwPVGZkepZA7pE2PCGRDgbFcoodXaJjWXWIIsG5gFyO18Zs4tAlH0JtOblhQHsjUKfNrBx4QzoRM2szR9ANbFGeHpjSpM3BjDm6pSmWMEmQ2yjramrSG4SJpg3O6NRqYueeNDFkz4yTZCLkkogQrI6a6lpn3hZD4BM6LQldpntfYGwKW5i06jFrsPQb/ADjDYZ2lbaHFcpMFksCLMzMsETTl9SxiQ0PEdGIruYMOjVKBWjPXlvsbHNHu70oYNCxdChPHVcuq5XX42UK4bFGWw50hE5Ilqt3q1WSYszMYwoGiXc7zWaZ9pU5cvkmvRgoqIZ5XQtNNrmp6R18c6sX3BJva0wvXPU9MKlwniYW0uGTazqmhZmDjWcxkoqST62lWLGdHBvoIpia6UsJ2WoRE05uAy8NR7Y3eue4rEJpGxhNkEJ5t2m1aolrync8t8UGA5rVprkdqcvbGsouOt1mmVCq5toQC9WfMzk5tRsXmjgE3gyrWPeWGOV09NBiyxC0WXeLKmlqWDHHkykyfO2jrMa6a2CtauGCniw4lD2i5yw04KdddLPOTG6kZbHNkBlknonTkBqDiRYqsyyRR5rHK6GdH0FVAl7c5rFJu1mNDS9gzWxnwoytXS2v/xAAkEAACAgICAwEBAQEBAQAAAAABAgMRABIEExAUIAUwQBVQYP/aAAgBAQABAgH/AMmv/h6/21/Sv/Hqq+q8Vlf1qq/y14qvNVlV8V5qvNVVVVVVVWVlVX8Kqq+Kr+NV81VVVVWVVeKyvmvNVX9a81/CsrxVVVVVVVVVVVVWVVearKyqr4qqrK+ar5qqqqqqqvFea8VVVVeK8VWVlfVVVfFVVVWV4qq81X96qsqsqqyviqqvuqqqqqqvFeKyqqvFZVVXiqqqqqqqysqqqqqsrKyvmqqqqqqqyv8ABVVVVlfNfdV8VVVFx+JwpvzeP+Xxvy3/ACuTBVVVfNfFfFUq8X8z9DiGGqqvNfFZXiqqqqvMCLGhuTGb9CTxBxX/ACJE8VVVVVX0i8WC3w5O3iqqqr+io/Ffj0AvBU9seHCjcfl/mkfmQBZFlV/NHjNFVVX1wuKgkxmcPB4r7qq8UscHDn/OaPh8babOQOPLFPMQIvCiXJMSGLCyTTr+hDWQoS0B4E/Cm4RXSvKJxuLC0jb75L+ZyPyxxZuJ81XH4X/Onj8RsTZ8MGM350v53CgbI0Klti7iPCpPZJNyMvIWHKV+x30bjQxciF+KOC3E40btHyBIuDFcPtkucqL4Aj4u203Ck4ecRGIbDKrAySQYwfFeQwgYVyHGXR5kaWPqAHDWL2GZiHGMezKAQyhgJI5FW4gIyjRz8R4AvrddcV9Sjs8ypFwiFbV8gYytLHIZO2GEx2oAMfFiIDSxzYA3F4kLxTcODiSKxBrlrE8aFWTJEi43M4/QUGRMSJWfkPaYGDw8OrcnJURJWGVmkmdyjcxohkLllmGJKpWR5O1YkiMalZWmWad3cSdr5DGmNJypYcaPYyq7qBHyjzHlBbLwxtEk2yu7FlfvM6t3O4lPLM0U/aXXmmY8p+SvIXmJyl5fstMs0fJMqZq8GrYzHI4147YuRydc8iznmPyDyxyjO7mOOIiyuRPt7CoYljKlABm7NvkcbEQep65QovFEHrrmtVWoFo+oIDlUZaGdu5OvYvHiLM7KewkZHF1sA7p8DCKA7NSAjIF6BEItQmgwMXR+7brOdZQL4AL0VKHEygtYXd+vWqqyfgrl4EIweQuts+DC+/cSrGQhcJw4Tttd4MJ+dtsVSoHjUrmtBAupXAupXCpXxsvMWT4r/AD8n4rL2va7vLv5r7Jvt7hyE5R5/wD0h+kv6Hvjkd/f7JmEvf3dxk2332Evsez7ftnld3d29m4l7+/v9j2TyTP3d3f39vZ2dvsHk+yZ+72W5Z5R5LS711lKq9rywwk7fY9gcr2RyBP29m+2/Z2dm15fggrrpWmummmmuWX3LbbF+zc5XXp63r9Kxa9QiMXUIurp6hFp1CPrERi6gvX1dPT1dfT1a66VWpXWsu9ixPm8qtQtbb7bbBtgd9tr+CLLFttrsHwfFVqBVa6VrpprrR8BNdNTH0dPV09HSYDB64i6PX6OgHZnL9m+xcHKrLva7oeQ12Wsm7sNvtscvYNeb1WVVVr42L7779xftvffsEhk27OzY+A2XYy6169ay9jinwc37N7wiwgfbcuWtRlFAM111KCMroIx53Y77ly4IfYSYM3UiXe8o5V77lydLvagj4+IpJOE3tvvsG2LFg+5beyzYGEl4fBwZtt2+bOWvjYPe1qGFDLzbrVCAjMcUa4WIzWiNcLCQvscJICk+NKw4z2cJVdcXDhPitjmzNjeBmmuB/YM3YYtaOUV2fHwsZ+0SB+zY47gvjSbkx+N7STs7RJIS2waxGkRh6ghADJhwYVVNNBFqgbx0VqraYWpVoJMWky2y9i+xOIrIQkdkmYEHAVxlOBRkM24kaTZmVtxgNmQMZNg3a8jcvvMnb7Ec9dgDkYr3GSeQul6HL3VQCySsbDdndrVYQ+XiusyLoE1OaIrA4DvRLg4IzC0XUuAuYT0qThDsAzUuBWYxySCO1fs7AQR4vK1oN3FTjvZKpYCrSuTZLYZUdDIQuvWx3eVSZEeQqMXEjLBBltGi6ou5JDYIlQQ7CR1fKGNll6xlcgFZUVQ990c3sjwsjkS0WpnkXdAMaZMZFUNpkiRhgEeULCgKkjrJE0jmOlyPEGtmTO4y93eHzZzJnZT5GRJ1iIEYya9axtHk0xIOJjRerr1xOo8Ie187WbY4vgRFJp5FUEDGxohhbAdrjQOYygBAJIEhDUkPYwQ9uzsvhA2NnW2I6yycxWZelOLJjZsVwuXVZ4Y48XNiY8ZlxGURpjANgk71VomR8QBsGFXxfCOmf/EADoQAAEDAgQDBQYFAwQDAAAAAAEAAhEhMQMSQVEiYZEyUnGBoQQQE0JisSBDwdHwIzNAMFPh8WOQov/aAAgBAQADPwH/ANUuLjZvhtmLo42I8PoGHiGqwHYeVrQ0xQ/usR7sQYhy5dtU0OPxodI4V7M7MQXN8LI4OIWzI0O/+OSQAJJWDla7EBLiKg2CwsM4TcLDOYmFiAkFjqXp/mMDA1tkzDzBopM+ZWZy/qG11Q6I/DupyMzVEkj342O6GtMau0CIw6Ykv20RY9zHXF/8Evc1o1KZgtFGlwF4Q1WkI1oLLNj4hpfT/Fe8w1pJ5L2hjZOEYWO0S7DcPcSQBcr2nMIoQfsnsaPiANdyspqtVL5spNCsOZMzusJzC5kh966otcWm4uFhj2fO5ol2qkiEW0yr2d7CHQJ+yZndkMtmh/BjDD+IcM5U9mXMwibT/ptx8xOJlLTSFhgAGUA3hPEsTNdYmSkW1WIS97Wuc3vR/gudOVpMCqxcasZQNSvhtLmuJ5QnsIDmEHmj7OwzVzroZrINN6LD+M/4cZdF8HFDoBWHiAFqzNooRJRmLp7awvmVjmWBiZs2G0yazqmgxAVCDCJJBKw3/KsNmR4PET/Cjf3F+Kxo3UNG6w8aM7QQvZ6/0W0WL8YlmEQwu0WLhOAMEHVEEghOiYMKPwOe7K0VTsB+Z3ZI9UXvRkwKLsgrNM9FwWGVYLhwS06IsZOGSTqCsc4nw8nFzWNggF4Ecv8AQfjVJyt3WCLvdS6GHiFoMj34WRgYRC2PubnBmTaUGt1go9oeSOK7LBvVeyuE9k8inD+27NS2qaCCXPzC7CuCYTYrdBjXEWQjxTgxAtnX3M4amU3O4ymze6cLFDMOOaL+s4VoaSoEe7JiNdsU13zWRopddcYbOiD8LSqwcsARS6LJBh21IWfHkg1pI0T2ZjMgbIPws2G4zFisZrZifBYjssYJtIej8MTmRaByRdNUKydEwXfe6y8INJUnhKkpkkxomuY4Oshh4lCK1gafhkwsR0OLeGVA7NlnkGJWK6CXf8LFZHzeHuB4s1jZGBAhORmUSwgomAE0CyAMaIGrhEqFqFNk7LCa7VULCmxE1XauUXmQbXRI4UW6+KESG2TZLzeaAIYj808RuFS9dlJhYuUk02Qb47pvA0eCAsU4kElOa0Awg5nmsVsCKLEEUGVPeTlWJ6ShGbyQiM1Nk1+FEga80MN1KhOCxAziZQ2KY4CCg3MB1TjZBDdMrK9n4obBKezw3R2TxeiwXAAiI9zjQYZy8yuqGacxXBRBoqnYr+EVPomYc/Fh0oiYNFzTInMiLoVpZZSSBSFmKbcqW3jZaC6xMR9ZAlQ05VERSFm4vVXLlnloqn4WI/MKaIg8kKUug+YMUT2EZmiN90X4vBcmix2knLa8GUMbEzFoyi/MoEtY2ydnhjuHnomM7YBO6awHKKe4F0IZgHEgLCOGYcR+qdOTKS7RG5IB5INOZMcez0TGuhF9GtMG5WG0jUilUcTChjZIIhFwAe6CBospI5oSAd0DQeSLXDkpJLvJS6AUI7cFOcY1Xw31lF1JpzRk67IvEuMclFQjoheEChiDIxolOwWNGymEXNiYCYNrILFfAERzUMiBKeAdkTXSU3IBA5pjsosmYbS5oWs3XAQgDFFBMWTfhEzKzTxQuCposzXBZaDdSx0BYuKatGXdNwwRlAd3k4kEPMeCeDIEHdBhFk0+agAQCghC2WLmzNEhY2IahPa+S4BGSZEKTCdhnhCz8UV0GizZS420XF5oWQJMpr5M1hDCGZx4iKJrTdM3CJ7ElYhuarvQUGWhOcCS1pC4hNAsKaBMjtJteNMGqY3W6FKQi00R19Ux2ywGt/ua6lYQdeia4zmpsnDsglQTnY5YZDpmdEwUcTyR+V6LT29ERQlA2xQsRuyc66fljJMLEAjKhEQvGCnNsFJqnAdop5pIUuNZRpJICaXGZqsR2IQCSnCQWmnMqI081I/uOhMm5WGe8gQcrnTsngVKMyZsiSpdJPgqkSsuUTKM9n1Tr5SPNOOhWLNAvaW/IvaXwS1Yg2WPNIHNe1N5rEs41VaoJjTVHMYsjsUbuCwzv1Q0c7qjMZz5rFA7dPBRQkIGyHJNgQ2qfaB0VRNE6O10TpIlB5WGDBcU0WeEBHCCnOnhjzTMozGEyTfqmaAkp7KNbE3QGq2HvfKxBosXuJ9shWNFWEeaxtJWOwZj90/GrRqYCM1U2TliPe8CAwIu7TQnRE0WIOy5e0RGcJj6uxJWDhnRezuvCE0sqCitwBE2YOqxTwghPnjLYXFTEAGgWKLvHkjbhqnFolGOwOf4PFYe702KZpUVmU8o8lJvCbNyq0dKNJZRYgM0WKK51ALnOqiCs26EdpEFUiAgbgCqwxmhl0AOzVS2Cwo7LEA0A5p81cFOqj3QaFEWACxGmZBTj86Jvj0TG0bi02UmplCexKBEBkJuoKqm7FNpDEHHsqlwmjZclqheUIpmXP8ACURqUe8VJusLdQfcBzQmypRqKA1QkISvBCkXR3TtSuSaTJHulM0lNBQN0N0F4I95HdHvFH3k/h5BfSFIiB7nFEI3j3lEFE0RPuO63Q2UBORKO6cPcN0IvX3Hkn3ovZj+YFhus8df8Pl/ojb8XJFFFT7jv7uaO/vG/wCHn+IC5C5qtW/om7eqOjyOSxhH9c9ViNvjyvaYvKebz1R7zlP5juiYfzijpjFPH5hWL3k8/M4rEFnuWKfzCsTvuT++5Yh+co99P756rF7xWL3ljd4rHnksTcdE/knfSnHXoj3in94p25Tk46rEH/axO8jm/vlA/nFf+RHeVibhYhu5O76xv95O75WJ3ynG7ivqK+or6yo+dy5uXinbFHu+qxBaOqeO08BHVyJ1Wa7v1TdWrBO4Q0cFiAWRmyGxXJDUKRQhGLBHVFO3KenrE7vohrHRN2CZsUzmmblM3TE3ZDZN5IbhBA7L6UU7dO3T90/f3Bc1zTd03dBBNQ5oBDdDmo9xGnvheCPNTonmyOqYLo99HvhO7wTxZ8eadq4Ifwo7om8J24T9wn8k7dP3WJrCP8K59KImUe6E7YLE7oWJz8FiAjg9ViT2PVH/AG0eacNfVP3CcPlb1R2HVYmhPVYu6fF1ibhYn0o6wmd5YfeKZF3Jt5PVBeKdsjyR3R3Tl9ab3lsnLmF9a5pqaJqsJDRVuEO+Am989EN/RNA/UhN1TJsUybFM5rD5ps6rD5rD+opv1Jo1Ta3TBumjf0Q5oblN+pN5ph1TE3mhv7ggbKiahuvrKHeKbzTawT1TaV6rDrxLD7yw90y4dUc1hXpO6Zo8qRQomqg7J1/ieid/ueiJ/NX1hfUnQOL7px1HqnDbqn8uqfy6p9BTqjy6oo7eqd/CnJ65LREUottkdAnJ2pTuacYMlPrxIi5RpxIQJIQOoTe8Ezvpve8k2dUOaGi8UP4UO8mXLk3mm94rx6o3JVkBv7q+CA2UzKPRW/ZeKATnE0Wpd5J+U/KPVDLDSnRKfBusXcrEpDisX+FPmMwT+8E5O3CdPaT47UrE5dU+b6p6xN4Ts3bk80aWRQNmLbCTgOyBKPDULQu3tVD5XG9DCcZ46eCp2v8A5TYEuPRNzRLuibFMxVexPindnIEdcohH6ZWaztLr60acZ6Klz0RqI6IU4ShaPVbN9V4LSqMWKkdlyefyneaO3qt1DlBoPJE1AaOacbHojNWp2l+Sk8R8gjYDzTvnsNUB2AEZKO+qOm6Oro/ZBT86pLXKt4VK7rabaKD2inVdnCO6PeR746o6O8k46glfSCqdiYVxlrpsibD1Q89aoSZc2VhzGeqwxIl0ppg1A2TaQ107IQNfJNAiSmCZLqpmWzk2IyoZf7YR7okmqfThARMlpFpToOqdunkRnKfF/VHNeq2+yfHaprRHvLbeqxIJ0hRdyNDJIKE9oIIbTVSS6CCjQyibD1WGCJxJOgCeYrlCP7oMvCc4mX+SZeTCtBvyRA7dVvCO65wjMeiIAy1KNaJ/DBosQQsXek05K0+KJ80XVhwhECoJR7tVVGlwjSHvb5p3fKlzjljaqberqi1EwaQQqUInRCSJb5JgdXNRM8ymSI1Rk8k7ZXn0T4ER4Jwviei+skqrnfGeZ0KZQcRi1EwTcwhnjLP2RirQfssTTIKJ24ryRrxoxB0FFbKSSjbmmihaUKw3qjMAeZT3N/ZZTe3qqgBxryXOExkUmsLFntiTYKlR6IbSI1TWi3giYkoxyXLnCBFASZ3VKXWWAGC1IRdaFlqSKqEA2TKAtSSm01M0QdFKJvDfZM4SSmiKpkgZvJGKGiBTe8gPmrFlqHXsiJ4hVQ2ZE3QaQTEwiZvvG6cWyeijNUkym5bkpgbDdVpmPitTMeKNo5FOzHg0T2g8InxQgSP4V3RC4ZtKrSZV6FFDN2vJEkcUaogyIPJbgzF5TiBB8Vf7rDmNf1Tc0SVMbnaqcR2IKfsfKyJo862QFz0T9oE/yU6SaRyTjXKPGVjUH2qsjOFjnO1pATyBtong5eaAfBOlU22dH00UVJjZRJupDiQ5MgAOJNBCjUBYhwswAyzdHhtPNcMOohIhTLTH7oOaTSBcyhU0t9kHNtTYpsWATqjJSPuiDOUTWY3UmCypG6JA4BaqnK4iADbdMDuE125ojLIrMImeA8yjmyBtIosf5oG9ViERMyiakoGk0WHJ4pKrlB0ReflB9FrIO3/CAoRWyhwAEoukxrqnSPXwQg8U+KZAk6JzwbeKDRlPEnFgyAX9FjNZ8swsR0SR0TiQ0YpAGm6AtefumkmLo0l0JlonmmtIkVXgJFCV9Y8kMvDCN3NgKT2fXZYpqIHmsuWcQlxNv3TCRLz4BUJklNhpMxCbmoKKHEm9EMpactbJ0CnXkgCNeSa7iDIEack90wyI3REk2GwTj2XCnJYbgQ4h3JYYniMFRQGR4LIYJpFFhiofehRcDFWrKQCf3TQe3QfdCAZreSvNBuaJE2TXCmyyvyRaaqW1oSDRQ2hitU1zvKqJeRB80wECHDc81w2/dYc8JMRKMQGCdP1QpmrTTfZRRzES6XDh/RXaTBPVc/5srgvFFOiw52MbK4LpXkuITETKwvldJ7kynzraaLEjsOusS+Wk9Fi/CY5uEXCaAbI6sNbBMJGYeAUkAHVPz/qnB5HFTVPJLT0I3Qoa7FNLO0W+KdEaKjeEfZNa6STfqgIrW6GYAOqdkS0UHgspdX9k7Pm4rKajDJG2qxCBwAJwzZ6LLSZcfVAycvIc0cpgTCnzQz5dZ8k3DBkUKlwZSCE0ilY1ThPC1woaKg31Uw6VQ5ZpaU+l71ldocgtJg6FYQfJPZ9UwOIDTNBM0XDOs3lcZdkpzopnhdn15oNDm0zC9byo128FAfNaTOyBin7FMkHrshwgCtf4UBhtgCuuqfiObQWqbIVJdp9kS+Gu680A2gqY6IA2O7U8kS3RCRDjITRTNpssOpINKLBa1wa0jaAnw2jRyRbEH+BYhpMa2mU+ROI0DwiqYysORe2ggDWbp0QzqmyHEmqdmo6gNZQDqCOaBrmgzXLRREVW/WURRjS5YpgkTyH6oZWtdGbZQOI6ear2r38k0W1TSGkmi01VnOkGKHZVdWeKqbRaOOt/FDstQGKK033WaJ5rK4jLzqVwg5RGZHsmkwmuhpJCx80WANN074lDI1WISEQQI4QjNGU0VLTKFBztC46tn1KdlMTwrDEuzX6oMJ1r0U5jBDZoFQcuia2c14EDdS4HRxt/0sOXZRv0WLPmfFQbUlGuTeg3lPisZS6SgNJqsxzfcpvxYn12XhKBqCZyyn/BdJi3RMidx6qRZAujW6xCxxDa0usTI5pgVuNiiW9nMawpPxHFUnTbdZqg0QY2pJMXUPrrYSnOFNqp7XQ45gPJAgEN9VAtTWU7haXgAhZa5nJtBMHeyeAcsmioOPKg7LlHy0KLm8LQDzWGyTlWcRl8ETjAg0Oi4+HS9ITTLSQQmhzfUJhpHh4oxtxLDeTLTLU0tyhwumO1qTssLYSTfZZIrJlHPXQ20UOa8jouGXG9OiLcnFQW3QkyatMV6LjEuF7SsISddK+iLzPOrSjLmhsEzWPVYnBB/gRHz+SOFDmQXGyH5pOUdmskpjyCyQDBAKL/AJiaSsV7jADT9in5AMuUau/ZGmV5MIYmUVnf9FU1vSNk2hcTIWC7EzVdKYww4Qmlwp4rM2XUEW8EJOVhMaprnRzTXZRW90JGpF6o4kQx48Ec0mQBaaoOn+o2m4TXYuYuLi0W0RGG4swxyCeeJ7YpZTi/ExCC1tkakv8AKIRMhxmtwm2Cc01DRT5ZTIOayIHZtrCaXBhmSdETSYHSUYfxOkiscllINqoWLjBiVh5RInS6PENk8lhiuqxDEsjihRm4O0ETlMgymkEN4nxbUJ1BkFa81xzFTcahAtBtBT2PcQ+JH3WI6hHzSm5gM1Z0QdHIeqw5y1EKCyW6yCdVUuyGBVcOYAwO0VUEHLP6LDiATJuVg4QGTzKvEUU70WKW5RvP7lQcMVoDJQcMx2MQstqGNbLLcyYTTBMUQLRmd4DRFzm890Gtl96ppAJGkyFGeQK2WIJeAXvgQSVh4rg7GPFFWix8UGPmaBuq4cMvuXSgKF2UE+iwINLcqpgl0RTWia4CGzzCZLjEIUhPPymN04kw0+P7wiPlGkymtzb6lB4Ga1NaJtYdB016pksz4zBKYADBM6pjTNL+KbhPY0RmJ2XxGtzuMctVWYihXaDrKCMLnUTRD5GDKRH6ynCOATOponMYP6YE1nzTgOEiSKEVsnHOSRNVImbpzXlh2kHksJzZ/krKczO0YkrWhTSJFJsPHVEBoLeAJh7McjyQFTKwzLedvRZgBnoIvonB+WREyJ2RbXaZHimu7J2omva4ZnCbbqHAEWJqsR0k60lEAFzJ5oD4kiwoU15oD2eqAe10kp4fJb5o5AN0DSK1QHaMuWGGsgzmbMJjoBFOys8Bs00QGY2EXTXZofAgLDzh2eSZPihFH8oCzFxFfAL4mY+iOIwUcf5uiAHuk01NVlDCA41ReBExzssvMjZUq2K/yic1rXBuUExsrhhk2K016UQpSkyZKxXPLiQ1s2lAU7SihAUAyoaW1En0TQ4w7Wk/ZYwaQSyJNtk0WaXu8ViNg+I8EWuIIB0CwsTLajqjNBhf1RDoBFlhZbOO3JMHh+6w+GCAIqmZwC7XosNklpmdeaw3C0mEd9apwzZTeOqcagGyIb4QpEFxrNE3BlwED9057TF0HOIMZgsXiHDDiPCEW5TAoUwsFJ5JmG4ghNbiEBxJj7pxFbhf/8QAKBABAQACAgICAgMAAgMBAAAAAREAITFBUWEQcYGRIKGxwdEw4fDx/9oACAEBAAE/EMmTH+cyZPmZPiZrEyZMPhMTAyZDEwMnxLkyZPk5zl8fjJkyZPiZMmGGS5MDJ8T4TEyZPiYHxMmTAyZMmJkxMmTHH+Jfkyc3DOfmZMnzzk+JgfEyZMmTJnl8Bk1kyYBk+EybyZMmsmTJkyZMTJkxBxN5MjkxMnwjidGRwEzeHxHJkzeHy3kZk8YGTJ8RyZMmTJkyZMmTJ8T4mT4nxMmTJ8TIZMTeTA+TyyXAyZMmTHEyY4hkZMmTGGMwyT5mAZMmHyJiYGsmTJ/DWS5MmTJkxMmTJk+EwMjIyZMmOHE+SZMmT4TExH4GJkwPhHwfgq/yA4mGEzh/AjkyZMmTJ/EJrAyZPkmTJkyZMmTJ8kyZMmJ/BPwGXBiGI+SZMMT4TJkyZPhMmTH5AZMmTAyZMmTEyZMnwmTJ8JiYmI5MmTJisRyrkcj/AOcAAP4gn8BMmTHBiZtk/gJkyZP4AxPhMmTJk+SZMmTJ/wCQAEyfCZMnwmT+IHwTJ8JkyPhPhPhMmTJkyfxCZMmT+YAfCZP4CZMnyTJkyZMmTJkyZMDJkyfwE+SfwAfCZMmT+ITJkyZMmT/xgBMnwmT4T+ITJ8J/EJk/8gAJ8J8D+YCfCY4nwmTJkwPgfx+/xBPhHJkyZMmTJkyYGTJgZMnwMv8ACJhiZMmTJ8JkyZMmTJ8kyZMn8AY3BzPkyA7+Mncdfz/rNuWARdi0vWOEmgKHKbwScPCo/Dit4TOA+D/AJkyZMnwmTJk+EyZMmGDCtkQDlzwNxaOUBFo0fu4Gs8CtY/C4cTJk+EwMmT4T4TJ/4BknxODDygDjtmMCCSDvAg0HFmE6BcQyaFTFKgq0WXLpFOwLo+DDg1bBw/RtA8HAHgtxMn8wK+EwMmTJ8RIGRWG8mO49Srggh/6xukHlxqih34ue/k8Na+Exw/IPgmTJkyZMmTJgGQyGekNC50jWzfORdPZjg2qkDHJNS3Q8Ima5RI7WIYhGRxBRXuZFBwuHKOsoCkTbxjA9lX4uCDGnYJh1x2I3PG+sNXNMA2GE7TFIIG84AKkxuzzkyYYjxoKkd+sORZsJT+MTJkyZMmCIgI5a2uWA9qtXFNwD2Hi3JyxOcU1lrw151lKNV1D5fifCZMmTJ8T+AmT4HsCyDgy8KURf6MWMpz2fqY8LcAi4tRAw6DowiEG9h39ZuE6I3xhihQg4MvJJGlh5MYCFqOneJKJbiuXL5Q84hXQzHRtLg4EibMTpjX3MCnS1VUmsSVDj6MmBpvRscvCEpXjDyx4wJLSTyBr7YSYYO3AwzBoUeIbc0p2n4yXHtB5uPjRwZHDiaA7Qe54zo4A8fnxiIKc4j4Zua3ilER8OTJ8Bql1jRnlmteDMQvQzXjD8mQxdIQ2hhQzCpU04dbLSTpzWPBho+0wMV9KubkgKiAnnLIDtXEyZMDJ8kj2Fy/Rk+810M8OGZMmAUtl3MOWGcZrFd93CllIjH/3ivSiOwPMxUTwO455Yp2xaGNPXGhHtf9jD7OUomDjQEEPXOboWzjGF+z85oiBpPOOMq6TG7svMwvFEM22jq6zwMNhxiQ6m2bmGdV0vjFt9NwSlKIFN4l4WQ5GAiXfJdOBg9vQOnL5p2M52hKXJesEpOMY5MDtZlKiCrX+sSw3EYM4rXgNfCLYPy4ZC8sbmBW3Ug2ZbwPGzgkuMGn3vxhESvegyYIxrzMLTJeLjmDSmFltN0xFQ7NeMsUYWY/ZmRQLpcjK6ax7otH9XJkyZMUBysM91B3rzPGDImIK9BkmY+OYmIGhZE0POasFc5MoKTZxuF1D+rikV3M02YiAZflD/ADOJJuec0Zg3AlrAFo3iY01U8eMe3l2YzZsRwUBNebLjRKMZlagNPvGh1B/JgSCC04XETWsEI1u4c+DXjx3hm5u4mNwL3DsBDF84oDlZkS0cObkWk6Y4A9ctuPB0WDU8ZuYPGa1D2Yq5tW3DdGYN4yywtqO3wOAqGBuHGFoi2jxZmxsqjfTl9qtcJmmTy1yMrWqWum43ES73hMBG9mMsfNy8FbrGp8tuRm0R25vhKG8XE70BkjPtV0+TG2l6DF8J4yAWCYI6tKYeTkf3TQz7xHlfA6wkCDcwW9G84mpvJHY52ZAUND3gckQeAMWSQ97MQ06fvLsPCNMPORPeufI9YCiPDBuhcMQaceHHoy6ebjIUUQDBKBfRYyYYxoGNsyY8iYqheKrFYkFwQlDz1rBhNU9veNlr4YkBVbuVo3pN79mSBBwO/nDguJ0xkUrYIcGPaR2mVDNbOQxI24q7Xgg3T5auoY/GV47wby84Ap4yLRTu5XgNl3RjwrNHWaupqeRl7EvK7G4UAlxQdLzkAzkdJ7MbkTNba+sRhWXrJ/AUNxaPEfjymexMBGi6xvB7XNpQm05MHxG7x9fQzTyrrEwARiYAgHlvgDngJrAs9ddkw1bAAxog0Nzkhsxa3Xo1m8GdL17yKQRucK4pVkIzJ6FdYSSoricOByEiq+ExtwDoxWKKhi2pUGaluIDFA0HccKU6rcucW3HGOl3ejBMDtuQkB783ElrYcBgqEvP7wVwQbRrmx8G0NpwVTe2UmITnYzAgd02zFFNEfLHHQGPzvNMBAwpABHNzXYF1K77uQO9O95Mj3g0VjMJOrccCin0Y21SN2uaZ2phkj98OTqa3TiYlpltTWBDFRpw/eVpre2PQpPPvFVTeOCEKGKtuA8GGKNYkJaYkDX6zSGI1kqCQ7uW0t894KkEv/rNsq7xYHIaR23y5yG2pgan9cjNNd4ZqkazadHeJXenkXAN29XAIKJy3HwJvkTOptduBp+IS5f8AqjGgC+sW1TWNUCH0HCup87DnDBpyUmddOLi4JfETKZf2zaxfvHAxwxvE85RSPrGKAwnGLFQuboOTJPxg0apvHOmnic5rCjxJvI1N7XBzw6rimtUbgtBe1L/5yoCL1nAXc5C3wOQTFNkzWAllO3JzIrfoy9FAZ6M1HIml1l2ImnFAaJwuBap9QY5anNMcVoxcfgyfeXlMLDnA0yQps+bklg6TjoUrlNhMWu66xK2uTCk3MUWNrLzmmP4d5vCDuTKiP0MKu16w4i5zVylG1MeYXoxNy/bhN1pj29i7xSBz6YIggecNTNdKus5W452cPOanjzM17a8POMw053ziEALxGsSgKNjXNsY6IyAxw6ImSKZTDAAcWOvDCprFqoZw398CcLNq8hKmcjwYDEKNMrzZjrczhwsETpvODTFyvWXag/WTbDKOMGtj3jtVeRxe+RJj/ZBw2kMSb3fAXINmPm5unsrct0sa7x6V704J31bOuMkI5eU84dZ0xcybQd3FweNFz8RtM2UKIu7iar9aMU8I4WT1kyYa7Y7jlZxeLjs635M2wQnbHIIMDy5HlX6b/WBSU6XLSB+cFlVMEUwRuJiT2bxokMdeseoLiYwmj6cYu9Dy4k5sa2uf4Tk3pXswuRK1rE+V5N/3GW7OEmKuGvGA7dTy5Gg7UFpiBYvXGLVX0MwOz+cmEbZqObFRORwIlAlvGPMlW3w4fUPAA1gY1TVORQIZj7mWcFdtM3CjqJiCF1gkS1dNxOjTAjBri41bs6XOp24M441CDBYz7DWLjkLpcr2+E4d4Lzc2vLnKq+d5d0PdwMn9mGgVkG6ZtuEhbhN6XBJ8OMlJhLGDlLPO8r3i2jWWIDTvBomh2uSUv0xmtz6yhyfWVqGyK4PSfS4A8d0uICjrxc6DlbvnNmlu3FFEOYZJHleMXU/u4P8A8cU4R53iybsdYt2zyGez+sV7xtGH53jNZkcj5fi3rBCNsCUufWK4EcesFM4NxpuDECYq+M3gnnJpmOqP6wMzKswZf1wbX1YYro/O49KORHOsQlDN+hziDV/eTirnJMcJhMgjMaINs4D8+s2/4IwnSuT7yXrFYfBD1hkcb5wuVnWbXNh3jfLkzbquTA3sx5uN+MDeAYtxma+Ie5iXEY4zxkysCamNPDOWM9GL295ElyuUy+oZogsV87wQ3DyVhfLjXa5Y4/vC+cjlZHzm+sI+cnvEcjkwKiPbkzRn3gR/orgsA+OsEI12nEgBvlUxI/QFcC4A8OJcfWlhv+wf9yuQHr/pnBUfNw4sRvC4tuj9Ynv8rWcbPtxudWKctkDDkIeG4E6Y/aOU4xWOb7XJXtg4n7rgUaY5QxPX6MQOP0mHnx4IexgPH43G1x//AHMa8GUVxxD+sMNg96xKmHgMYF+yzCfL7mJmj+mdIPzmuHAeAYW4TxDCO/6MIaweQ8EW/RMR4sTI/wBmG6ZK8tlHBX0Ys3+0Mn1/ODoH0snIiwq4+bKa7wLX+AuKE+sBr74wbgbg4Z9GKcidLM2BS4cz++AkP26wHQ15cjymLKCegx5hH7mEtJ+bnl4Hj6LhK1/OA+P6w5UJ5xSwHzWGju8OKNfimI4/oYI7J9meXInCP5MPAyHAyDyMOvD2Ge8/BibP2gZa0GKYfe/nHfKn/vldKZxbwjcZPjjCfsZ7meG/3keblnHMchco7/vH/wDRgDN5pfw4NtGJTn/XDXD7HHnHwP8AeKpdHwBhVsPitziDCdWHIXNthyce3XOey1OX/rFRX6YVWnzdYsUg+lg3w8LmmX54yh+/IJ/ZhR2vziprb7zWE/szYr9jCUgP0wh032sbIXXe8RgSec6f4piAv7DIgtQ0kdY8GvomCbH9MFlj6TL7AF4uIu31P+5z7/uZRtTjhlJo+v8AvkDQ/DDuv8mC8v8AWK957mdTh2V+C5QKvxci1c6XBEmrlGzNUMGLOqfnJ6PtHLaP3JgGlrqIY1tzOiHA8pjrkn5zZ3/XPCnEabf8yjaH24o0DeLeXPVzaFdPbLkSTrPCmTtfmYFjr7ecaR2NQpnFu8cMjG3V4YotmtAQwUKX6lwiuzrrGjReMW5AYw2+jhMW8vKjy4E6w7gAPrEiN1wGR2U/rNJ560ZUh6E0wUJ/jHyuvBmq48xjQVh9ufObccPeJEEedlyjd8OtmVP/AGOCtn+sRws7mbWsYan6Mn/348zf7cPJffOXpQc4XExeBRxLYZoFH4cPxWYXO2UGsW3EjYY/mYeX9LAps8JvDOx5dYqCqM4gP1w6D74ObZT4o4CP+Wcc7SfW8VSv2/8ATOAPnyziBw2N4UALzkiXb6ZEE/ImHK9uEY+EEtOmLbpE5pgQAkzZqdm5MT05MV05HhxWeVbDcy9pvyTGpEiyTIaiejBig3mBmuDcR4zY2a3bHNbbv7vvPIIdQ3fGCG3nrB0kXPu93EpBUwpyqeTllV1etYdReus2iE33jrd7AKFyUDq8u2dUS+e/Gcyu8diOzNOKgLvm3L0UaTBihmzeSVxNMezExVeNZLBDcXCqqbBbm7ZV94IU45AvGW07jxvEU74oYsNoxaMH2c4IDv1NZKgCdN5aCfbViAtpt7c0AOzz4xrTczXgDBHkF3ozd78uDhFS85VbDxg4lONRyA4lnfB5wZqBNIO5k0oV4smJQHRL6XOODegPGIXmbmGierkW5tcBLSv5yNFLucZSV0+Hzl29Xe3DoWnzedGKCxvVzja7AvjIobmtkY8sShAP6rMuG6L47xBr04NpxjYWroIN6msWYL3e3J1NaPi5UTW8BU2c4y8Nq39bMebVOyc+8FsfNgoF5Uw4y5ancDd1isn4RjFu7z2wWB/F/wCclQE94WEtUmEAoa5vD9YHYAAvKYTwe7o4xTX8UMDE0decBaIcPDEITWPOA1ARNFr7ckNMQJ0mcQbNrAh5FWdYk+mDiIS85sEGnH/ZzmN1yeu8GNO6E1v/ABk1o4K5wADb4eX6MvDe70s9Y74b+NM1RcdnE15XE09AzTLdcuGSptdaMliJddfjAvCIhMhs3txm2uNjwnozQmxeZxjG01SoGP52vE84oRIhDe8Q13HBGUkya2v4M2B4jgx3iDh3bcQMlyhUMAQXAHGC6By86VxhutOWFEVfHLvAl3FYTR4xUbSQ4onvgxoSTeI0DbguaKqfFacKUzapMShKN+PRcuwScOdn1ajgwTcB9+8U7oHpM0yIUqZVTGpAJ94ndtwgDlYjB1V3+M1ja2qH5uUGN0QyLSI6rvPHUrHbDm8t4GYw76eNXfeD9l4HOXBRg5xozje8YdUUYT3mzKapVueZHkcvxKdDkFEQn04SbROgtcYvTI49Kjb/AG4SEx0DNe7m/NL9iYDoldfjziHA4QMAeTOUTV8mIq3DgBgponlnNwjluW55Ejs1mi9kinnK6lDobXIwURSTWVEnSAU/OA19tl3McjY9rnYBCh3iqAPks44uLaZGuOchQxPMf1hUYXz1ht71AyofZy5XNkTml8GWpQ3pAvuYcQ4knnvKCKgAUGQg2wgCHNuRkLHCVL1vCKZQVzBeS4ny4l248TlzXXp2GhOrlxVacbYYOrmh7vnKdZA8mR7OCLTi94qBDR4Rv8YMwAgHLnETMF5FveKmtYrHe8aIB4cCYuygKlandzYJwLObrHKE726frAAkVl1pe+zOJAnAF3ipeNDg28/RitKFTxx/xjSrIQvJiKNBdWX3hI875cd5C3bHo3iJCwlYZvo9ZHYlamvwYS9Ccq5vdx7rsF3fT1iQfSy/UuIEoL01XAUCuDcxLcAsEAypRgxTtjribZW3eesggy/g+ZymEezw/GXmjyHXiYg8wE4K8YlQASc/W7hhm8nRMlTnnHWAAcVq8YAFLvXlxRQ3XneEFShvNUnkrcPF7Cxm/GFKF5cAfnNKIGl1ZgCY11194FwLxwqeHN9R6I8/eannelylRa5b/hgXS0cuZ3jNjUXhj3g0i636wI0ew7G4IS0c8I2HrIDEtIIJ84iASgiOzFMpf3coCDuu541lAisR4Ws3MsGbldnLkA5F2vscOhrWhrPKZODLDe8VB6JyNfeKryF9BtTJd2kb5MhsmjR/eAKIYtJP6848DPg9vFwSm+Te+DIaFThcznvEJQKLdMMRoXhtd3CLqVRo+o4ahLCt69YENlruOMrX3hrGhMllJxxcBNBLaH23mrULsTRWGTkZhKeGUFo0JMSNZ4W8RNG7Q1feJhnqaCvveEgtNs6cUHS6u36axOgxao9bxUFiG2y450jLrUPHjDFsFeB8mICAUl8HXGSwn2V+3IFkHL/5yloA2HWRIbtTiXFewwmBryNUdzw9zAdJN+cRYFZpEnaZEpBo3rb24lNF6I8GRiJ+6DvEU2YinP8A85oCoOEWHY+8eA9oPId4FSTZQyEBABv6e8EuDAQgOTJjNQQMrgVrDt5HrDTA8G2tGLqs/o4zSLDilyvEGgdF4QxpEbIdD0YcXevZ+cMMIars6JmoJsgdM5woR7s+7zjwej6mb6hS2hvIW0KVNpvbLMWRDytNd4aQsK8E6mWoATW51rWEgYyd8WXQunhsMHKi28rOrk0Tfn2ejHVgu/PB6tS0rre/VxAC2AWTlr84jrMea1wor9LFf3+cSaysiJO3B8hCHZyIxMNWxpVZrXqwzTuBV8I8awEjZffBHXapox2hHR0d+jDRoFdYo5SbgkhmicOd3njRg3WR1YTBCpJRcXCZZVl1awHBunIOAaMCwYXCIDc3/jIIFX5KbyF8SCMaZM3ZtWnnWHrN1Qe01lzuNq31ZPGbJokHw4uwdCNL1rGk7OJf/GOkv2RO3eaKcnS+Lzxh0Sgg9enDhelL0PONpKowqOzfvOS2iohvjEnlFT9TACKIr2P81nJeJsGGAFPCK08ZCBozXW/WEQTZu4Gz95UqkM8if95QTjVdjvjIihAvjfdw5mTUbk1u52IpSKtMoDigQDHzl0QoqI8p4mQF1OVj+XjuTDuh0Xr7OsDYI2o9D/jGdGNuNXGLsctE7fE8mNExpbyt4I74G6rnE3qaeusKoQVQ7uKiuPXjDnrwAwbyTafTcFp0DY+87QhQywur4yFImoX4Li7GGLB+RxIRqOR2XNmmvpF3l/ZyLid2DRinpxWrolEmaBzSih+MNLqza43gnCB/t84mUYVBDpkCKEACCe5m8gdop6xdAarD+5lmRL75cS4tCNNQccdaN0vcN4c+82OaYK3UxTszedeIXTEag3hOjfeCUGWrSuJsFHwm5lsERYPZxhNRnk204JRtOjbxi2ZqIMZbm7To2eJvf5wpjRj3T4TEhMSzp6w1LgdcPPPnBJ4N6vPOEGxAR3lUQHfancMkJuYDXWnbHU1m+3SuKRdDha+7Ck33i60hNljgCViodvTimV0aDvEAUVULYvIYQ1qjKgBNTOU2iK3ycEzQp3FpAP73lRUVAPphuGg2Oif24k5NbOy0yZ+gJyfBjUGtHtjt5YkLEhtTzl2lo0gwBXUl7ZrMAAR8E3pXAgt072Q84iLCbOHx94CGAl6FMSulnXjnFFtWlIjdJkBItrkr2ecKBIkBt4yfUUY1xvWFMi6eUOhhiiQ7N3gxCkBYhdJm4UsUHQd5QlvVW3nCrlCMEO6TbjdTgU4aYpiMQpfQOIFEErtcDJbaNMwUA261xlx4t1w4bFUouzzzi+n36ObgDAhiNzgacmEDUEqAowhceEPWOQgCm76wrD7Nkx3RUUJzTN7GXTSsWYRQdTkF6wWgaaSWNxZQgAdI5CEYg1uuMpUjXbR+lxA6qNf45A/IUAEl7w1q0IPE3ZhV2Ap+7gpEEIc88ZKRAi7TvOxhO0ycTSd9cYvitt5g6zSbnJ/TiUoS2XAAQE2VJ9PRiy868iLiFQFOjbiDeaATaH+PBikiFE2Q6msEm1QWNghecAho058HWPpTc+B7zzwqHW91gmFpNdppPjwuKqaS5DbYEwlGmuSfdmGCFkV1HBEgUXhcOSUmbk1pBxHI61oy6NCn2G0w1EUHlbTANrS1quojg6WiqWrdcGm0Gl3ryYIbCw/POA4IumrHm5eRKNGNwIEV+QTgw1UiKI63I4VrxCXR4YhgDohkcYfcJNNiTlTqYdW6g5a4Oi7GozzMhGIgbFN9XFURZNrfOBZCm1hvrENFZttx6rgaiQAOMKLeyGhcSIGrWyfeTK5qczqzC7Y2eTrnDloKLVF8n7w4WqtEHGzRvgd5LaqupqKKazgwLqLZMbFAOJoB5i785sUSae8iCRgnGu7m4mo07kYuNQKI3fvGlhFOAbzkgKHXjcLkHnyJybuYzaNo7IJAwIsvI6xK5nKanw4msQbXB2OOzKNFnD/nIwUCLduT+8AetQNXhrHlhUnR3E8YlKhahLvgYPugqnkd/esCLmaKRenvxg2QCXqVkJYjOW8LAvsbCdlxrH1eZO9uFA5sXBxrNUtBUYb0NxwhinAHf6zSAlqy+cKDpIuorZlieBggBqDNaG6q4fjJyiVfrnWGApaPNeP/ANxIqhJ4xvbMHac9XCRkdL0qv5w5H0/bnIk1u+t8Yaj0P0x3QIgcj2+sbc6wQK3WIG1BRTiAA1HZH6xJD2Ate4d4syS46YE7aCbl/OAB4sipcW2xdDgtxJUcBmzfGzHjEd80PzlBQQVaH11gk0S87WG80pnRKN4N4bjZscecVDLBl0e8SJaC1YhjgAB0aIl/4MBErccVKfrKwoSeXit4HIxFbg9LyYmhVI7cuQjQHFMVugQdfWUJqgJ41wTA+2wBsu13vRhFWELoS/16xGtrcNQ6cCnIK/rjAkdVTyOrmge/3BHNOuCrW984eboIcflvWVbGREabM1tqaXDUPWNm2oRv4Li2vt6PG8M4W1O+X43k5KFXrxkwCoru7iKzURxG3hAd1ZzZreAqioTZAwIg2FLUf6ycqwB5Hm4qsJCrg7w7biYJong68YR2qkPOi4aKg6wIngxH22K9NwcAQajzMAIgCLWtzFVRbsdphUzETjZi0rp8nOnPG3FIcy8AnB93PCnIeJ6vGLb6J2tamNbQS6fJ8ZZyvaYk1enAaJJV9uCRc45GmN1I3QbJlQqd0RB3/wAYFJiMQeN4M0jryC/jtxerZOzIjk29necQAoOWu8PQBZ2p5zVEjRU3xbiKuqo8MCMrBKmLoW2CfRwnQ0EkaZZkJ3HpdPvJrAqsBAajitdg1VfLSB9YCuusvGuCkv7iuz+HGnPbIFTZ1imOOkZuc5uFJFTgfeGgrsOIXEOGoxel2Jlrq1tvWCFTe+ddz3jSujpj0JmxwBbYGMLaN7E+cZCijD3rG1Ci8W9r+MYiYPEW385Ry5BpXiYANHmB2bDfzg6lR0cX1fOTVxhmh2fWLYQAnaHevOCpo1bqYioLNoN4h6yB0IowJvEEFse1zgEIZQe/cwpqPblpLiIXb0Lo83B1yh7LtE3j7bkdyzrG5qWh1+XnJYJOHOAt6AOhvmuFACe8jmXKRY1XUNYtG8lWy4XekHu04MDLJYE0hMGSMIch35zyoWDt9dvozVHcKA41iW2vjmeAwTOpNqnlMWBFHA4VPPjEVYS1k3vWIBBWUuO+usKsci8Q2ZYWA0psQ+80AeQYl8eZgKOXzXGSiKfQ8jcQTyF1OPUxBEcLOUXzrA1Ahz+EmVwVQIt5/AxGstnKN68ZadTUOV8+MA7G0DmD1gRlix4XXjThWq0HWLU1o95VNetrUf8AdcubtUmxdQtphHiNm9uDioBRDTguJrvj7ZyBiK7iz6xHRgTk6tyBCdoXzgD2BAaYd4WiBbvde8M9b2c+d4kqHSdXCJw/g8sZyI8PCd4xWOfV4cEOl7RB7JxhsJKzl7TECrbnzX/MZjOqbCfWOHxVXmsUtF4h5M//xAAiEQACAgICAwEBAQEAAAAAAAABAgARAxIEEwUQFBUgMED/2gAIAQIBAQIA/wA6/wCm/wCbl3/N3/V/xfq7/iyZd3d3d3d3cu7u5fq7u7u7u7uX6u7v1cu7u7uXfq5d3Lu7u7u7uXdxnyc1ubh5e136u7u7zcjFnu7u7u723GW+bkPrjPm5D87jcm2cPtd3lyuwGM3d3b8pWz5zzM3KATk5FJghIHDAbmgOvN+5OSORycxUhXTm8fk3efLMWfPl9MCADD6MvCpzfSxKrMg2gy2fWMh98jxTVGKjLoMXT1dXUYTouMqkzBAUGLpXFoiMpBFg1HIbsvbt7N9nYMsvsEDTTcAjXXfZctVVaahSJVD1cIgg9CCUB6oQjdc/2r5IeXHl/wBVfJ/f+iPIDn/o/orz/u+4837vt+37z5H9T9Y+WPlm8mfINyYTp1aBIIVKwLrroAIH7Gfs3IlSyNStggQQzWtmIIYt6DbGEiXdg3AzN2BuwOWLbWG2ELH0DTMDCK2MML7rAACC4csw1pQU0EL3NSpTr161WWwWZGJQggBtu0HsYwlhFJAZ4quEDGAGZArqQ4Y5tskxhQishIIy5YcpOsZyFOqYzjeCMKMCFSbrZn7Gy4mGRSSkVdiNBMj6hYY7hVeZAi5Cr7qAHzAsFxtin//EADYRAQACAQIEBAQEBQMFAAAAAAECEQAhMQMSQVEQYYGREyIycQRCUmIgMKGxwVOi0UBDcJLh/9oACAECAQM/AP8Aqj/wJGJagZwoTItvdOmcCN/Nads4XFait9n+ZDggy9jIcSJIa8n+XW+Qdpnv4RmQIyGrx6+HDhxYsnDhQ5qvtnGlIY1E7Z8UbjSeESrQvBLEfA8YwgyXGUlW18I8kQTQP4uFBplrhIEd8eEFRu84zKyg7ZLiRI1Xfw4M4EJLtTeRhOot/wAD3y8l8S+ZAPCcpR00DJx0JJ65xTlsKDCtI5CRG2lM4S1zF3WSXkKrrjfhODcZJnFiI04z+WW/jOMbjWGcbQKTtkeRFpengOa5pjgPjrmuuI8w1pvgRZcwmTnotGRujNMOYOjnJ0PDUyKgnrg7aOUeEyRSmTI60yrOJPrSdsnN1zXEbMldpi3V449TJXkk0yWSrJF6ZPtjWT22PAfzZrgGHMVVmK2ptgyMmuhknJnbB+qReRHSRmtqH2zSxVyelOI7voZ547NYORDIppMwpIpeSumeSPPOIDvk/wA0bL752Rw7+B2M71hd6X9nE1twTImoZ+zB+lr7GF3zN5RVOHbHpRmpcj2zWxMIeHCn9PFi/ZHGvAMLyPbwrbLb8Tt4a+I52MlfTG9axxxx74nXwbzzzzy+mTDYfTOXcY+ZnGNuLOvKbn42JfxmvMHPxf7XzY/8Z+I/RH+2X9XDf/bIOnLMyD1lnAH684X+qZw/9SPvkP1wzh/rMg7I4d/B/Se+cXtD2yf7cn5ZI6mVuxw7nhPoOcfoZ+LfzBn4uX/el6ZxpfVxZP3k4YZBvTIdz3ww88L65G+mS6SMP1mbVP8ApeP6z2yHWQ+mR6f3w6pnZx6Xkz9WcVr6zJ93Hu4v5Zf7c/a/0yTvF98DccraD7ZJ6Y3oZLqLjtyS73S4KUOftb6a5K9D/dkmIunrg182FhnD0189s4R/jTODoVu+eQXQftgflrIdovvkekD2wu+T1rELSR2axs+VyVbJ65Jp+JXlvllWuORvfXvhZq7ZGqRvCWllZXWOu2uUDzRvF2pye4hj1Qvzx8tryJdkdN7lkUUhF1q9c4l2Q4fLfbJWvNH0/wDmSonry7mmHLpu/wCcG9HTNLp+zj3jHEdZnZxiPzqdTOseItdMBnq2ba6YLvTkx36OhvkdB7auLdY1vgZJQerpm1buAXzFmSp+bXOxbWT3sq8paDKNYD5Xmqchkog/DdWhyUqCysjL8rppHEQ116bGPLuGm65Eau67PbCZfLLyrzyIRSSdnOMSjqr7ZfNLmCRo73r5uVQyiPkF5KSaNm6VaVm1W9xyK28R11M4tcqxOm2d53jdlXlH/GTl9N1nLBX3syUxoInXXIkF51NSjpnEFGYU1q9cSueY9NjJrUJRLxiSAqSa/f0y4usbtNDXLp4nLptnz3J1DJzskGjvs5CM15KWu2a/QD96xS4HpJyVXRW+ugGTWMDljB1ZVp7d80i/C0U1k3762GT5pSQ5en3MSNdzpphsKnbIJQr55VXG3u5xJogBdVVZpGpMb6GR2uXvkSt/e1y47IXsmribGl4dnCl5X3yUi4x07uSiafTWuEUpqsjVM613Ov3yPMnMv+c4ZzFF91vOEqSk6HbPlZSmBW4djGRyr6pjHhhFtO5jyDGOkr1zkIil81fYyJKyPzGuruYk2XxFV1RwjHlXnXqmDEbCt7317ZIjzRkctl1vjKnzK9ciQRjdmucGMVgPeX3x5BEL9XPlLte3dzbWfN2XbGgOx7406l4HLKQX0vJzebm9MQGaYbpg0maK7GM2ouQYBKSo3RgowB74ADT6VnNpyuMYUapvEbTYu3HepI9y8nL8tXXlkhpeWtBrtjKPT5R07X2yU5XR8touuPLw42W9PPIhK+Wu+vTrkSBI3l0ziMrmWRNMlBE6oa4d43/XPiNWX9tcIypcIrzOq++EmpRVi5Hm5hbclaH9s5Gy7y9fnc4g75xJcXmdTt2yNJvkpB81VtWVRzMns7YPKKijhGPKuj6uIzHRNOxjKFLH6nWqykFrTv03yUQpzjJyqyB0Y9QyV8y0S01p89MOLB0Ja3EcjQfCoaUOuCXG47EmuvnnDly80pLd3Wf/xAAfEQACAgMBAQEBAQAAAAAAAAABEQISAAMTEAQgFDD/2gAIAQMBAQIARH+Db9Hi8GDCB+z+T4fwfwngOMYhiAS/1PiAwxSQikh+Uli/JCSSqkkl6klhxLxJLxJJJJJJJYhhxepZGGv4o/Du+RerF+NPz7NCSSSSVTqXxa/Ppho+eHxfV82QgYoBLVrjHNgxYlH5pR0aB8mn5iZ/NrkB4AT9sjH4ZGMviHwT+aXzfNpEgZQl8f0fMs0azm3Ro1eAgkjB4PN8ho/ljglLNZrnNDyYpSEMkAW5TjPodvYbevWJAvLYJTOmUyJnb2ltvOcJgxKIahEx5qnHidYjriYyBHDDDBspKUZCV6URLJte0pjywkfK4CcIIEUQyVjOA3EjleXHny4ceH8/DidPHjzGnly48eH840ceVI5WvPnz58uXLlzEKUrRVqQgK050pVVWWJva1m7W8HlhLw7LiVsZLdvBK9nazxjOnQHBFnCbAsFtslAEDAKE+CROUEKCCSGIxweLL5EyFmBOMYg9BjOAxygFnETxvCQUjHFIV6XtKeO92ciKRjhIisIIEAQfLuWMmIMKIE5LLDABlsJM4zlsnJgk0qhslIiUUIf/xAAvEQACAgEDBAAEBQQDAAAAAAAAAQIRITFBUQMQEmEgQnGRIjAyUoETQFBiY6Gx/9oACAEDAQM/AP7BC7ofwv8AKx2fbHZjGP4Pf9w++RGPzn+Rjs/y8fEv8PKTqKbZ1ZwcsLhcnWlX4avk6vSVuq5Xwr459Vvx+7J9OTjV+1+XexNawlj0NslDzcotXXfqT6UlGh9WbjdUsnRimpLyfJ/Raakmn2k7qLdFOmq+FzmopCjFJKku0lOTaq2/i6slajS9jjJp6oXVbuVUdFRpq3yR6cnK747dWE3OKWtqiUoJyVfAuO0f6TXim2+0Iwkry2QeXFM6T8tbbsd5kdSLlStJnVWfC1V4IxSm072FXaE1UopnSk01a9IUF5ReO8Jy/Ffbou28PmyXmpJWuTJRgyIbXfHaNKDjedCUpqPi4v2QhmMbZKsmR+LfCPNYb7YHTaf8DXeDi7SZByxajZ0un8t3yQgqj2TVPcilSYkIXIqIp5IojZB7kORWQ11fZr5TA29h+Lvyp8EVGknruNJkUssiiDvUa0i6JNW4s2UWzNNJIhm0Jr9K/k9C2se1EpNkk8wZJO5J0Rq1BEXq6Om60IfLKnXA8tponwxkv3fU4sdb19UeX4ar2Si1TJvDaP8AkJL9UbHVeCot22vRISrytiadRYqaaY+ppVLkd0NJfhE2rErobyUqRLl9r1yUmqNqS7N7j5MUa5HySQ3lshVZsVUmxCv0RIqsEX8oiNYTFwJ6Kitxi3R08304nTfyo6fDIcyFtP8A6L+ZD5iSfBIl7J+yZLkfPZ8sXL+59T6np/cb+VnpiIcnSOkvlIXiCK0gj2XuIXwIXsXsW7f3IvRv7n+z7+xcoj6IEdvE4ofKJcr7kiXomP2S2idTgmf7CT/UKv1CXzMXLH7Hwx8D4JLRE90Sew+BkuEP0K9h8IY0snA+GPgk3oSvNkr0f3HsmS4f3Je2PGGcorWu2lNn1GMfKJcok92XWpRgb3x9DOle2Se5yJ4iqPGt2XbRLih8Mluz/cWlsjyyIiDWothpu8se6NlEd6GMsWUhq0l2dM1qmi1+lk1tX8k/3JCvUp4GO6KTsjJtXgSf6m2NfOJpuzhk9ydaolr5Ce41TsbVeTY18w7K2yxNKyWNB+JFV9RaMhm3QlhIf7Y/+kt3ZtbEOhaJkh8bG9Em8EmmhrSW5LTndCa49m/l6JN6r1yLeRBy1spUkJyp2XrIjY5O6MDzeSL1ctCFLUVaMj+xCe461SQ7x2pcjY7WEikjFlok8Kjqa2ifNDiq1M6Ec/iS+o7V/czbo6j9I0V3loUUjiTIq6Sbs8mKKvNvUp4ihLFKyKi1yKLRDZDeiG9UjZCWiL5Y28oV14m21CVYNM/wJJNEstDklTRm7OWJ4HFeLVxG9qJu6liiWL4x7odYkR8cuz//2Q==", D1 = "data:image/jpeg;base64,/9j/2wBDAAYGBgYHBgcICAcKCwoLCg8ODAwODxYQERAREBYiFRkVFRkVIh4kHhweJB42KiYmKjY+NDI0PkxERExfWl98fKf/2wBDAQYGBgYHBgcICAcKCwoLCg8ODAwODxYQERAREBYiFRkVFRkVIh4kHhweJB42KiYmKjY+NDI0PkxERExfWl98fKf/wgARCAFAAeADASIAAhEBAxEB/8QAHAAAAgMBAQEBAAAAAAAAAAAABAUCAwYBBwAI/8QAGgEAAwEBAQEAAAAAAAAAAAAAAQIDAAQFBv/aAAwDAQACEAMQAAAA8FLVH8V3UraJ6DGqSiz6Bh1IbAVKDUtwGUZlb0yMpoN1+CWj7liXnq1GnGS21Dtgla5Sh5/c5FZUEwMCUbeNecVK792sEXU15zKOWNS6AWiDpr6gqwHsFM0xU7pNUjnCXkRvHrBZrjYowlDYKiViEW4L6WwpFM50lwmVFuJNgIGnpiUx0KvYUFBSqhvi1nwbY1ApItqlF1ZSmXyyh0YALKzC8bhzJcWXZBCuU/PouUjeJPkso43YCHMWGfj7QN19nng/ovkuhPTJZSoYBfkrD4KiZYjShCotaHUKBvpmzoUy17UQoYqGODVTIFVvhTwNd29a+537jGXxC86N9ZbSGvIPSpJ6sqYKIpsiYTkJ0iJFFrOUD28tIcwRFHGLE0QGI0WVjQPNZsiFZjAjsZzw/fuSe/1DE0arsb1knr6vzZ6z5jrNz5zl2aiugzTsAlV9AjK9rPWRtMJsrMiKowLXFCUm0VTMbIPUUVkFhfLGkO+uq0zh8GZjXJ8l0pdeJjQEhegnl1IftnC5JXVOFmtqJiQJ8VSAX8FxllAUlFXdZp3HTaPkU8xTwhwKBwg+0AoDZb13oa3ypasHk9Xqpvpa8wfgv6f8OpyZNOZXzmoY4ds7gtrGlZD6YN4GEzlzJkLCUhMTMRY9SVDdURTo1yhEmABlRY9cSLgGcM8JYXi3oSaiglNxy0llgdK8MsL5Uw6WKUWosWOCyhoHAKYtgsdIyD4Is5BGEXVxkqQ1OY/Reb0XhYvVTN57Y5Pz/RC2uY1tYRwu7U9PJ+d15+d47wHbFkKWA9mTgBHZuSyBqMp19gegAgIgJePbI7OlkUvrPoC4/XcrOsraLgsmglZZ4TjNHJmFwk1ladRwEJgAT0NfydOPFWxp57ZmzT3NLNfaOiZxbzVWxt52H6RlbRzlHoONtAO76dYbH9QYLZ2tp1kzBZGq0EYdGdKY92MzO3wV+XzjzX3v84LHjBfGLshn4/MoyZtmL45aCQW9CFRMaDPEXTjRG1XE6t4FdlU+q7NU+r79s3VQ+yPUR8GcJ+h1mauUrJ4tyCHPAkc7fXrVrp2643WJlQghDbCGjqT2gv11F8qSvgxV8RHURGR8beodfPtVbVB10fbXyz0QrcKxnSatRpctJV+ZIVc3Uy8X9uzXbyfnhusZcbQIqAS7JGSDfjGpYUG8jxTM9wdD4ZZZpc/Ip/rfkfv1c6wLDnwrR8dQspiMQquxNouSlolbBz2wLqMVIFgyw22P2I6NJkYpEY+1aYnNP6A4U4Eit+ZiZnbRmw3O8vYV6f5DuWX1zPMVff0WHk0vz3npsPCW2WhredSV2sVcfQcHHCerzefpz1AsQMfELFVdLIGIzoWqrU5jT9RK0uepkTM2zqVl0xT8VTqN25xhGETQftPyRNvlQbkS5JssIje2vOAOG+rYZlicXiu+jD3fzb5qMNQnt84s6xJKTD07AzpcBNI2aEq2STz79crjX3lllfRertHZLND3cKvGegeWQTCAZ3Y+dEjTVZSNthnebLrH54A/QfilqoSK4Ue6TPvDuEUi0RNbVb0Cpj98yEV/JyBbwHhpX8ckljK2jV9n/uS1WgZA6JIsO7awav584gqKZTshoct0iHaZXS7e+fsjj5c75liL6zBKu6mWLC+VEnYMEoonraBXUU02npeehW52nQjq1+OW5KV2PnG9CiuThsdkeTyWlK30iFpKwUJCCuZp1MFwB+eJMvFNcESKNhRH845obTZ53XaDO64O5XMlPJjFUhOpZCdooSprSSDh+wz/ABIZK62ErHUbN6XN9a038vstNlnxGiJoaeW4/wBavwP5DuzOaYnAsU4jNQ7VsxL3pqK+7nE8a9j8i4Ni35O6hdSB6dm+sZd3XaV8Jvkq5kIrGtfD2jXHFL/qsROBKWLOMyS7Ecw2D52uzQOVjm8XgWhT1N6cZFTKAFHIUsLDKR5sx6MWLBM6qy1pwJzwqQuqrHO2iNutB4xqI0VqvRcWGqvFmrstZRmMpVWhmzjKktn9mfInv0N6Tk9J2ClI8uBzBRlcnaodFmqBH0kZB5fjvZPz0qOF41GtfOC60mZWdHgrNXKbPU9QxO3c1IKZrrs8w82sFt1FlQw0gtp/LuC1wwXa3G7T6n6PX5m4kO0WI1hRNBgBOWMS7WGEZVj9YrnyvK9epnvngpQ9W6SgW+LC+Q5SdNRo1uNmizXttE96CMG6m593ikUe6ibPMvqMuwFBarcG/wCQ/wBkflcDI1LmFAMOzCEhbK7C90S4zagW8TF18E3DPb781wMRXQx6oq+lqhSxSyS3nCTGlH9KmjnK5ANAEeE6lpmOi5xA7AaY8rKPmF5A3VKHOTI2QolfEzsSioC2yxwJKJPL2bHNNFPZF+nvBf1XZSKbfnsP9z4EGuyE2d5bV5VhctdKSpvj/raRN+ShGIqzsD7UW+++qpiej9XV2RmW6YI5idznm+Mg1g18bIzU1SxpqdrHH3ID5drzkeOVYtHWxKdxa7pjx4G0x2AWCSFtPoJXbSaCVFhXxOE0roqjfUYy+KvCcmwVXIU0pT2r9AeQexdlRSgmJdXZTcrL+csQuMvqMswYJnSJlKaK3yn8Rj6/JJIIMsehr6cQCuoLHXVfdiTNuofyZ8h22Si4BDRPeQAJfDjpERLKVeuQbahSV2aBMBe8yOELpK+4xRuzbqdotWSmm2n1WizXaSZCYxK4UIXsLa5VYUIGHNgfEQ+uaqn6h0gxnp1AZLWgKEkQkFaUEwmzHMaXOOpyF8g2Mdp2qnwfyP8ARX50EYRI+DW/RJRlyPWZhyJCyLjuhQXR3oSsEfA5YUtwMXMB03Vl1dQ9SkTzG320x6VLZRcs9ANQwjHItG7C1UwruWPntJgPpSlps1v4kRLqE3KwjdOU4GodGKUbJ7fAJvRsp7M6eomhl+iwDMA3ZBdRchWNFLabFoH6SqWpHSQFoVRFTT+If3x+NWVKZY55UQPGU52RZvZoanPVTYVSka1lHLnQ7jOrpcrtJRVc3dklZkkAMDLSNnbQb5lZWR4Cd9RwrZdQUo79D6aeRrdjP6EIvYMdquRTu8h5TWEUETXne/bW/VVhSfZvHvd/Ua0irnqU+vr4QovpvRkzpE7m5iN6mrPqN2kUugD0AO18G9585VfIePrvIfK17QEnG1b+DthYbgcDBNtGLhi/toK2zN774bPQa0YYirUK+tR76gdt/Ln3Eb503avxFUxOy2BCikjvUlC6MlSJVtRpOMJsk52WpqPiblwlJBGE9/59Vc+42+K2d1Pdg/LyKndX4FRqbPQ+UEq3rinyxjRd8mz9I2+wRuVRt1nFEoXQccVQC+ltScupb9JRfPOHJAnlOXNRe/COXnpB7PjKtJYNhobmmmz6XcjorKNlnLGBtV2ML4WoJTrvG5dZUzys51FndXAMfGknL9eLIsRCkpTyNq993pcESuRX1HBuKjnBWapW9EpdZNa57XJdBtTaTRCVVJtumJOdJaNLWsut+LpM1RtFB5yYkU7oor5WuFkbNsuqv6VAiYHhGg+OwY7CZ3//xAAqEAADAQACAgEEAQUBAQEBAAABAgMEAAUREhMGFCEiIwcVMTIzNCRBJf/aAAgBAQABBQCUpLavYJLizf09Gfn2zcj7fHAhZI0/fQ6EVh9yzZkm9WDcSpPM4QvW+QckFcnVNOXZ6cNii5rT8Ppk5prUcg5YSLcahAjR2NNBak4KJjSiFKTI1Okkz3yPn6+Udx3iGO4Le3qL6nz4ARDNInVlbkJvWV7WL5XsnNEStNUazt4BtYmjaFa0koaTaqUw6JL8a3FEuo4sUaTJ6M/oJsvkzYtK6M4QJ7wgxlXUzHFLG1CB5+UzAYLN6sZi/wAqrFfQrNEy1zCv3SGU5SXk4ycHDM8XKicj8ZVpyUvpQC+ksy2PidS3A/pyOhiue5mr2nbjZR6ZesFG1RrBYOWoaIw2aJMFlUzw5NiTrG7mOeqp9gk+aclSuCR0R7TLOZn2/wBuib/XS2qTc0VRpWkGaqFlwIr0q05XVSlxBEMcwYjrhLsRNlfTSS1n4olkEJ/H8fKTXj2qOZk+5tkU/KkXS8+2JGTZeztZk2+kzwo9DBZAUNDyiVAMiiaM9ApS0wpdQhqSlpGj2UctomJrZSKefPufOebEJMk51Tmm0kGOhZ/JJGtpcctVTFkHrcvskrN8sgoxrCWx0PCJz0aMmO2fEuCE6dquJtHZN7JebJHO1KnrslZ662hjEWuftwsfKylmSRaqEcStGWTNTjRgm28vj1fAbpCYrXdFZ2F/5Hc+HX3RECWdUfme7U5RaxPXahIYqC1xWfl/wKV9OfLRx76LVuGSVH8gFfiKAubBzZ0hxL+nNGo1r71QNR6cyZVco0ZA3n4gfZtE58lFUb7qKIt5sa6R759yBcn3PYXf6VxZ1To/oTU3Z/RirjyWrip/btNWr2lDfc8wN9vkJ+NjT4S2fE7QtOcuYoK66YpHRGgedEkwyz9l7LI4cr+2ekUTbW7y0lkjmtdURhOtgl1ooCj4mGeQvTTETXMniucv8pv4e6TQReapEALOZPGZbUmg8CPg3Plj6niTAmhRE9C9qyHosjQr1yGm/CJ8VPUZPUC1U4lQTOnqJs7FmDO0+epLMASJ2XnR6tf0t9LYsn1F9UV+oPpTtOvj1X1V2HTbT1v079QdU+645r1y8L2Yrm0h2cATKVDnF2I+OhSwQbFzmr6Wed55shonGU/JEME3SNTMFEe4qoS9szwSGZURqL5SVoIzqyGXr6tYm0rQhny5j9s9FSzSXNQsqRnD2KBr+Ek05PUeQpZUmzUSk1f2WpepDG85L7BoLcob2IPpVywA5MOR8ZJ8GfEYniC3hJMC1fJoDycj5yXnGXdpq0Dp79fkhv7CDH6y+m3zW/piqa8H1R0tem1ZrspCj4NRE4CftzGkVds3VpKQtFm2AQtmoeRvomhzuzMl0Eanmi5+SCIaXWo0GtCEWvvQzEyvgV+QBEUKzkFPEeMzHnY51nZGMwvwU4UR0j/GDodXTTQ8IYrFnbgofmrJOWX4x5VFKgqoUSX4H47R+W5BUT8c+cIPlbyrK4RUBV18F/HGp4Zr/lGdudD0uztdX1F0eZfqXP0exNfa9N1m+31H13Xy6n6GxWwafqXpYdnk7HJk+eGxFnoo9ntiWklzUzrh0Yri15I2fSctLNRjHEKz7BPS06qAxh4doDmWac0mUxHTTMzMTAOU46SMKGPxSCPlk3xn38y+aiis0PISHEyPdmQgT8lZOpcBSAysrBptBWDOp8syMLTmTDMTXWl2MQ0psHLwzUdtuMSVYvQlPTntxG8g0deC9PJoeIQSugA/Q3Wfb9f2uNbU3V1ekI2iNyjxjyidnAaf1X14wdpfLWAnN/Z7MK3uTzHqzQFaV01aK+1C/qNLqlG0PaGWbrq9EziGytW/4aJQWZk7itVnOJPik/uCuNVp7TRZkOaqVC0DV+Ql0ah4mifwhQQy/EyMkyh/YCZX0f5GQR4Gd6SEPZ85NEmFnZVUBA/GIF/ZCNwQTfQc86aC7hxxXXx5B4iK3KR8cDEc+lOiPcdrkkJy1KDztIpDlO1ySXq0eu+aeGA/P1fhfb00lenOxmo4dA+N3oBkEfkq6W5ecvFA55iyx9UlJkfeJSa0aSvr9hjqrKGa9LY6vwI/3Ie/mRaLPoWraPR0zKVFc9DQRAIj/JjxMHlEFfz5QD0eZcPT4Z5RY8ASFh66KPDwRISr87+RQUzqlmobxWVyjv4bzp2kctqrYOwHFPnifjgqgVLDnzg8UqW+guibB1Q8AW/NOwAaVsSB8w+G8vVlf9bXCrbv8ujquxVLWKQinLZi80QtyuqgSM28tRRzIGdatlyPoR7HZk9cokvorKEbb7H4alKzVWkEZqovoHmOWZDOVP1Ut5uHVOpyi+ij1lrPiDhpuik8QqFcSd765+jX+VlImfko7GalHX1WnyrT2rUvNve/4lHNSs65LLol9OUpDJ1TjVvMxoedVH+SPIKL7c+iuj/ufc4ZMFnnR5Mye2iIpx8Hl/sCpiqz5Pq/nnvQg/W/WLeGpYSes/aj92Pt453qft6R0eiNzTeea69iPaJauzrMkCu+Pyu3t59SmW5sr5K0SezQCxiyBfjqpgH5QIqyPuv8ZbWhaupaZx2Wimjg030Xw+6wjQkQC04VmeTkzBJetJIUaTfmaE1GGVFj1sWovWotD1s143Wyaa5znbNDIOU2gc8xKJi//q9rjXVOuX7etUIMiBz6H6H+29TTW0F6PWdJ2y9NBgvPhHDmUkQUc02WGDf2HuuzKmnLtamTVDVN1hOb2zemdtV0vfS8qt2wVLzYqVYeeq7BM1uz3J6iMFS8DPGU+Q0s8oyar8SzDghYzhE0VhUuP/TouVs9GbnzSK0z2YPEZ7YPuLo6UmkwynLH20X+KEaAgz/VM15FK7KB5b+xkM+s0VL/AL/cozI6tz3QvOMmFIMKInosJTM9O7Qu0dVdr7UxLD6M6Qdp3U5FTop7v9P6VXQ8pXV8SeGzqD9tIL1TDRT6kvL7AFXzk+0/6kdT8XZDO0UyyQRps0MyaP4lCpzbJaP6EKA7GfyMa56e4bLd9V6BpZ7Aek0TR/rOZKfM/wAPo02Dq4aQNJZ/d6Tp5ZbDOPNUyQj9zkwa88rii8g6HmXMIpqqQjKDxih52OgwT6T62urU+dLLqzHIxNPEW8rOzK3zAulnRvuCXDE0o0XkeughrVjzT1M/j+h+jXrergD6e3jnRXA7KGtU59whC1m/NGjNnl7Revfu75vuGaUEP2P1T1Q7LplbzZAZGgHlrhKW0u6TcAIqOboEfr7yk1NKF1/mGbrUMr544sPY0jSZVvgxV8lmadca1tw+8iwUv8fxp90ic0aflyde5XTTRm1aHakK20vfiUKtDsqOjtQsH93LqHlODXw0zxd938Hb6vcrdCiZ/wBdEPgYSmxeLngtSFZaBTjeVR7snG3+wHZ/xfTPbadnXaCJZdA9Z4YfDnG0kR7J14NuUDsPqjr1wdF32vTl+odKuGdjHF6/aUb0bvMeWHdaLuSlLPykWaueaOt4eKsrotGZ+ex8xnnGNI5RzHsmubtC3mXmxzMXaUzPmkV9sjLONqipVVShq7P9ujDsU+eUwc92gi6LUUcFgKlEKyn8Q+ajaUDvVZr7fCqt1HRGvX2/uOJtFa2dR6ltgULb5W+5Ar907D0C8bWk+T2VLP5ospMoX1pb6WWGDsK3+Y6ial1XxTKytXL4liW8O6+vNjFM+Tbkzdcsuz6x5RXbPZlNvqJBd+2zYl3eQeQ0TSdGBgaugQqFXPoHDkq1KKQ+Gudcf8fxUuPatGs6KkEijiuj8WX47rTOt31QWafFE5lWnyI9DT2IUoHNrO4VSBQD7l7MXjT0BivPRPdn/Ndqqv099T36vZ9Rd91qFdrNf7laAAlqaySlnVk3ML22TrxQpeUiwxhAdF0VWDNZLT+H6UnSvUJirPsP/wBSYKvIeO/0ZoFPrih3fVH1jXutH0T9VXzS7PuM/Z959UvHrMGn6ozT+jC1MTWcHkz+fZmUqbc+2I4zKsZZys9E1WvqvxobWb7Zoyhdqt2TNNDrYzk7lQSiy2/bBK1sIpRjGLfALIEaYrObP7/g1QO/DFksE+Rl8pyDmqDMiT7fQxBoVCvz6c24lp3mOJ6xKUCxvR2Lere1KcSJ8nIEnJVZZUaaTvyKoy6YP8iVs9/pzuRHNG09CDNaVFj+Kw88+uYvnjhfBn7Lff6fwad2z6fMp3+m8ModvoQar5tl++t1Xa5u4xCWrTjrA5vZnzqsiXD0rmb4b7aidGNUinqvXTZb7Kl9GjbKEr9jTRJPwmKEglcdXlLz8uXPVxI58+exspZEkc9kVUb1voLHShARgOSuI0SkPBqq8FW9dtmtoP8AhW4KFTDctvpNyeIvg/GTyXlStCjmr14Z/Gg0e6SUKsbqDWoPJZUB+k8wu7w29fTD20NCp2DKLdyvt2wbcB9OddpGj6cfM2fHWWd8zTxW7d49Pm03s+53m/XzWr9lKNBLHGJdUdoIvz3soUO4o1pUpNEQ0pLxsififITFUmr6lVB9O9fnuPiSDTxZ1teoVdNVYvX3Dv8Agsgz6D5Fn8AN/D83HZXe1GmAvytWv6O3s1GJC/gHwwybAmNVLKpbzF25+PVAfEz+6AW5pQwNKfwS0uGz6PcmYdfpLJ8PXPF9GvV0ObQrb7YDW8UU6+n+dbpxkd2zw8ae6yw2dFRncwz2eLTtmDW9C2p9FZMWKBZSr7KB8r8hL2m8/h0P4dkuIElfti6aebpAVKlk6ZBNL/NQ9q/5z6EUxes+I4o9UQkBkDN5SFE9Rfw6qS4X1Lj2SVSedk4nnPk8/Zn9SOePPIhg+dfbjZ2BlNpgUBLl2SXs3Mj+h1M1Gp5CKAWm5Bhe0x1cPh6/rpeU27Djw953GveNVd8e0l1dByPQPwdd6rXJ6tj8NmaKzqewVZUqLoUUwGJG5hyIluxaPy6nk05agvDrWIqnymCUd4Z4mWgXeWNWFO0gWbrupV8RAizbfta6ysZJ8hdJ6WnKcGo2r0Za0dYp5nPx5RQEix8j/oKp5jHw2+JrFAPPge6rz0J4PCvml7RjZRy+qYL0HtJ2dSSvEo3mdyGo86clnn5pm9KZVe11Pl1mko6/DYN3Stn0dH1DrxsSipzr6wze7VCnHiX259UT+Hu/hmsYlW5u1D4xpIWbhRYrSnqJkz88Znc5qSSUvjZ5aikp0QZ3r4vlw09qhZJqZ4L8n6VqCyYGLW9pcd4s9pzSOafu8pkoQSz+xLsQ8FDmkwr5q+8/nHy9nm+KyBjwF+e6qPyq46uJRuz08eTJWpRIUmPTwrNJGegDJX2MKArbX+cXY3ho+h+47Pt76CA2h/1Trve32art0zCa1HmeNQKGZ+5x/jR9ddWuPvvw7a2VTS/lTb8vdgJ6AyQ3zaezYo4H/HzH1hCClHktE0wOnHFF7A1bmqoy56nQE3I6pmzpWkck0N5WZq0RJrNAjEpK92CZn8HyV5oig4jBXZGZYgCKMhftADmRyDTK8syzgDpr7HrbN5hnn4vF15nr8VD2HhrdkXHtQhbDwlgCt2HBTyM9wOfQ3V/YdJZixon8yzCuqed/Zj10zH8ciV2a1+PtZ+U0/wBSMDW+nl7BkY2owQEtYSRXsrFrKCaD3VPcsqDjoq8KsTOaxltoyc6ZaHFTXMPpm+x7VMGqmC2epXPmkrCOjayDQQH8lCOtzmnaZZyRLPN43+TlgzED+SmghctvkVVZa9kS2ZQwbXupqX2KmpQr1rBkh7Kzg0XRD42q58Sp5PzAhlHhPYFf9VLc+m+tPa91mABX9ho/FIMW0T/9fc/h5/6f67O5X17NSC2zFPf1dpzy1ruQM9S4c3PG9lPngTyEZvV0ZePPzNmPMF2c7Vo/PpqOpsm+ZlTDqb5NVGL6LWZBejctUMdlCzLT9QD4lGTX7LFK8adaFdY1nzyzcaAZGn8i4v0Fl8PIpV96Ceof4bg/zmmUl18y5DBG7Lw/CpARBycmLOfHE8eXcAQck/0p6oNr8+mWI8tp/wBsv5vI/wA3e/6R/wCd/wAW79fGmaFsmQ+x/qH1pw/VfxMzoFmiKzcsvlip4gZeZwGO5h4FfEQSeZCUp8qucCHLl063tTFSMar2RoNCO51+I2htnEF2eidcVnRFi8DFixnWe3IiNfRlmfhWiRr4NYv6xBC0IEsCuW7dPXYOMeTHlvRBnTRSLLV680uVbwalZepQMrHPRy6WDyzh5Riqj6G604PpnT+IZv8AbR/nGfNJH9u+/wCEf+Wv8D6gTmFfbNgf9P6ydcV0FT7ULAyoVSj+G9vADeRKxQWp7A8RQOKfBzVI0eRSfY0xrpotb1sBTUc8VO8rfb6OjNGbv62AkZoq0dlo9Ukd9gDM3uzzXM+sNWlmMcdE9dtB5NlnHfU008fk/wDY6WKJp4ug+p+RuYwfkfIfIx+Qkfi42OdVnllNcXUvu7GUlRdp/fMvNH+cI/Mud7/5pj+Hd/y71fMepHlMZ8D+ouAa/pqh820KAJ0PKHyzIQobg88PP/0fnn+OdLKRvv2+M9CozVe9lyoyU0DU6wdlBu7nQ7HmuhiGK0y55r6PVSrwVUqPXgcGSZHS7M3Mrq0728u2gE2Ptf8A/G/2mPLiTcZfHEdgyWUJioPk+aXo25J1bdNlOshF7JQ39NvTsO8ivm2o+bRXwmk/ti/0nzuB5yj8S3/+bufzm6U/mP623wXV1lofaaaJNhSKzDevD7EJL8kovPHuxH5H+R+T1WcX1as+jTa8gunOak+0cld3hrZ/ZrCFRVOsLruxFHHyeAjsrtGU6diX4LirIn7OUQVtMMlPiPxTsFyp73T0qOf5bKPNg6jgl7sMnGBR409Dq0v4YtRcjjwxUK8mNP6Q9Uc3TZvzSx82mPC6j+2T8RQ/ntf/ACH8R3/+TtPzj6Y/u367J+Hh9e9ac/1T6+H3Ah/QeiTdlORir5ivB+Cf8g/t7eT0tda0SNYnU/8A9lbyfNVfkd0iGnNEtS34XsFmu5EKPIlKvRFqa2XPlJ5CKeWP6abULpD5guMqtoNNAH8uSzn8FRzDNvLOS8PccqC0znZiZtM0VaAB0ZAeFacT9W+mMH9u6XL/AKEebp/rsPh4eFzIf37Mecjn+Lf/AOXd+3X9P/00+V2Yz5X+rOIT3lPfgwu/FwhCiqVCv4qnHB9/PP8AJA8HpLylaltvY1u058XLZxs+WF6Kn2etCWC+2UHw9NBrlv8AxE6BWKePjbQqtCjFjdFS1PkaelomGtnS9aPFH/d/934OdZLzB8qq0ayAFUUaPRZ/JOqgIrhA7hURVstB9O9Y27vkPhYj1hP86P8AA3HxXz4yIf37Aecj/me4hoW/bq+q/wCvYDxbCfz/AFVw/P0M9U5rPf5Z6M4naaTygudEF82/FXH5HAeTJXmftq/D/DHONTqr1IsPlRL/ABgJ8LyzrF+aNUhzWI/bSmxzJMmUEYdhOSe5yxKVSKDWpNOmR5nWPWaTVluSKtwcy1E5WQ6YF/AofWcXXRlotJjzXkqVLSp5LZSvP6YZW0fURHhD+I5x5q3+N/8A6LH1xofFNv8A5bHxG4Jkp9um6v8A79mPAwt+31ThG3qf39oNPlLL4lP2fLLwLOeXRmevjkl/ktFEEZvTkR63pI309jM5klsjJn7KlKOtHpXJUGiyXRSImnx1Q+VSS3cC8dRvHLtPJZNyzXDU8PXF6nPJTTGWWGKaS2r41+fHIoXr/YA2XFiePNvW6Rb+37WGLD2KEdXocp0j/Hk6X1H9qHuest5/pn0/2fX/AOTb8Syj8ufxt/8ATrHjOP8Ats/8tvzJh55m/PR9d+L9kPM+vb87k9o/UHRVzd9PobKZdLPjYc6BJwHKHN79oZcMqBzlMlolatll8U4/btomYh6xk5pgVS+VmsuVsAvY/Ic+OiRsAWvN0XAvExzAXLLi5AoWM/tkn44Mze4yrwQTi5Jee7msuyALDpUlTamZPQY5Hgxwbn9uhyWSKcbHFm+ykeJlmgEpef4l50WZc/UoPNtR8TyD9XPNX51b/wDn5/n2f+Sv/FPy+H89HgP8+78z6+nK+Gh9Z9Wf7rbPpKNk0sj9ZpAPW1HKdJZynQuHfpSz06y9AOloAcQbO3R0Lf2nQplg0lzjor1zfFy6j4qvQLaqrx5O515mnDPtuijUpI1MC+2wKaK+VtccXVYlNdGVHb2L0PO16W1+wh1GlFXpv1nOqzRaIEBQr5JKP5f2A8kEsDx1J5lxtouigJAea7W/XMPE3bj/ALauw4T/APTq/wDNT/jJfHOtJPSY/wBdG78x6+3iifvD6tj6y+7mHOmXGo7JLWWdbo3G3Zxxt6eDq4dEvW++KNTTOTHV8hjVBwaJcrfM8215UWuvG8ymXRKOmwPYbNDD0j6p6lVZSiePAYeVZeLZCFc+Ws6lPHCvrxVDIjQV2+JKeCzMYpMIgPxsQ2Y/FKC8Wc24IJ5waXw64fWZE83ddOUteWgr+s6PyP76ux/3Z/8A6dBJkxBgpAbp/wBuqh+Nm4/wR3xz61+s8sk7b6i/uGc51ZjBPQTsQ0iVCO6vCxN4GYCq6/A/tfOTx/KF/kRHnYp+ZrZfmX4mrbUA75p19v7LdJ0yizj1eR9FLLNR8Z+Oav7AshBDATNOfIxbzQc8UKSQTE5ZQjnKKVoWpNkuFSThqKo8n1Ks0j/mqyUTrIyUL7i6KkezeF5fVPZLwfV+4Gnd7Km/1ftz3h9T/c23fVvbJKf9QNyqv1V2RTN9UdjlgvfakrX6su6XtM1/Kp/GnESTIglMezvaSaWehoB6v6MquKIi8M4eKLJ1GWXs8JkNjm60wyZXwpFqdfLxTBAh8uda6c/3LyxIiOqT4JTZpkuw9RP4i9GkvtPP78ZV9rL6LFfAZOD42PxqXCqr/KqA3JMqW4al0UqeLVPef2wl8auG9n4/7o5b4Xox58lGB/HFrUP2Ce1MAVdXZ+xzJlL3cDhDe49lNm9R8Wr1VbvFlLIFdy8KMVlYtRrhTXOlf2oBeKik/wBhlmBRSk/eyo4/PhhN3VOUIY/lTQu7DwzBVIdwpir1mM9ABMlWK+gnX4gr1USBafgG8HPITj6xzfM1IfuDI8ef4gjB7Q+JkpRueq0MnmFWKfJWPqmWugkXzzP7kOsAp1J6+Uos7RNQM/jegOd1eC3T3vjE/wC4S8HR7yelfCzRqFrJVBIM5OjxSbKqgKxPilHy05Tr70raeqpjhQIIrDk40dZVuiG/NKoHofl5ZY8OqRTLS9aXnVisvTgh78+0DH//xAA/EAACAgEDAgQEAwYFAgUFAAABAgARAxIhMQRBEyJRYRAycYEFkbEgI0JicqEUUmOCwTOyBhWSotEwQ1Nzk//aAAgBAQAGPwBjkzBT3ExLhzDRe4AiPZFiyDzNHAuNR47wltgBDka23mthdwEIALirdAQhLYAbmc7QKBtANWkd5WPcjvCzsJSj2m0AIllh8AiQkwleO0JLGFi8ChiZqlUJZTmaiQBC+17wjWFnhhgxJinG1LFUOAAJpyN55YUmEhRCysVX0jYwxNd4Vy+kQ4MpW9jvArMCO9mBhkIK9jxA+PZ13BBhzAkuD5x7CCm8pFqB2nhBzd7gwaXI2+xgsW1UYoBIPYTG75zuaI7iHWdQHDDvLS7uxLN1W4HYwgg6eLi05OwIlsKP/MdkcAqxFdo6HCATz3MQUxb1bYCauVBNGFqJJMX8zLIpewiIF2lGgYS29cR2yjjhY6DGFLEy61SqG/M3eq53+BUmFjOJU2Pw43goGAOIFEHmomahCATCWEC8RkYRvCuoWGUoa7QhgXI7ytfaeIMhBgyq2oHmL5KHvLwgAkw4jiOr2ELtjvVC5H2MBIKrtpYDkwvmYt/lmpQAtbmJ4tjEPmImRsdlL4PcQJYCZN132EZNrYWogXxT5juD2j4Qw3QOszBnrSaDek0kMeNxxqhUgb8RkLBmbcbdoHZWYHaWvlE0j35j42AsKSp4MdWyFRVn3KxsihTqPJ/WMP8ADihywmLGV7x0cXcr71LJ8g7SzW0JXjtF8TiAhRbGgYCTRPaKF3hLNvBQ2JhBa4Qs53hsWYSZzAQJxO3vANpZPlgF6hFAh1tLQbGAldomrGa7momPCKJ24i5WYsNop6dRzuJjOUkEkbQaBvUfG/zb8x8emgR6WY7EGjCXmNl4nmYBqjdIGDYwfTeAlrA7GMlbPwTMeHGu5HmJ7zIra9dGlhTtdjbdTGbXTpyDMbpxfmnSZMrlUsqzelzqlV/Exh/mhI5G4+0U0RpO6+kBVrAOoH9RNza+ktG21mhXIiC9A7XxMKggGvM47TK+JheN7HvBjJBtaodoy6qF/nHzZNyBQjZXOrJyF7ATScg1HkwANY7RbWGtq4EGuYyWtq2Es3tAb3MXcmaLAh8MEknmXkBPptCVBEu5vLaAVNh8KA3m5KgwAc9puYtNADUXH0XTPlcuq0qk1q4uuIn/AJr1uJMFtumzNp53bgTpelTMni4mtnTOA+a9qY8flNPQfiuPKwVyVy7A1wFKzLhyqTlDkGiG3+oJEXqnKbHiYkXFW9HaJkVQGqWRxBvFAEFsVXbzQ1lb84zOuoGEqpVewgV0DIJlcfIFpVMxkPpyXvD5uRdiEuDqHI9RFfGzUYUK9ruYyrmmEIJpPXvA5Y6Sd6iFVHBBPcRMhrUGowvxT8D3jHIxAHB9YQN7FiBQ2zMNvUTIyD5gQJjxuVY9z6Tykqvb3MVcDOSxp/eKAgmp+3aamAocCO2neBj3i7jjtKMsykWzUbUNzFCqOIVVYS3JgAacSz8Npx9JZAozeXz7zfiALNhOv67rMagdScb9KmpScjEUAQNwDFy58jPhLguWNLt2UR3bCMmAd8fKiYc2JzlRNvByEste06r8ZxdQenyp0pc4seNVUMo1WRMYXK2n0iviUBo2PIkADyzzDDjyHatpkTGs14sRAErJsZ5QNuDA7sCh5EOTH8pPIhZm1A832MJCAOOD6iPSXZ47gxQWbVVCYsZBAFi6mDWdW9RncApRAEXGce52Deo9DDakadjGo8HtApsAmEKASFtZ0uVSRkG5M05DU8VU2TkSuoYqCNoFHy/wyxyIVHJ5MF7kwIsY3v2jajQEN8Da5zSwBGm4toCzDiUmwMHrUJJMq5sZRMBBg3nNQk8zTNoCWhDJe3M/AMBzM2HO2U4lPCHVomDpMPU4qRAoVSCTDg8HLlNbhQCB9SZm6zpkK471FfQGdb02VNerUgVt10nmFFJONwWxMfTuD7iVksgmVoO+2wmjTRPBh1NvAH3W95qRtyNxHdD5fQwJ0zk3yvNTUdrhQm5QpWY8gxsa4/Mi778wamJB5EIWyoA5msKbHzRTj4c8tFVTTL+Rg8Qg+b8plyarYmiBAbstwLh0sTa+veHgd/YwBaZeRvxDlKWukgDuLnmDFbuou9kKARMehgdZsiAPakymI0pxNIXmNQ4EAaalG0Kr25jAWYoMFAwE89pZO5i+I2w7TYDaVUITabyhAam8HxM2mwmHpvkV28zclUHJn/hs4kC4cWJ8IXsFUGDN1H4kcmEHyYgiqIVz5GUDJY0sQpqZuk6fGNJQgHkzJiK+UoAPQ0ZT4wzA6kJ7OP8A5n7uxpO44jY6sjgwal21cDvAybEQZD2g1LbdluOmnSCIQqWpM1udvSKyt3gBpKGxB7xzqtzFHhMrMLuDueDMrHZdXfgzxTbg2Ct8e4mjRqVzweRGYpR/vHxKPOd9xcBLkPe28ONd22j47p1JqHWt9oo10NND6wKyLzUyE5NThzfvPDLANzcUkbYxufWbH3MFEXUe+ZxvNJqFUPI3m3Nz3ig8wKBCxPlE2ah6TfkiHsZvC1y1UmaWHw5mx+G8uLRrfmJ1TC3zoCvsh4gahqBGgnsV3mRXwZMq7oQjaSvayeQIV6fH07ZMxpizuxH1M8MksSQsUqtKmOljA8d5n04vJ1V5FIG2r+IQua3gZmE0jiaCbEOlQHltQBgUsARAC+00Y3M0uGYc/aKMaDfuYAWpwdMZgQvue8RCwZr3qasiDUVoCKt7Dg9xDiTIXyVTGHKVI20kmaV4B7DcGOS3nriZC5rWNoNQ+giUQVZvygBFujbfzAdoSBRMUb3zt2EUYSdIABvuZt3iorc8wgyxxCR8xh3skxFX5u8J4E9ZZl9hEZmhcjyiWRFMUDcmCsY45ln9vFicE4Up83uo4X/cdooHAHaJ9YOqVT5jTr2PvGHT9Kq5COa3mJn3J1fpPzEYeo/WZ3xKDm6f96n25ED5iGA2rtNWN9oRvcBIgy5RwIPCUgDvA2vf6z5iRNTH3jOmQWsKsCp4scRXDEt/EDKLFAew7xxx6ExcbAsSKEyt8mjtF3v3Jioj2G5BjPYBM115u8FoQbIg0gE0CD32msD3qFwwrUQZpHMIY1tYMVTtZ3lKIHMZqgB2JiWpFnmFm3AEBEKjYXL9IX0wliBXAM1OfL2EUDeLpWarG0G4g1gAfs7QwzGciVn6gjLk9VBHlX7CChPuIErvNQUTFk0/K1mKymwYJkVltSTY9jOr6YMdKudHuh3UzcmU3MDDF5ebhUJxBjVN/WecbGFFW4VI8veKMe9nejYgZMNrVkzGzfxcQKTbrwIGOPbuIgXEVYd6hfWd/n7xSMRIHBjOoqFjv3hGjsDC1Hs0XTSi4t7mpl0tX7zcTdqP8PuY3S5BRBFREfk9oxSooAm5EQmoiYhso3MKiKBDCb3gDd5pDmvSBLNRQDSjmDRzCLJNQYwpJPELtquvsI4zIdCna4ExgErsaEt0ZQfWVfxx+Il4OnAy5fej5U+5lnc9z7malc6uwruO0Ng3feVcC6px3lBt/QbxMrZSu18dpqKkTpeuC2cbeFk+jbqYuiB+wPEXAqb+tTyGiYwy9pd0IDyCY+nYGEM+18xPF6j616TMcTWmLcC4eob5nFVLLbxRrPmE0tZQ8mL4R70PQwMl6t7E0AkNVmMR6xFPfYzw8gFgjSYLPAhCn5qnT58PZtW0w9cW/eEi/tLYksYXZSEOyy+1QknvBo5qZAVIqKI2o3CKjQFuYxb7XDQ5Owh1d5SjtPKvea3Uk0djzCqoargTIdBDGHIUJT9IUwoVA7mBG3JnykTeY/EWs2as2f2sbL9hNh71Mgb+FlMauHGqcfDeDStTO3ZRQ/SHbvOo6RztlQpfoTwfsZmx5xTo5Rx6MpoxxN+IuSthwTAxx0sXGjUAd6igNZA4hJuXxLzIX1bLFXCCgyHzTd7YDaam3gP+XiBVW7E1GqhZOYcrLVnYxqYhwbjKy3A17abikHaDy2SKEcBbBAnhbBdMUJkBtN/aaApZF4jY9NGY04U8mKq/eZFXkxXuj2mtzHJn7kWbgfJgaoHU88zUTsILgrftAGhN16RjRNmFmIuOzY+NxcfFhxmj37Rc+Ulr9uJR02B35mI5Evp+n/fZfej5V+5iYT8zG8n61GPuZnocKtiKTvXE8oJ9iZTY3H3jOVIVQSTfYTqtIbLjB1pm4UatwlH0ES6pXC6ie53lkdu8xP6oJg61F8nVLT+2RJameJc0CFG5hZhCy7mG/gFVdwZeV+1iYlBKirMODGdSM2xMYFACIurkCAopUE7w0J4XO4oQMt2OIGrcw77FDCDvKUcQ5FYAAihCgYEtZ25Jgw5bVuCZlODqFKj1gZw2ph3h8SthDl7mDkkxC3ENk1UREBsmNlz8LwsOIdMKC81CBj06zNrhlTSxgCsYFuDXxKX7mHILv1gRhsYcpIG31n+IdKfKwysD6keRfsN5nzNzpIEJM6vfbSlj84oLS7mzAxnyOAvedTnfp8iIMyOjlqLOg01Q5E6ZHfGUPUprVAbXQOD7bR6WkF0TsZ05P/4wZ1GFReRB4uId9SdvuIF5EorsYCFhuEadoQTNzNiKh1HzE7Rk3ZhwYPNuG2msbuu9HvDmyHd+3pEOEbhd5v2FmMSPLC/YXtNyfaH0viKAbJBgKd4QeTKOFkLsALiINwDtApx6cytX1mhWIFWa2Big9hXFQqQT9YU7XVS2G/pFDGHeY8jrspithoauYdPzVMWvkCVW8ULyYnvFPcy1HHJm+4gJgIaWbsGDSLo7zS6VNebKuZnyFEr5lA7N7mFPUVCZjyAU+W3P/E3lMY+TNlVAq6mN1tMhXqNL6yp0Nqo9gbG8oEHGrUWexdnci43TdK7u2LIjZkXEaRau7mimBIJp1I1b8idPqsE46a+Nh6RhsSpnVp02ZGxjJqQqdQAbfTt6QIdqgUCWRGBqEIJqXeWfhhZk0ueTNgATwYMRxix3hy5t0UUqeky1Y8u0ZH5IjL6dpZ2WA7Q7bwN7bTSOAYx7mYwh4aBVXcmgZ4jDfTFPMVO8PrFZdzdwkituIbNAzSTCARPFxZASe0ZQd/eanbzQA7CAB9xC+Qj2h0mFQN5eU7yl23g1biCWVMKvsPSHIc4QHHQW6V3PF/SGhSiqvmLiHLMFiAcLQmteDHfGobIF8uJjpUn01TDn68nADmX90gORef4/rMPTYuhR8pchMifMLHmoTBhz9e+PDzkGRAzbm61NM+Hp8ZQhQmbKXJY16MsObr6bB0+IYn8BtLBVXy6vZjyZjy9Jmf8AwOHGDlUnUw7EnbcTp+s67qs6dHkyhGxL5ceoAnznvYEzP+HZV8BqZFF0pO5X6CefmH1hyGrlrtYjsTuZZNho23EIluSWUbXNQNg9oDiah3ECkEiZQy71tFcmt4GQkjvCMgqjEGJqAXeKwIsQO2TcjiaF78GaBuQd4SfWI3cCAVvwJZGyiBxKA+AyEEXLBmomgIdLbmLqcnCzecenvOkyhQ/iKbrccTLlKkKXJUH0Ms8VC10JoWajxPaAXRI4hoULgIBqeaeRRxUDbzS3NTCXyMSzOVLG6W6Ais26USD7wn+YfCoq9V0zeESW8dGspo3ul3ufiGXqOkGVQRoKAYWYarUOeYz9Pm8HF4YGPEXZw1ctSiJiy9Q7K1r4ei0rk6TOkwYOvdwiVlTwS+LUTqAM6b/BjC3iPbijpJYHfYiZ+i6rWzZ8b4lHhUhcbkq3G08PNhyY2ZQwDqVJVuDR7GHkEw2YVB2mgDcQq4iCO9A3CDzzKWDHjLe9cAS2Y3FQY+O8Y6ZVQBeZ549DmHWDXIjqwOmqhbVurH7VGGNR4j1qPtLUcD4CZLO0A3r3jqsr0EUEd5ka5jwqaAFmUDLmdOs8wOEhNW4HtOh63APK+xghXtNpQgAE1tvtAZ8u0raamUTUBtAqrQHM6bpnNFFoH1+CgWyl1/XvP+Lm0fKcuQrkXdNRoadthOnT8RxpkxnIxz47bd2G58m/l4E6Tr+hwr1PTo7DqV/yDsVJAsDjTD1mUDF0ucIMejEXDhuGFczwPwt+oPUAm+pZ2xBDwSF7LHTIcHVHw6TLkXzY3arCHifheTq9CIrq2PFVgZkNqdKkKSJl6X8Rw4/8bm/eN1KpryYxi478QYEIchuV72JuJQmvvCJY4gRBuI2s+eV3hatoAflB3gOOrhQqYQYrB942QgaDdRl03UYlCE08xWIB2I+8BTYPyICuzaL39oaF7Q6vWJpO0a/WE+0A7mHizAvFRizbR2Oyg0JfxOEnfFm2/OCWO8vvKm4uKvaAjtKqpZqciUODGcjedc2VQ6E48QB/9Rl9O5y4iT5CfOv/AMymfQ68q2xgBbYGxvFV1Qq3DA7Foxyfh+LqlSwtOUI9yOI+v8Fz9OSgBcZCnG21MZ1mDFkL4cv/ANvJvREXHlc5VFgI5OlCw5QCZmKOAh1O6kkHWQoB9rmHokRQrMMiuvlIZT/FXLRX6nNkZe2okwZemZlIWgwO4j5czE5Cdr3noOBLFzyDfvPP6RkUnTGYra3PKJqJiBOTNSD6wZWsAyp5TC+R9+wgGTfGOI71TMxIPtFx4m2C+YRVCHfYD3lnbSK+4mTId8n8J7ATQu7iY3A+sQgS+8CeplVuIlLwYj9u4jHhQIWPEHxydNW7ODATDQgsS6HBlsKl1tAOYKlnmuYDBBpqYjVasj5D/wBoiYV223PoOSYciakyKthhz7Axk640AoIerUxsuVyuPJ3FNicem/BjBMX4jh2Nojrplp03Ugdmy9Rv+QhbTVnbvMTtiV1BBKsLB9p1wx4183TnRSgEafOBAK8o3E08WIfEax2uF1m+wA2Eq4QRuRCxnte5jrV7ShuLgIhJF9oMm2/ImPCKCjczKU4ELEEgTFkx4zbbExMSkWXgVGoqKIiDuFOq4+VxY1ECDa6Y7TGNJ83aeITfYwKTCW7Q+hniX3hYcwNNPaAX8xlg3N/2FBMtYWaE1BUqbmA3cpptFAO8ugfLOlQ8+CgP5TqupPOR9Cf03M+fwTkGrTQ7flZjDK2NyxUYejXuW48Spkw9F1CrVYnTSDjLVuAvYTApFsdG/uTG1twjHb2jbcYWb/0sJjI4cbRlI8rDcfXkTPibY48jJ/6TUAB4mpzAYSJeR9rihDUVV7Rkh3G81hpRNVNR3IjeH8ggtiLhGO6HNRVcU7GzMyJsMagge8xMw1tov7mNkdtbZRY9jHIILRta6VNURF0swon7iMi7lyqq3pUZNXG8DsTvxCkyBgedpoM5mmMa+kIA3G4nvD8NoFERg3AmmBZqE2+HvBZMAKiAd/eWBOl6dVHnyog/3GoQv9K/fYTBiX5V/RZ4bAFclhgRYI9wYufpmbNkbKfKaVhfzMT3J4mfL1GP95kBO49TZI+s6XbgY4xr+Bo49cbp+YJmL1Uipmxg99v924nXKrfO+ugeNYuajzAIuNBAF5mpjvA1mOSuxEytVbyiTKIoy1NfQwoMJNx8YTcwoo3uY/Ex2G3aFV3NgLUyMws6N4cuRPm2EIrvUxr4otiCaiKMhIDxKeqsWICMtkkgEe0djxUpjSrAy9oCOO8uuDNU1witxNFTxFGzfEktFY8kzYxgDxzDq9JpEAAlmodxvNQEEsmUO3EwZ8YXXicOtixYnVP1CYhiwooDIK1ZHjD/ACYqmHGBZKX+csjh6/OMgGyrQ/OYB/RMn9NRffPX9plxnhCaH1gH+ZCPusPVAVi6vGMv+8bNBXHeAIZv8LMJJ3hV+RGCiEyp015N25mnbTHCgAVGylNd8Q2AFKxXflt1uDMQDqFC/eAFzakGpi1Dm7PrM2bxdIU7XMnn2A1/nFOKrqj73LLWxoAekQjvzAoJEK9qhX1mJ+/eMFOxgYmEie9xvpOYmd+H7TUTFrgQqeIWUi4T8PTbaGhLJlH4bNLJ3m5qdCjLWTNfUZPq/A+wmc+rARj6KoExL3Lgxz9RMB/mEeYV/wBa5mB7wH0e4vVIN+kz2f6H2MIWzCT3nmMuxPabGWDL7QV8FF7mgJjJbUYciGtQgd1Go7iY8DA66LRfFYUAQFgXqB5FA0iDIx8zoBU6jwkBPCwDPkDMxvRH9X29gJS7hVH5wGgxng2LWORLitFF7EQ1/DAKoQioxPFzYE3AfQzGhFIo4m/EXTApFH1lCVL+G4lSx8Lm0/D+irbJmGv2RfM0yMBQVQAIPd7jfWY4T/O0xH0yCP8ASYz/AKv/ADAfW5jc9yJ1nSZBa5unKH7ipkxMtNjYq31U0ZQg0SjK+JUCAmBhAYwdiT7z6TIzsAo4mXqNYGlQtx8jZL25i5nR2HYRHOIqAdojqwAiriQtkYfNEQrQRa+phUDcmCzwbMTLfmreOLihq4jEL5Q20TkEQleTNDGiIVimtjCtAiZF9/2EPeEkzeHQYQ0NfCoLM2M3BnXfiLDbGgwp9X3aO3drMUe5j/1QGA/6jQH/AFFjf0zGf9aI3vHPdQYvuv6ifiQVaXMVzL/vG8N/AtCfSGbwQBYR8LgHczKvNr+UyKTakTX1K+RdwJkylF32RfSauqyADbRjERWAIq6gcruLoTURuTNbsLPAmw1aFH3aZDwe0Kg0T3mNuQIEKizC4BHpCpjZN+YKEJIjueCYx9R8V9zF+k8osTUeICDLlTcQlZRUiD6TfadCCKfMpzv9cvExp6kQfeZPrL9jF/rMv+ZY39AgPpnWAzOPaYD/ACD+xqfh3XIvOrC3/cJxCLlQ/wD0MZ0k03EwK6lVf5vpHy4FHhp5QILWlq4uNXImI5smp+7HtFGP5TSr9BHBUsvc1EVLBJ3HtKZtmY0PYQ6vWxDR9z6iKy7ioQ24iOwoAw8bQBRvc0xAQIFEAX0m/b4CLAtyiJQm80mA1OILFy9PMrnadJ0qL/1syofoTuZixoKUaQB6BZjHpf6QTJ9Yx/lMH9Rn3SN9Ix9M6QH2EyiIvoXH5EGZ302cIGUf7IdIl/C5f7YyZMgUJ29ZsPNpP95j/rtpYJGkCqjZAoZqsXNeU0GJqDIK2IUTToUA95k8MCweZjUNbld/aLtuveeIWp+DCglwATSd7jPyI2209xN4N5kPv8BAP2N6gNRb5qKL2MHrDpnmbgx8o3HS4C33fyCL7CfQGL9Jk+sY/wAsX6z/APn/AN0aZj6ZEP8AeL/RMojL/qN/cTLiYWGQqfoRUz4MgpseRkP1U1LFbyz8K7SyPgZXxRKY0boRkqlQDiNicUoEZcYPhnbWZkD+csux7CADL5Qlj2i4w1gmaXWwu9+0JGQjzXHfVYFRwLrkwNpozUeRNtxcWxK07QgiAEcy1FiWe4hWOvv8R8DQlkTTUAowEGoCTArcwrDQnV9Wy79T1NL/AEYhUyH02jQTJMh/kiw/TH/3iNOp+x/vE/omSEe4P9jGHtOvAFLkK5R/vECRRLmy/DeGEzf4MuAhb5bvBmZCEq7buYWfFrU8CHBiAWuai4WG9WfYTe6HJmLNVITsJ4jmkfYRFI+Z6WE0eJmINcCpz2lkfaGaSRYihR5hDYMU8+olCAhqjN3uMT8Wf4A1tLWbzzDaCoB2gIgPb4fhvSkU2PAuv+pvM0dvUkz7/DJ9JlMWN9E/7hDOs/omM+uMRop9fh0HV9mV8bfbzCWDuRCWJubylqCEkxq9f2Da2xi4lf8AdovPYQuhDKtqL7mYSaDZT5VHYDuY4R7Ld4FFeKSBUxBWvQtH2InnyAKgveK+uwgFRK2ZliAt8y2foI7V8uxgJEpeYWhMPlntfEbTLM0gRvr8SD3m80kfAOIQTvCLgud4QOZ+GdKd1ydSmr+lTqMY+xMH0g+sMI9QI3uYkP8ASv6/DqwOPCaYT/og/wBoZjb4ZcoG+DImT7cGHeE9oWo1DNwYTCK/Yu6jYMa6dS6b9pbgs97A8CeMCSVSvYRCFLTU+OmY+W+ZpQ1pUk+pMyu5NKuw9TEU/eMuEbtS/QQZD8zjSojdixuETQwmSjVRHBGloyqNxKC7x9Y2Mdl4iOo3qPf+Y/FJqQ7/AABBld6lq013OCfeea54iTLnbjpumY/7sh0CH32+F/BBBF+gh/pX9fhnHrjb9J0h/wBFf0hmI+5gnXdPX/VwOn3IhDXYO8AmgCfLCa7xtoWraUIAYGMJ7RVY0LmNKoVsI+IDioWXEGZU79jCzC2qgTwJpx27VvAjCixFL6CYcXCgcxgBvyJjL2aWwIK7Q7Goc2NTGYE3Ma6vLc35MUsotYukc7GOKsQaZnX+b4IvqwER1JBqMhuMVTZppqMoQ1GBsWeIATNwZus0qTpudZ1JHmz56+2MRF9/gT8MX3mMRZ/sgmX3UidL/wDqEMxxYfcT8SxKvk/xDsn0fzQOzbRWMFEQ+btKJmnF3g9zFcjf4Wy7esZjA6sNQ4jsWstFdCPcRFC27Nv6R2fIltyBMr7lj/aIcmb95UYt5gO9bkTWyURtNxtCNPErQN43kr0MNrTAwbbETVUvRyZxvOJ1NHfXPkMxJlGkXsfeKBwBL0ibqJsol6RNWkD4VNxNxOhx1R8MMfq/mgHoP2MX3mMe0E/2fB5h9lI/IxvqYn1EHwGZFHnQfmsVSIFHMGq5dGatxAzgkTUMewlBKlm4EKCHTPKDAsogkDtEerckk+0dnx2FFkzOoxEFnH2ETG2IUOTEbAlrVGuIXdAON/YT95uYL2J4gNbSgNifgVBFXCCIUqGoeY+RF2YXNsYJERlXS/eIviE7TQxMJ1moCuSABoou580N5N/SDTk45nT4bs5Mir+ZigDYUBGP7C/SJ9IJX8nwcwj0fIP/AHGMPeLGHo7D+/wxZQtlW/WUywMoELaBUIbGAIaAoTTQsTZBUNIKg8m5mNGXdpSgbiFQwA7y2YDuDGfajx7wq5r1jIa0czI/hgEtAGxm17iNgwAIkGF28tfnAVBgsGNZ+kNrvzBzyYScZljHUJAH0MYOlEQaQ24l8ywB9RPCZaN7MYoY6feBFaz6y8jhSTVQAHniEg9pqZ6M1G41gXLD00xdTjCs+LgOCRuKg8boFI9cb/8ABgY9djUtvvYEXwcyOL5VgYNpzPtFHtFo95iUctp/WGMJ1A9M+Uf+6OPefaZvEyVWQ8C5ox9K+Q+rELMmJulQAjkE7TzmhCcbGAAsdtxPMpEpLAH94aUWYusmquLpBiliBAaJOrYwhfOxaj7ShjFsYDxv/aaQtmt2MdjZr0mIFax1CGVtIJCAd4qqGAJ4n+IfKExhe/eMwctRitj+4iaslXY+8ALDWePeDi4UA7V95XqQILHDRiAoHzWTwIQahpOKgsWSf7GFUx0A2+/eEujgXs3P2i+XWva+8XTh/dqe3IllL9FI3lnGyEDj3gXQSagHrDQIPrN+YjkWT2EY1TdoC2ykb1AieIVq+fKYGQPhYitSEiKv/mGT3DoGgGQYMg9dBX9IG6e8ZPOh42LNnZ2XkONUAw4lXIi2S5Ok2YMjN06qn8SpuO3BM8/WKw7AYQIHZVIYAjUi8GNhxdJj8+V8jE73qnjP0mO+41Fb/WV/hMCg7C2YzI74AHdr2iEYTTH5ofEWwBcfVjNngCGll4jVL3jnKoCy8ekiBvDokd4fMCO8VbG/IAhO5vb6RNJO0f8Am3lDejBXLQ42ciYcdEh2N+0FA+3tLbb0Nc1BQhbJbALSjsIKAvvPEGXYnYjjeIxqr57EymxEHsT6xS3B59jfEdA+kVt9RFIbzVRsT/qHR3qGrUcGY2KKSDpNnt6xTqZhvxxt2MJ0kuffyiJjDDUN3hDWV1+Ug7/QytAZDvz3ilaJZttr4hYKu/MyNpJ9zCCAGHnhXVRMfG5BXuJkBUhu0ZWDbDmLVYwD9vvFQMdmskcEiEKt0RQG13ATiC7Db0m2N74JA2lsVChdjR5jeE5AoWAaiZNV3sftHDjZsVjbuDGAA0syqPX12mHDY8zAH6d4Ow45uAfL6mAVVDubitpAbVVneh9ISw8wO3ckRhqth8iwk7EAWDvA6N9hASfotVE1E/pD++RRZH1mPH47DJxR4+p9BGXxCKo1exr/AIi4mzafOLCqdyY2TXf0PInlIPfntNS4waBowl8Z8R8li+wG1GahwxPHEa32Bu4osnUQNud/WVrNqSAQJvzq4uzXqYyZH/p9o6qLInlNg8/aKClhgeORDR8pYatuIBqO+47e9VFBIAoWQbI1e0XlQpIfkD7QgAL6H3AmlaLDmueN4ype1D0o13EZcmUWOQosmouhlIY7g/pG32FbL+oE4c0Gb0BEC0dveqlAneu/cdoKFiiwLHb0ib0EN6+3rt9YwIRid1BBB29IFCsO9cAdgDMpVmat75A+k3s6zVE0T9DATwVOnceYrDkUvk4tVq1mUZcTopBZXJ8tk8C4ykjUcV+Y7WeIqqCyl/3hO1RWskNRU/5hG04fDUEEtd2ICiuW3FcCx3BngaGKkFgd64uZWTGWJUEL2UHvMYB4o87bi4uZbDLuD7HYzgBMajSBxbR2IsY8LsBdTfEBuAVPfbtfE0aRQUFSvO47/lAMWMK7EBQ25Un9J4LaAfMQ2x9uJesalU/RhVgzIL0ttwbP3PoYisxYEgAqnAjN5gApuWxBc9r5Xmf9bZT2JYgV2mPNqsjZAboA7Rc7jEMh2exq70QsKMzJjO/F2K5g1MS2zEHaydhGxqWB0EEnc/aZKbfGKKnYc8R1bHr2ssdt/aUwA8gIoc1tLK+Vheox2INbA3AMeMuRajtpCDmUcDbDkbBjCcmLwywIoDarq4SFsGqUbAESmF6ufLViAKR825O1VEFAn/gT/8QALhEAAgICAgEDBAEDBAMAAAAAAQIAEQMhEjFBBCJREzJhcRAzQoEUUpGhBSOx/9oACAECAQE/AKPdSx8QWY3FHu7MZyeZCmx1EbIbDqdf9wn51c4VufSayTPpMx+BECoONTJiVxUbAFFXuZMY0qkwYSh20ANbMVaoQgVYr9QKfIoRVBhYLQhAPcsWB0YfdYlMGBNAVQnTdToxWuCMbJF7HiUTcKePNxAWJJFgQcT4jCmUeCYe+oAPPdwjxP2Z0LMBtrqVbTOxWgI3MVqovLl9tkwYG6tYcYTvZMKAjuCzQ7AEIJ6l0eg1x7rX/Ex2RLqOAVIPUocOIH+YFNAEm77jg+2jqXW/EsMtiE9DuH7SahFDXmY7LtrUFmb8CEX/AIhUwV8bjbEFCchHJPQjIDMB91EbqfUPj/iaaiAO9ice1aUa/ULcaMH366uOTd+JvyBvzPpjY3FNUh7jlxQU9xVH1BfdXLHQhuyKi6XY7mxAxJsiHj1fUS1MB1c7owNc/cJN/wAf4lCUbnt6E+nxQ12Zy/Ew2Tfi56hWoMP8xb3uV+Zx/cyfaQB3P7a42ai+BZ1CRy+6jV1B17oN7/E9pF/E2tnu4oPmMeqh20BAgqMdX4mytiKP4C/wASP4KzDj90MzfeeMwVxr8wiwRPlSIq1+ajKSeUr27O5e+6EChVnfjqAnyP8AMYkCLZWdqIDc4hhvuMCMlxloE35uI9God1Lg9QA5BEPqEUXE9Tdx8+V9otVMfqCzsz+F0JhzrkX4PxLMv6eOz2YTyUG4yAwLUbIEIBmSuQB6M+oqchPrMWbZr4iKGAjJQI8VBQG4wYsfipzBIWEiGxdGdLQi2KgPIX5EKcmuOLIEUEMPbUHmIAqcm7jhG3xFxsY+JwAECuNeIcV+SI78DSDxRM9A6vYBJrZnqD9omDeMXOIjgB0ojXYmZgcx/QhHLGvzQMfdxVAEA4LYik+aswj+Cg52PjqZDkCEkRW9oJnHRlm4rGjoAzmWba0R2Z3udHdkmdQI+RbFwA+YVYXxiq5SidxVIFE3CNzMF8izPSccGYAgjlMzW0KlQAI+TIjION2e/AmXLkXI1MTxWh2LMw8uPMYuAdiXvW73E9ZiAoWa6rzXkT7wCLF7E2DcAJfj8xHTlSkGE2ohBE6YSxV/BgpqF7i2GZSdTYNQG09p2CNyz2YPMDGyIi82ArsxAEriJlxq6kjuDz/BI1C24aJFjqZFfM29ATEVIQ3dVLBnqDxxlviBiykM2j4mPOr4chxuGUP5vx4ERk5hxoV4E+unNUU3c5boiZs7/WpRoeZ6fGEcsR3Aff2e+owAAEC2Ica7oeYhUsxse07hZBVG5u/3MZXjrW5kHMEfBEWdienQAXL3Ae/1OiZ3ow1UAGuR3HG4wY8jMWIHAlijUPNN+PmO5YU2xCFHQAmP0yN+AOx8xfTrhX2eWJNnyZjxKuTldk+ZmDHIDy9tRcVHldjzKvzqeNf8zLlbFjHk3Eb6iDxc9S5XEAGIPITEuV8NudFt1qzKYsycdBRURjVHuMgr2iUO/wASwAINzC1rUAlR+QYgfM3fU46nDdzj7hDow9VPWjIQOJJXyBMGNilsY2FRVCAcSDHwu7k8yOJhcAbi8mFkanVgeTMYBZvNahKQY1cgsxP4ljHZJ0ATEJy5FdwfdZCzHpB7fyB8QuAeI+7s/qYhZ+p56icnYm9dVANFZplqDuISGEDgVCaEy0HMsdmc1qAwGEe6zBdLcIDdygA/7jdD9wiFQRY7hwqwUFZ9Mz/T0XPLZNxFVQQOybM4J1UI4ACvMy48mTPkGwAoirjxtaAk6qI/MEcq91VAqdcdjzFBruAAMIXVroURKFXL2IppoFBo/wAZvULy3+prjFpxVTxswaFzHbEEieZ5h+1/3H+wQ9wNS/5nfRjPREsTzcS7N/OoWHIzkpzuwUgf/TERTRBA+BBhUOGHj+PqITQni4HfGzFx3FJoa7h10IPmIaUfw+NMh2sPFaEA8iBQe4VrrqY4OzPMP2vMn9OH7oBYYTGGsjwILJoytStxiaj/AGkgbqLwOLjRF9wABRWgBUQMLBN72ZddQCqMyEhhxNiZE5rzY78CB343cVydkRsguoNARjSkxMjMY6+YHHGfVq7gz31ENqDXcXzB90PWSZP6bfqHsRfuaIRy4kxgLhswNOxHKgW5oROKMqBDXdn4hyruhdTkCN+YALnIA0YEHBjPcxsxqAAG4A6n8eIOdn+MhAXfmX7hxHUL8iv/AGI2MDY6MIHLiR2J9IEgXW9QChF6i/cZ4yTJ/Tb9T/bB/UM4e8kR2HQO4rWTuCDqZAGUgwKtAHZrswhQAFWHkXFiuI1+bnQuD3USIMoDcDofMyAE2rgCpx3ttQZ1ACQ5EDE31FNqpmdkAAMTIhNAgCe2tMIcyUBcOZOXcw8MmZSD1ueIOhF7aeMkf7IOk/UP9QRmCiZMqCgO4HQdTnehGND9ie5UG7JhK6JEGUd9RiSOQF1FyFQOQgbJdV+zCjmKrw8qA6oTgbO4VcdmYc2L6eO2A9o1PXYzkKsj3Qqo2N07apb/AO6e49kzh+dz/wAdio5G/AEPX8L/AHfuDrJH+2L9mP8AQj/ek9SCcLV2JTg3Acl3BmyUdQZst7AqHLkbxFzvQDC5bE2Eo3Fdl0dm5jynyhgOVnC2AOz8ws19T3DuFqvqczehGYkmXvZMJVR7m8z/ANZ8whfzUsH+6oGavGvMT1T49LkG/EX110GUf4n+uweSRF9Vj8WfyIM+McgSbMPqsVbDCL6jEFUX1M3qMZ48TZhz5SK5anXbTf8AFCpQEUAHuBvM5JYJhzKFi5iDZO5xJ2DOPe5QF63KNwhhGUEeJqtRQ530IaBq5X6nA/icACSFF/MKr5AE4KR9sTGwdTeo2O8qmZVLH8QoVs8ZwsnZ/UGMgT6ZlNAKh5ES2vYP7l66Jgszjq7lCAGf/8QAKxEBAAICAgIABwACAQUAAAAAAQACESESMQNBEBMiMlFhcQSBoSAzQlKx/9oACAEDAQE/AM5Btn+Tnk3GxrUcZz2ynjrZq2sbZ5fBTJ8uw57/AFEtXGTIQ+WmXr8SyZ+mCkbLMwtBw5g0u4dTxnj+WF6mpaxW6F9fiHkW2M513L+UpUTC+5fyZOVAy9wraymJYYTECr+Vm+sxx2syM6yMrxNpkhx9w0219PHH+5SubfqY7SvuUKpZDonE7GWymIY9kzVepc3+viVgH5mP3Dy0tU5VdQryLOdziuOLjXZHf3SrWrhJnlutsJG9XVtyoEyRydaZUsn1W7mRzrUpYDdcs7wRGrhYAyt8uJmxsZzvZ7m97gwZyxmWe6y/2wBImJmZPzONXyYrmfKrL1aWgucnUb5Zaup4rVfG63H7nXc8dnYy6JiNXSEdIYJezgCVm42VMrLW3+pStQN9y1cVymmciuis09ETExfvExbO5tcBL11icScdzAsdTw2w1z1Cii+p/kWqGMbSePjl5GdalqGC1Z9R3PGHKLVvK8Sv7z0y1Rw4n5My25udZg7xETWYVO2e5le2ZFYZzLTlYN9QTtJky6lraj3mcl1iYczeYTwf9s5T/JHkP6nsYca7L6iljBARJfA5JT6rZbRsEVUPzMWrXemccxwM0Wi7nLf6YBx73EZTxrvGj4Yj4FpnlGjkMw8Nzb1K+KmMMv4gqFfbPL4mr+T8xMTxUb2xKhW6JK2i5lfHzLJ/qcW2YUu1MmiFlqca4T3ERM+zOIeMWFbtsZWJ9dcTh9GbPfRHPZ6imJy1K9w1qZA9Z/M5tRh5F0OpmY5XK1nkralR5OINrOcyvluM+aORZTy15A9RqW2uTOp56oigT/GPuZ59eVx+pzt+Y3t+Wf47XGPeYuL2/sPI1wEtxQxXEs2bu5V+mUxjOY2Mk5qVPQu5Vq0sPvUUDDATMzvUcj+oa6mDRiOOq4AnFnj8laPFxPPcacPbKJXFWeSxy+k1LJnOMStklPJbBll23kz+Cf49cePMbc1WXcJghu++juc+PJLiAe+yFi1v7ABz3LF/XTPbvcePCqdSmpmjvEE4v5lxMGOyW66lDNI0tmY1Oico1Bzn+xsBkYrbuVs6GWyT1GuycdTZueO9a5M7m/lYPdZhMiS6hN2NsfE041tDGc4ziVa56c+47BGHisDdxxCWa28NSnWdypGzylW3McS3mv7ZVSiPTOVjMMM4oxECOfcepd9fG2wivWIaeoo/bAcReKSvmvVyPfqFqeTT3K+Hxnol/F4cbpU/1PLwyYywvinG34wSls+O1cH9/MpWgbf7K3yXp66Jk8Zj3MjuXqiFTOWVrarh7IV9sQrbjrCe4hgc+8MElbflmcRysrLG/i32/wAgrOTK95zMxrmVJaq9TxWuVBswuuf5O4goPXqCugjyx33BKhLmjJ3uBHytK6DUtfPjs8drHrD0kcPuUM5WHXGJCqGWXEttlN99x2MKrnHr4axBxONnMDExmcdaIaPgdn8le/8AUO5f7iV41M8iWufiZ58TrEtnNcnrU5WhXWM+pTHArnawLuKqBnCxONjBkzGy5avcOpfxiKalLGHLFZoSGVsMygnw3ZwSwjKruVXIRtxh5MuJ6nqV+6kp93wuZlSuxgfBtZwfj4GyWcVx7lrM+c3pxlTctRrPn0DCyzVtmUuJiWED+/8AR46oy1bOZoyJDy4nMc57njNrH1PUr91JT7z4W6jhD8zGIfEtjvqXLFsadamMo/8AEWmVxjU516i8sbjs/eZUM7nTKK1wzyW0B8CeSwAjK3baZev1R8dh2S7X/eZQxWM9SvdP6Sn31/vweibFYTpxEwwg4l67XJnrUqZxlxmG1mKkxvGI1+k+CspdxjE8nIT4ZxuXxyZUxBy77lliZ9Q9R7j0Q7pKffX+z2z/AMY4zBw7luyWPgWw9S4qvQzjgdwDXvM3Gyv6njPE+StbuN9+pevj5W49Z1HDaU4yzXr4BHi9dy1Vla9y3jMmXuBhSe/g9E90leyP3W/sPtYV5MvgttlL0cRM5lazg43LcuOI1VCBWqDqNc2cdepjHTOOXOZxxrOQYmXMPHXa2Y097+DiNK6cscq4ziI+1msdygQ7+FvU90h3Lffb+w6tMZQziP8AjZ3zMQ8CJi84PXMjXABYjVt2zkh2LPqs+o179Tg51MFX9znbPROV9ZqdR8jXPUPLZddy97tmFvIbFmPLw9Y/1mZvnCZi2fUBfUy9BOT6wQsJ9tp9P/t/wwpzcFjOOo1+srkyeo+G1e8S1Fsutzx+NyjPkVnywMdE+WsfGOMJPldYxL0xnE+Xcx0/mNHQpMHtjxqS3y3oc47nGzsnGznLOH5JWpqPiuWdV/sab5KbleJnAR8l86P9EL+Q0huCucBLNq24vizrs6gnfCWsZriv/EPHRNCTx+C1PIWMe8y/iz5a2nkq2z+I+FN8ev33HxWtd+lT+9QomMljB2srTl2Pr9E8p5OKfLyf2Hz67fGJ+MTkhXln6n0TnY+6ifvM01yC/lnWw9xrYc8g/wDsSzZeSv8AI08mPtn/2Q==", Y1 = "data:image/jpeg;base64,/9j/2wBDAAYGBgYHBgcICAcKCwoLCg8ODAwODxYQERAREBYiFRkVFRkVIh4kHhweJB42KiYmKjY+NDI0PkxERExfWl98fKf/2wBDAQYGBgYHBgcICAcKCwoLCg8ODAwODxYQERAREBYiFRkVFRkVIh4kHhweJB42KiYmKjY+NDI0PkxERExfWl98fKf/wgARCAFAAeADASIAAhEBAxEB/8QAHAAAAQUBAQEAAAAAAAAAAAAABQECAwQGBwAI/8QAGgEAAwEBAQEAAAAAAAAAAAAAAQIDAAQFBv/aAAwDAQACEAMQAAAA1k2uoZAtohXwW6MhBmeGlXaZouzhYgsXyARiw44gfz82cyPf5bRlB5BWykb4r8CZDW5RK5jV5bUQvrS4gv0StSxyYu8vmzfL7ZqPbsiK3Dj+V1eU47uciqzWPQaEcSH7ApoZgZXtcMr2SbSIviE8rtmPR7Dz0eU3cjfShYsPv1vCbpJaFQJqcZm0V3IEEnpZM6doXJ665ouM3yc1OdH4x3h8ez6EPOTLpmbjmV81ps7pIX1RcQWvO5JFK2cqLsiej2ekKbPSlJtzDKdCFcfTk0O1VYV58ZWIeQHABJoZlpM5rsFe12Enl8Qrmv2a5JCEkbIV6DFWBJPoZbmpGx21fH6ysbHP+hc4zXiuLOcsyJoQefUCY4xYykaTi5WcZfFWkxhLPlgRsJbiDWCY6dM9oQJ2dtSWCF7TvzVntp1o0ATGdzuQ5bmciC2EOinpx0u1OnNnpPobPznqKT6yOxZ4gsNJDnmCsV7AMyo7Zzmv2f5VI85F29KyUqkiSFdzVzpTo576B7eW3tOe7ggjgttkxUJV0vuVSegzmuuQJWvbcSeikzXCI8ktor9K5mywQ8FvxOGFBykAaFGY9GhKjStZ2IJs+Ht42/lODurlcnsee7LOUsgwZh4yT+Amuf2lSokB3fxatoOrN+yEea9KAAzw2DpXsfg57H4Se8uyORSHSxyYPkjlZS4zcU0TA3CclIZXqfPN/ZDGfLD2sLL5C3xjourxWn6KQ1JIqKtqpeBsX6d0VZbq2Mc8FOhbcjaBGioBlxRaPRoyY4nRHZTQ874e6kLn95XpEdHe96fJwGfQcv8AN9Db3aucpGTnXSBXVy50kInrKpndaJrP3RuV7FdrpYLAL5I5SFc12EitXBXNfgsschDpopXWscyermwk7GWLZ3dZrVvJ1IuO6ZY40X9zkuUFl6PWhWk6XGNYyGDOe0C29Yr2UoDB6AHfkjpXagUEVGk430hEcQcVc7pIubp5R0muX5+sMLvZbGcJtBivxmA6Che2CoE2iLn6ZgqSypCSCksh0HF7aszBUMUm8r43ukjmu2f5PEPcx+V0sMp0ksM7rNpBuijXO2WRtgfQ+U9O6eQ+KMB2JOC+PRzBfJnZ3dnygavPddDedH6YEcWrbNedWGgz4G/JXr2IwoIjRvyvob9Ag4HUtAyFs2Ls2Y9lHknbA3Pbl+h6mnTDmeF6tzXh7Mw0mAWhQFk5ergPjZQBBY9htY6HDeZLzJmRj6zeqewk95u0jo3EPnr2Crp4ZnGnLBriGnVZaK5Pe5bXdHNpRBYczwUp7Unr6egcziINRO88wVKykC71jwelaSXNWz2jz1eas1yhc/fH3430V8eQosNawPlXQgq43m9DE2Hyc3V1HOLnunkAYm2G4fSqh203jQ1e/wAi3PzynZrXDdBjzlObZWMzqUxh0cjKr2uwexzTlcikST17GD569hl1ftiQaGE0uhvtskXKyO1fJ7rHuCROiVSnp2TMrXK0r71EWV0VcJGrG2B1OsU7qtIT68MBC2askq6YoHMUWOvaGypm6Om5X5f0WkzBHE9B0uy5V2GcOWBdNmoXyme0edry7XN5qxTmkBEjHRC/PMBhTRHcscynHxSUR7mO2e3yHOVq4Sz1rGR9itYcfRU9Gl0zNy4Ok46PFzlW3Q8vVqZCkKnFAKctWKQz10xuXA/gxKvV9mkSN4yp5myVnUFwb2ag5a9SOYnS9Ez+fK+zZR20Hc3blMX1QSvZiNKCwfOl3MXRaVD0DY2saTQXq851+ULZbaRuVtN4MdKm7cEzK9WP2VPNwerFJmsVbBnJPWnZerFa1HvhpLORmDaWkG8ovRwuGnbFNsrkfsnlTaRa8WN7w2quLxB5Va5VvmMuRdv7Z3OyO2aRnrjs8Rp7oeUkSAhqzsUz0XQodPzvR7Zzfh68nCXgYD89q8BRM1HoSN+XNKVjIo6DOacHS3hpaZnfC8pK6N+LmLHs9zFIlsVZ2WWxVssOmOd7oirvO2fJC/ax6u3a48VECZjz7VJmrXLqQztqXYYQ1r5nUISuROEeLGY6WjmYwCIB9Hak1Dcm3QYngLLcxugwsql+ict2auTym55vz9AcAfr8vRl8n0mg25PtDW7vDmA7oYy/Nhy1nR5c5N6SVUfE9TK+NxDm+QB6s9tNNXmdZbNSyV6mg2C8jDAMaOeiGkhqzNSbOwJToF51xxjQPotC3PTbWlymZRujhsDIr6OjRlGtSVZMlpoIAw0+bEyrqPYea9d28PdHZeZ1bmKlQZ1fj3RJ16Jzen1pjy3Qcp6H5/okKxSywFk6dHu4BuK32eeE9iHOAiyQslz2ifG+dJXwvyPRqbPWNxE01eXJNapWm2iI9EMWngtBqrFEDkbj3EMr6B19cRlEfqmb5iyVNUHHWZvPJDINYno032ghz8zLaoTNZIXOjKqxYE2q24MrZaFOcOQC55sQ0qC7xUKrydCrcgde94bXZZalZ8bSlbzJRTx6tgtJibQnxOllnQLajgk9pVjnWV8Lsr0Z7CRY/bWJq8hSxZo22H1M+Gh285dcHk1brma5RFKmvAUHSpN6PyNLLWTNdt56M41VrXtob/pmV3mwujoYqzTsNqN2vTj0UdTuYTRXUxnS4ErUzBvmCP0oIcIAmuEd25psE1/J+iqxbD6tASPHescj26Tm4du6LmZaCuIUsHm8r6l2borF2d5qZXqxdp5K8uE9qlZZd+AoSHSPZIhc5k2Z8larsUrDnZpGyzhorvrJy2WSMrvRxlX1WUirq1WgyknhrOBhaj8LVsXKjaecfplthchucFOml0nHe3dfLnHD6KmIBvcptvhYXSOmQw+g58Dsum8v7S6URhrJK2YsxOjWpdi8lHLGmWRI02mWJ21iSvJlsWKdhlMvgiQkUDoWu+isB47Lpto5/SYrOyU58sb9nujaVfA2psgl4hkkHx03nfvZcmDoLGaBEUzlG469T23Hev8AJ24jAbvnXN2CDoGTs4tXeO4sz3Q5bjDl/RM9mcOkDAQpKieqZLp6PWxe4wikNaCQOh/0SlXrF7K/zPDPfD460+s8rbsUbOWSRZ8/rKThnTJKpdI1+yyIrB8kb8z1ahz42wYOGKEwjBKKrG8FZUOJE6BrCzDRgxpLFTbdN6/wXrXB3S8y2uL5uvKANFzf0fO7xY5ls6SvSiKCNusDQEtimZ96kvoLRwHvP7xeB6fzNK8pzJPPeh52oNjukWhn366vJ8v6+NlWRY/K0z4XkWLNGwZGZ47K0dOyUaSSOXF72+xlWOTByt8WexsWyVJKOEGdI5p50h7KForYHX8xPS0auBOroagbIhdxz3Nsuq8J7Bw9swAmI5O8Ry/qfL/R80yaFm+zgo1rw3Z8U15XzPQBPcVbV35KPJ2BuTbPl/L24OcVufa8LZ7EPoWSEQWzyEQBtZsY+uY0fP0zvrvVrE9Od5aieCeTTyRSDSzQyFpHMXFzo24zei8c6JIRoxlsUVHZkvmrRHU31LTtEhZJH1ZjM7YYFpYY2Stg+uYRbc47FxffSrtBhOt53qhOV9X5V28FvQANH28JZjIBn1LfiE+ouJ93hdMqZ51wehlsIawtpw9gyXVPU8izdqYpG1+d0/NyJsT03lIMWnz12dNI+F8Kzy1pHT//xAAiEAACAwACAgMBAQEAAAAAAAABAgADBAUREBITFDAgFQb/2gAIAQEAAQIBC9jQNY0jVpsoHxir4egtbKUstfrqiXTZ4MEolcWD8uZ/oy3wP1+u2Y5Tm+uanKQQaFvF0CCIw80zRNcSHxRK4sH5c1/RlvgfwPxS94ssspuF/JVZXDqBT8Hx+s9vkFw0JrsOy2gmdUSuLB+Ht3zQEI8mW+B+tFLRa/hRHmuVwwKkJGgXqwzvlOb631rF5l+NuPimVxYP69u1b22o9L1Gj1hlngfra9ThhZ8jm6Fq4sU+wCjtblsPiicg2yYaTDKZXFI8dxjfvu5r/fy8n9m+NvTk12XMGMs8D9bwio3y538XRNHzUVmoBIYJWe5ROUmiYgYZVK4sE7JbVo06q884nB/m2Ml7rVdn2JqruMs8D9BDHoVWGcwR1ala8jMQqQkSrzROWls46NCKpXFgnd9/yVkFa792h30e9W/TWHv0ZdOK6zwP143Tr3fZN9NqMhaLGTKnoyLDBKoYZROWjzi40MqlcXxa7Tc/GW2avu6LdJz16Rbl0T2Yh8elzB+gj43xsgShqXztplLd5FUWgeFFYMMpnLRpxUaNKpXBCdF+nRSeGo149gGm+zDN+trs9xxacqMtmS0n9BGaWD1RaZkmqfLXdmsW2xl8KVPiicvDOKjxpVK4stOu2+V00La+7NVMeK9ufGrB6XkanqqfOwH6CNyGbQGVFopGWaRXlz560EaAk+9beKZy0acVLI8qlcEvr0tmpz5rUstFGvjNNf2d+vRBjTB8FQnHymD9BGoz1OK53VM0vlNbGo9OAY0z+aZy0M4qWR5XK4IwaAK11wuWi9dazVLn4zNbM5LTjpaP0E9K1silrM5zi6VLYKRH8mZz4qnK+OKlsslcrgBoF2vRi5PkVe/K6S+g0W0ZqtXI1PljcnbZhOgQH8B4E9K5aqC4ZDml0pmhqLvZmaIQtSCGVTlIJxculkrlfnrkOIxcXq1JkGd69B1W1l1a1XBZa0yF7PYD+xB4Et8XlW0DCc0ui3X252D2EVpWqBY0onJwTjZfLZXE8exbvZpst47ky2iy6/QTZoZcK41ZokrlV66R+Ag8CaGWXGsbKcaULoC5/pV4UoFPxCv19YZVORlc4+aJfK5X4dO91+ehuDryUX63vseXRCmTldapeoKDJVXUPwEHgS9Kq0x04mxVZlq1DMgQL1/RIt17q3xpol0rlcE7KcsL+Wu0Wbat+hLktF0W5NViadPvwub1R6x+Ag8CfVXMKgpVPGwY510F6932nlft/F9IZBDcXsl8rNRWMjM6bsnHNt4DBwsul5sARYrpQ/G8Zf7B1Ab+xB4EC9dAEANbslO9ucHI9Dj/APPWr7R1Gyd9+Gmmyp6mQg7jltOZtVllNTXaGtlk9M+PRj41tVtL1qqYpUf7HkRtTck/Onm/tjHVxV3C58P2DsOgnr278dTvss78poo1UXI6s9K1Vu2S3Ns0nY7sStk+y+3qpXNlYmfMB/Yg8CV8AnBLk+0eROwv69e3v316+eyxc2G72+r/AJK8WuIZ1pZrNl2x+Q1bb29G8da3c+i22Xs2bPYa4PwEHgRthYQQt799eo/jv3Nnym/5BUmFMS5xX6mWarOSwtaXW5uMK06MF+F6PUi171qx3ZlhTMqoPxHgQT3769BO/PfsXNrXfOFTFXx6ZRV69Evps2WWsUTq19IxHA+Fr5ojpbWy34vgxrqobj7Kvrp+Q8CD+Op37e/yG46Pdc9fHJhTOE66Z22NrLxo0acYGPI13b77MZXRtpNzKKWptoOarFtr5Y4MrUAuPwHgQTv29vf5Dd8/utSYEwJkWoJ6x7n5F9pfvzbfbud+Npdr5emZc9zjiNvNVpbWnxGmqhD1/wBIyVmLZZ+I8CCG35jo+RaUwV8emFc4r9eo+i3lbd/uDO57Wb7NXp656VnzWjm047TuHD2cbo35Knz6AVTVZ9nhK3pE5bYoJ/AeBBAiYquPrwJlFITrqWabeXt5I2eOwQToOtp6eDOLRJpgu1668u6rhG5ynid/I8evDV0Ppv08q9K/ILqa1Ht+A8CCV41oCBfNmm7mLeUa7sQQQQudXYXqdk9tMtU0gW6hknIV8WOVz4tFOy3edtj4qzdntw2WLVnttaN+A8CCdeO31XczdyrXTudgxtJuCKs7JLe3sDTBA907tw605VOLS8cpl43aM1wESqg33cTUvGa9VaOafyEELPru5i7lWu8d+Wf54EVR47JLFvb28ZNwYXaLNejQtT8XkvfTHTDp0046OYuScrdwzbL3XUAEh/sTsQS3lWv8gdeGuNgVVCgeSSxYv7hu+5XdVytt9yWT/n9Flzlm1VU2Vuqarffk4ajmW9yAYfHf8DwIIP6NhugXroADx2SxZmc2e6t7AmwNiVhqS5cl4N3IfOZanEaddeiu626ZL75ss6U+e534HgQQeS/zewXoADoAeO4SSzPYzMykMtjWG6vVw+iya2d9g4flbEramX1YbdO2i65xfxtlxvtF3f4A9iCexu+WAAAdeB/PZLM7u5d3+as2ZrWrn0eCpYbEtGo8TVvzhszoeSxU7fv6+S4rDXVYNYa5OQ78d/0ID2AAABOvxY2PZa7+9liBb/YWXVVaeHIs0NpGuZUr0OgpGhdd2F1ufCiR69y73NtGlHSHx3/AIgAA8D+evPcLPZY9jlrrBKGss9XhvecE4sue9tQRsnMV82/Ityz8gz2TPMlSJaORPIsJhz0U/C1dtf8AI8iDwPx7Yku1r2P7OUjV5bis01izhbPex7DcFlJ6fKcn1zS2X/m8NaTS+2zacdWXKikObX+T+BBAIIIIP7JhLNY1ru3t3XEVkQzTQ84y1bHjmyLKAFtX5BqXSZwuUS19l1z2NgqpZYzWtc7tXf8AwCPA/Iwxo5ta1nPcrmYuixTZVyVNb0O0aWwKkq1fa+0bCmbJSjHTbsv2W0DBiV/Ute2usl5mbvwCIIPyM7YubWsZz2JXKXrjVJmch7Uw3Autk9Ueqwt7fa+9wRUXPtvufTZxlVNN+o63VLmDxhit8if/xABEEAACAQIDBAYGCAMIAgMBAAABAgADERIhMQQiQVEQEzJhcYEgIzBCcpEFJDNSobHB0RRAgiVDU2JzkuHwBmM0g/Gy/9oACAEBAAM/AanCVRwMqLxMfjnB9wflF5t87zHi3rljnfum5/zNO0PK/wCUHNfyj8jpCL8J2p3S1mgOcuuXTuz+0v8A6/1n1Kv8LT6qPCdqetb231sfD6eUz9tsBW5Fps3uViPONlaveVuSGVP8H5GW91x+MA0N4zDIyqtsjKnEwfdEHf8AO/5yi3L5ftKXD8/3gtxiA9qDgendn9pJ/pn859U2j4Wl9jX4RO1PWn231tfh9PKZ+2arqfC0J8uENznGVgAW1lY4SW4w4Lmxg61mA1ohpTUNjTFNjyzIlJuzXMvoyHyjj3B5GN9xvznj8oeYlQc4eXR3zDwgfaVq8haU12WvdvdMvsSfCJ2p60+0EHOX2pfh0iaS2UHoZTP23VVMXup85iqk4TZs5wtMr2huPGWpvLrTPPZYLTEbc/0hHHhL2hCrZjeP94x+6KxzQSgT2JR4XE5PH7pV+7GXIggyoNlqZnSM2xUwfuiZmetMz9kJlMV4rbQAyKcuIlFb+ovlna8o5WBXuOpEyOEX/Oa9OUz9sM89dZTN84oVDfWLhi3gwVJip7KedFxMNP8AqgbDxgtLMJlrM+XQQYwhc9GcyMK7Xs/I3gNDaMhoZh2Oif8AIJmZ632FsybSlTHE+dpW3yi4bflzm21cXVPprNvrMwx2bgf+Jt3VsjsVa+bAG1u4zaQi1GrFlxa9xlegbdtT2SPnebMw3xa+Vxz75TBAvfXOBiWXP9QYD3ePRlM/bWA3c4alZsdS1v0lcgDgDke6VgDbgeMqmo2KXWpL0Ni/rEIot8SwLlbOEoLcZizMAtAGPoWM7ujWfWdmPeZelXHcZ/Z9H4BMzPW+k/A28oqZObHhbjKznKwXvjorm+JrE3M+rNWqggVNFB4f8yk6F8FiyWZeFuBE2WlXNQVGUn3CQdOUUAjGe4n8otOmynNL3MLUxeppRr2I45i0qKzGne+HO/fFIpL/ALr84VatSq8NGm6OsYW4N0ZTP23XNht/0QpUN75RerO9vA6QlTlPWm5v3ztT6vsndVYS61B3zPyhUrccSILWImU3vQz6dZ67Zvim7W8Jf6PpfAJvGesmfob7dw/Of3aWL8pfZ8brhJNqin3TzEKrWUtdT2e4yqQmOm2mo05QqgBpKV0Nx+kpU0tw+QhOC1t7PLWMA+fWcw3a8jGanVt/hll8OUJpXLXKMv8A38JgqV1Q7qHLvENx5fjFcrU4OmFvFYc6NUEgaHlCR1bG9tDzEymftsO0AVQbuBhPK8x7R1YbCA3HiRLNYtbuMBV8xB1hG7oZ/wDyJfZaR5bRML1fH9YG5QYgbcYcWnRZpkJn0Z9Pam/s/wAc+18J/Z9L4ZvGesmfoVetBTJTa8wvTNziR284TXq4TutYEePGEV2uuIEW84KWWHLl+kPW7rtg110tHOzXUjFibXujL1BzJIsOHnKlXrbkXUXt+MrUaJWjRLO4GQzOedptVJ2xUKgVtQRa15U6vGNcGAmLiKpysDFTEGAOf/7Gcm584VqJzvAy3E3j7bF5DKXuTfEPxnu4TpxP5QYKt94YdJaumZJIPGNu/AJfYqn+WuJZ9p85ZtZYDxggtBnMpn0Z9GczM+w+MTN/CfUV85vmesmfTaZoRo2kzfOwGhi1sdVmsvH5Xg6l6pX7RyR4GLUpEceB741O1QaNr3GD+GphmO62RiMNmYHQEeOcCYqjdgnLmctBPpCl19YE0gXCqB4X18JtLuu+7Oe+94u8K29fLPjNn2kAbMcDDWmw/XOVqVQCtTslrYr/ALQpfTLmLxmC55cOE3cJvzEu/L2ygRWDWFpjP6y4Y80hSog+9rCVp/BPqu2jlUUw9btHnHUYhbIiMxAved3lMpeZTPoz6c2m7R+MTeb4Z9T8z+c3zN+Z9Oq914cK4uHd/wBvNlrqcbsvcBnFrIyLTYUtTf3oKaATKGrslULr1jEDwMZN2pl45Xhq51KoRQO79JVDu1Fr00NsRm1VTsygaUgbD7z5w7Js9OktutIvWa9sz7vlKYUrUcuLl90W7tTNnWns9Tqsyme9nrbWV1K2q46TkgY87dxgan1yru6EcjFXIhtdI6DFqgOvETLFL+1MLYgeQlTERHP+0w9YpxTdp+Bnq/pEeBl69TvX9JjvlkIFOkAlvQIMOO3TvGeqp/GJvH4Z9WPxN+c3zN+Z9OMCxKsNDKy00L4LBxpHq7ZUrG4DuRbuEFNLR17FiORjhcqZxcJUZRdQIlRb4VvztHosouwsBa3PwltkWhkLtja/dpL7bTsd0BGPeFUZeEeu6s739WrOfyHmZ1uy7RtLsfV1FD/sIm0oaj7VRXCmVO5FhMFVKRYEEXuul9Zh2H6QByPqyR3k6S9ucDKykZYZgZtmJ7AuD3GXY+1XrzYZGBQ3hAKxI0JgH4xcQPC83U8TBi+kF50p68fCv5QYJh4Qwwzv6O+b/TvGeoX4hN7+mepqf6jfnPWGb4mfR+EY7yMc/MQuhV8Hf4SihFhYDIQFZhMarVIByllzacjHGuYgKkmmL8O6XqAg+7/xFq9SqWv1aC2mkU/RlWhVtiL3c3+7pKK/xdEXwLhYHu4/OK9fZrKBqrKO7O8J2LeU4q1TF/SkI0OV+OsOJjY6AwCrSqd+E+ftgaqkcpwtwM05zsgzePjPVi3359Y2kc6LTfpH/IsyljBlBBbzmZ8ZY2ms3xMujfn1fzE0+GblYf8AtaesM3x03lRLmkx+HhKik9YpvwlCioNUgXmw16/VUqwLHhCAcIzm3U1c0kJe9gLT/wAidP8A49+9yV/WfS4b1mzDD8QhcfZETq3IOkSrkR8ps4rIKtUkaaEH8IMVelszWTDa2pylwgdhdbiw4qeffLbU9RmViFNkHfl5CbQK7FGAByA4WELjFhGfeP0isxuSMtIFUMotvLfxvOMuL8/aEVFJi3z0hIFuc08oQ78sZ+cvS194T66w50nn2Hw/rBaAS8NobDxmpmkvLEdGc359WM7PhP8A5H+q09YZvD0LRWHO82PanR6/WEDRQTNh2RutpbMqcucpIbMdYlV8dvAiVP8AEMVBmSYc7Q4piqpwzE9aCb2D/kYMVTc7WgldRSC2Fzl/0y/XOmjIcu/iIjL4ThCBc0y2Vt05xXGFnbD3obypWyQELxY/pLDL2h65QIirYZnieEsD3QkDxE9fUvxOUPU/7Z9ep+Y/CZUvP85a45QQTKXtlGtDyhhEa0qWFo2POfVXnY8Jv7T/AKpnrDN4dOUuLcY6glV8r2gSmL8s51aaTZus6yo4L8EJltoNIjI/hBhvMjBnAz8POJSRUAuSMTeeg+UNXMAlsh3So12YZLqIR9HrVZOyrHyvu/nFBsoyGvfAtOryOXfKYZBiyGbGVEtUXMEbyjUeEpPvZaa/vEdwoyvx5mZe0tVW2t5qAYTzj8hkuUvtBbXQmWonwEI27Zz36zJfjeMXZhxmIDKWMtByg9Lfn1Wp4TJPCeu2sf8As/SesMOIegG53hWsgxubkTAphr7LjqEktnNnVmfDckxKOYUCApgvppCLzeMyz4zexc4ajpSHvHSUHC0MrAZ/qZfZmRDuu4HkBG6tSO07ZeAlhu+6czGaOlgSbwuXNSmMOnI3lCm25TF7ZGWHtMzlchtI7aQsTlrBpEJvaADSWeme+dr/AFmgNFDBB7DvlNWuWE2dqbIGvEsmukddo2litlZgR8pvzP0MSQ2AB743Vt4Rdj2bZxhvdQJ9LOdygOzcA5TbVwddRChnwg4uMw7R1ZIWoNVvOsRXGhE3jaWHQadUFRmJtL7M9CkQajfaG+g5CONmUscxV4+EwbtPgAAeUPVWvxiPWrVKnZpC48TGWq596+nLug67gA487iAXtwHtQTpAukt6Gkzq/wCr+kPUL5ww9AGplIe9Nlp6vKB7Cs3gCZtb9jZX88p9IPrgX8Y5+02k+U2JdSW8TNmTs0hOSiMeM7/R8v8AvGVFRjiGutv3mPZRxynX7I+OoR1T5W43n/kO17P1prIFNwhwZnPWfSFWpv12ZWu5xNYXlGhWFeu2Jxmi8u8wHZBbhN+8EyJ7oetNrX8bSujG2L+k/rDUo1VZr5qflH2iyotyeUXZwy7RXQNbsDMjxtE2QVicyBiz/CWY1L3DfhKd0uyqM7EzAq2zHOAj+RtKSjNxN+v8Sn8Js+zUAKjKDc6sBKPuLi+FWb8hNuqfZ7JUPyX959M1Pcpp4sT+025s6m2AfAv7zZB9rXd/FzPo2l2KC38IB2aUq9wlQ6sZzgndG6BAPRYXA0Iuf+IesakezbQ6gxMNXHTxKWFxKVCktOlRyUWVdAJWdrt8hoI7XZogoYYMRl7ww2Oh8Ym0VMBNj4R9iFUMqW4MM/zlEOmILxJJOAC02c1WXZ0BX7wvc/OZFD8+c9abg2lJw9wCLAW5eEBWonAOQvhLp4X9psydqsnzmyBGYNiA1tKI0T8ZWbJE+QvPpSr2aT/O0+mqmvVp4737TbVzfbLnwFvwE62oXr/SO0Z6gNgE+i9nGW+ebEuZQXsUv0lTgoH4yuff+UY6sT0LzndG7p3wekqBfGLlnAeldoXCR58olFbk4mtmx1MDtVQrbyixLxKQspjue6Xl+iwlek5IqshGlpV2jdrVCQcsRjU2wsMpTLX6yw43v+k2Y2WmWPecrmPSCP3i2d9ZtOeEKoJ7UemgTGO8jWAAKNPaP79f5CbGnaZj4mfRNH3U/ObCnYp/JYfdpfMzaG94DwEqNrUY+cHLoQakTkpMc8AIfvReXoDpEEqNosqvrKbdoXmzj3BKS8IogvEpLynW3CVAovbvhpOuBnY34nKK6JVW+EwW3WvGdrn5Q9NhFUZiNzIjWPHONTyubfOM/bubacIMIGEC8pNhd2LWPZ4RSuAceE3F8B7XaW9+3hGbtMTB0KNSIOCk+Uf7oHiYx975CLxz8YBoPQHoDnHbsqZXeMdYo4RRwg6ANZRTjD7iyo1I1H945RHBBObZd8qJWwDM5Yb/AJzrUfCOw8b+E2ihoVJM2evs4Jood0HSbPbcQCFWO83zlujIy9d76LlFYDDrx8YepxHifnGBDLnf3TKIGmJuUdzoYN1CM+d7XjdnAVv2idfAe2HC5j8F+Zj/AH7eAg4knxMUaD0BB098tqZfs3MrvoLSo2pMAijhAOlRqZTXvj8I7at0F3VBqTaKiqo0AtEolnOZ/ITEcOLf13Z1dTa9mI1GKYdtccGlsdM+6SJ1dYodHzXx4jov04nY3GcrDdtbPUSoaJy0Nh3Q0zRtnbMwJXcFRh4HuiA2WAUxlf8AOMzLnwt/JDpEHQJUbRfnKr6k+UHERBwiDhAOlF1aUxpnHbTKE6n0VZ3qDMJl5mAmwjJXG0DlZhzEwUHZRixC4/aM9JNsTtId8DlFev1vu4IFrUK3u1lsfHhDtGznB9ou8niItZAy+Y5HlLG8xvplMTGXtMoKez06Ns/e89YOuXkxKfL/AJnULT5lRMYxsctTCzAAbzaDkP2io9hqOPOWb2o6R6FVtFMrN/xGOo+cEQcIOUHTSTVhEHYF5WfjaE6+jSp9poT2F+cqP2mnUbHSW28d4+cOo1i1EtaNsr5/ZFtfun9otKs1HVKoK58+ErIamzg+9aK30cUBzRYNq2VT7wybxjbBt/XJ9lWzPxcYtUC0GGAXMB4RQ3WEZJn5wkM+p7K+MG0bd1Y7KLafXKFMcoux7HapwW7ePKPs+ymtU+1qa93dMRJ4TJD3e2EHOVG0Uys3G0Y63Pj0KIo4ejRp9pxEHYErv70J4+iF1MpL2d4zaKnHCO6cejrq6JwJz8Jdr/KL1hUjSboy04iVKtEdWRiQ3tz8YtVqK++lZRY62vMG2Mw4/pMZqJ95DDsX0lUpHssZT+kNialcXIujcjK2y1mo1VwspsRAwyMvNAIFK0kOmp5mBNlqVPdQFV7zxMPUvXOrtl5T+I/8ixNpRpYvPhP4vayzEdTRb/c0NaqKSnIaywnq6ftaz90La3M7rRYg4QD0aNPV4g7Alap70ZuPpUl43PdHbsC0Z+0SYIOnfqVOQsPOb4vAtW7HIx0W6nKPcirs2vEGf2nstalleqoccxMfW81YmW2gRqVday5ZwVKaKT2tO4zZNsA60WcdmoNZtlI3p1qbjxwn8ZtCj1jU1/qB/KJTUimSSdW/aFnwpx1MKUdm2RO0bfOLSp0aC6U1z8YVrfSdRBeo7JSTxtE2VXfWns90T/2VjqfKE3qvx4y+c9VT+P2qjhFHCD0aVPVhFXsiV34x21PpIuptPuL5mVH7TeUAgHpdVs689W84uZPKY0AYZrKz0BgJ+E5SrUFqlDCecZdr2fl1gmCvf7whXazBW2c3EahVam1wQZ1lDFiGWoOk2ck6+IMT3UJlZrdZZRqQJ120hrbogq/TDVD2aV4f4d6zcYXr1M8/WPi+77uL9pTe1SoMNFMqNPiY+0etq7tJRkIC5IFhwEts4v8A4l5ezc/b98opqwlNezKz8ZUbVvStrEXIbxlV+NvZKa9PEcrxr7pgO4cic4QtzEN76cJUJJG0/P8A5h2erTY1FNiDl3S9NXHOBqzNAUItwmF+sUaQdl+OREoFuwO6bPs6E5Xj16lr6wbNsrt3T7V+LGdX9Gr8MqNszoubPm5/SUaS9btNS9uEbaSVTdpLC7E8BL0qnIFYSlj5e0UamUU4ymvZlV9MpUfU+jn0KozM+6I7an0R6eUwlUrHd4Ny8ZiYuGup08Iyg/8A6JRPu2uc7Sjhwo+HLjnBURh1h0n8X9EoR2jTHzGUNKndhnAlMlmHzgqrcCdRUuNIKiAEwOutuZgGGy+ZgXZ8F5ZZb6PpAcQBD/BhmGAcI21VurQsRw/eYymzbPc27R74mzIKQOfHxn1cjjeHFceUGo4+zqvpKj6n0wIvCO38jVpG6Nb8oesKts7adpP2lKoNVB/zXSOc+vXT3SIBe7j5xW2evs/3Kh+TZyum7iNuELDeF856tRhteZ+OkNGpBXpCOHYl7Cdc7eFhAG84a1PZ6YPFfxNhKxoU9mo6ADE5lDZqJB1bVr5zCrCjSWnTUZniYaj3POXxDuyhx/ySCG+UJ6c/bonaYDxitowMBLQWlLP1a/KKL2AEOybere7UGE/pKbJ1uLdteKWPVrlzjFg1pjpLYQLdiNJjunfPBddZtdP1mDFT+8m9PWOb8YBsuy4vtKtQVLckQWHzvEqbOhz0mz4gSrEzGuBKBtHGVrTCw/GAe3AmekJ9tnbo7+gDU2iNowPnFp02dtAI1asalQ+XISgLXqiK5q74Okymsznq2I1AvDVU7LXyxjI98ak1oMGojFV8ZipkkeMbY9uwNp+YhdzYCwFh5zDSAscuUQkuQt+dheHaNqara66DygUG7C3fNksbvT+c2MXszse69vxjM4sLD2wEAjGE/wAhn0AZmFjkJfUShU92zcxkZtezjC3rqXIz6Prj7BfCfRzjdojyJ/KU6G11AlrMnfwMJGUq57sIvrPUv8Mo1nTPMSyq2sKHul1uILYTaYlWog3gbj9pZ2z+cpDM1FHnKD0XC1ATbhAaVMkcIqjSC3QlEY20lFzmCvj7Un+Tz6C5je61o6t65f6hCRdd5ZiuAbH7piFrr6up+BhD4Kws3OfW2z0T9ZlrLiWaepqeEOINTezTa3RetW9uIiVRlNspZ0878JtafabMfESk1NlOtveyjVnD1KVm4lCLN84lO4WgL/FF0xA/5V0lqS25RjcdFoFpr8UDe5Npw4VCec277lM+cqntUiD84R/M8PQyC85eLisY1PJ6YZeY1jD1lB7jiOPygqpcbrcpf1dUG/Oe4+nutHWvWRjogt8+jWCeqf4THXMTaqGXaHfnNhqi1WmVPMGbMrHDVJEPuIx8TNtfii+V/wA5tLdraD+EQfaVS0FavTpInaaAIIIsHOb6DoZszpBwgHCCLa+n85esvhN6EZidavVNYMOyTLVDu4XExNZxZufAwiwb+k8Z/dvCu01VP3P16B0bjdCjWUGGf5SllZViCMNGMq/flXW4MZq9Wsy9kYR4maS0A4y7zFtB7hMbZKCeZ0EXIvvnv0+Ua0t0ECC+Zt/Ma9PrR4zOYlhRgRE2pAGNqg7LfvCCaVdZiQqpy/EGEkq2TiW2tfAiZdBm6ZnM5U5SoPdOnCVV5wjUSi3GKdGnU7HTyzbePn0Wlgc5cmY6rnmZ1Sh6pC30B1+UdrWQ25tl+ENrmeEteXgORhpOEc3Q6H+X16d9OjhARedW185TroEqD4W4iVqOTi6/fliKy+cwV6dT/NMS6w9G6YDKy9kmbQOAMqWHq7TFqgM2c60RNjb+5PzmzVdopU0DjE4GsAWWEyMJJEw0/GOagFMb3OCmMdQ7x1PGcES/eYRnUeBuwJna8wUbwETgdOEJorfUZe3v7LeTosRC66y+UcNctlHFFwvLK+kp7QpTBn7yQozLyl0U90BHRlMzbnGXURTwmXnKa6zZx/d3icNnjbRtl+pwimt724mWHRa8uZ1lSw0EwENbOXzeUdmW5lfa64UCw5T+H2a57REvVH+W5M6/Z3Nsl4wq9piU901Q+Xo//8QAJxABAAICAQQCAgMBAQEAAAAAAQARITFBEFFhcYGRobEg0fDB8eH/2gAIAQEAAT8QA2h9Iznw4omDY9gZzfhuKwU/45ldiKUKbgwCCvYifDK0jA7f3Wi1trvF2z7qGcxq1kv4jWtCgbKLjUmii/eZixSMCzm68QakGmAdoiYfOYHzCiP+qY59f9QxUluTj0CH8nr/ALfMIdHoIMpz6CEWEOh1NQIRsBXm0lm8pqNZW1dMFv4tRK7Xv+2cj4BG7aZcVRMwSewYwwfUA0nzn9xCXb4KfxGgPxwfUWlo3zV+4yMS+39UrAvth/UQXg98RNQUhqIXU3e4q836E/wOzFY/xU2gKnufwh1f4PTH2/3CHR6tk5dB05Og6EqVAlZhO6m+CWMuTiLmUInwQkSrVf4mOC0VvUOwQYkWDHuFS2Sq3EtHvaH3Qp3nXuPT5cf8jyL2ES2Pqoacj2iCHH3Q5Ed8fUr7npn/AKCEEoxPtW09sWQB2+Rn+Vam0UkMn8MQ/hc+Yi1l9FwbXwg23lQ25jaUVe25dys7944YvzHq2Tn0BjqQ6BKmIQIRLdZLHwlrsdylQK49u0L5EBY6FSvMq/3D56/EzR5YdyuDysWPKGK94KiNuLL1NQsN3OdaDBuJmx+GoAbfNOyfJHivLLq3pjcAOdDjg/8AlPwYktU0P5Sxau7j3DUWI1HN2j78ylY5Gq7R/iulEPbwTUC2LI8UsUXQsHXwIK1ajJZ9HDFWXgnHXc+ghCEOhOOgQIESE7QHYRRGJoYhrtq9DXSgUY2RmAdyv/xGJlFaoPpJbtktCYjZwGaT/s7IeSNQliK3bws8jKjDARIYRRZRAVC4/Nh0OC8Vs1TQjT+mfhQZR5I9dJQei5QaQjBDsKC/crB02i2tqRXBDIiLLgO5M7Qj/ZYs8kSAoCBLmDUlNBsozdblnGdhZDQkC5TNoFxCepUJRgiXHKJYMMx5a7CmGpunPpL6EIa6HUMdAiKzCJxfuo8YJya5QjbfkXEdWWV3+MQ1uuEKqo4E2U4ldwGvoWoRnvZfBZKQrSN/v5j0sV2sIQRQHmVEgBJpDU5YuoLvOJrneZh/s1PYoXp/up+NBlN5x6axByzMQ9rTeIa4MLwwEu000dd15nkKKYDMBRSXGbLd8DcoOS4q12NPiWR6BS9MLsuKC/NX8qrEUexW7sbU9QkBV4C1sPUWBCtrt1iPpTOwt8u5wMXbHhNKJKxeqqd+HzKhZkdembI79JCVCEf4GpXQaSqbauHJ0QWBLYnQZse0rsYTJ4gGWJbs7OYFuuh+Kmaq3FxoNDHpj2rFDHgnEiHLiuagj2EFAEy1gCuk7gLxjuAPnNnz/UNj5T/WcQfR0pgagnCNtWIL75LEFVAtrNRvchcPwhzB/pDC2rN51MRzjiysEJg+KyoLs0m0wNarfRCHeDwkzcthA8Ifk9QQuwVNnISiCmnKCY9pRlGolG23D+SIest6Lq1SlS41CXk5vmogvmQs9hiS4F8UDlHfpIdCHTOehuEITR+Ados77GFHIWNOyAsU+cx6X1r3FUBVjfJLHPKTxpfkjLOhxhLamriWvJFi1VC4NMkRJgkygzb0WUIKYGf/ADEOR3nPxQJGTQg1BBaO8vhbDfSWSu2gVasA/uZJmxWxo/EWiCV5rZIEGiWtBHcYQQ7cHCu/EJsLNnRVxW9w5VABkvHcFtRhi82urHqpVBsNozCvURDTPpRedZjNnD4UlDStW2fRCeIJw4ygI979YEJQxzsZwVZS/k6CVCEOoQhCWhgG7AcAMWy21XmZWxWNjV5sQlRtNGmiZ7odbi6b5jN93MTPXbhafF/pgqIKX4Z6mlc1AX0ChCxCXfQITsTR0u7ln5Z1+x+0P5IcJo6tBXGMMoE3IcZMxeag8jGKoptoAJYuuJ/smJTShnwMkFtGt2GmDay2msJzMJ33ZtHYyicnwT5uEUfEioGPYRW+CLdBgK5YZkbWgp63NQZZNTNGZISUEBtXy2txwUzIoCPuXTbJFFPVRaIhMjlP7IuIsaqdnuXCEAhCHQhCHRwyKmSBZr9UWinHqJGCmWigQlQFKAMaHYkfYVC+LmPGEPmAVbp38XKdLJs0FSrEYGvxUfmneAcJUlKTwIUwajk1EgrNeoM3aZ/w7TQdv2ofvYcZogwdGHNmhMuOxAEFtq+OyOh+YSbpFQCsUCMvjA5XYL2lLiwCjUZR4mVVEXZC3W3UDcPc2QpsYPtLIBG11nEVtSepyWHg7xI3UXg/bMbIBkYCmRODEMJpWGVNUGbMPfNo9phqV3/PXp4gN4VqwBfxBSq0plXxyMRXCyq55mVCHQYQh0IQ6DYL7LNzmgpw8VGsKTFc3LgVpCFUEEzGCex7qZ+L9TDB/hlBYFDXFw5h2iAEKNdOUiCJKTtGXdoOInSnJ2mPnjT7F+UH3sGM0TSW4jOyCGd7HwwW3apzS1pWKIg3hLTHQ63/AEF6Y+GIrLBDQMJdCDVFxNEUnineCvrIzrGhfMZjvYlRXskzABg3Pa59qWkXRH2V0iS2+w7OO1JnKlBaELd9gaUnsEAt5fshECqo8l8/cveBctv9OpdAPYr6hBhDqQhCHQAswJA4o5NXpvEeHYvvFiFMC3EcRqsOQZRx97FQgl5U+EZkvf8ANBMluorswviO4hVD8xaFiqqZAOmiJTniEdk/Cn0P3ww0u37UP2sMjhNJal4F/UeqkcU3xLbKyjTn0ZvBIBQBHCPERbaIiqGJZeMxqyR5U564ZxagQjDxBZKfBFOAssU3/LB456i8F8QaSfba+AzFFE4wlx9XcaAhNBxYDxtWWdXk00y1TELQVC5kdt6Mi4VbnPJCD0KvqVMQhDorRuMfCgQFrBYi2Gq8csDDsy45hr2xS+ckqZU3ykkxMGMQRSrGBBUKEufpFDDAqIzEAghPohULmPL1B9f3Ryw+G/bD98BDYiwShKVXNkyiHS6bFlO1c93M4hOLucKjW/1GMDNF+tsVW88ME+IBRPc3RvaEzdMpTpdf8jlkbUeD4mMF8Kh8qFRY3i4RT4TFdTXggz8RE0raaBlb+hFaQA8S1TtnLcXTVbF/ioygJeehiIIQqVPYIdCD0JfEOgehGtW4lozFd1v8yohe7Ark2Jg/QELBShXIjXUxvwzk8T6UU9A1TAodIS/lzcOVnZRQ4hRYHQX4wfGn7m0RVYH7pjLYmhC6omghDIlBqOyDVU/EsNQp038tykwYMAXd4TEAVnioltfL0TZWVXM3yhc+2pWatA2mSIxyzjcU/cAVbwCu9r3QeIV7Aj6U1KqYhG6UKVK6AoaDXJcqNpLNA3VkCmq8FrwgAaGD0Q6G+l0y4PUN9F/NNBGi1F0fgQ8cvKaw2Qhdtjwbzip5XFSr+pfIbLnbBrx1+oFs5UVTYXocywIevEJFS2RYjM+8CwLUaGGaOxtMBfEF+iZEcR7foIK90ENiakpUHxC+h7jskwoeUKPiZJyfZBycI90diMeiHz1BNAOSEQIhYcx+j2x+yiOGzXgDJ9wZoJQBuGzmF12MEt5qU4Le9ioPbZmtYDLR2RJiNAGKsbUErXBKPuYA59Icu6djP/DLgwqMMHBKW+odDqb/AIHPSqsIJRB0uMXMVVtANMolsVBMYim8MBN++2ibR2jLUohhr8pR4i/JLIqx+5exy/UCX4XRAuIBxAkoS8S4Zmj1CsIuPH/TZg+6Cyd5sTQgKYlBYOCYfiLmET2KeWMu4LFFLXBxCYUG0jVg3g2xFsFwZDMSrBwjthylTtMsogiy/aUvgigMrXgMp7l/lGzh4XiDGbD2BVAAWKPPyEJTPoIGFTVBf4idNG1WeVZI0QLunyCwOSGDqdDXUoOelzEAvYajz3HozxLAVppgaQmP+QmzcbgNQK3RlJ4woZw/udl0AOl4lMzEalpA5g8EHmHxSViX8FXZGrpF5oE2zRFkjwTMa7Strirs5ElYRVaS3htw2NFAXlgsoNo0g6wToLNArFWsKgshcoctCGvuYn6lAbWjnM3EoiPkt+Y8ozrXTJEVfABLi4aaX5bflmyWjIVECmjY+yu00AYsu9G/pjTsuZd25qCoXC4HQ6H8A6Ry9ma5UODGGRBxG7fmUH2v9xZX3/aESSTYAjuGGKRXdD9zC/7dwRxyjyQ/lnIfKqUvlACKW95GPF9SdjTtyIsvJipJr6DxMiip5Cx8CaDFEODFlCy53mWvHgoKGIoHRxO+WUjAVzMKlzXCzzqsR9zlIi6osQgozghDnTSFRC7Qj6XAG770/YwQRmdbsLU18MJbdkQJXLfEQogiX+FYQNh+nclW8QtF845S/qU1SAOW498olLm+F5uFkgnUZz0YpSob6RuUqB7QemWyB5gRP8xiQ2/nQQdJxL7Ynd/o3RE6O7oX7UCvz3foip8JE/No5zXJU+hj1q7s37ZTog+ozXQFPdSmK4l+ETusNNSpt5gqZltdUCGtFN4aGFtUqlxxCoO++sKaYp0upYKR60VQ0rFlXoAIEVkisEIEUEwIXHAX4vmKWVZVS7yG3Y9KGVNtgGmmbCKQsd81qUKOrKW+DAAQhrswL0qYLdfVDDLDkQvvTR1P5TXRTUDF6RS6QQn/AE6WHKvFsabbOQfwLC0YPNkHywif6OxA2U6EgeCDhI/3TDHR80Qso7ysbOvoE/J8wBPAfWZe8P5xMuR+YC7fQuuhJzDgnMQst8JVSoEUw0INbnEJkDSu4w4gaCsviVNzkbBj3OYldoEGI6JQSu2kPyjKoSFalWQPkuLVxdjklVaRfg+oFZQzWnsjHyr8KF+Dcquwpzm5OxDbgLJYfKY8KZfBcAhBoN/l1DZoGjpiHS8wlxTSHThWhQVCwb3cEufy2hi2ej9s16v8cS+AfQahZcHYRb9K5R/RUfmp/wBAbncfxROXL3mHgqE+ZRAgwQ5nHtlkuhukhRfnSslrJ0BEA+5kuHBtXwcsQcQNFPuUZDZLVx2l9LnrSNJL3dOMx+CvEBltxELdRuXdTJxvRLKlpuuAgCt0A85igQHGAfepWgXQJS/UPeAPog1GNFflTORGJ2Hn0TJXb+Y6Bl/zKDnp2NXhUzXsGDgQPaaVQb8VQ/NQfXzj9Q2q+g/dy/V9izgB4Cpa8T3LJVEDAjBdxqIlViiZS7N1HDIPgle0pWgh7ZWPsg3+cHwSqOTg1TsRfknTDzgWpK7UVJyJzi4hxQgOG25fAKFT9QbTEwkShDspmK03LdpVzRGk0B7xMF4LOVojTRnTyhLAFIX9RNxEqt0e2P69vECo4YHwFmVQCl2zmhYoMGX0Wc9LihcXSPgegi2k8/0QfY8P+jcF/PjOKHqc8QWA94MHFGacz1IGiRsQL4mqPfLKNd+CV1ynjiiBOITmQJpm0RYam+GNbNGKHzAL4wPUIsvsLBRqFbvVsHF8w3YWD3sjsOCn5j898Y5IrI1L8A/9IQYV6BuMNSk1DPJObWXTCycly18bBcAiqXTvZxL5BnltK44g3chbeIqS0tR5rnwk8QYdBal4nMOig9Dl9iW3AYeXRW5XvEuYlBOZboVewXMsQhQwuwoYhHL3cs3kC4E4yBOjTxLwKpugI3aMWKKMLtqO1oX/AFoiNCxFOYyK2eJBlZh3Hj6MwdU+4bGJDgBfiWLQl3C2j0wUT8Xp0zC06fYYV6jjSiI+wjYWIOiodGlzrlmjbT7ZQPsd9coMXHfRLZnIghPoDl8JyQqVum5ZnydCDL6j1HVqlI97EuYkhd4m6G3sQ/MTiL5a9JUt/wBoQLJU4wehAcQBKCaXRhF8mWGrsRO0vuCgy4pCFEe0sD54SVk7Goa1BfdnGVxMBuKxDRXs7S8ra7mwPsYY9l8nFtLEoIDD5IqrZiO14/sIPBMZwGERmYfCrSawLEbRU4qr24E0GW15TEzO8PnvEQFptE5BYXlwtE4jtTHwirer5eZlyGkFgwh0v+J56QKzHvQOxD8iOCbE+hc/cpHDNEq7LmpgjiBIUmCGNCEpbwLBXXwS/anyxO8GEDESkHllkX8GpcHqQXVKrtcsxnbcq7DLHXdDQvFRASWob2RWoNr5fkjXeFmDuIa9nChwvk0xcAFfyqlgqgI4tUEjuDwM6Yji3fDAjCiS1FauDzAcJqaXf1EDSwe7j4NE7P16QLBjo82oGnA8bwlzOTBG5d834hCEuXF6X0XiKKVGh9saGITRgeyaMzVEA4gYRgMw7FH0sl4WDsR61PuCu2FEOiQrMZp8TKGYQ8uWBL9pAJQmJrLkdy85MpUv6DvDXIVNpAqlKHErfrhsj3gKyljV/wCyXgllL7MNJ2SMVgSY74yv4IwOWsP0e5AVg4v8KMSXlfxLMGsyKV8HiZhLgH6IF3KDlTQnR9+UK9jfdf8A1D4gP9rEVeq12NviWBDS49RVllFEfNlREUeIMHMvpcvooOI45T49IG4gdoBCWGVCGOVLIuZfhUjaqsU0x9Agy3NbwjZb2wEd+rswTGBAFBRF6gjNMsrYLpc3AKg3fRuX4ICR0pil1moLBT+HqF+tDt4lzqUPshkWEvgcdo2wH7NMJDWE1TKYLc2iNw95QICAs8B2YzJFv4NTKWKPYQAlJUitiFdjX5A+0tXtFcPd9uViSRcBgo4JwJTwEC5JgPmYO1v5h0uX0uC9FxRwBCoLEhkELua4M5Z1UjNoy12wi83AEzNd4ILQBLu1O2pigHxL21V7sEgHEepHjGF3cVRFdrGUmVlK57kZAc4Xs4qB9iGnx7IFd7Gma+oTLNNMaCFLy/sJXwolSYCWdI9jOY29HE7qBZCkixRtF8ZgNGfQXFXbbWYMDzjZKttxnX3PozDRaf63oSs5ZNsAaIHLt+jvPInZXM0h7zca24U9Rly2MGDLjimQga2ZaGUtRUjlrPKwSAYMzTskLqp+CBFua75Yq27CIBBVEAI9Tg7xhtBxGmM7gxy+PcQ7NGGymCXVaeYI4aBeZ+IJsNy7L8jMyh2yrESXtPYi2oszsXATVWDe7j6dNnf1GSKaeYrFcux4zLcWS3IwWckV+CWIuMYtqtbgS4mAVMrUq2vMAQF49MXMgXndqV6yCxEBkzT8kaascOzydBly+qt6FFL4dR61lrthBiO4AgFxcihAYFsxF14JY5JhydbCuikw9J+/S3lkMYLOYNy9PuNr2TLtA7j5cKVvMUglaNBX5WX8h5K/iMxtq3zjTHmTWWoBtYlthgQtjwQVFYzUDXgHiPalJuV494czaVLQxDxRgD2HWEqOMVR6JQkY933qZKF323BfdlBl2eVhJHOQ9NwVJh8RXL6Lly4MUvMUXQQhDe4d2cpmNUrvb6BrDF0aIQYwkp6dfS9umYRocJ7q1QyyPDEOslELmEfkj6REesJfX8h3F/XGj/sJA7kbg2F4ywph0ndlQajPmVMWNOEZkKbBZIFFt1BqZ1KUPdZJSYAa+4jh78aR9opCDBB5gAdaI9DlvsXGiqOQxBXRV16MMlRfMvot6BgxS8xR9B0DYNVQ76wbvlhrH6AJgmkJRJfQ39MgZZFm3Mexi1htgO61MR64LFVpSzKtXC1KqWxgJgju45rKMtZfO4i1SB7JhAVccLYUioUxBYOq1iUy5EobGbi2w8JphKoMBhWDeWf3KmreeL7q4ul7drl8wKGtGMvBVc3/AFjq40Gr5gg9g21GLly5ZFlwYPUKLoMARgDfNMwdDSBAzAVghBs6XGKOtDs8Q+IJZiFK1eIGg/FwO0cX/GiG1djaSoTyBRv1cWWybyD2oPPZ3bsMY0XEyla9zJAIytqzaNFStCAeiqk8x6ZvsgIAoKORlLaafDMG1pv7UCwRGksOMQVfKyoqLbTMW5wtjDwVl5DFQjO+mMFqsrFk4ciUoTIy5fRcuXLgy4ugdM5OhdNOoaQLbhhhDoS4sXoAGWdqK7+pSlXBubxjg7EaXcgMy/b7I4X9mP7GOEaP/Dv073cQeIyxe2vkTegkF3BU4WDFxeY/rSMvFJkVWDycxVUO1oZTCuFwwFKboDlBKjxa8mjHKW5Qh7aqNVLvwPbHOHAhWD03CuwIS7uHoglJvvdP4gQ4cWuIyl7FGAK9mB9ksUiPmLCLg5gy+knqRgEMCaIagYgry9MdERZ54iom6b5llQ3Lz6itiVEMhDrCPu5aQc2UPcNzguUwLiXrv+YS8b9D57R9SJXcYoKuCkOXmIn3/RFBM/TAxD2TBDswMfdMLOPoIsTjsCQS9oXcsh2/gH/BLWS7LBXigXwZYLJgJTAwQ5uq7Mzai4vAvQeExT0SqsRiDs+4YrZ2SyCoz/E00y4MuXFBgQEEDoBuEMEGHW1jSLolQyq5sb6V7j4eoyBEPklancAemVRKuGkjS7Nrs4YcPCd0eHuTZw6ez/UTvvPiHEzFCJggWtUMuPwk4Roowp9vML2i8fc4AHxOIfmZdfjLrmJiZF5cjKyxEAwRqLcI4DgINV6/+dzDBUtcXo4JQAAHbE5xCMFN6iBviuxG2D7Yly4MuKKZIBB3/iEe8F1DpcpiyvnpY2EIm/M3jk91+pakMS2wgFZGEML7PEG0A/KTOMwS3CgIP26mXtLNjCXyMZViRGcVPxIFVPMeG1wY8qGVaVoj/bQ4J4jBgFoSU9p93JAlFjwLUs5lFomWpcVehlhSN6/4GZVsHeqJiuxTqVFWKjW79jUsMpPq4ig83LgweoOghPMOnE4ly4sMUUPMxfMzdTG/Yv4jpxL1bFAW4K7QvITVB2iuhkf6Yt0p/wDDKwwAuGVWlhlKl7Z+HELGmJLVCQQ9kqXI7svvEsL8UlxmlvgqEZ+JRDNiHpcwIGqwQE9QRb6SLenOBHlWcUtIeuZlyvllqOcKT/ykx3IisRBJe3bcrDec6l4zvKcTu8m12YYq7F8QQwdQYER1Nw1Bgy5mOIvwlxYjg9fyMuXoMZ/L+om/BEirF1i//DJfuYFIWkWwBa93MQbsB3xZcZ21DuM0lv8AERzXEBcJapZEVGAshmYuIGCARXE7uonyfDEV+cKcBGlWNRMTmWSxvHPzBoSomTYaCWVL4I17ajkgJlzHsGiUKhst7xzkotuYlPXEIXORLja3B0Ip/8QAMBEAAgIBAwMCBgAFBQAAAAAAAAECESEDEDESQVEgIgQTMmFxgSMwQlKRFKGxwdH/2gAIAQIBAT8Ap+S5HUxtSeUOEH5FClhnSxJrsSu0R+oZLsLl742wUS+uX5/koRclC5vLfBBtoTbiaj6V1LwR1s5QtSPg6olllotDaajXgXLFwL0WTful+S97z6UIlHraoVIg8E1emvwLHJFPkqxYHbbIJp7VSiLl/kXBZ1LuanxSX0q/ufP1ndTPnTSzNj1HlpskpxyiM7W3f0rZKHS39zpi8EIpJk1/DRhEHePRF+7Z/TEXL/IiUlGr8nxGvhv/AGNPUTjblXY68OnY+5o9LjbaWcfohmAtNJNdv5CIvNWRbZAedNIUaXJpKo1tQ0RWUdkP6Ud3t8ZqqMOS3N+RaUY6HTLxkgmkxOX+e5o9MYUqeSqmunqV/wCLFJrEqp9yapi9S7FqM0ReXXk0W22f0fslGqZFqi0QVk+SPKOyH9KO7MJWzVg5KWWm1+mfC6Kgvc05GpX0xk84oloxUMxFxwRbSjnIpvqxJ/8Ag22+l/b/AJNR4IvdcbxJL3miRVNn9MvyT+hkHaFwiDqx8i5/Y+EP6Ud2dh6KtdMmvtyhKXW7rDJxb1bg0/K8EotxJ4kcuhfD1Ck+e7NNR6rmrwl+CcYxwisC2W6J4kzTpNl+87T/ACO3ghBpCWzpM6lawdkP6TuzsTlS/wCyWtKU5acFlRuyOlqxnGSXT5NbV9lluWWQjmyWpKbUfLEk54JpXzkpJi9K5Hp28vBDTjFmLFxIQrKZ0scL7i00ns3S2RNpLKfBKUtPWlJOuuCf4okpWvdNp/YcU1LN4sjwQWJJnypKmpKrRH5elGu9/tjuWrJ9qSWy9KFCXgWlMej5aOhJOpCVIva0WXtJolqVNkZGpFzhJJ5P9NSh1O2rJw1Hy/wjqUW0svuyKEj5WrhqScXVonFdTk22uxVvhpsSxz6Vs9U62/JZe+NnKK7nzPCs/iPwj5V8ti0oLiKPYvAibbi6eR6cpxdT5VkovTxX7E1RHJ82or8j6U0+m2Ne3DEvQxULHos60PURepLhC05PmQtOC7bWX4GJW6OETrqTNHCX5PiI9Mvs8oSzgTrg04vUeex04/Z0kl6Vs5Ieojqm+Exaeo+9C0Y97YoxWznFdzrvhF7KQ5SNNZb2fJDlryTh83SruLDpo6b4RpJQi14yzpvpT82yXH3fH4JL1IWj5YtOC7bucF3HreEOcpPL2vgWRIYyKqO1vrQsT/ZfTM1Y6UsyWRdMfpRDhX3ZdyX4JOx+hJ7LgpjnCPLJa/8AaiWo33ZZZaEIRY9oyT2k1Z03NMmKhxbawPmhK2/A3fCJEl39KJakpd36L2W63bosWvqJtOmh/E3KukhPriOS87PKTIwffuUknF+ckmMbv0dv5aFtVntNVe+SQo5NGun9kk1JotUOTqkXN8WfOcZ0lhEviXx0oh1yjdbLGyFne/TjdIrai/Jrya1X+DruR8PmEvyODM/2CjJO00iKrl2KNyTs1Uk1TPh41pIenHuh6S7Di1ytu4x+pbRQkM5WyPio++/shHwjxITfB7jPg1Jex/fA2oxF7pGlGoR+yG9mk1lEo1t2343W8Fw9mLZ4Z8RG4pkj4N4mY7o8ZYpS8yNZ20n2Nad4Ph9K5LBdI5eDvtNe0wJH/8QALhEAAgIBAwIFBAEEAwAAAAAAAAECESEDEDESQQQiMlFxEyBhgXIUQpGxI4LC/9oACAEDAQE/AG4LueV90dJRTKFgTRCqJ+lD9Gp/2IcX+B8L74cbr7UNDFHhH0MJUTi4M7SE5Zdiky88Ffg6LGp1yyaqEq9mQTqvwiXCMfdBeUrZcj2e721FKEz6/T2Zq6nXmj3KVnS0K2JEWqRqSTSoz5/l/wCiDuMf4ofCHzt0t8ZNPw7lVn9PpJZgfRheIpiguGkkJxeGThkW7F8nA9pStpjaZihVb+EakbyiFtEe+0FhE/QLnU+TS9Ef4ofCGQi5XXsaOjWP3ZPTadKN3lHQ/LYkaqknhMniQ5t0+5Wb24+xj4GrXBqwp49jpaF/5ISpNDytkyLJvyi9U/k0vRD+KH228Lp9UiMVFcNEtSUtbqjjI+l4/I4o1U5StqsF+Vp06Ki8x/wRyPa7Z32Y+CMLjInFKrXY1oxpUJZj/E0oJjg0NNEiHpJehi9c/wBGl6IfB2RVtI0p9LjhNJ/s8RqudJWo0jSTq5JOsti1m5YaJKxx5HFU7iiKSyvyRJLbuh7PbTdRNfgu0h8w/iaLqaJpqRP1HTdCWCXpYvXP9GlwjtstXD6op/nueT6aq8o05JaVTj8P3FNJuu/bLNO2hxHq3PK/RNS6fK6y2Rbazu+UPdkZJL2NXUjgt0J+kiqkiWo28jbe0U33HFqLdn98vhGlwv3/ALOy2hG3RDQjHTjqzeHKkier4eUJQtyxSfsaGl56HBQ4Juk/cjGKz3H5dOxPGz3aQzFk02/wdCFElzHZ0Whzgu5HVXZNj1ZtUooSldtkY0dto5eDwcdPxENHTnFSUdRqvdywiOnG5RkvCxlF1Sk7tGt/x6keOadDZqvKPqx9ndE3qajvtQqUEvzs/se1pcsc49nfxk6pU/I/3gk26uh9TfqZ0N8uT/YtOIopFGN1F9I1TIOpJmj4uUJtxVcEPHKKajBJvLldsanOpSwrtIcyUh6kLdrPZkZOlFUP5GPa62eySXZFv3ZX4+6n7HT7tFxOp9kdUu8mLbTSU0nwLVhpyzDh0LUUx3ZJoemnJiTeLwd8j+x/fTOhnkXc612Rcn3K3o7CWSGYuL/XyatOT+DQdxT9sMtrNnQ2ataaX5LyOWcsiPfhb0xQZUFyzrh2Q9SRl9yhQk+x0cWyqGt3suLJ9pezNGf0tXPpeGThhU8F0a0nOV/4LzJkVmvbki8j3fG/1H2Q5SffdQkxaXuzpS7bUNDe72x0seYHqijR1taCpPHs1Y5Sly/0ibz8ISw/kWBHK3wNbqEm+BaS7sikuFvRSQ2Mcd2mtknR1eRmmPApKKfuLhP3Y3SiJVy8/wChEXhobv7UkuFsiit23s9mLZaGnKMWrTaF4RpW5Gpp9E+BQY0L2JTjwW7UvxgirEJbIQ+WNFCX2vahsZ0r3GqKlyaL8kb/ACdSo8R6sexF2kyskYRuxRguaHoxlFO8sh4Rd5M1FCEqW9Kh4Q0WIX3t4GYP2Jsr2NCKlpL5FBJHicTj8CmjC/vQ5RqmmyTTwkSlhqjRbfPseJlesxak+E8EdRojJOq2fwP7lsyTGLgumWsZHg8M/JX5I5R4z1Q/Y69hdNcn7NOPnX4yJNuilCBrSucn7sW0W00KVraSrfH2yZJjEPuZTFlHhpVNr3IZPHLMH8lPsJKuEOMb4RorDaNCHdnitWovOWYb5/WzeDsRdSMqycng/9k=", z1 = "data:image/jpeg;base64,/9j/2wBDAAYGBgYHBgcICAcKCwoLCg8ODAwODxYQERAREBYiFRkVFRkVIh4kHhweJB42KiYmKjY+NDI0PkxERExfWl98fKf/2wBDAQYGBgYHBgcICAcKCwoLCg8ODAwODxYQERAREBYiFRkVFRkVIh4kHhweJB42KiYmKjY+NDI0PkxERExfWl98fKf/wgARCAFAAeADASIAAhEBAxEB/8QAHAAAAQUBAQEAAAAAAAAAAAAABQIDBAYHAQAI/8QAGwEAAgMBAQEAAAAAAAAAAAAAAQIAAwQFBgf/2gAMAwEAAhADEAAAAN4kqEoTNcr+Yq11rFZXRc5xTldvlihikiNabsVbfGCFo6wJ7yXCJS43GWV6BEInAgEK2siOkMMrpkOeBh+d9DNiPtxfQ5oyRDafRkrTJgjcJORQ3CA+N1L7Ei/K4RxXuQO9ZXC67FeWSEc9Cr3kAr8n0PEuNsPtuo0VimwkPbepuf8AIGI0oY/HMgMoZdX3YM1lbYkw2VxSeyNOPPQRk9prqWqcftlXnUOEuoeSTKnpYWS4sweIqVCmgsMSVEifLUw51voRbrEuRMSW1C2xIRDxPulW1pUJxfnZEOIdhUn3AeqaVGWh1qu1xHUPTuXnWsWviOiDJTsdmF2HwaQ3BdRanpHpUVbcuPBF8911UtIAo0Hlu211zxqCGiOSiEccuznkNEb1SSkyljanxMOXuCwcT7t3DPn1zcIpXEua6JMzufYYTiBDm8KjUuqkg+e4Q13vTEucdh8jyhO+50FCkvGd93yWtpV017Q1wXi1+hsxXUpEHSzHYpxbIGeIIIb46wIqFFHMDkasFrK2x+l2RZj9q08dTYLINKpee8LbrcpwcsCSqGqCd2J6Ga+NekIShEuAxMCSjDkoJJKmOjFmertpkmY7Tfp5+1figZ9zVSxfkLu7ZtatScebeNdV6Hnveg93vIvfK9GZ6pQOoBFxsuhhtmU6uXg6TdIFVO1oBlDYhHlCE3d1zC56FArPp43ua1b8Z2SUxHGwF2QrUJlA1xhN4giREfLFoK7KtZKClz7jJgqc6xukAHzazA6TtJCnFkAkMxZFaNDdkdIad6qRznltKlkn0Y9YPh0N915Rafmtu31O1fc90opbfofKSlXuY16JRa/rw/brKgGW2akLGqk2RDA9DMwkJQehNNkhrkYF1uBCMKqDyXR2ASLkVwhdrGJQD13mxaqVNdgiSVqipUrkHXVk0OcGnc8wa9JRlx7bmooUfynm3ek3HKpN00z5U+htu2g7d8y6IybGsXIF07zT7KlTvZGl88DHyTY5RnwzXPvj57sOFekouTjXkrYdu9X+u6jEBpCPXSqpbCWXRAbgv1stUbwZfB8V0nxGfMsZ4pZ5K5Y7afQ1ywEVKGGRNDydLSyuD2Xfh1PsORM7jjPSHozw3MlxZy1GeuxUufIzbaTXfqbHegMuN08dZzNaxvQGmg0zQhz6r5oOaya1+l3cL9Vfu7+Z3O5LBLCP3NYHAkyxZHpa2EN5pSygfLv3MHL/AAN3SM0sb6X08vngrFDpw3HpRVG11urjUGSVEicurUpB5hFshS1IR9jBFM95ocqj5LSpQzUcHSfolirTUyKzbnunz6dfo1Wru3d7Nr5uwrpR0B5zqQyk3PZydmywjjHd5l3DUg0Wdr9opeoGr9mpxbq6TNO56wVlFDbtGgNjm8Dlk1mTjyb4bz6xdnZZpFdk2myE6rMZbpHBnL1YXKhgM/Kn1nASxnKNBrMILOXOY9PEqGQ+h+TdUmQq0uqbq9bEg6kHaNm6h80LRRltdPumHyt+/wBe0W3JWpYWyzmJt1TQ9EulXUNT1wkGbynQWtmeDeX3TOZanZ9eXFAekZ/2vOALDCECWOHap9FIoPfjNWekyy0uiVqt2WBs6IozXZE2Xf1e1qu0i0NAI5AhVJNi3QpnBTbRoxChmzL7PpR25CXveK5zQrzi+XSpKWK7WYPmbqlSWbLYsq7s3FY6XRMi5jkv0jmeTtTD1VLcm4JY+hOhzLNR5q6efWGDT3F4lZjvUfZaYI1eR0rC56ivpDJsUJv7mmaNi7ruEq9prW/kjX0wGaTaAWi88UcwMrTJo9lxzufJslAg23n56fA1OO/pM/8Apj5Z1LbXpGYXbJkc2UCdvtPOi7agYPtztdc8uHmEWgpUD11eV5paKtn08FTRUiPJmXoSuwm/QEbBHJhVvIcIeol7pOTbmZK35uLrbGzrU81g6vacDvzwVjbDyufi7N1A2ioqvte38yLo5q6jNhNCtlSu3k7JUnhtK0yzQdK8BoJ317BZ6/ZuDsyLuzQ9Fnz2UunraA+jSLh5/wBDBya/YVn7glQQn635wYOja9UlperXUW3v1IiLi1mzeBdNwMZaat16Yby2wwUYTOG13wYL0a6tVhBXGxbPeAFwUTJSnorb7a2DrKnktqcG5RsWzDX9doDBqvWAWM867RmatWVRLHDBEyma9Z5nVHaJRLyOJdE2bpEKQ1cpyWBez7zh6sTXzXO845a6H12nS6li2Ll0TWeb3DCmqxyOzTsqtFC9XxCc+GjpePIQChSrKBn6DRqBNgGpsuzYjKVsa1WKrkW23GxUCz0tVq7f6AGFR32L1JXqn39ltttrlqCm4BsQUqRBiu8joX5+h2joUlIkrrgAFhWrHdJM0CdYAtMK02rSRmKOpVR8/wBFi2rXpkqLdzGh2lRmOcknWCoKVJMjfXpDwdRZXxLhR/1bgLfqOg0s35f2Fmye3iKnq2pXt3qeIotf0PNcrjKTp1T6uGviWlb8gRLTfQskWGuWhTuxnJzWfTo8inWCuyVh31F82E1uNMhWix6DnugEXayVw8EOQHo9bV4SWG8zZPB2aXsraN5jd3BQOa661cTYmcrZrXNWyIXx7oJ65hWKn6RK65E0yJjty+t3ILsEZ06HOQNNMTL2iMQYmN6ueGq1ksPgMpfdbHRpPD9DbNfE2M+cIhpTnawBqholX5mxGU6nVciZTn9wqfp+Qw8gtrdy1QCNN0+dAl12EzlfmU2bnRBmyX1/JIu9UpLDGgZrfnTQj9YsYUg/EdYMV21t57aR66JyaMhtRkRaLnOrxvRSKH2yrIbx837MTsf5tAfQ2Vrti7Ng10xvYKcXACmnEnpt2KAqJw3SZAp4Vxw5CU1JeLAmYexUulO9CoU+XmZ23EplN9Xn2iLXZttB4I7GyOqjksg52cfCTN9LWPmzZGi6JNfeR0z0TkdMppytqh9a/EX0btp0D5l+sqnSfmi6VqdH1iz0K4hDcmFIZZPueIivdbrsS+2oFb8GWJIdhymkKFYIgeGAscXLpwabplG5vX8GjgOliXd6jbqUzRTq2cTplFZAL+EHEkGUJtBgMXClbMEsmJlIbaYqpWpZtdstUy1w+eYz1xw5RnoUQ5Dju/RyR15j6dHlgky9dI1taDFZvhHys8+I31/ZZ75c+kKCN+e/qKCpwy90oiJpE+uGYpJUZ8hXFJMbdR5T1pagYxSG9DN411Xco9uq+O46KfVVpy7NfoGi592ZFwQXqZLv6qGMWpyJJ4QZIxIGjnLijBbKJlF3dWOTNgSKnMyQ7tYt5elFmBOtlDd4r8w1MvQG3Y3rko4vSYZFC9eG6XrM3wBG06kgoKOLDWUZognZcf7J9jOYfrtKn86tE1Dm1rL15YelBSjCVxr0Dim1GK95Iilt9Be80sPJ8w9CxXbdCruZrB93m7Mwyvac+5fVqROeP6mBYgfH24ednyLahk/i4imleaccQtg51whAyUftFqMnkSrkcRN66wWXw7rxoe2pJC4IAEtWGiUjtbWNEs/OSpYGBW0GGj37PeA/T83510ukaCVqLCrc2a0YRir0N4rJ824R1C/ScUyqR7iUxnXYzoj7sNcblA0aLnvwekfU1Srv+fYmqUt6g0pxDqpbfSFt+UyM9lzHA+aQJRRxEkQEGlCROABMORVIvkkjIHMCqiTa8rrwrVXcoAtdiGBw/sjTHXhD8gKXsk4USbrsqTZsWtnu+4RbL5iHQm7s5xZ0FjJ1GIh1I3hL6NvT2J2ITTWarNEsaYzzI55K5PLR0x3zPo3W+pWN1W3ekxiv/QkANgftphyZNJ0hJFFn3CRJVyFjfEFT5YwQiunVwnUweQDTNHpwJDyWN6OdW1Dw1iHa7GTas45VnJLq/Wbah//EACIQAAICAgIDAQEBAQAAAAAAAAECAAMEERASBRMgFDAVQP/aAAgBAQABAgIzUe+zINu96JL753zvcJa0seBGixgIf+zT3XXPZwBGft9j4Z3sHI4MWExpvkCaK/8AHZktlPZxouWm/rXG3sLQcoDxuDhh87LGD/i3uahaGHkQjkcNLLPg8AH4Xh+D8AEcH/hHJM1DD8A61xt3ImtcKPkcPB8j+x+D87JnYnvNdevy7cMuotIw18ePG/5g8b/m/wCb/m/5p8Z/k/5J8SfGnDNQhA4P9T8bZt9tzWtcE72WLxUTBXA/MD7/AHeztve99u/fv379+0OO3jn8Q/jXp/vtieNgBPXyYSXNleOnjloFps+d/wAB87m97KWePt8PZh6/mzEltqKqWQ8GdmeV+NSs3TXG977du24B16esV+v19OhXr11yOdW4N/ibKPrfBjcAUY+7W32Z1VMD2E8bmy/bc11CLWKRSKxX118X3qf0TWta+XpyPE3Yn8DBMPFtjuxe1SmD7dc77dmM6hFqWgUCrrrnq7K8Z8vIrtxr8izG8irjJV+dc7avJ8VdjfJMwcRpkWGZFtHjw/wSX3wFWlcdaQmvpVYWS2JlX2mUSirSY1S2Hxc3ve5rndlGX4op8YmIJlliTXjs/O+xMAWtaUpCaZkv+mas2Ry8esUWM7YjEV5FmY0Hxve961xvM8dkY0MrSmq17bvXvnZbc0taUpUEEMtyCLEx84PxuPb1OUbMeGzyV4WYz2840pVHIpyFs3vYYN14BvxszAnjcVrcgpVfeBx23wFSpKgmjfXYaWS2u1LqWlGRxY7TqsFd+TdlPkWRQLUABWtxNjI9wem3e9hlbZXiyvPwArnrkXgcE7mkrStEuyKb3VsWo3XO1hxrbcfQrpursut6O4ynsKMq22gzYZqliVoQWYis0AP27BthlcrxYlheX2AcE8AJWlYS7L9X5nfKWi7ucdMR0C5ldVjulxsqa52SjgCWorLHqwrrawLa0YcU0mv9DW+wWBwwZX5vgm+CeFVK661XPspN48dQKzCQWyFyPetmRZ6TUtftZKsQYmYnrYxJVYyNgmkNknr1DB8SjLLKAs7BlcMGVuDM23gngBErRVAyoVI0lP6RTc3t6112ObGPYH8zpj5O8iBu3UvVkK65bZNeXbHG1m8W3PVmgJgVQsEBVoW4Y8CItaKo4ai/FTKZzkDx9t4yN6ttKibADe+xw1V2QigGV1em6o1+rslqwYt+NvEuyru3faFeBNwFT5FuDyi1oigc5JtrFt1ldpi0eq6gr6oAtVeJnQtU2uzgNvxlVqMLqfzi2tKcSZNpeC5LQpKDsb1vF4tDo+Y0Y8KEWtVHJioWvlB9S5D5FZMdWiVAY1dSZi+vqiNHr9YnjbEPpyK+imjFAybMgxQydRBEYk2+5CIrK15h5rFYQD5IrrZcihLKgrCtzlZuNk2vqs/pKmABVsMUhkFbkPO1NWyb7LGQLDZFO66rViyuBlii7g8CVitVAXr8a9Vifi/N+XIlNj5C4/QN7HcTqE6FmUQRKldLcht1oJkWWPtaDStNQCisOp0Ci+tQj5IMPCSsVxZol5Vbvje8gUukyqMtqoTk0l+iY1VNtNdXqRUbqIJv9FtuIiwm1hiY+FZUcdsS5BlNOwcBLaoJ165yGHiuVhIsUtGjBLVcEi6hIjopyfdTl1XdsrGrxLEpqtoqppuF3XrtWKvUtGw9r0UVVvw1lhdijXtxqpRaMhb1t8jWYeK5XEi8NGMKxHBIslYvVKXZGeZD49NksoZK0NF2PtiHuAgYwFGDVpVWTavZqJbQ41wiiCaEU2CxG4rlcSCAtCeoLVhlIMSMuWjGg5OYgxDGOYi49+StjFaLW7tx7tqxeqteNdbYFaGExBB8CYlufQeK5XEgg4dDj6W+xqbgZe9OQy5FIptx6sPrRHZswImS8taw9VL1suiuhFdYJ7jGJmUzE0aA1zsHxVrrkUmIaikH0Y2P+RFHFmPjO9GVjevKFUU246gMVuSV0WArW1jdOOmO3Y5f6Nm23KteDgDr11169cO5WyaL0ErNZH3ub5etZbLq+ixbckd8WhoXovWF52SOeFKtso1TD3QkfIKwQKtZnjclWzMSyqtq2U/QhnWDkqvD44QRckxLbIEM0BOiy60GIYpjr7e7ELoD4EEUrCMe6qxWycR6q3Rgf4GVnjcZaxeti+hbBkdlF7CIuo9hYNBwCrAmr0DEGD/nf5xw/V10AFRL75rx+XsNdj249bqQf6NOqO62VkXoahZ3VNdva1nXprjew26zvp+f8/5+hu7GlqNtf2jBZhZYOzLcNGVv7MoBhpuqurVAm2csBB9iLFYP2K9PSZ79Gj3dq+BCNA4uWG2LHr9an+zKJ7LVtTq9pcL10U+QABFt94yvYYanQW+6xIYjNCZphAcfKS2dxZ0m/wCpW+lrGvL6A+wAoUKF6736oHWZVntmw9kJ5IYcV205XYkWi7+5BV8KzBav511C9QgrFYQJ1NXrEe+zLseAEwngQcNDAd7qy1t3v2DJGQH3wD/LVmO+MaPV6vX06dAgQKF1w2U+a1vcnhrSwcPqbHDQ/PdMoWdjOy3rlLlrlI/bf8iDWaPR6PV6+nXrGyGzmzWs7cbJLl/hLUP/xAA8EAABAwIDBQYFAgUEAgMAAAABAAIRAyESMUEQEyJRYQQgMDJxgSNCUpGhQLEzU2LB0UNygpIU4SRj8v/aAAgBAQADPwK+wBBFwMLhsUUYjYI8WNhPet+utdAZI4E5HaPGARPcv3b98fphCzRfsEbI8YBE7bbL9+3hX/Qk7L7eWyPEPdvsgd664f1Z7k7I8EjZCnvXV0Ttz7nD+rttk/oo2VDkwrtB+RV40T/rCH8xU/rVD6iuz/UVQ+oql9RTCPOm/wAxH61V+pdoGi7QPkVQZsOzP9Hn3p8EBTse7JpK7QdIQHneuyN0lUWZUwjo1VE9ORRR2FFFFHuMOioO+UKg7RfS5dobpKqszYf0xUd4BEqtUyaj87wF2WnpJUeVsKodUef6hjswuzv+VfQ5V6ebdkeINsnZA7oCqVDDWlPN6jsK7LSybJTtLInPwz4UeE0qhU+VOHkKqU/M3wxskrCJKju1axhjUxl6zvZBoimwBOOZ8Io7Cj3Ah3Amscx4MiYKDgCMlT3276ZqfCY8XCYbssq1LNvgW2/O5BrESc9tSq7DTbKYzirvk/SFaGDCPBO07Qh3SQqzKnNqDstjWiSVvKgwyQBknNxYR5/wnU8TW3HKdUC4mbymPwMIMxmmuEgyFWZ2sNDuF7k1wkGR4LHhNddtlUpHiHct3MfG7JBgVoCsvlCc/jrHC38plMYKLYHNc+5HdKnYEPAlWCEK8gwnMPEmOpt4S4O5JzCTT8ot6qq6f7rBUDj8xhw6rE5yrVJLGyOaFLs8ARbVDFvDzK+C7/d4dOqMkWyaf2TmmCO66s6flQaA0BCFYJz3YGCSqXZuN/HV/ZPqG/hHYBsY3MqlU8rx3wECLbZTvpKrNh/y4lr839SBaeIE4bgJlSnAaAWmY1TscDVP7Pb8I1KUNJk5yifNlh/KqU3dkpsdb5o8SbOTKon8qpQNxbntL3ho1QpUg1YaglSIVSqcLPc8lT7M3BSu7VyJufFAzQaLXQLQ6ZRbTNSmNb80wANqO9/7JhEhw7tNtnNuiLhxBzVXI3RKmu1MDwyRiOiqtxs4cJIhuqaHyQTLZRbUdhbI6qrhyyMzkVS34eMv2Tc0eaLmvbhzb+UGjETBVTN7p/pVQvxMeWeieJFV34THZO73LaQmVmm3sn0ZLfLs/wBV3sgpWM9NSg0bull4E92m0xK7U9xsA3RE3JJX9S4mbvy9E6nx8ZpkXgZIYG1QbTBMKAIJOfsi0DG+WGwdyPIqdm7YXRK3wGie0wVTNiIVJ17Ldv8AhtsNeq32CoHEObdMPHhJdJAVIuE+UM/K47kGyfctsFvKFTFHr1XEg0hwCNOoIcgar+L0RhPaAJQ1F1xSFjb17wco2Qm1R1Rpy9gtqEGsw6BNk3KNV0D3QaN1TyUeEyjnmm1QIz5Kqcr9MlUEcTRdSID2kqrTqXyTXtFRtXDHm1QwY2uIgR/7VapM3Yg1oeKfUiU17Q95gLBV83AdU5jL3ZJiMwP8JlQSx0hMHCXQuEQ60rC2HR7qnJEqWEghY3Q1+UrCeF8hYcNgWzMcinPwl+Zv1Wl80C03g8kKZGqmXNyKEZZIOYsLoPoiiRcIiDswtnv81qNoeFAWJwaG3lCjT3bfMcztjvxconEyliB+pF1OamoznkmU246T+KMwnWZjdij291SZ2eN4SWfKgKZNMEPQq08dekeD3zTKoeWkgEWbyQZGJ2LpFlun7xgsfN6eia4AhTSaALyqjTDqM2zTgXHD5YmMk0vdhfDtEKjviWI/KaGYS6xTbgfdHREaE3WMPpgZ3z5KBK3rNBh9ldpDp4bojO67KLmic+axGW5LdPLKo4HWKN4b7oDhIghXU+qBQhYn2jqVTZhvKaMgApdn3522hCjTNQ56IvcXHwiym1rcyVSJwH3VTcEXwt80hVmsBkYSmBpqNqen/pTWbUe030jNB9YOFPdED8psdZuq9KGubI+pcOdk06rC+QZ5hYgML4nVVd2Wlw9ZKex8b0C2UKk+XutzXZnywGfVPbATneYwqIVNshoHVQ/y2izcyUXN8mFoGiEqjB4otb15Ju9l1MRyVJzz8O3IKm1rXAuaTpCqDUH8FVxTABtOoT3hkRLUd3JITruGme1zw1020CdjwIIKVHenY6rUA01WOpgGQ8PHV04BmSvjvbh90/ccDyDlGaqbghplxEAKrSP/ABuM1S3bTWz0AVF9KWW9VUovg3KqOBTzOQ5FEXqOTALO+ydIEynt1ssUcU8ljbAddA9FUx8P8OMuRRYQx+RylArDjZgIE6I2NOxCLplW4rf3UWhFs2H2R5p7cnpz7uumBsYPdUH+SQUQjeOW0bpkfSmw2qM0eeaNtpRCPd3fZy/UrXn4bC5z7zEI42lrckxlMYgeirvNLd8pPJB9UMwiC37kL45qOMjQJ9F5DB6nmnG9Ug/0hSXQIB2NIwiDK67DsM/3VbD00Tns88J2G4RY/DNtEI4KZ6mUWMcPqtKDS8ZxqiQjUfETqfRUQ13CcVkyicN8XqjKLRJ9oKqNzn3Uxog7NY1RpUzA4ozUZqnGBxtoqW5a1qPOwzQOqs5Ys+SEDv8AkYPFlh3d5t7hHA0EgHMnojTeMcBseyovgMd6EJ1N9UvcQ1uf+U/tNbEBDWy4HWUWlwbTfvDHm5JrT/EbhAuc0HQBU4dU2fLxKQScgpIRKLjZc1hrBvJqGTlgydwprpupYWnksuKXclSZTIBknNOt1C85cNIR3dUmLO/db6pl6+2qgYZsn5hpVVjYIxN5G4XZe0EBk03cswms4ncTuaGGfdAu4skJsm6ZpwzuqJY/ER0aUSfOz0lQcIIRMrqqoiAnRfuzX9PEsjQ3lpBuhV7PjNKXDROqmBi4gNdFu3gWdP3CNcVDVp/7brs1KRPlE9Sm12/Aqf77XVW+Ds4AiDzTg3+HBTmicNlZfCdETqVchBrZ1WFoEyjvqvFqgnEQnaOR1TSeRT5yTguB41lPc5zSNbf4UVMbrHFY6FNeOG6a36gZTLjInO2ap0MRb837K1lDY7ggSZ6riibdVF4HSE251OSeSW4j1TxexUiE/IHJWCKKKms/xZRDak+08kK1Ikw12RTqUODAMIsefqqLP4sw/MZ+67OHEE/Ef00Ko/Fot+G4usv/ABeISS7qopY3A2VSqcNIWyKsWPPupqGMgmU3Au1WOoJ0EplGtUp6Blp+6e8k4pnNCDdPGR0TplOcLhWudjY4lTmWHY17YKAeeKEMTuRTcU4bIysIKxFS5B3qjTN0EXKDY5Jrsx/ZMceEuxck8Cyl3smudBTWiE1NKC+K/wBfAlEd5pxREH90yqzA6/RPnhswCD6J4dZgIjDOVkXPbu5xB13fL7LjmpghrbnVOdQ4ng59QqBBYylLjqmU6eN9gmsdw8Q56AJjn55HiW6Be14nkjVO8nNOJhoTjKAOaqcvROcQYgo7BkoOIPRF52caLnBo1QYwNGwRAViUCqrjwsKrTGEpp4XGDGa3LoJudF2dzHEDS4VIYScRnRUw3eCR0W+p4hmPMqGbiZQa11vRFzQQnJwTlFZ/gWRBFrJ7LsPssYyg6jbKwGTkqTi8Y4jNdpLH4XiJmeiEcSpOBwRAzRdVw/K8X9Qh2ctpYeCInqqra/A2aUfZVq9TMbotuE4DAx/BnqqYMCZ1nmFvcENN7qhUPw3eyp4yH8Mc1BOB4I5BUnPiY9dUWNAdTJa1xPVPdxNynJNMg5qD3A10SgTmr4zyWqEGdj6tPFMD8lU6InDBPPNcyUx15TJ9E6mROWhTnWxkApuI3kBaiE7QwrpwIhoJ9EMLbR0QTUFFSfAGu2Z6pzbOQ2A5hRiibjPVOZQyxQFjxU2Ng9eSazs72vmNU6nhFJmIHI/5T6naOMWBz5K724BhAshuR80/uqu8wVM5/CobzO5uRMKtI4cIm5BTN5FO3L/KhrcTrTrcJjsZpQ7imP7JjKp3xnhnCqoxEZddESL0fcJjxyKMYXc7rCdY6oFSgVLoJsoAhZRzVoW9dLvIPygBiNoyHJQ0vd7K2dleGu+yrTSa1wecymYyCyWjOeqDHAxY3CFSvL4hA3hWUSi04k9O2AqWz4YQc1Gm6D3HxAUAPa2ThVSqwVGmMpantxm8/TEoCoxsQJBJRDhJcb8lVY5zjAbGf906tV+EWG2eqNMhtR5veFXD/h20XaHtGHD/AHWBoFR5J/ZOkvpkzpK7QX4s+iqv8qqU3RWbb0VKnUaxkQReUyq3CLFfCwyCOaLXR9tt9gARrP6alNy0Giz6IuwhQHdES3ERBxLEGuB0UVXa3/cL/wCIzFneEQrqwUx3Qt5RWFxHgWQKKhNqtjVGm7C7beU8PdiMtTz2gOb5XWenNZU9z7Ko4Q558oj91SNLzxqqRpbgmb3PoqbaXwz8T5earEYqwGLmmlCXNafLyTi+/lcjTfTAcLqnRLg3zaFCvcWehVw7yMUKpSaC57H+uaBd5cvZYqbmk+W64hrb7KEMroSgFisFu6QaM9fVBottC+yw4ejZQwF5zP8AcokxOk/dXOwHvh9Jjvqao4vBa/NPHlqKs3NFpuuMkFA7WNDcZMSqW+wBwNs0HCCJBCrioREDIHUhOLajHQAOSbMgRYLeODnGDCaaRbMwmVIIMfuqW+NNsgjXIIuDmubi5aJu6xiq63yLs8jEw31VAVG4fSUKPaS3zjmpDDiybc9VvC+pvbQVAix6JtbC4WK4S0qI2HZjaCOW1jdU14myYfM8D8rG20wcv8qnZs6D8KcTuajK66eBNI05u0/ut7T6o03dPBz2A6Kk7SFGTk4bJQIOEQeart4av/ZU63mChuKmBKc91RjnTicJvkhiaMcNbZblrahdM5IYA5rA10qq07wNB5yqLMqfFr0Tw2aYBkXTHkS0N/sn2LRf90HCMMHWE8mEXYREYclILTE80+WkaIlF+GdFfZOSdTMaIZ6JjD0XZ3atVEaBU0NFidKnZOaHeK3PaGuOWRUXTajJW6dB8UdwOBByTqYGoH3W9pcPMJmGRnCxPkzpbLLJBj8JuMrc1TaMgecJ2+fUaTa2FGowMcsNVurcN0Q98/UqjWQwpxdxJ18LwHEWVQGHZ+i/ozTALlSMlHdMQmR5oXueSqUzGKFV+oJz5M2HghA7d7SwHzMUJtRkgI0zBHiDXZG2VhKv0TZloTw9wf8AfQLclz4J1CJdiiJPNOMcIzUMDCnVHuOJWudE1jchKkdYzTiZJzULERNkFFY7ZUbMQghVKZzkL1Tf5YT3dBy2HvnZu2Y37HUKoeE2oxrmmxUJlRtk6k6D4jo4YnqqmH4kYum0bKre0Y8XCRkrdOSjiiy3jSQIMRIT2uLADzui9rWa6aI4GTrkVALohC0O9lvIvkr7YNygE7Mp+Id+mRNvVNOVVn3X/wB1P/sif9Rn3Cfz/ZVeR+yqDn9kRtGxtIY6nsEahvly27o4HeQn7KVCp1m5eyfRPTxwjhOHNV3gB8KKmG/+VvJLHwQiGi0KAZ/CgwG2N5KOIBhVTeSJjkVi0ujF1LlAVlyWLNBAd4OEFU2WDHD/AIrs5/8AwuzH52/9Suz6Vm/lN/nU/un6EH0K7Q3+Yn/NUd7iUDrTP4Qdof3TtCqlMyD9lUeZdxIHuRDHm2h2Qm1M1F2IjP8AQYgQVuZMi5UsV8UeoQggLA1rZvKExsvCaE89NkZlT4Bn+HP/ACQ1ov8A+yZ9FX7hU+dX7Ki7/VPu1M/m0j6o/Sx3oUWZ06jfQoH/AFXe90x2tN34Rz4mrtDcnpwOapPPxHYeu2yy2RZxtzU7WPTmfoJEIiPpQgBNaM0HGVzQRPcBQGQ77xk9Vv6T/wAQnfyaZ9lT1oNXZ3fI4ehVE5Vnt9VUPlrNcqrfNS/Cw6OHoUw5mf8AcEzBitHqnRAeY5IjNU5G8yTcRwzGncuro3Rp2OSa8SDshA5pp8qjxxEKpTgsM9E8yH04cMivlzRP6CMwmOQ0KqNTdQnfImMp3guTXZrlfYPmyTMZweXSdt9t0OJZJ7HEgpr7a7YQTTkfFOwFA6Ki75VGSLdPDKPcBTxkU/5oCoNyGIp5tMDkFO06oeAYV1msk5tnIO2kIoaoc+4DkfEldPGAzKot1lO+WyLszPdAROaIQPcy2FXVjnsuuEJzDZaFA7SnDa0qkLti6HitTeSHfA1VFvzJvytVU9ETme8Aie6QmvyX/8QAKBABAAICAQQBAwUBAQAAAAAAAQARITFBEFFhcYEgkaGxwdHh8PEw/9oACAEBAAE/IcIExRgDDcAVUQWR5hkbqA0TS2D8osWxZctnKX0MdS4MduKzadoIsE2JcE6NSOn6KlMp/wDEZcHoP0X9FC0AMD7FlbcFXmOMRauKNzLLLF6MuXNdBLjMwncVwzlCG5kJWjxDicplOq4Muc9PJDjcq89auhHf1H/iWtwLJ95yVkLTO5qxM8moGBGcxbzGLjHUvxLlk8IdEE0kZz02JqKl1os3KsehbZnFuU2gR3CXBqDIjUPPQwfRX1D0ej0bXmKY05EIKz2ja0lBVQ2j4ly4hwxCcdMMwlDABLVEtd9SDSPSVbOCcMBmFyqU0+4QZfoF6LqEEv6a7fQ/Rz1FGz5lRIBm5nwJRJfwltvWMGJEcT2hASOxjPEtIlOZ7S0JUWZ6I6P9XTdRi6Ol3Dj7gjrpUqDE2R6Vv6iYZrqvproIzQLmi/tEmJg4/pMYYTKLctCASio7j0xHcGoVDx0e5C3RGMn4mdue5taKyi2EOSOa4ckn+whIvlTLR4lHPU8ETjzN+5rT8S40zJAzMQZlSutYh1roVX0rzFfk6FIYTeKxS+glJWcSjopOUj6S479sJxv3h2P4hnZuibtBLopzL+Z54d6eSW7w7kO5CJAgKEV5JQZM3Es8UYm56oCaSfE56pHOvoJi4b6OuqOZaxsW5aMxPHQoh0XT5SaKbcfLgmEmdiaf2pSwRzOUtxRFKgy+i4MuXBgzmE0hqEJcIFgoKZTECy/wHxELfhZv1PEvpgv0uOlw6VicU76WM2Y9UscwKSMtInMpETlIZaeoRWHbmff+YvBB4ncXAQQlxPSmJ6goQkHBYh1AgPTVvptMZTCHUMS5Je2Llu3+GJUh0rodKxKYxGDiKUHRwAgmGZQfPEuxce6UBghll9b54hWe9sx3e8RuyAEvovpsYrpyyyCR+0XxO06QwO3SJUTEKmG4Xq5XmJEKMMST2WVgJRRPodpUroT2SjCy7yYq5juSujCVncdQ3DfOYplFaD1FBhuFzCqwb3LgHAiIF4Ye07ltly4segRxkygmPFcRYRAcQLoolSoOJD90h+Zs3x0RVg5lddwRzUul4sFbSzgWOx3Ed9jfuRkZu4WQ2dNJLL2RfAbqAh9wzBmJX0sJSkMy+zvGo2MPeMIwp6OPpjlho7zG4CWl8RBDUbWHCO3ylPPNyZV5VyyX0KOxGbWFxUThO9B8QXEDKPpuIbJQA1UvVwLkkybZzBY7l5CXAAMkpt3jIYAbrhFZDd2gLse0pZ4zjgOZcubVMQOwGf8AKHR3oM0Vr7zZv17QkgkEw9CJ1GY2RcU9MrlDBAnETENzmbYVRR2w40EyNSz5ocW/BKOlOOIvbx2hRL6JIzcTcV4jLqO4gnE4CE0tZeA7zdR7c/bpc19GCWDFDU7rhZzAugtZrv2pWlmDLVM4zapFbb7ckC0Dh6e8F4HC7EtcjwlmL820x5ZhTDEyUXYFOOyAtufYXmEuDCSSTulXUUQ6GQbOIlB6EenidQZMqoc+CUQL5uYOX3mJq+zFpkPcykttly2UI7LS7lmIyyCSrMEQWqIKqB5h0x+bS/c0ADg4PCQvJhb4zexLWZw3iWzMIsvcQ2GnUyKy5S1gkLJubvzEoYYXMslwkhSU5VBTl9E5qCytWPMC8bKp8FeZWTmLWxdo30EwpOP2RWvrHvtLHLPtEF3sS0fbmEsK02vzGwnVJ+qaQYQQdIDuN8xk6el7TBV7woJf0RlBXIKiU8H7x8TQhTKuT3gGXcXowwsI8WQe0IhLS5R0FzP+PsBErDxDB1+NQ7U753+Y8HikVhMu70S701xGlA5P+XcesSVvxEEA3hgTIGnBGKSzq+I2j/vExcMbP3jtNTRj5los3GXCZeqU9c3C2pXui9LNq1dHZpi4PNm2wx37zZl3x8yrbWzC6l/ZnZYuM4rSHEVMJgzVZhqEl3NC7ziE4cy7IPdH4GceIPgbhJB0inMNrcT0hBVYxDg7jvHIAFjATB9mIcCVk8E4jtveciXcWuixcExnjo0cQGuCztNNa5XEUdTizSMvRNFtV5Zak201DADt4uHKLwNj1ArU0Oh15RWvhxsf3lv9VyCVzUSy1l8vaAo2YcLs8ktQNc91rslNngh2cXtbLIM8GplUY4R+tOawzgam2iuYdcqy+N8d5UBOXEKLR9kuL0wbf73mts7epYzUO1IJ3oZI+wzTPvKCZWXN+Y/dMvZBam4vnkmFLHTMsyTb+kthJ0B0vDpCgdGomefMt1zNY1FyYFGXcczToL0dZqmqFdgOWVmDqmGG97cqJ3ZgLotcvll3OONZ84Zlgvvb88TlwQ4ajawOqKs9kNBI0FOK8SoqwU1e8QLjY8W5jMSceDxHxhdeowpDZ3i1F3nafMvaAVmLHimVSg/iMEfy/M1G8QSEaDWtX/MMBnB/PMddBn3Kr4bgOWJv0pb1MYQcjiVN5hqV2jcpcC3LtWZfaA/g6gt3haYeRWefMUZ03DXZKweZThNZTiFWVy8ww3PUUFk34OIXeebqdcQyOlZGWVge4txj7Y8w2LNEzxeljNUCGSnCud2L3zkfNvaWqDDkWHqWBcNPB8xKSUqMpzgw7x2w3bEVlWWpX2ygGlWWn/kb7FDkmI8HLM4aPFJL8ltDUweWjuvxHKqxJVhXi+LhAcFVxAVGpMqmSL4INfqTeCwk4VS3uJC8VB+6rU3JgNs8QwOfNsNfi2efR3gWigDMPuRo2ZNOYTv8WS/UcEYVtQPsPDEwi623J28BF7Ye5jNf6bzD2RE3HrvurnUNXgGviWduJsXFZLhZTPPEl/WbpcuJJYM+nRxesvR1nimnHWMwDESoCsXFXil24igWMQ8N1yRz2HTbl1GzInDk/E0WV8j1LxNsmWb7xNZ5rqpj1eQx92YWseDP3uJuAcYqFljPkRJ0Vx2zBkyXbOPmLSUDCW6JkQC+anKFeoZJcD+VXi4k7mtsPZYElUJDW+K2Zl6pteR7rGpwzfYltFwsszCoVg7yqFdRlecYHLE7bd5dYvybqPOvK1Htbz4ZjHKjGOoZ9oDCovfapZnJyReoXs3uHYnH7wn26DiOi2VzTLllf0y1t7U56C9Bb1+ghhGQ2PbFepgWprijOZQVbx1nwz4xDTORuOfbHWpZcvePSmyAhaS4H9uZcWdyWR9+JekI1DaBqW1/EPYN1Uw+Jvbgi4TzDPFfqiBW1EUCmRzVMqUnGzO4meY+D2iFZsW3X5mCeufO9EBGzELtMMhMMHA5lPbFMt+3xGODFrLcrsTMdCWidyifBTcFWFeJU5EoDrzGWxbJkwneYfu7zNve2WZxzxjUOMwB3KlIIIheiFcdBA9MdQw0v4jHBF9FomnpBKlFUypeh48niaZsrn9nqUj5obwxeZjdXjOPEfnbRLuthdygx2uF6Z1HXERYrLb/ABBxaihllrASqUxsbo4hNWTzdy2fDb4GFADDoqIVVV8xiJfUppu/OCbFVWeMxlhzuKgXwZS8OL7yzBzR4m/VcUNViIk5wx4mSpxEDM4P35Y4Lwu+jHzgoLVmhmFM3xxX2ZsUDkyTHmOT/wCE/wAc9+SbCo21Lwap2qWxeU1RrzDC2nYQRDWq9fEYbbpMsBW1hnKaxzzBqZozTCt8u0Nys+5UIp7TNuXcw2eSXfhOeg9Lma5o6B0IBRCDd6a7y+HIu9uYAGnJKHe/nEo66105DD7GbGminH9DzCgu2uYMrBFo5caMMwa7/ARGatvm4YoVhaqniW413hH8JexLnf0QbyCl8xFreXy5X7xxl7zv/cTHmldfHeFB7c9plI0ceZRpfkwzbHlszHEV7gCqgDV3ZlMoVfxz5SoUOKNFRbfbTv59TObDRqVqNANiztjQLV9uyBsLmzbl5CW545isCrELMTLcIsLAwH5hrU7h/coHGKXeSHKQi0u/+qJ0n2lj3eI4F0yJ8wjuMPoVHQOpCBGOWmVbGuJZTLQ4b1ABdaeT5QsRVFMMFUI5VVbB3K5omCfhCGSpiE+Gd/tD0fvG5cVj8ty5BV7dv6hUZqxz5joJmU6jD8D7f6hZ21dt4TaEXZgoNK2zbtaQtTVPMIAX2YrSIiY73FJkgUR4oqcPEv5gIbL/ADKPgzqfoEMayAPu5YOLIS3i4qM5nUtS6i00sgjcM9GJyfwf4nBV+6PDtr59VPDbmNZPL3DnGsJKMaI/md9MaYHC4Y+hz9BFCPM/mDDrgj2mAAyJD4acjmVEqAQ77KilxD/Id6aqNcqxwk4nAA+b0fXb8xGtcth8VcE0RulEywLXzKYJaHBOFiJWFqduKKjQoDPBviPlksznKuGUslXZKA519vcApuo5cQu1Ih3V5roStaiGoe0Rt7QkMwFM5QqpsO7+YN26n5QheFLHmFBL3Co5ZBw/3BK9JBkPcoMCRBdn6IwvWMvh9x6gJoQTcW1prkmOaZ2pfjmXj2IBZ+0WNr4frD6uz4h2ohqE2T2BmnWM9IaghUzdRbzqFnCu1aYF7R+D+oSQS1cRzTLDGr6r/Ca3ueQOJwK+/D5iHVlKHMHjXey2WV3CKmHYJcuTIOKnmUsIixwO7lYXEMXKJ8Boq4Altcr51+0XpNWZxTiNVYHt5l5HuxKISD+1Gm7sZePUaaLbMhEhUHT4jarXaKLEJK3F4jIHwfEoqGXMCV7IqsOMK4N0doNv7oMZ7+BN4A9u8Tmgj1mNl0vwRm67KowgniQw159TY2LxUyhA5aZZBYaxm1x2q4GmIOyWcQ7c92mnWPoiokco0uAB8pQKJw1UVzLIBgTsxcvRBp/UphtGzuTCoA5OuvcBqw13+eYNcLNs5TsZz74AtjzAe5DvL2O85agl1T7EBptlWKc9y3QW2Mi9mpVbL2ARNUGqc/2il5BoYdZYUjxtL+yJ9q9OLXWont8ZNfd2nk9fDXmpR8Zj35ljRSmHiXe6aH8JoGc1a8Yghs7Rw2WYMGn+xGDBTl4xK6pb/wAw7SpYB6kVGNYdo2pa0Mtfiea0OX4mLeIVoNmdy+bRYU6r2j6bmLpKlTnkPZ8xIini7nDFXMAshvD+Lhuel75OSmA8Zmj9MPReLijFy0ygJjn3AsT4lhLITL3lsqufcuttYWnGiBRtfse4A1+AGDx5mFvsebqstHzCeuqLY3HWjxWcfyh7CEp/KJSO53Y75rRV3RLVJduwvIxTf9nly3VzPmtLLHH2gnKzlTZdVRfPMN5WAe7kqYwBVZl5E3acf3KPATxXKQhpilT23LJSmGbStXvFbK9dH/HuYRorv9kutxDnC7/uOMrD5hmoWOanhyrW8ua+0qxZaovufiY3SjwL3KK34lNu1xMmyVFZjiuoRYneQc3amM2a+kLUVdIJbcJuyXaMXzGMXaeE+1ZmE6GKRWgwIhpmkcp9alGU4s0lIezNFOadCOLtsTz2Ku/xGqb5Bq3xLNcroNDG5ZkGFc/3MroDRcCAHuHM7ZmE2QUK+GBJd21vfYjFvP7rxGeFU7qnUu5OuzLXTDO/jMQFJS8dp3YKNHKWrN5zmPCg2L8dIXuNEwWTt37pi8lbV7wVmUTu6PEe7zwNQVmOqc3nPzHY2lsdWGfxM45Pu3LMpuFqWZ7VEEp18QKx0EIMU4FGvusxVQ1DucxRxTSWlwbBxGs1dmXML87lFNDtgNtF5hAOIUIeEVBBx7TRLXPDldxNsB6hrsblgbpeLlJnFI3WeOZ4Mwb522zjvBnOJUJXa51FYytzfpUos1d6Ks2yiJvyV3xKisI9wj5gEJxWcOLxMSVpX1faV7oCi1S+u0rTGy+23H4zLOFCBmrri4V2/u3FQ0fE7g/uRCDyWbiNSndywkLnVqiKMxLFFPtGS1ZVPiNvzMS+gnb3jJbACHbjPIXj0TwSBIyQghCFIPMubZHqAQ4Goz7tQ0zN0FiOHQmbyxwVMEG4Mcs+CZblyNxMQEbQcoGEgKI1rulSipkeRmMm5d4PEzpNkSut9pVOjd8cqTgFYjv3AdjCwcubrR/3mUJYciL01qOy8RHIHFYLTaMGVbw5jz4oqzD2mdujz5jg1pPRbg4w2UgkE7dTIGb/ABMJQrxKql3UKdwGiCVfZ4ji5Jlo+RxDda+GFxB+IFUD7Ssg+8V08S7eIk5ZZoi+Z4wUJJHCVtM/tswBGYPfiJ9njpmuaOkYdGO40SuYGLqpRthCsIzEzMKIwv8AETWtnVsp3LbedVDMEt00L0eoG19k34RGneLRQSEHdbk9Ssfkoo/xLMBk379oaJWlaQlnd2Yq8SqIc7qJZMH/AB4lPRxXgXx7iiOnd+8sKE7eoxtKcEuUJc7Qu3tKOkNVVRdrLzmBdCW6EyQXhmDKTGiof+S1qCBAgQiRET46cfaGiZ10D5OGfBi6yfozBZX0UDB4fozKHEtUKClzcNKm25xCCJiC3tz/ADEKJXeVL4no1HELHFa7EviU0GaFrL3lCXZHLEYeUG8o6v7S5Tbtm/5uyVKxdO1+YlWHcYlrL7VuZzcNSouoYcwDjFSgcUYlgMupRHPzCEiDwAnwO/3lciZbHmBc0xt06GpRqFm4mbSVCBAxB0K4xErGCdqcJOzudpbwCyK6dP5jN/sSrvp7zF0rKhBZ661XRJU6/YSroeV7PzB6ZquVKUV099z9jikuwpi6eRPwH6ygK7Uouu0cGLfY4uBDu/BCmA0DW2/EEKxzU0k5o/HmFbVj9YIXcMGFum9oRe2Wu4ylcQjl9cB3Ncq7p/COW/wphBv9d57fq37z/KZtQ/OMGPEKbsnAToaL/wCcxM+iEl9TLndd0AI0oPu/hLSW/phS+XQevvrddLbqoS8Qs3zHiDDF6mNHN2QkWmBSoG4YNcWdyYFZGTh8S4tq6tXXaolmuVQqnMbdez8eYDMUKS9EWS6rmaWJcKCGMa5qIPF4jtSvEdhSyhXVQwAhBqEnTCOp3DES73/eG0h7cGZ+2wZ/apaAIGtZr+CblHj6WAxFOX8T+szH2GkFpfeJXqE5yhhf0S5lz2lXfqJn3+kGmmrn+aLiCkHkRF394z1eOGYAU9pcQYPub6fM9TM5h0HMqEqAIsYNwC9e75jTcXXHZivESoHF3LQWezguW33fMob4N+o3xYdSxpydo/hpF/7MXeaUyEi8fRcLZ7xHg9yn7Q/6M/xF8PyftPDeyzGJ/B+kX16iv2naxv8AeZkY/lKlOn48WceplBCLDkbJVS/jOd+42LR8ywKFcb/SOINTCxv/ALGphxDuOTxi4gjE2smKn7QTG4o7nRHGOlwz0H6bnm4I4YdoDIE8wueF34mac3E3B/WBOXetQoWsQn8RtrHQIBN0QAqj6KvqrbMHahPzDc+7+KAmfss0vzCAPxhnKjwf7gH3Ov3glg/h+Ilq9rilDy7v5Ielsaxym+w8mj+J3T51FVHvrOPEWWyuW68zjmXC8frHl7hekT5UwCB1KRF/TANq5d1BKCco3VZlOLCNys9GXMQmPoHohU3DtO2mJKbn7ShsrW8YDwzBcdiWeOjX0PSov0hwuJaEBxPFTg3EYpjW0ukWv7e5V5oKlBaamvBbPLDboEIyYuWSrRxv4lW9oYy2kwIuThqC5V2SjUU5iQ6hh2iZNwfoyGavrfUuoZcVLm0BhmQ+5dtR8Rt8QzFy+ZfTMtDoRxpwISLjoa8TiqndUIzV8s/riheGQqc3AueRIY0TvzBWpQY6E2xmWrpjmoBWs1+s+wr8QdK25Zwae85NO8pqejDTDnwzuNrw3F66YjzPEEsEl/TcGKT3EiEqHdKiixRwzGYQg8YSePVfD0CKY0WR7mLE/EeNA/mOW8K6TlmphTLH7XSN50BKNHPqYAqGWcF7agLY5/BLzf5cwFP2hSKz4rsSjY3LVfMtNLOUmUUQ56Ghtmq2chEkCrNFZg/MD3h17fWPaK4iIZek9YGBIGHixCyD5myt6g9r7mrT0m3WL4lr0eqzxx9GpgXJNhz25n//xAAnEAEAAwACAgICAwEAAwEAAAABABEhMUFRYXGBEJGhscHRIOHw8f/aAAgBAQABPxBaHE4jCIaTO4upQw8IIFu3CKQs8RSiW7HKRbqKiEY1ilRu0xDmKfp+Aq1UdCInkRvty8VnIKaV5YlfzAw+4QW9/wBEZ+aH6y4HIeUgxQ2M49qPs6giV3NtiWs2XLolH/wLOJSsDZf/AIEuEDZ+VhA7GEAlIb2U6CasZVqmMWGRioiyzknl4MtWLuVHiLUSLUecwFrNFMbfkYoEoLiiDuWO46WEggRvKPb8TQ/FNG3iBqXwkFKfEo9hCge+ITroqNxwsx5wFcjPNCbAhzEUCVT1DnYBGH4qHYMslkIvxdkW+vycx/CAFDlhRwHiGLVwFsFDAOIG7XcdFwSgC/UZX+oCvAFqLaWAnPAgXAXqNH+Rvv6TiEoOYdDUWy9KV+A/sYUIPhErHtP1H9R5B4n1kx9mx0+58i/BhxBGGahHuCbrqDYO/wADS/BPxyQgJUCE4Z0TuGoM0X+FGvlAnhqsj0AUcS5UW7xibagdx14J5gDkXlgsPccUQFe57wz9LFdMSDVIBiRIW9ieJF6tVLSa+1f5HEs8BOkqrNdZTHRCwPPLAqboxfSNVWDP4iGa0r8k+4wcQLXxC3LAZYl2xhD3EJcGQSoMwxlrDSOcIWk4jhBOAM2ecoqUqrAiwDqC/NnUPWGMQ2oVrLWNFO5bcWUPMAUaeGPWleosi1pYxnqEbIgFkOwmYIB4ETFqByNFBu8llKmW/oSgw4JaAw6COEeY8ZyPxP0KUMFhibD8NQp2pSs1tQ5mqevwEQtgSrmCWE5Qp7gDuFoEBUFsSMDEBKLywRBytL1EaeJW2y4htMIa6HmXjtOIgbLawT8LiVk7uGANRaci13IjdBpAe3khpnDoyvsiXRZZjutxsHzgTNNoZULzwQpMFztW3fuKQIt1fsiZqZf8degP3hDc/wCpfVGTr+IhWB24Fg/DBS8lzAMaCnmDWu5lqMBAqBLLBcqVGxALiXtMUgpx/DxF0KiUBGpFrglth9sSLGmUsWNIClGoJcMjjvcPogwMCPcqyjWbyIemSbPMol0djDdB5co3woVFW87HEL4aiOfXTjmTl3LFMD8z2ZJTzoddy7UGTZbN/CzxnEghgx0p9S8fnVH34VLT9Zl/EMGH3FPKJv4ogoUl0kpWBzKQBGEVExiUfhaIJFXXNyzr7YIby+Iiq+CNkoWD0YiBbvmPXKFsUp/qUmOxO2e8RWpYE5gDho6pu9QEAgyiIN0TsjAu4fBO+G2FK2Ju7lLOeMJXuYw0QNSy5xMTE3DVRLSG7/ENA4ScuI7JcnyEHfBQUax3uUqCJ0xhImix5lsLRqAtpe2xMq2RjhBeFIQWClF+AJBFBFBCGKwHKruOMKlhLCwhGzFcjfAuDOWa7Ahn++E+i8SntYPSwB/IIFgl2A/GzFy6492cmPttMecbUOOQeIKAgYFeg5ZbPxeQgAQbL7E3CyKlsqBsERvIiUxPKt3WfgsMINS4yjC4CvmGmW0h2izquot1UsyKktDsmdevCFdK05N1pcbCxE4Sob74D5YUDzTAwnCkbLt+CSdQU4xFKsagwipytWWWEKmTrIl/EK+Y4bIQqiBOECOCA6lcMsHhLLQfLC/Ad0D/AKQa6kGxGN9V7DwjZSQJKKSisIocMghYeECWEqCOWRNaukiNyNnnhrIsfwEj6iCjGxDYlHHaXpsLiHVx1ZwrLmQC6qyKSwVgIWZfHB8sPTyXZCnOwCmFlWnbKVUvUpM5g9xr3NqGJze2XBotj1Ah5Udyc0SqjrCBPxBviEIqHhYSo5ZVJ6Q6w9rEmiJCJ85QH8lUUV5F3KRNEUulNXTLsEtVkW+AlbEAFL7mfNMypOZkCsam4DBsQ6MetlBQNQ6gLZz9RUCfMLg7XpEAz0eJVT3wfn4HhiaD8TbGg7IXFHAUTllmqbSFoUwCVANku7cYhglPJU5q4FkXvCEBvULyyjiaYMW1nJSpawkq4uO3S3K5FBeEJiroQnBCVEvZRdzKiYnTCC68rXcoDG3iefZxqUyh4c2eSZkiSjuJUvu4KW4N9theQljG9heEWSBFHGFyyXgpRTtQFjxsRsIKQ/uKI2haLy0gm3rFEV8hRgR6l6quvyJefxOCb4nSTNgCEvUHhZ1Dtgy4dssybVA1GYjlGLtFQpvz+iVqmACWitiSzIcr2RWx50e16IRyYOU/jmdCA6CN7IL4nA6xllYxuOKgZFBciCxW4lK5L0+hTqeghBZlN0U5tbLriPpLpPUDIQrPcLqDpiQGN6lKy9QO5GBqwov/AHZbdCKyDbJhfafu4a0D7loOZ69ic/UdfPgMI84tS5raOiX0x9VBsspi+Fi0RmINlZdViamkVgHDBZerQi0MQnEFNfwbXf4xYp2pyJ+AbZDJC8uyaV+eQRCinAxjjLNMuUBH3OQUYYOrggkOkTyLgyHBdxSt/bdSCrEeWNCCLF2ukzBo8Rk0QX6lfkfkQAshnEx4iUAdsZ8R02ZfBA5C5tF5RwjIjAfbF5JpWK7R66LCTzgmz4gjpTL8ITl8SyryIWAg3OvuNTn6COEC22oZWNBpOBYWPoljw2Zld6bQZV23iVYT9REoUMrgsrdjGC9KEHkvcidAtygNb8d3HhJFHKen2R1XjqXKlUBUmhtfiUXCgi36FdsB2UpoHuxcWCIAw67pMpTZjn2xjNPBezCU9xx2e6GAbIRsiJSVBGMFauVAoAjYS7uvuE1Fbg2Bh1B5qpZ+PHgD2JR60L9ExiMPlQxS1rBWLRbDMI1Wv4NxyXjIerg7CGEc1OK6MQ+7ZfyFcyw8nLgeslgXU24pKDFQXpLwCF/MEVkMEzbHA1RU3Cq5dMMZgU0p7vpFa5ETyX+FiwCXIROEZTCXp7OdidKqjDLVYc3YdqGzrDVusW0RS32a8uIq8qoB6k6xgA1b3FBSLgPQ30B57ILqAbfdqjWmUZdPS9U8KEwquFFanFUScz1e6MPIMOg2YEYoDe1qiVZU1OYzYOCHqVjW40AuXE8CnxkDiDkdAu6piC2LNoovgj7qQovYFqhgf9/I6cyqKCQPVCN82NTABh23D0Qv5uvgh2gIV6htAIwY+o1tKOQeSHMcO9TncpdVAm9z8A3mM4Ra4J6nGZ5dtg5boU8yjNgXdvZMpkxKfKx1MMDDp/ZAQbpIp8Qipjyuwt1QI+24lvBy747Yy/ci22GglarojoQo0B/1JuA4plnQgwXgprAoqA33EnPYwm8GllKxMIkPOsDzEcw9RVcvoJzDYOxc95vol9lQb3Si6Dm6kWs93UpdOizelO2PITEtfrOGiPO9bdU1s6PZB6u7YIbrOA5QtwF5KAlUVXcEWN778UvvtjsAAeLTTYAFoWOlgSDVaWlJ/ZHKK0rkTjDaAN9HBLK1iUjLtn/+nmWgh2GwB7jLLH+OAQXOQbsaYfmA1TO8YUz5IQW54i5JtiNJAR2KDCVuhoefBOlYBdyjVCyjle1Gr6iwdXYn4LRHhFBVBywWjQEb4cMNDTV9Roe7+v0zlohhXEQun5YtKc/hmgMLIkfhddLtOg4YEbmeh2Oxg08QieENbqV2dQNXMF1FNtmZwlFulvJQQf4pY6PlI0yuas8XpLgqlMRioRVJAIh7I9Qo/lSxRryuslVKJ6l2CUlGgnVy30yvpS8FIQNVtevqWAM9THnzAaZ4B5iKHK9K0wAOSwWi1QSlVRCMAhLF4cpClioZtlB/tHXVB2pchpGLbrLcw8WBBAushbQR5XVbqmExuCrDPDN+Fy70Hkyovp9vcSRKQUjHhUCl1d5uNLSpVCnogCAZgjFP+zbscuZQDTDeYFOYhyxkI49QvjfEFIhoacMCWpOVUodvg8eX3GMVR/FYyyyUfwkrHEECkpJfW4RQeiJrbM5fxsgtuEpklT791cVVxQiltpAmkhVxxyPZzFbifyUEeFhro0ZFOQBSR4dArYh1XHpAJgoCl5cMWqlld6VEYgLsQDu2NyOyV9vK9G08jemPv748nw/1ENSkkR277mzEC9EBd8EQnXP+vkmgrIZ21x79MBu+PY8CvthC6cKb8F2QPpZR59dLefEQtlNCQcDwWy5IFpFlPa3uxNoRFhhrLYuFYawpWAetBiIqRqhXCsAbBr4Tr8FqjzCbqFAdI0ewgi+Ft4TfwCPG0rNK5kFZ54O6hemOBpSRj8XFpHtpaWLqOAFFCxhEBUB8rBtBst3LaIckXthnj/FUDZx7KESIIcwjZULTgxgUPFEBQQoFZe3Lpc9Sl9RymBoyCRI+Xi7uHEKmtZFcKqCp/wB2WcU5w5OlIwghsW5FOvJ2wyInWSSnQEYRqG6VlNwxi+BcVldF24KwAUqC4QBg0sHMretG2BVudOv10ZC+IYlfJmUMi1L5IG4u/gt8SvtKNWv6IYC9Y5KmgMRSS15EubUXXOvkSKA275oq1VhVRCcotudSxCQYtoSwoaIg6SonIjKFJzL7IeY1IfYAdRJUsgrdSWdHhhXcGLCVgUiwKWV3B1Lom6hEAmN0xex6s915qByrbUXY7IR59CfyJpqGXryz3ELgGO20dp6S4c2Fdd7+44i8dRdYMeldzHCp5r5ZTWFEsL4i48eBxj+M5PqGutNC/XU8Fg2Kr7VixB6y1P3JtsnH21PhgQe20NylgAom/wCFKaGTggi+6qUnEHMujCW37kUMDDUabZCIsvgW8U3Gw/mV0sXbuyggWpLuujaQBQTbWnqtRO0EwfAWaB0SvvWmPc606gQ4jQ4HObbIIp4iCMAqFfY5gKdt0dfLxEi7RxdaRZS65a8kPyzoLplooaC6fXDL/wBCgBaeV2odNBm32OuYs0UKG1KWouNuNw7B6eiDiyNVers3UpRdj2DQ9nmVIKi+/WdQUNhQLt+pTcArOSmDPTEGuYNRfXQoAOAgFLBsO1EKsL+ILFB0FwsG6iSSvRxPIsEb5zvZaFSu65H3cUgo8/6IJeixUfIGEHZjfNS1109DkCNETVVLoKACUsC1NFjhXl9Qp2CBRSDxBYLSz4lNLMowqloP1GwxA02kY7JYRSiOS0wfFFHiKlB0RWsvYuwLltZN8QgoQwnBDUsYCPUsQFqKvtchU3imrKUysCO8pxabfU2pb7hJtIQKOupqKxrk7t+Wmcjx/wAyEqWqL2IJCT0dq9/oy2y3eMtZy2ljVxsWzbaVRHQKsLIJFqNCmV11bBSu55qHxEAfuAP2SrjNAYxMvltCxN/AKr2cQq7HgafkjDCt4kvxKFo2UGjv/IME0yw34WUqdY6uBZkUFK4g1VDyWylNcTV2n7YBFNklKKCBGlZXL6iWikDWVJL9E3xlqsDQ84znpaa6GGgHY35KeXxBNfpp01RnbIe/PjoJqzXQtYyQkYeEnBNXLkfUhTRaS938rbipVRQOLdIxacFQPmkhuTLC1T58y0yAtwfLERLg4OyxJ3vDHjIu1xtrphNGjB0RqQewEpFrDmKM8Eb+F4pdwghAgWQYHGxaKJ7y5KCUo0l+IyeHwbk5E2bgD+hGoqLOE6d3QcEq/a0Nt8AOPMSUFNTVg51akohV6lOE8gS7e5W1xcFsM2ABRueWjzqRDYcBVVB6juWM9vfEtYq9gTK9p5m03eKB0hdw3l1lvAZecxKAcFKBhCYUXfz+gWisSt9OcB4hqtiaCOYWKjt20NvgZErUaQ6dFGYAyPgJUDHTSCBaR1yKhk1BUzRfECWFz4JQxgKFG7vo7TsuNvYCBkI+L4XzFIeRVDug7bRuwOjyv1TBU7n9CiDUF5m3ahoIhiFtI39XEo65RxB1QnJt2KTaOmoeSK5cK5rlq6SFLywNZFhhvRa27Zhru1EO2nfplSpFjPkO53YAhvyy8QLYVHfbkjdjTdB/dxukO3dwJZcyrl4s4nxHxds5l7OUFs4pxygPEqJQxppHQjkSxKqBdozFjC+djiNfRL+IT9S5e4gEZbVjvase6eatAdcpjP0/ECGAK9lDSbOhZLY6Bl4Z2l4IsG9dB3KiyYJyYR2i4Y3TtOYCiHQVoDV8zjuaLErzvkuoNh4DgprO4ezLRZSK/VAh8SVEFfuDRA58vzUGXbCGnfB1LTNtYbOyJRPfMHZK7iRqr8b6KiBLhMrWprNuqlg0LZLK8JMKQcxB2RqkmDBvXxGg40oGnDowtse1vk7QpjdxFn88k5wrH/hLx9zOKdexexiXlB4lQKEDwxpXOJWiaHwfKy1ENwsW+W1WRWBLsUfplKY4d/HsZZXtx4aI+BDmurHZHCUb0yw8xfPywQKTBiGcHEv0V5Q1zRPwzO5OKVEsbsPI1sq7CV/8qEgiIlicMQe5jDQI5BbZbsr2hVOA3ee4y0AWYHyRZTgC9lC451lycCbj6DP6CItcCBuJPjiWzGKMSm0a10kUMxQ10AcSiEimaiJywvbo6unFmXUEA1Dim16iHGaJFnp19EamXcnJf930zETkpXBXUBMkFf2VL4uU+LxNb6wNQpej9VKhFKEeV1D1Mo3PolsdIhpbqnqM6b6uArVdJkBmr4eYeEqmCj5lJdIRWO2KiImtdBr5fcWlVxB53aBlSm1cBu3r98Q2sTG8ZKTS/bHAvLhG/wDzrD1/tjEKvgLnYwhAM7ANmQiOB1aM68xeEgDasCf+olItbE6pGmaEtn9cY9xvoIqcjtitY0rbd8wjd7hpIXBUh8qrSfXsWv4vNk1JjhmZ3GWGBKS2BFHwzuDlsg7R/khF3MeV5HtQF5i8Svq1UnhmMBQNu15hUKDrQN8pxkMBDdgQuChyLu01IlIC4LTwksdXI2oC2AQnKrsyvEZIInNoM4n7dg5LEd6aMFQIVGjAtppdPUCqirqEvwoKPdy+qrjN9XAQ7Qi5bS4u5wIdSJxamw8NYmAXxzDTtDFtGzhdsY4oeY8pbDicYu+nz4hMoLWlNpnMsQrGVkiXsLoS+eiMqur2Oc4C3SlllINPAnjuEtJCJYbQXGG+ZrViCBVYJiiBVy6F6+CLRDbXUrnbNYr7CHLDjby+dnvQCJvxy45BMdQJHytZBxiLwVaLZSugl9iqz8vNwplSYVf+RcqtOFbXvYDelBg8YMcIV1KCy6qPoSvvmVaoS6ZiBTCkD/6S1sJqTIhKuHAgGkElTEKRpOb4KF59eIzwJ3PhrLnBwHaIxF0WMLJwNNhukEv25IeowMaqbWArjwAWQj0uXwRxLvbrYOteFbjEuqNgeVqqFIvYwnLGqirBv7x9JdSdlV0UwWo80sMIyj4jH0jLzzIZz5kCd9/UW8ziR6tk5VNkvfijat24oHousrSAFUQNhiCmIQt9XWc/VHaB5aCOR7Iw1ZLo0kLqx5fxOZtUfKrLYgt1QVaf4g3ISqgvBQUjQajeVh+JDZAgL0VxC2FW3TROBCNOdZxLRs6Dn4eWcHpQoE5qDaAupx6+3ucY0gq15Qfyw6NrNCEaai/MlyukPRCGOANLmS/SDzjtRbH2JxEDEYkyyztLD+F4CQntvCUNCQPuFpByl0b6voYAnQprahkSe5sVqYxc2nY/Vlpc2GsOlwmSwG2okSoJ2uiItVsV6MbkzfkWFhcz0gZQOt7IQWwwg13sdtLbyahR1ZhuLmUJck14SyLsw0I8o5pwoKuk4FEdtFRPhShL8iWk5WbUHdzkIDa4FsvCn4PctSOU3Zu+HFQ30AXiVUzpZp0MYkZXDFLM4ybPsKm2QEKdbkrKWEwHXLZCJbrnN90PUY6EdNEL35agiiySFtwdPCQYuYQj0DxUB0IqCh4SrIvbiWOtD5HxFskVAKjg8Ln7yEBuzzA0Y9wbGFV0PDZ9jD01dgc3ZKZQR8R4PaARh0O+z/TBLaRftlAlrd5uxxOxs0JwSjIjeHizwxAbLlNC47tFVAFFa8oqj21EYtAmwaHN9MSYLeK0lAjycp1zO3W8BwMv9Bar34uVaYAjdP4jEGvzkUAtF8DNPSSCyyF3Os4kQPKcyCkbOz6NJdG3eq/VQRSHAdmbgRpGi7uA0B0MVXZ4jx9Ko4TphqXlTDqUaXDDeq1w29/EBi9UMBSluzWFq6/aVERFnMFFU5MlLGNG0r5BkCK1qFHxKEsgX5cUgkNFa+BY8xV2IV/Bu4UAtVWizhxfctFQYBUKuw6hfR92jptLlbYJUhyQlTeIXi2+HPi4MF+UjRrac48QIhahKCpQVdvIKULFlvUvZQCNX4LSjsLQF6EfkeYsODSji+eJrtbVhBKi8hqXbaErsE0e3iBzaOIXn4EvLvJNSslgXRzXTNm1VlIdyOqtIbcUGuHx8xOWEsjgcO+BLltQK4E9AZzYAz4wRUUae7ydi2IpXhiGy1d2b0hAHB1xDgj+JbKI0slyr9YKkNNXL2dMxjSs4o2VAyJhRyu4V2cEaYgU2swT1ZBNd3BQp9BcRwyjFAVIwxI/LBGTSj00JGPm6OI3b4YXdAL2uSYvP5Acj+6X4/iCEGnVnNjEuhUlthKLt4eGOMkLQJNQ5yA0tYR2Dn/EEdOxnJCs3NAha3miL3cqt8NEFGmYApGWNpuV9Uhxtwrw40idE1lSzKcuQ0MBYDU/JQlMGpFZRAvDSDEVnUqj2R0NoDEPemhKIa6D9kj1pjFprofTBy5UTo1RAhlsKghCpqiJb4jJ6BjfK+4RQZ0z4LV2fEPrHRHhPHYysUONUfwgdQKarv8A8BYgb49D0Xw9sVsJRB1gEMqB+zf3Hi9SwFUeYv8APMLUNyoakKM1Lh2L/K6JQtQ+R2TMF3X4Sozg2Vjx1UBCesdoMicBY1ZC/ET5b2CoSi+8ImQnlUarM6YID7ISIfDyTLXEe5jMDCDSk+TzHPTAl2MqxNm7a7dTOanr67PIuNEBCabtHtL7iee2C8Mp9xa83UYUtH+xL2AVl8Z3nKFVvegA42Gg4XPE13Z4gkSBSnaA+WPHKiu6UjpCDNBVo21L7jWclBte0OBDuGSQYGgF4WjcGwBYFIdjBauTwVwjzF7K1sDaX3HoHBxa8rEMNFXHkJVUc7bU5cC7aL/jLV4JYXwRZdWUXFWK6BL/AEy/YSlKS9H7QX+6g7m+ZWCqt4shw1rxXC+SN2QvXazSEMEahmAqOYX6qI7f7lnJuoUuDRC/6f0xkzO4a7eAcvJGAoq3rmVtQngMxHcd1fMuQbfEVuwYMgW3ZKJl+5yEqjxLDYnqLAI99RCcURoA0z2RE10kCOj1Y/SRpaQ1ujy9yh3C0sos5fyPU4V7hq85ETJhY9WnBdSEOWrYUajoVlY4yy5wu+PCEsFZPUCFh1lUdi7Bb3xccHbFlta1NADmUwG1K6CK9pLvpqQfwu9uJVGgcE81H0dS4CcXrpUtUpw3J1RwYKXasYmWlIgOUNu+xHMpQoq/ZBBztRhANVLks8CtiIYCFwg3o4htInAoselhUpUO4TFNxaRyiHaU/wASkeYUwULhgJfBXgOiLy8vMQDPwUdRt4dyhozHZhNpp/kq0CL6QLfqoWrLyorIGlZvFPTL0e55khsOHhIohGzahV7mRbpGbh7mRB0lKxcOJoKFJEqHcZuCuWy4NHBs6hEAPNFWwwTsdpysv6LqIs58LXrl7l0ExupRaq/8lT7SwBXLp8oMHgdV+rjI0UosKE5NDlkZ6PVO/MqIURQr0qeYewsWHR1ZKRCrWFImkLxVcbdTxBuyKK4QCF26XxGB8Fpl1VV0URCsFzD/ACL5+6F31GdWqeCumBZHUa2kKkSzh5gDrDAB6FMdoJrmZoIcU7Vmj8RUUHjLIWWx06V+7la36De/awMjnmKZQOpq1OghsgydFXFLRXpjAEZBDqEs8dsHLHrsadb8wBQ9fmc5MEeB4Ybyn8s4+b9MXAuG1CPkE8XriErzLsxviWJPmIW3qQRnB83GojxSP2XFa8QJ8pQZx7OKrioM3qojaZe27MKMsrKRr0eJhxAOKfKwlFSkY22nhfZjQfc8C14YI5N612xLRU64ScobuUtVsr7lfMAN8PPDyy3Z0q1AuA0ldlKDF9OCAkwDoc/d9vLGGihbECW3baoJQYKGEV6Ijq0tQb5VXs2OEbo+YLIQyiCSpNmvMLoWR3fQ0AHy8S41D2EqnCh9nykW+iLJVhfvKnw/x/ksaT5yD6c74q4OrelgCyNdln7judFHhghChafxT/IvaX/9zF1vgWOwLUCjnW/8hXvgLh+/hhVuxi2ucXz9PqDAbS/9IXF5db8oitlfmJzj2Cg9e4bssbyvcbP9EoqqufDKUvzzKHTqFFNE5i4qphPiOgCndbDom6txPuoMtQp9U8VKTRaiB/2bO00K+vxbKCU2DSffoy6OkHtNiWdt1xcedbwG9BIbioXLSlkEHcWmquFQgKeKiaDdHL2B44+4qt7oV483BrQoRauB8E0wi1HLDQq+qTIBW/bHC2+0ZQ0JB6Z8RveS1EqpU7CJZAlQFLPEaR2RCOaDbT79MFIvRLg2+4dFav8ApUFB4i9/CKiUlFvhHq6P9ruLq4LGz+CAkFfZhLyspwqz9kNidvAfqyAxQZf8qJ0v5I0cSx/sIbrTZ6BOUucZXDviPHvAsbEUHjxEIDpnn5IzIXNP4oneHlSie5ckYKS0EEF74WOKftC64TG1KSNMMawmwqUeMmguZfrJ2jUOUnCJ2QxkicU/synNnDyKGAkrCuG+GBEUo2DSExH0NwJVHl7mCLgJ4qHawIAXAdFdygSCaGFEpyKIQjsXrv8AcHdtt46SFIqOMiIQGVYlMqEsdznECNIiUuDwLnwxx6/+fMnF/D/zpbVjexiFlBcF37gM+8H/ACIqqpwSu/qabtD4B8kUAjhDxFva7Z/lOdeP7CVCqPqKIpThuLvUQj+yMbpgcwd9oqIcRRDxo3LGs0uvligA4N5XbtwxHto+5Y/DTOHQ+SD1FJLlyVI7O1wzDKRh39M7KMs5ZYLGJsFTPsqIZTF8n4oKdIJRuMu8uUJyy14hqDS2N+f6IElyVTEADoqUwXoLEgUbChxtvDBVS6rOJQDsNbuBpSdO9fT3OCVuDlqZ5xeDVlOqtnlqDCAi7uUzoaSlD4XKPwV5YKOiFfEKIbh/XUg5fj/88Xj4hr+EjcJ9P/eBFIf/AEUMFt2Mw39MCLrikWvFEhHm1o7fDKWgMSB9MZtdg+kEw9Wn7UDcynaKWr7tCoAd1pHkuDRr+d9mk4BnUK+fKWWYZcn9JuwjYgrTonaFLBrwVCNrov24QwSDmnbwlcba9+VQgI0VMvK+YQtiEoIsKLkWCkahOQQYF/iK+YHoohoua4xnRdSVjx0RQNz3Oc7uDAGoNcNMZWQ2b3KgaqL9VcOXRUoVS/v1cAs4DfYCD2wcZhOmbjVrAlGQyXYYn4efEtYJipQ6bOuos1lXi+mHNiq2Bht8lMeZ0cS6uG+y4mWR2ESFU/R9pKd3dB/5VsrtFoyv2MYcqLo3R7OYJLvYKEwsNhULz4jqxXiB7j8d1VwXaixJh88PYUS0aP8AcJm3vfFwOk+SgQKrjrfRGAJGJ9svQlewBC6pmvmALNlThEHmV7yMxw3yMaXY8TuFnkhIU7LsgvmckAnyK8k3P5gqbLa9MGsIM7zb31cdt8eVd37nCebzvY3CPS45apzhl6sh1Hg2dxrDQGnpilVdYJG0GjrxLKohDgmCyM2ErRjMH7g0NQAbFXTPJrHfR8Q+3zSH9SwKD6h6OijsxPa3Gey/Rnkla+QVHIr/ALgMQc7Bpca2JRBujgtjsxtsq7IO/rj5lkjVdgx1YJKfXf5lYBKYfFauXlYyiF0HMDG/qaXU1X/YTouJShw8SiVCsj4qqVNpGxRqzFf+hgew+m5xA2A2dm6nL9uEZrkmmhB//YV3cHmBntuIrzF6gLxj5NwcMHkukSi/KC6T0sTuKkyVbIKeIR1DDV7ggQB4cYNgowq8hVL4B64w88+5i/L9uRohGRt/EEgxiXNvg6IgaoceSEg69/8AYKB5g5TFqqNiQhlNX9xWvA1+oEVwC8NvcZZhtZ1A4JFIvlewLYO1Y8HM5hIq4UIxRhk9+IVi0rNp+YBG+7h+GcIKqVVWsNFGvc4FRXWJChsFCD6ZzlPhl8ljBK81FbP5Sq1KuCoWTKtjzBQ+5d2VA4iUwGqJ1EbSqhKp+QitEG4Ig46TEEooJ0lyvVEUbulmL9xY0s61Ls8QqH0P6Rhfn2aqRdrLA/EPbO73x3L8v0EX8iqxlSPp/wCSlpfLkf/EADURAAICAQIFAwMCBAYDAQAAAAECABEDEiEEEzFBURAiYTJxgQWRFCAjsTNCUlOSoXLB0eH/2gAIAQIBAT8AryY2QKNochMLQAmChDBKmmBYEr+QGd4evpUHptU0yof5AYcpMY3ADcBF7QSpW0EAiqYAB6CE2fUHeE+o9AR6n0NXLNwCpe067+lQCoSID6AXB6E11nNTuwhzY/M5yfM56X0MGZPmc5Pmc5PMDqe4/kFT59TO/oBc7QCBZQ8yt4oNygNyahzIOlmNnatqEOZiPqMLbwMZZ8+tmWYGMD7wOYMrjvFznuBBlQ96Pz/NdQV6KsZqg3lonU7+I2Zu3tEZzBuIVuaJy5oE0ibeZQmlYFUxwii2IAurnLE5Z3lN4lfE3itXQkQZCOo/IgYHofU0RAIi9+0d+wgAC6mMOTxsJfiUTNECgTaavE93mVAIQO81KyEqbFdoMz42IY6hdjzMORWG37TLxOTTkpgAn9/BmAvkYbAhFBHc33jMtX023E1hkVxW/YQMDKBmnxNxdbQUfg+RA5WtQ28iXe4m9xV1GMwAImoXcLWYBAsqbCFj2na7mXjsGI0LyEb+07fvMTczDjyUBqF1YsTVRowMs4rIvJYF1UN7bMTOnIVSK2FRKfIqjazP4XlAk5asUDR69pn4TUinUrBbJ26t5if0WGwog1c5KZAjMcgI6iyAYzHEWsA2dqE/i8F0SfwLiZcbfTkEBYQOD1mjuu8Fg7ftBY3T8rFcNuJ9CxzqYm9oTBcVa9C/YTJxGLGLdwJk/UKUsuJvuwoTiEz5x/UbIfhaVRXacNwHKDAsnu3GzRG5aNp4erT3Mtb14mPiijtziSpUBWJ3PzEKMAymwehn6tkOZkCE6F3Gkj3MPIvpOEXdmxhmA+sEdD4mIYsmPW2IA31A7w4yaJdypPtBJFfBE4PKhTQoAK9rmbA2m0F1dCYeL1kFSLA6GZCMoJ079/mHHRJxsVJmbG+xbqK3qYWc411/VUBB3BuByIGV+vXzCCpjXeofV/eZ2OywmKN7irPmH3TiMjYETRjJZiBqolVB7mYwowoA7ZD1cVe/eul7zGiuUOReooU3YQY0GRyhUD71FyYSfderqYuZFNXansexnEpjbKXABIXba4NA9lBWZrBBreZuCyYuJbOjli1hkN1v9pwHBvgUDoD1JMDohBa9S7ADYtY7RRkZdZJRrsbg7DsYHfGUxuisKJD3VVMfGUXZNdKNySDQ/NTMRmya0ZQVBbYGzBxOABG1iyar58GMKpiNjC7FgEWz4mHLmcvZYDURRiA4iCCQt2QJfgy4mSxRhjEnfuYNzFWCE3KnGZnONsGk2/8AhkHuOxmDmlsXMVVK460BdJJ1fHWcpUd97UKPYB1aZdNaxWMr18H71M36gUbYK3/kLnCYsmZ+bmZkPZBsKhxYzptbruY+H3WKYDzMQd/brBQ9Sd6mNxqGNwb7GMz0CGIobbXLDBdpx2ThMOkOGZj0A2P3i8NhzLrGpa+Kh/TyjHJiye49Sf8A9uZTl4fIXdAPgDaY/wBX4Z6xkEsSFAHzMuPIg1o1UZjcPleiu4B9u4ut45BWvicLkJ1L2HSXZ6eiPexjneIPQwCGcWAUUEGy4AYdr8/E0JxipjyaQyqAmXVuNPx5nJ5Wd1ykkhkIIobCzW0LnJj1BKS/p0kDzR2FzLw3DDKHTENmvVuaqY7BBL9vO/4uXS9AQRsYOHbP1NL8TGnD41ABIINCuojIzknUCRvvMOcH2sCG/cSlQlrstU4/FqznJVvRUD4MTnJjBBIo9O8PFOoJG5A+1z9Q45+LzHFiJXEoOoA0zmfp2AZuKBJNA11794cYQABjtMfJyFgFpvjb+0KEHY9q6C7i4s2JSAF33vvMPMPtZbs9bmnciA1vD1iD1sjtt59WwupULvuT83GyY2XGrljVamG+oL8eZZyYgGck6iD8k9/m43DheYWcuo+lTV2I+UPjClDvRsdQPmIUKbUT36UDfeLlobdQ25ikuAXZQBLUEkMNxCgDBiwU+OsLTIltY7TjHyJynxnfV7vkVON4vIuNUBAdxCpXYAhmPtvr8mfpPC8tC2k7bRuU1g5VAM14UU6QSQO3ceRMeXHnyOOU6upoV3veJnyLkcOrFFOkkjvOYoY+17Gw22v4jDrZlb9Z/midIfTOvsUqYmR8DnRun+g9j8GJlDqDGBI60exgWiyaCvUkiYc2l8eMqCrahqrp8XGxf03Y4t2AJAyDa/F1HyOgopiU7A+LP2/vOEJGteJRQS22k7H53jMFFAkX9IHebkiyP23nMRqp7XuZls0rLt2YGIPb9WqpW8y4sL49TZKC7mZRqzNkZB09vwAJgIfIXdqRO/8Acxufl4Yh7CNbBOlIO7eSewmLhjhcAbX0UjpMPNBG4da2813qYuH5erkJpRgddUDYmjGO0ZVIBbetxCvo43uL0hm1TLYUntCVL+03NIYivqrp5mPJcdA42NWRZEN8sLRBPRD56XMAys7oVJyb2fm677QY9J1FXtdzS7xtVB7AJcFrG9TFkzgs+nUL2P0mY8zkMGoe7oP+rmNy4BVKQHsKBqZMuA42bUKh1XqU/wDfaFwa+3m5mx6kmdHJCL0vr4mHg0OTGpoom7fJ7CcsOhDDr1nGsuFLJN0QPAJ7wcSyZA1ENVeZwZen1G7Yt+5hjG4YesZNivcdIhhg9MnDYn3Kb+RtDwKj6HIozHhbGABVCL9pkU6lerIPYbwPlq8ftdhuCJl4h1UrkzEMa0gC72mVgfqt1I05GaxVbbXMBwuitkw+1TfTYg942XGrAJw9Ifnr9owwuyaLAvcTk4mAvGorp/8ARHzIB/iCpmyucgAbe4MimlDWQu8cHtU1ogDkUehnNVl9mZQR5E4nJi6vkS+46j77RSc2Y8uwu1v8jwJwwKL+w/Alk94TCZ3Mcd4y2dQ/IgNj0HoQZuB5MUvven4EF0PPeFBd1vM5JIsA+D4IOxjPnOnHnZNnGlm3sGacqY/pGkncUKKxc+liXSqI073uOwMx58SFSQtXVVHy48uQOEpQaXet5lRXc10HSLhWgBcTCEUEDr3joYyBhRFiZuHyHfGVG3SoqZytPh1HyK/9zBw5G7UB2AgYAAAS4TQhNwCbHYwgg/MK72v5E6zvBDKqEDt6NqtaI673OMbJoCY8bszd1qh97jYcefheWx33o33E4b9Qy4sv8NxBJVdjdVRsxuG4bIpAyE3XRrFmZOE5bKNVr3INxdk0X835JiKqrAgJttlljsIRc0mBYvDr3W/yBFwp/tj8tBiT/YX/AJQ4sffAw+xuNj4fy6/efwyndMk5Lg7j0YAiMPMO/Xr5lwS/5CBKmRA4+a2PiZ8OAuDmJBoV8kdDOF4nJhzOjCh4G4A8CYdTgE3FwWPftLA2USyYJUqJyx1P/UDY/wDUv/GAYiPqxflZyweiIfsYQB/ldfzctu2S/uJQ8AQmVDDRABlGVCKEs94K9TBUqZsCZBuq6hVE9p/CYdYYpuBACmyqBBYFXfoBOkuFpZhPn0GrsTMbuBublg+pA39CNj+37wf5vvCg7SqhQGcsg7GU4PSB5qBm3oeko+hE2ly5fxLEAPiBIFECwKTAoEMqf//EADIRAAICAQMDAgUDAgcBAAAAAAECABEDEiExBBBBUWEFEyIycSCBkSOxBhRCUmJywaH/2gAIAQMBAT8Ai4y0GMAQLL/RcG53h28wk1BLgOwhgFzRCAOwFwDYmbV+qjDBiqKK2hNytux7GoTCwhJPZbh57VNhNXPe4Tx+m9okoVH5hFmcbDt4hM3hn4jHsK8iAXW0Cv6TQ0KH1ECbciFPcQYz7T5bQoR4MoyuwhgFwRdjLhINw9iYWl32JEsngQY2PJgxC/MCAek94QPSUPTsYa9JQ9JQlQ3CFviFBNBlGKDvCOw3gU3N+ezPvFU+Ydp9TcDb1MXGPO8CQiuJUBAE1TVLlmWZZ9JqMOStzNdCagRNu5J/MJB42MNgbjsICdQMJjvW0RPJhJshRNN15mmbCaoTLMNwy4WuAkQNKXIBsFPHtMynGLNV4MZyNTHfeiZjbXQvYcRdQG/ExuSYRNxL5uXtuJqI/HoZQbjn0m9wUVEdtIigkiGxtAs4hJlm5vKHkzdjVfgCYPhefIoZz8tTxfM6jB8rK6KSwU81KuUZkJVbgyi/SY8i6bDAzL1Q+WRpB/O8061CDeYxobSdiTMWVhjK0puxuN5gS2dSa95k/pi2Ii5EbzKE0nxL33hlg7N/MAq5etov0qBW8C/z5MsQmXAIOl6hlUhDpbgxekUFVLaySLC7UD5JMxdRg6dqxrjS9gSCzG/eZ/jKAHVYK7Ebf+TJ1+BguTJmujsh5o+tTGcXW9Ihx6VcEkoPEyI6Eqw4mD4eh6fVlBDk7WNqqZuhZRqqgeDHBRwLr3lFrYbjmY2U2tixMwGVfGsbqfX2mDMuRSBzFWmBmbpzmIN71PkvjNMIAdIm4lAwgjsjeDxMIABaKPXkwwm+/QdLizscmZhpW/oBAZqnU5cuXqupDImOhSVYpfG/iJ1WXGdK/SwNlitiz6TL8TUj6yxbm6uHqmBJ0KCRyI2TWbIG/M+HkricopLXROqtomVxnT5mU2yEFCQwpZi6xM3TrjP2itBHtOr6kZDWomuBMzqM7nkynYaj9JhOkAMl7bHgwdToc7sCBwwsVDlR2LLpU3diY+oxuqAsAzcDncTG9iuCIAtHW1COmMBfxG0sOPEr2lRlrcdgBYHhf7zgQmHtc+FtjV0ctWlSGse9zr9sWTGEYh3IL2CACPUxWGbpxpAFlrcnx559Zn6fplYtlxkCh9R2HHiZGUOdA2uL077O4H/WLkZCdGwOzDwRFtHTKCGo3V7xM+BxqxmiPHEyYtjkU/kRvpvbzOa2nyFyczL0YsA7mvEbot7Xmf1MD2QZ8O6LruqxPnOLQioW1vtYAvaO6sq3fvMeQHGCTx/aDeNK7MsxDa/Uxz3YwTpbXWwcClujy3494mf5PzAqMykszJW31+bjv0+nG2PYHG1lgSeQLEfCusrQNJyxv9/NTD0eF8ZbQdV2LBH94Vc2ADYNGZMwLMAg28wkuYMaLjTm9uJizZ0aqBHvsZlUlvsYCKkwICGN1UIxltNTJhatQW6nw74ZiwYlzZU1ZGqtQsKJ1pTB8Mzs9AuhA/B2mRCn22Vgpl5ZLi5sqDSGsDYbQZc1G1Feoi5SD5N+88AwiJ9ohhhMq/O83uA7CDMranICnbjiHW+laQKHJ32ImTP1OPq9KqPlkC9qFDj+ImbEFxhUVK+4jYUZjfo3LsCVC7ajwfwfQRsOXI73u3p5Mw9MSRqFAj94NAJH94ClkgcebiMzY2GjeoVqYya3nSoHZlbitp0XRYSxcrYExoMuUKK0j7iJ/iDrQdOIcHx7CE7kX+0yZasAEkeJjYOCxQgg17xXZeRaH+RAV1XRqKRQrsp+jsZ5iH6oQMibgavDev5hQgwEKdxt5Eyqpxay970B5qaUzIciM3Iofv6RcKY30ZQTjOrlLvfzXERMeVqUsUK7LVbD8zPj6fFRwsB7n19BMrOcigakb+bmTEdtgxAhxksFdCprniYyqLYJ2j6myfaKIgBFzpzlGQALZbYRKx4FRW87+9mZcydJ0zuTRMzZW6nMXbyaAg6bG6k1+86np1XdfTiD6QdK7Sr5EC6iIJvUQ8jueRFFtFFLvNWnn7Y6GK5Q3V+xhI+aGH1AMLIPHmZ8iZGtnOlUSlBpd/YcxQ7j5bMn1bW2wr9onTYcRIC3akAg+Y/R9OdrIbk2SZlTpMIUo31EWSfxuBL+YhBXztuZ8rICEINzFkQMVII9yNrmk5E1/TY9Dc6LIoye9TCV3Zp8S61+qyeiA0o/9iuFIImBgzUOL3mcKEajE83KJqKK7VLpr7GHkQGJmcCg0HUnyoMbKrTngxDsVJ2MUIrfXTKPM6ZcWTTWIULJYniaH8EK93jRQDz61MzZcRpWLMw0nSeCIDiy6zr+Y6sL0rNLkNqJA08esb/MDGAmY6hQJ8HxvMfSZ2Ju0OoWBvYE6TDosaAoBmdAj6loWYOoatyZkTxe3iaaO6mK5XjVUzZW/AmIcmACACDsOPxAaFQ8foBvsdPi+ysarxMB0klbHr7iK2NwxRKBU2AKozQozaVXV73uDGxIwBxMN/uA2/mdRjfKWom6i9HkGPS2Qb8zAv8AlwQWZiTe5uZM7b7x8zO59vEDwuJZuMzek+WWO8Ciq7DsfQQbQ/8AwwGoZ47CXcHYVvMLBWtqqDI2LOH5XY1GxYsv9XGKY8VzAeoUl/kr9x8VsJiyHICWXT7ETLlH+haHEdmZoXoGtzNLXzz+gmE/9oSf97j9oGbxl/kTVl/4mDKeCsDr4MHbiD2lfqB7Y8hU/wDG9xEyZAv9MWL39hFIOPfceCfWZn0ki/yY2bws3PJnn2/QbhDegP7mEN/tb9jNVeXEsn/UDKHla/E37b7mLK5jJXEBmxlek37rN5cx5nTYMa8iDrcgxaB63cL6jZa4TvtCe19zB2IjIm1SiDNuwugIDvFPEb/TK9YRAYSCJS0N4Umk97EsQGvMDS5feieBP4hIJ4lwmFhLJgG3b//Z", q1 = "data:image/jpeg;base64,/9j/2wBDAAYGBgYHBgcICAcKCwoLCg8ODAwODxYQERAREBYiFRkVFRkVIh4kHhweJB42KiYmKjY+NDI0PkxERExfWl98fKf/2wBDAQYGBgYHBgcICAcKCwoLCg8ODAwODxYQERAREBYiFRkVFRkVIh4kHhweJB42KiYmKjY+NDI0PkxERExfWl98fKf/wgARCAFAAeADASIAAhEBAxEB/8QAHAAAAgMBAQEBAAAAAAAAAAAABQYCAwQHAQAI/8QAGgEAAwEBAQEAAAAAAAAAAAAAAAECAwQFBv/aAAwDAQACEAMQAAAAbbMsujk1yxyJ1zxSDbPBMN08Mg2Sxzb1SzeytH1ElV8s0w0e5pI0e5/Q0e0et3Sz+hf9T8i76jwWj7N6O/zPENXuHwN/2D4CEcEREfhvpG/wZBhSA2IEYD6GFYDYtkvBngEYD4MIeDfhkYDoCJQGVBw+uyzh7c8pxay+aINeXTvATZOkLrfpDps++R7C34I+wtDH9siFXxQaFUd0k8/2zaqAeFahD6SuSlSfE3TTHaNG8nQPhpu7eWuo2Kz0xnBEBZjWO4PApSVyMjvopUea7UaBbDow2VNuvbUhcp3Ay4iPy51b7pHtYylwulK901XkiTedrOaXuBNnPZdE+Dnsn6cvnfj96NLm/eOUmt9mHP8AN0nCNSserUIfj/ZN88k/Vi50fIN+evPcfQNk1zPN19LuES5r0bZJ8HvyaSI9KEoWbnYVlqk0dDK3HKregZGImZ5y3mnkHIrlpzEq3BmBS5HqGG3CLGHLcpfnQQ+/PWBb8U2FzMnktVL59NSbtjdrhfbm0gOICSSq+ddzmu6ibWWWi8rPPTSlH3V8EBpDSqweEKE/at+dOqzRaAm3cTixpbxajSF0NGuKuQ1+XFUSM89MGLXGpJj90Mti+Qrqw6FMC6id8AGYrDfmzT23xYrIWy0sDNm+i7g7FflrhU24Tri7o3ROaYb5duk1pCJUZK65Dbqd2mXl9dwBy40nLq0fTZHUN1VFluHQPXT4vJtcVSYMW1d2plR8aFZCNWMDkh0YCJQDVGrGCRxDXTc6GZ0zYsSuHpdFkJx46uV6qzzQn6Zykq6GfZGgMWNjriTziPXJDWm7qhnFBqRt0xlQyjAmlc7sywx3D/z4xky1KA2IEG+cgAttwi3owM+jLWVlwOyQn9g8YR25NZNN9WlH3P3lddc/eefOLoizZSEJIXGPA6KGIWo+FTGA0kEzfnpCC/WxhOSA1FFmpnFlwNCbh0Mq11MDFppRR6JSylkUQDnyJzA65DmsaKqWLzMpaZm9hF/i0QmP21nb7OATjKAtNMCM3gDGFepJ6Bc02O6u3SPrfPIMhAcUbn9ZEWO+WoQ/RLWng5z1PiLepww4G3UJATLNXDL0yBUCzIHZmDMC4Z0zmgmRq5qxxHbdzQHoKeTmmJPKI3P0dSwimWL5+9CiFSBDuaMPTRPZtjsH60lzdZDZpG/pa4Fw2iB6PzvTMpNTeqnB7urvPNo1b5ozzNiATRa1otilK/6fRz22V3JiyQ0mEdHnwVacGqlLTh0yA+buym6xmdD6MLsuDyYjXoIcGVcbQJUVWyYdVHqrmHrurNtFq6XQQV9eNU1kudt7hgDfL+G7HLE1qhHyi156q5UO6NDuW9UR+vkFOyG61MgZemKdefdSVstV01Ba1xa/Dq5UEGpa6fj0clENOTTFy+YRXH1c+vz3el59l2e5AwsMJjnbX8FWvJe19py6Q95j1BWT1mhtSY3duyMLghu0BNTOqlMm6YmWY00YZpbFa7WlZtwurOC4+lc5ne3ovMHNx3FUdd3LvzBkTHcKj8RsaLm4mr1LCuO46oQFHoCN2cnQ7Iwhtw/TzzHaE9a3cdMGl6qzp6nyHoUap0hreT8RPqPP0Ic9s+/gzX7bRrxGJJGOW+8BGjRoc4dXugedB6SmJ7LMMB5hTIoseQCl0MBnxXOjMUovTuw1io1J14MNS2FuYjmuzLNL9839P+Xeo9ZWvX8Y0cS+gzSTSy86Q514h47z43ALM2q2a5DK9GPt4jzlxzpDl1Reh5ufcSu9NREyPQwj8Pi3p0Fvy0uYboOHRHmHX+US8ttfvbx6rqrUDSQ0qnPVl1AN0S00sOn7SnSoPHLwOCdnypVHlCTd47rCclflzbQEXbNY67z4jHVe1WwpY9wdgqBHVUzonnenEEfCxU4840dfI/5/rcdtdFpFNOUy6TU9UHNCKqT9ivr9Dz3DFvSUmU2gaE+1qHO+rcvW2HcRJrkmDfHq4m5oVGvj7cnP3HmW2G/RR50c2+3DvAeVDFR6bc+kWbRh0US04dCL+Mdg5s3uLpGlPeVsMy1xjWSIFsg/4WQ1WPVsxpM0ZbK98CTUJzsTdTlUvL9W9DdEe81zERp9PzDVoFkx1BdqU2jHoQgBTC0/Ij6Bl8Hf3uPRhyUgQG7YLzn9RUYjOPoPP0ey1Yo0XN40j08TeR1huXtVwfr/AL8vA2DDq6sWe8Vpk+3ByqNN2S0J68Wy580ZtEk+S9a482sFrGBsG6pwNU1MEzsAkQSzsb+Y9O9l8zPZufK+iwqcppXJNivzdXQIRp4uzTyp+5RpDqrPC72cVTogdDc7wZSjDpCXrLRUnweBlCoU6c9Q18V7staQJoKjuvhcs69ZydfUJ2jqfMbsh7fkY1IwiY7ObkPvx15NdVp9DglG1Bobyn5/lS/Qmz83dyiiGunc1lv90y6kHpNYfmXrbatNCghKlUVXWjnqb62opJM1uFZEalVoYY0WNmbxVqYeXufN2NAMZp4ulRZtDiryp7/znr4wbworffwdU05DfD3rLLg9AmzCcSLAu/CK4jYt0lMR0FK6uQk5rd0X2IKyK8acz9v3dXCLaxbnjuXp0Qw14rsxbvQ4dP31zSQsn9RQZgGaLTUVTPkOE+QP002SwXSiCe0aBcqcCGYpcT3eQwhKnOqfRS3QJ2KJqpFmzq7VOjLfj25bshdEL8Hcmdc5z0XOsqA9KXTzcsl0DP63k7Nr9g8/0KRInoU2IIrjoi/m/QldprUmDI0NXnEZeac9c9e9+foovatZdCLZi2dXCVdgTBydmjyXiXBCS8T7eM1PHhEKGk111PeBZqR5CaVdA3d81TZhl40QDsWkCSM9Ka06B8uOO4kFYqH0tsvw4nL5wl/oAOtAQtqK56J4jbqi7vm095vojjvsJeRXZ17bPnCB3dO9Tyx5LQ48+4vpBKeWvLOgcyaxt6syKQqkvrbRUcov61mZw88UWunj7CtWisuhTICWnfmdY2Z+Ptv8rkR+ZioLT6PCyCNQxMeEiaYRye0Iyaxh+L3M6+bFt5h1dQA60816FS16MmhTbHyLNVU6kXyhImsiNJxtsFk03Ho58Q1sCu1j52y83Szwq+5unFg10XAzFswej5h3rfEe0XFllHuXRbk1eCt+98c0WQkPz6HiAXM+x8ovPV8M+256eic96VFm1lkE8vXniS8S/KkS636PBdRReUM1WbWewJ1Q6ssydLK1Ij5FMAcwEQA6AjPlrVDbhk2+3fOY+WwVfQv8DCXXiueplBc0nLUs2p5bl7LBxFJVdGgL04bRH6q6lXxNyP6Pmmuw8b6lUMNlN/L1fVfVjlo9pc2U++I9h5cGPnT0uNJX3n3o+db07mXSubpJi54OPsNQHfOOHqBy70/NWbdGSni1YN4F9uA9ILsI1DFMojTNsSWcU6hnbVA4DIJ8ByNFyjIG6pW0jZqFXwDd69ommPGOw477MvKd28dnwq+PHTsf3JJYdHW8fGYC6wkCJ74GukckNaY93s5xq4O6TTy9p0zerBtuG0I461Vpjm5+oIKu5RYAyi7fV8pi6hxPqfF2sGMdVy9Jekdm0y4Zdk+9XgMUYfkiOH6QbSS98xl8GZkjMweFvRdDUBXQLtlk8mOaZfHimG+mn0LvPvk6s2uQRGbFR1Pbmayc4JqGTQHw9t0hXsadkWsi3JWi62AG5pNaswL/ACdQtlG6ejB5vSL+Lse8oPTneiwZY1oT2Za1zRpGvfT87D0xGaOPrKxxU8vRupyV3n//xAAwEAACAgIBAwMEAgMAAgIDAAABAgMEABESBRMhFCIxECMyQRVRJDNCJTQwYUNQUv/aAAgBAQABCAH/AOLf/wCz3nLQ2d5vOWcs5ZyzlnLOWchnNc5LnJc5LnNc7iZ3EzuJncjzuJncjzuJncTOaZ3EzuJndjzux53I87sWd6LPUQYbEGeogz1MGeogz1EGepr56iDDarjPVV89TXz1VfPVV8FuswBHqq2eqrZ6urnq6uerq56yrnq6uerq56yphuVBnramG7UxmnAOlksed9yXjhebuhDIZA/EO7gqBK0ow8xrA76890/GLKf2pbuAYDJs5JKfacMp92dxvgrKCDgfyue7Pdy8AOF2Pd8nfznuA3jg+NF9k4D857vOe79ltfG9nzUmRCwYRluchkWJUTGLBmGEtreKO4yx4WCOVMTcX82rcLRqqo7K4INva6ywycUULs7zzotnjRweRi8v00DhVxVLA60RHvI034BVgwLeWl1naCTIAbMYQ6i4sxJtdrXsXbN4mKLCEzh85x9zgcPGMicxnnu+NHwclXfb1wXHUe3WhkigfC/mmKp7pxl3mhpTh15xR7jiBQdjiG2SB+QwHcWjxO1wJo7zS63knlUGNU4qCI4CTkiAScTx+QeGyMZfeuFF44tpjD2TMgD8QASzZGF5EtMwdwIWhKu/JF+cKjxnFBxx1hAXSogYb0myc+3rxxGJr4xOO95YkHJFUNB2jiQowkOQlYx5MsJmOOymYlSvc9x/RBDKkGlSNZCOYWFOWcQZMFBs/j3z+OfP45sFFjI65/Gsc/jTn8ac/j8PTjjdO4oxxOnbA2OljWfxS4vSY9gH+MX9fxYGN037qrg6Uuhn8SmfxCfv+Kj1n8VFjdKi4eIaEBD8oejQyZL0MIAA/RCrAZF0ZZCQsvSVjcoZenRoF1/GJh6bH+/46PP41MPT0yv02l3NSSdMqdx4436cisRnoF3rPQR4aFfgowdPiyWhGInOR9Pi4rsdKTjyz0EXIDJ+lV4yiq/S0RwmP0FO0WyLpVZzDu503p8Y1EKMeeiiyt0irJEWPoq/PQn6bWjPipQgfu9yWpVDkJX6dRkT3CNeOBPIzXjOHneLHuxPvgDnBDnawIN4Iwd7nT7cmRoOIwoP3ob88V8Z211vCnjH13oznBfnAF8YoHnG47OBRvCoOjkS7MwCRQRJ5W1MWGTmd5A4fsCDi3AB9ZZXfDOGtYnDzy4B/YJk4IEHDBVh5BC0HprMhWuIpLBaZ/SmTit1IF4BI6wZWZtbPiVPsS5TEQb3pNWjEirJWh9NzABLAiKXhOrvpJYPHbiitqjS1labjGV9OCkhT9Bu/XQrjVnCczBVaZtBac4SbOGvGKAGUldeDg4qMH6zY35X/wBmbS6BO9b+CfAIJPzgZfnJ+20b7jZQiDO4m9YrocWRP33FwzLxOO6eoj1zQHw0inWRyqFY4JV5Z3Yx8dyPR3UMZaUl5g5ORPBuMZaki7fiW13eO+CSDkksqEJgdWOh7RIA8jRiT2rcCQsih4879MR7CTV3mlz0cUgTjEiw2vb1LsB1I7iHWCRN5YMZhINeeIDeN2Rs5wjKEhZ0Q7HNSzHKvUlTijXEqP23ys0XdBN874kCWPkDiNVmQB77wIwVK9zt/ED3JFlKyKVOiyuNAgEkAfrz53vNawb9RNgU8hsMdgYA28EUTJiwIN5JFHwztR4Io8MadwZ20wIuKibfBGuNGnFsRE4JgVPGMqbTAqYyJ5xEUu+JCujpIETZxQOOaGs5cYGGdrxyzWvhKxkkUmxFCp9mhihQp2gCeyQyLEXCdMkURKpe2kU+j1VY5Fix6nCIORmvuYrBcb7jaHCSEtvISy8mFh45OPEWeUAjy1Cvp0yO19sxsicpAM4aX2TcjI3KtX7rEZ6lKyyBge/OGe60RRY1XezgwbxAcUD1E2h44gJ+QzX7yP8ABfpJ+BwYMP8AsGa+ifL4MYe1sX8EwY3ymLrxh+cT83wY29DBxIOv7yfXDwcM8IOGypKEHRJOQvFGCTXR7RfnMxaQ7R1UHlGSoVlLln5NPcjIjOPM0h8qhf4ZSJPLlR8o3HTDuxESmVXRviKcxbOTSRSBSsU3DHuxlI8aYJMThk3KGw3IQmMSxJxQa6c8iAsWpGkvTQlAkdCKLtl2H5YAc+PggDFH+RNg37sGtjPBxJFCgZ3RrHkHE4Hznk1kO50LCcMe5OhAAt6U6jtroc/VRkumJOrAAB8ezDyUYsoP4vaiT8u4VZjhsTkHjZndh9yTkFGVprMAGLZlljciVLkh2/eCnjleGOeId2xQmhINam8o5JarWY1SUCGMyzaE9dA4z0gdYtTVY+GS8l2C0gVSzQdVMjsscg5o7kDlrXuB2vukm4v548gzHicD+BnPIU5cTllj3c541fkAwroWc7nnWReGIhFgky+niDjI5RGGAQDeb+cHHXkYp/yJs8YPk4cj/BfpIPZg+gAf1QDy7iUKfdYfcWy7aji4rozVK8JIxtCzxVGnAWFvToqqc4MvujXZVmZLAc7CyJvSmgtppWMkdeFY+cVGPZkkfYhIyzLM+o0g6bEnks7iNY2pe20YpJKhkLjCb9d+aydbaWSNarzWTHt4LU6ouDqo+HsmGfbx9QtPPKY06ZpXlwWFdZAImVYUctJJ7dS2u0TG8c1iJkeVurVZ37YUeBms7jJrTyFyDjH5xXlTjjNIG9p8A56iT7i4eTnZaJFh3i1/OGodHfpCDnpR4xa470wz0o+D6XzgqefEX+tPpJ+GDJ1LQuAW3HLksqGuoyBzY0yV4hFyAeRYk2bAdrCNIYLj2gcijVpmbJ3cKpV/VJGWz3rykyKQOXJEnFeWNN1BS4Ra9mSeOTJYdRyuK4eWImX061p2IT4xa4kAOWI2SZBleUSwpJlh3RZQehRcrUkmX+19p2a6+iiVrDJK1eezEPhK9Kyo8+gk5MVNaSQFTDEIYwrXJZvVDKklTmGkj4OhDzVq8r88hdmj8r8+Z9e3SED5k48/aGPIDEQSswyZChbOxE7ys3pYcFRW8AaOKvzmvAOIfcMTQsTAfrWfOfOI0nEa5S45lK5ubJJZUidzTuL2puSs1ncMULJRr+xbBEbSZBdE0jtlo83r8mrBYpHNIk1E4Hn3xiDl382rxrEsdMlCuHuengGLHdSSSXIGngkaPJLgdJolhS1GgUR+o9Undg5p8+sVW2Lb951Jp8lijVepJYlglUUJ1phwsM5mQjIoopJSidTqxjgzyNyRHyh1CNX98V6VZy2WpVD8w4ewdYtBwyF6vTClznkMICHdvaCU5XuyQzuhmux8AVj7s68lbu/GfczUoZTiy2FYke54M88pRleHuMwyFLCv4/vAfGDfjCT8hCe/KcBOEHXkFv3H+IwY/wCP0cbGT1Aks8CLGtCuBjdRReUYrixG8a408UMUwmsR2leoC8LlShp8owY2+bAyeUINZTlH+ssqwyaxddk5yVhsWuT2hXC9qvGM5+eGWoWCtkYmnRHku69HpHoWW850yC1G2zcCPGuCS1HN9yGBI5H4aXuScerKxQnHjcU4MigjkgV0STiCG6nCNhkqXJ4zIHM9mVxhnk4lFknsRkaQwdt+UzMsa9uOVt6enDPFCTj8uZ3kKh5VU2Y+1+PdlYaxfDyk9Oi+0Gy3YWIcEzkM/IZwOL/usaCjYw75jF1okx/gv0f8fp1O01ev7I4lUMTZM6ukjdMqg/fkYcWR8txpKiRMaKRScoZZAvgLyk9M6rNEGORSxzBuNMERPu7vnGo0UiVctvJBYmKRn/Pike2wHHXIi3XOXpyqvv7p0s9R+cKcOzJMcbjFCderrq335nq8gtdWZeOLf6fDtX6osT1I2EM8spCZ0kfrL6IF2r1pdSmLp88BdlnZP8hFMrN3O0JhBsqK9VJoVbJ+izCyWjli9Mkzsl3uRK0ZLHyd/rK68p0yzRZwpDo0TayONpJXXKxeBADNXgnKtny2efpx/WKB6mY5o6GfOzg/+o0biM4HHVuOcDnWIn7CSAW1ZSyNAzxxRYkCqiqHiDLKhrRv6CF8bzgYLPCGWFYrTvGY04LrsRyeRDUEKnjJx57YMpYGZ4K8snEyQ/elxpUlK96CRXJxL1bmZpZet0n9pr3qb8kWvZVj20sK3b54YuckOnrz8zEtdq8Y2lqMtO5TqFmP0MKmtYUSqBUjSOgHe8F9iB6w0e1ZF1R3ZkaGV6aLIpjs7kn7TA9urDB2kEVypZklGpoTHTmaXpMZdHYyVPtgjgcrp71IQbjzqCfdzpqKZ337dY9b9xg7zW8PjASPyQD1E2z4+V5HeD4yP8FwY/4/Q+caNTcsLHHCECgFlRdtLMzFlWOCUpwPBY4m0yVrK8TKtqElJK1hohF2p/EsJT2sY1VIQlpeNlhKFEdot27DADkHBLy9zzUrzMksxsIVl92t/GjvkekTAupJlWReGWIgh4Frcg4qwrxxRmW8zDtzKGoQsvsl6c8ModaF6aeVa8xhnml+69aOHYXqEbvU4J02VorI16g+TIIDz2nYENZe2WedYlcLyibv0WHaMYSaUJr6Vm4zrgbUOW35THOnKwklOSW7CSaBunh5HzgP9cTi/wBBNieXQXYzR+c/5JyIjtrgZd6x/wAc8Z4yUCW74djocBA8jblRI4xI2esUwNLBM7H3PHNpNzepVYyR2udeSRKEqvWiOJdblJh7JKHLHuKosrEw8EshHiLioW15qt/hkZ1yi3ZjsCJfkkuPheiyOkkhEK7A5CBSG3VrmTqKZ1qtGIhNiU4ZIicS1IldJGitySu0MxPYtGVYJarN9rqNBfDK8cilS3UE7XUCyMu4wy+okcnIi28uW557TZVRDQsl3ikqNBOIJYuAxyujiOokU4J0MGOwLsc6cQxkwJG4OdSCiPBUh2cWnDrPRw+MFODeJWgM0oz0kGejg856SvkcEXBcWvHs48MYXBDHnajxS20JCL4xIYwRl+Y1VhkDXHtxmOmiF00XmWYOplIjq8cq2A6RQv2rEczND6yAaSw16DluOa4jlDnwmxFwk9oFN/2gSCI5xjni4vJSiggsGutSdnKjo1aeIEZWuRtKYzZk17QnTZxMXr9Ym3cgrgzxxMeUMgXp1cGly7iu0yItR86OvenkD2X7J09u/TJ0LdyGVYmSC5B7RJAoADDusgGrqGHmitC0NNostqW6ZA46RETFwkkpRtFk0Ijl1gYgaCoCQMp1IQW36OAbJ6kkRk4DiNZ5+cGtjB/eLvvz4p8jYDDwPPjI/wABgx/wwfR4dSSpnqO3GzyQdTinl4Q24e7DNG8XVO1TiTKnUp1toz2+wIVkWGJIYy7yqzp7qRlXvQ5OTLV+5YXidDb+WwVldSTPVkZo5YNdQX2ASWjMgkrTvwiiiqqWjJbXHwtlvfvK1SRQeL1UkHiKifURWWvpNNNPOgv0Dwjs3b9d35w0I1Xs51awRGIV6C6LLOTLFcuTWUyWo6yygt0+ZI1cyLqKE50jkKac1ePsOuJDK4K5PVRgVSNC8stBunxrGvFR+GdRA7oz9ZSi5PvK667mSNpDh+9czW95+tZ48b35xPM9jSq29n9aIGJIvHWdxceReOd1c7qYltpZ+TT9p0nhxGh6fXASZLIIlkvV+dnlHS6YsIDyTrJFZjY9xJq+lk1HO0sZktQSPiSsXTmfvkOGPFVEcar6Q6mX7FgLHFpe2xjSaFGkqQz1ZJglQTFA058DeW4+Ue8gtV38ZPekhjIiHVElj4SU3aOVuc1ClOeTDplBDizgzOmdnuXO9MszpGStOq57zzWK5js2DlaLZYNRqUpAryScY+bYt+DxlW7XWVgzXoO07J0yJzNPZkplMkmVUy1OrzZ3Uzp/AIDkXuaTLrkRk5TI7pODXjD/AHns84Bkf++wMH/0PJIYa2uR/rBkn45+/p1JTXUqqRzM6WZfRwm+s8lqU37scK0dPfMrtoIc6lU7lYoOn1JKyF2kmEr6y4vOwiqlCKGPuWF9SWXV1HgViSy9jGdUhsMy2odqcicCr4ol5zErJ+8f40OW9LkfaWaTdfqzqDuvF0+2FmTrEPBhbVLtdECs0UlmHat0m1WmD5WTvWoIzEPlz1F3gmlKSSv32kalFZsyyc4j6U8IrVjdUjK8IcI73asKSFzG6pFzSta7VaFBS/AZP+OTf7mzWyMr2hHpTA/IuR1KX7R0HZNcPg6z+8XyBm/LHIj9+xg84N/OaJ85EPaMGSfh9epzOtyc5F1aCeEkgbVVeCqsEkmS1nkfnGI3SXUsT9yuRkRbyosh9hs9aXkXttOXkrc+nzySSnnIxZjGprmOeWJZDGxWq714liYiBVaESGnAY4tsgxvjGfduJMjJ52WEtZZNhaE0dMnV7qdmzG4jjhPq5XFh/T1iVWS3zkfCY+7BbSRSIwM6tBqGQidW/fR65COzWJ7de4Ej6wkQqqxpiSUcURDO7ZYO+mRbocpaVbS24KKoD/NJN7UchpScrJzlGNRV9HIBw5g9Tl5MFypE7yDF+ckftxs2I3NQcGtDUbD1E5zQ4+APJ1/RyMycRg7mP3OJz7mfczqFdLFt0xKUVKaJ26fqvbmq4dF5I8gZyTqX3X5pG5GrY8vJLFyfHm2oKVa57W1R4O3PAa03pxIcVnapNnNbXCViIpdK81fsQtnTeMkMSj9YE/t2AjPGUiGRZjDGw6ajCCKYbEknF2WIxdMBrsuQQRrZiRbOpIGU13hnd1zsLKkNVPz0pazBP3UxY61cpGJjZaM9mCkLFuu2deZROsTdOg7VdSJ7qVrADw0ZLtfiIqS1qyxRV6KfmB0dYpZJy+xKQKrOJRiM/HJpeAclj3ZcoRqI9EWuqRnzTuvP3O4Cm8Djzkb/AHp8DoDshhrwGBGRH2DBkn4H69VjnjlsOiVxIokmSsisjxSzMeppKKd+KaLvAJLNFzYojNybvwa01idmVxFG6rXUH4U5LIERWNC8W55dqgk2KlHnPbDnqPOxOtdOmVjVIR/PHA8ysQXcFTrrb8YkQTRhKabrSSJEdxkPYTiXEEZlWVVFSTJTY3Yjgiq1+csq9JngbvO3VWWKNAvSkrh5mEpE0zlGllqwkv0iEpB3Ht6udQLZ9whtR14FfuYp4royyfEKVl0mWCOOSj775CjNIukZ4/m9ZLFlWjTXhsqAp1grpiV4y2CtCcMEPnUMERmmGenhJ8CvAcWtX0Mi0I1AGSfgfr1OyZbUiZIsGQV/w3diCzwvlavI0tmEVLSvAI54p6casV8Su8i3I2WnO+RczX0kfqB/t64SxiGB2Vgw6XZZgFSBV5yas2IKkPM1LMtyyJl05/Fl5DwzhFOEtd6ui51Jf8fOPbkcY/2Z43BeOaFwVngEvCT+GqPyMBLi4kGdNj/8Wu7Fe1z7kXTunBaSq8cISXS30tpZ9TIlhLtdgK3TPQSyu9j28izWq8BjjKSaDHAW/lq8WQAhcug8Tnnmd02UE7t2/wBCOqs9hi0VKEKNelgBGaXY2FIIObU/k0yx65RScpJiN4GHwV+cRDgTHQ8DnA5wOdYogRtLF3RlJQ1eM51BUWuxMZQXnUz7iaJUp2ALciZTftWHqs67HHFV+SR5HJOeSZbqbWRilLu6Y1oFStHGJIYlLHJik+689dI4h7HkySVd7aaeS9ySv0OkkStJl5OVZ8mQlo2yUAzxxZBMkbyIVpTW2kOS9Lr1k5SpXCuWjpDfS4CI0Vpfd3lPLik4RmafqVqJkEaXnFKjFEtL7vTOR6i9yMHUjq01h8kbtM0opL3pXsGNTxy42kO+Lc89wPjTZ0+DXIkcQNZ/0MQnxsD2jNA7IvdNuSSvIjPLE5WT1A1mpnYGOp3Fgi7sf4jBj/g30GH8xklCnLvmYzUkEY6jt2WIdOmiWxakMkdfkjQ2NCzLm471dTkPUH8xzK7tyVppEjU5HG8jYtdVHu5HlKmd9PxeaVbt5NRereP2tW6j/wAJ0wt5s2Ja8deSOCGLsJAuWRuJ8sNKKtcxwRCurSym+fWci/WZBuE1uox2AUz0MEc23FafW61fzEhPodySHOowDsALQgjkux76wsThFczyENXW3XgjjinguQ6R1TgGtCM9AsTu7QOnxnUIiVOf9YgX98Q0y6rINvttDQzx7cGfA1mv7Ox8WoonM4kTpkPDk9WMwFmKzEHeV2+2MDDHkQqwxrVcfKSxt8F05jOaZ1WZRGqL6Wey/gUq8UKJHYjXgJB1Gu6usq9B/wB0paRd9ZBz7ZDBrNSKePjlV5AAsvIZ1CR61oOsfYuMDJO8MUVmuILtcnRq2FmLBbMwgrSPlP8A91FxvIy1/oOpDxqQvjG/dO416Ld0TkvT7+u4vT6k6z9xrPpjbqxvYry0JkaKSUix3I4ZbTrthEvE8g0lS0pySNbSiWK+klSqXEtItwbHoSLKJJFkHqZpc6UhjqwBk+Mt/icP+w/Skm3JyIa55+ic8EjAVJ1njXgEYGB85eB7zKq7kiViF05GVy7htjueQzNHo7sOz67deULDGpVkIwKnNcSOPQziuSIE5OnNXAy0w5JXQLuPKMXppXLX0nlnkaHo0Xbjfu0H9VesznqkohrNxg6vOi6k9T66RAli7JXaER3pdSUkkIheJ2zp1KORCzWateGJnPSoFL9zB+eWjqErhX/BjzsxhiMlCRsDnTjFNRTdqenX3uramn6hGzdV9tUOIHHqqkbUwssTRkjR4tdn9K8Uhr3aLpnWnCUuSdPYWqC5cgmaP312rzjhFUK+AUSPjl0xhTnbj5YIo+OUqqBRkS65gePJG8RgB5B/oFSuOwWPIffYs5Nzi5NklpG9sdGN24vJNGDC8TLTjWRmyWANx0tq3X492pcikXkoYdxMU5/WL8vl2pZDloIK8MMhkYIvHcSygEZ3lZgucVdcEUXufOqCV2XieSEiToMQMcsg6rVtSXXZLpEt856V+5qOKHqafhMOrONSdPrtFAOf/Ry1+LYw/wDHNnWfVx3H7ZZm/OrIeU6ASeNZ0uItcjfOrMDQ8LKhuKjRmSRmaJ53YATW66SNE9rqcsSQ8TVgmsOsMQ6b1WrKDE/Tuq2eQnj6ZBUndkjfjImRNtMvgcTn/eQLykGQrpcTyZM8AaBC6O1k+Mjfw2LIhBy3NwTxCFidlNm07P4eQqRKnrG0dAymHZdy3e2iePPbDeMmglqSd6FG701exHHODncxZPLZ3Bnd8HGhikUHLdS26lVpdOjrw6mMMse+yrueCmQRSkq56VBrUadNuw/6EPU0GBjNakd1PGWLUWziJv3N8DDlk+3D5pWMuxxuIy70FO+NTpjyWH1F0SXmMrVo6yaF2pDbTRsdNtwM3c6cbFhDHP2px4FmSxDMUr0+nRCINZRYkX2F10c2pXL/AAB3jSL7cp2FKDOoTLrWGROeUQv5YHQDEZdtruHzsMNaxI6zvnpYl1zjgq4yxvKqC48cHLjGhcrixj8MZ4Ytq4cb3Eo3oYsYAfEHjHWMrolfR2uOVpT4BQ4vy30P4nE/Bfo//GD6D8zi4Msv26dhhX372zj9w5VkjPjE1+iNYfnLJ/LOIFKXH81ITiZ09+M0BwY/x9CqkEFIIYt9v6D5b6H4OL+Iy7FyU5J40Mrz9vxlmUSHP+8px6UfTsRvPKSacGs9HBna4MwePgN6aWUpoxuvBnMx79oIcaKQ+MEWthivZOR65khiFR1xS5GyiDWx1uHlDzPT99hHyM7GL/39D8HE/Bc3j/8AH1H+w4uDOrylKgXKkPhBnpvJyUhCNU5Cw87JOyTobyT41kjD074mjSUYmQtpUOKd+cf8c39D85v6D5b6OfYcj/AZMuwctoVk+v8A+TKp9o+ikcpASfOb/eRW9hYbNhpa+GdhVdzBI5eMGv5MrZDO+tDuznB3z5Cpb7LmVtNEJYopneM5H6g6JRrJ8Z1AE1pd9OMvpfbCLXHESz7tGSwsoTPvkZ99FGf5HnD6g8c5T6zdnZyOaZ9vivPoYHnzq/dLxIaY86IUHJoF5bxOEb6AfZGMeTgZK295ONVGORyOsfEx2JSW0rThQMrSzNXiOFptZuXOU2O8w5OVmmLazlNsYDN5wyS+c5zHeAy+RjTybZc6k8hdc702t4ZpRivL3FOV3l4YXm1kUjMzHG3rOR1k0YZTuK2Y+5E57EqqhSSmhHGKWsGKxxzj/gTPsaZpCW5QgqRyvwxxV4xDGpUHK+wo2vEnOpvqtLnT/bTXEkKxrwUj5wn/ACkweMZhrwCPOcvdhC53Mry+1s5/3HIGGdQfneXITocsjs78Zak9niIyFyxjDADbntDQfegotHkoQNCO2hKkAzjA/wDznTZf8FMXXyd4H8nJ/MMuL+IGI7GMEkn9E+NgN8HB4LYT7ptdT49rzy9oGOV8K0bfcjyJwEGGU78V5DpsZ/DNiyHt7zycsQmNgR6h/BlK1p964GtJG+MvblICcv2IWbxjQ7QjH5MyAtHoNkZKqutghN9Ul/CFI00ixiNiqLsMD5wsGspgk14HPxjSgAsY5fI5GT2E5zG9iB/s+6WTuL7Ud+2BkiLIO4sl2qA8WRS6Ow9gMMin1JrImJO8CEsDhTJZqsY983Vqo9qPMXkmOK+1Zs6TYUwOoRwThdQhIn6kqSMMM6vVkxZCUwyAa2LCksoeQ+M9RwIxXU89mXl3uPVJPsJtpdJyBmBY67xEsWRuvpvImHsCwuCp0z/OBvEaZ3/65bQ7ECeTnZ+NFWmkIyAmVBEY5NDREqaGf/1ptE7ySTSZGzArt5xFHyNYNLM1mSHzy2CvLElOjkku5lIMu0ONIRnLzyf1LD49WQvg2HGuauFjGn/YzvICABYaPmwkJLEmjGveDtJMHdce0ivpP5OceQ16zx8TWpvbimHnsHxhkVQ2y6A50+Q8pVSG843y/k15MDJIGl20ZCVijKxHjHl0V0W87Msg7fttTajUirMSj8mc97x1STgpjUd6TiMKecUt3YjkB+2MrS9xBkUnhtSyBTGQvl+YVmGjncOc2+M4u2cmDPt4pD7sWZJjqY9yMe+KQbzunGl7g4oxjhG5pJHsuCe4ToBJHVRrvldY8z/ruOZPcs7edNLH7uInQD2s05bwBpPMkjcFjI/DWe84gmcgCa0UdosfycCOF45zeOJdOrg8TxbWDkPBwA+dNZbQXHkkLbYLy85QhkaYHBXKo5yxF59okdBo0n8bPckOsYEhM70wVRkkowyxSprEkCIVVpDzR86jLpTrv+M7/jRruO8mRvrGm4gBO9Hw0e+hPh5V3sdrO2M4DO0MEQ+c4YYwR5jezB/qFqVo5C/qv6Nq62wqwufn04OCHBCR8CLDEN+O2SNHs4IcMOxnYUZ2lGdrxnZGdpcd4496feyTTh7suyKsf7KRgYYQxOenGCny8kdPZjofxEo85Yp+nr8yy6XyulGUYQXUiVwg4oUYnedot8hFQeIF4klpZCCNQyxnwT5JwIF84XwNluMNgiXO0MSIBgciZxjEnPP0b95//8QAPBAAAQMCBAQDBgUEAgICAwAAAQACESExAxJBURAiYZEycYETQlKSobEEYsHR4SAjcvAzgkPxBaJTVGD/2gAIAQEACT8B/wD4ghEJw7pw7pw7pw7p7e6e3unt7p7e6e3unt7p7e6e3unN7p7e6e3uFiN7hYje4T29wsRnzBYrPmCxsP5gsbD+YLGw/mCxsP5gsbD+YLGw/mCxsP5gsZnzBY+H8wWPh/MFjYfzBY2H8wWNh/MFj4dfzBY+H8wWPh/MFj4fzBY+H8wWPh/MF+Iw/mCx8P5gsfD+YL8Rh/MF+Iw/mC/EYXzBfiMP5gsZ0jSSsV/crEedqlYpPqnv7p77VqnGE93gTnIuRN0SjUILSoXohVDRGyK7oURWqNOB4W4CibTQ7qIuo8N1NOAqNUyoJCtKbVBM9U7RaKLhXQsihTVaL9kLIK0q02TTFkCAnEko3Vx/QP8AYVkaStU4cDwhbqEEOB01Tm1KITmoqDCNVFAsRttwiOnVHXSt1ChHRGqdTUp+YCxmnA0UCPeBTp9VFlCIThaqcLIgCFuEUaI6oiBqi2qe2gpOqdKHLCoE8BFPE2hYo8ynNKIiViOWKViuWK5Yj6R9ViPWI9Yju6xX91iP7rEfQHVYj7DVPf3T391iPHqn4ndPxO6e6CDqnYnzJ+J8ydifMsTE+ZPxPmT8QH/JOxaPIvoFiYnzoYvTmRxLT4k5/q5Pf8ye/wAYF05/zIu7ou7rPH+RWY/9kHQdZWcnMI5zQQs0/wCRWbuVPcoPza1Knup8O6zH1Qfl3lZ7/EnPJd+ZDEzbZijiAi/MnPqTPN0T3F3+Szdyge5TXyPzlZr/ABFFxp8Sa+A6AcyzRuSi8O/y49+GzeAQ4/AVsFVUWvAKoh0/RHVA9tuARkwgh/5nJxqJC8LTTqm0IXKUSeqBn2jUEJUCTdcw4PklOk5h9uGtPJHmAhPiBZQvgd9kNKIcpNEee8IklVW1k6mZ32Tr3WFM1C3RoUFoLo0GI6ilWnhK7I0X5eGouEB58IVw0p+grKhOAUXvKIronBEeF0/REIinVOEohEJwTh/yPKIgFOBOtbLFbPmnN5eqyiBVEf8AI2UQel0RfdPEKJm6cLpwz9UAZIg9ITmxrugMt04D1TwnDung8p804eFYjamyxG8tYT4Trp1k6tZ7JwESngxdEIiyxKbJ4qog4jrKh2VuN/qqq8NCJ6K91aU0V1TW9kxtxomN7JjeyaPCU0JoQHiQCAtsgLbIBfEgE0XQFgoqggLngEBwpWqM78Ac2bZCJsUJlEWQuhzZhCjh8K3QVieDMwioTYV7JvNIQW6+BXRV8xVAV4jC3QKF7qy0yLwqLX6f0bjj8PH4uHwr4Rw3/TjsOI1PDZGixW91ig1rXg2XaKjWlGYohIVFVNkghW24fCiBXhv6JwKqIQqghJkJmiCNci1V0aSm1CMmqCFN0KSo6q8NVei7pqDuxTX/AClNfce6mP7JruykBtJTnT6rBza8xy0WGcxNkxwJ0v8AVTmi2qBJAEwmP7I1BTSRuswPksN1goB8pWL58yxCGnrQpwdhum86bIS2aGIEKvSKJ4BlYYjcUKxDHZA9CFmLS68JjolMdGyaYAFFhOssN1wmkACpQ5QLi6DyQ1A/6SmuCDidm0jqgZBoUx1kxyY5Nd4gsN1lhuTHeFMdRYb6dEwhpcgSXDstdOAMcPNflWqC347j78XOhucgil9k78VJvmNNlYEM7LegXM4ivQJmVwqHzzTon+zAb5VWIXNc3NXxRsm62VChz+9vKcaZZpZPkR9liFozkWRmKNrWegQo4z7PQIDwpwl2lVzP3XM3axHknSxw5DbyQq1YYxWC7bFNy0rSs7IvHUuhPmmoWH2ThQiRrdf8bT3O6PugoxQitJWyytm2pQfM+H+V+Fd7LpNEHCdSFtwPvDjqCtleU73inJ3NKxsX5ljYnlmWNi/MsbF+ZYmIPB7yxMX5li4sxfMVi4uX/JbcNx9+GyP/AInL/wCQxH7MI/lCfaVI2Oqq+ala6akq7gYAMRFYX4YwWBvSFUNAYD/igSZo3p1Xsz0H/pYoLm3aLQqVWaDaiGK0ZpjKmPNWy6FiPlraTELGrmiGgQiXS0VPmmo1UzncO7Z6K7mAoUmZ6LQfUogMv6r8Rh7ZS2yEEyGk6FZprEQABaq/Dl0at5vssN4BEOBaUwgzSU4u8/0WkZPVYjDjkAA/snWUZ21DkIOo4bhWVlaEITabqfEdUD3KaTP5jwC+i6qnhW10EEwR5pg7pguNUwd0wUBN9liis1dyxmT+WKn2bR9QsE/mOqbIkmlyuYzTSAmtFXEA1mFlytEnmKAyweiaLmk+iObM6DW00TADitvB1WUzVNBy8t+kLEBzMjtZPDpaJG0apskiJFgniLukSSViTIyigj6IMTR5pzQeanV1EWENaBrosoBNfJS+TV8GE1hDkwNIdU/mT4LbZRYJ8TqB0lYr30i2XvCD2Yb/ABAtoD0iyLXA2y1lQzzqO41Xs8j7BzBHlIsm8rG8s2kpjZPVYYIBje6h1ayDICbJdWBceaYKOTW901vdBtt0BXqmN7oD/kPVUpRYdLI2QuolbhGkMXqjdDXjuPvxMn2jcnbVGXO11nfyCa94gAHc+qNfZWNpGiwCPxLneQncHYLEY8kVDb9Sqi6sZIW/3V0CHSSB0NUfEEff/VGR0RjM8l8JqbDizMPKYWidAiYQM5hQXKGQ9TCc1zNYujyOxW5vKEwDBLwwCN9keUuBQsMNv/aZ+yvA/wB8SbQAT8qaG0qBvwgFzp7Jge9hEH/Klk6WkjSg8k4xNd1jOja61CjKRU3rtX6JhJiRuNNFEl8lDgaQUbpy+MoXqhz7LVCf0QRWzei0KNI7Kd68dx9+Hjecrf3WMQ7NOZYmekT0XXJK93EH7ITmd9qpxbSCLiLxVAudlkNGqdIe5wgCydmOeza2R9NVHjIp0WtUTp9/NPc15xCneKPqEbj9V/8Aru+6It91iREUNIhOmHFs+S0+qJDkH1uYkBS8/FcN8k7l0N58t05+cTQN119VngkXFN1iEsg00oFqwE/ZeHcX9E84pzgn42x0U5iRfw0sEI94dYToLjU7BPr5o+6ni81R9pjGrtIARlpI4b/0avQorg8KdENeH5VVW4PPknuT3XCe5DP7N0kHZYL8xIBE31TBmN9mhTlAiETBkI1bzQNkXGifBc7mGoIso9iGnO8GoOqcck6J7pijk+94TjTUouDT4KXKALfaRJEXEoYYDNa6IZjpRTmw23/KSogHlBvO6wXPGlqIHDBPuo4lrk7LMg2CctalMw24EAT0CaXOy5cxMegQwHEk095Nl9JY4dFhMEg6dFh87hpS9gqilD0qsrHTNlg4bwPfhPDnMw5MGYomy2xOqwjEWcnEDJSqdVsROyIFHQ3zugGtztiKJxTnJxsnOTiviuuykf0xTL9OG6347ji0YYa9ooL9VuEVST6nyTvZsIiB4o/RQ0RfVS005rZorVMYG4z3Z8UDlAKcHs9mDlJgBwofKVyNILnRqsTEOZ0dI1Q5ROaa/wC1VQHST+y91w+iPM5o+ywt9N1QHCyt3KKKtFwqwTO8Qm8rly1kRQzoQU/O8xlFBeomPusSc3/j36fm9U1obE2C5aWFW9iqQdPCf2+yw2jEaC6muVYcAgg9JRqmkkkUHRGCQQsPMDeP5RGQgQHTITpIQtrZY5NwK7L3H/Q1VRw1HEe8sM5ZQhbLdE9Cjovy3RP88D68DVbhHh7kD1QzOz+H6J8nZuihsEyde6AcAYOicXHQaD0UAA91UC7CoYMRxhloCkUiHXomy8PLLiIvSU0xk94fdPIBEk9EzkLvsUyCGywi56EIPE7jZGvNEoRHK4JpI3VOiZ7sIASJhEGtrppaz2pdaBAMp7y6MoF09zXFnfush5fCDWgTAH5Q5pGvRAkYGPl/6beixhzmTN6+afXogdMqqJDqKDa65ToNFBb5oPGFhzlYNYQ90geik58MFzURBEhBEJwRF1bOt+DT8xQdHmU0x5lM+6GrYqmU9VhhMCY1NCY24TB2TAhM4hlBMsmAt9qQ8ei/CubN3nRZPasEPpQyLoOaW0AFLbrmxC2BF0wsxALuF/VDNXnY4SPQ6L8OcMnpIPqFg59LZbVWC5kSH6j6LEpv/wC1iQ4WmxCeE5o6uUOaRZYYPIZrpsFgvJGgG6cWFzq+iOdzLuaJjzhAZXnxemixiKtoTYTWJT8ou6sXtJRa0NwZM+9SKI/3SAa3qU93hbhtB1flkmOikRhmuqc4xhzM2MotdDdBWOoRrOgTn52mHU0WJAdrCMhzpB6QmhTmxsXN6aNV24TvoFcNbPqmgljo/VMHZNFkAmiqwweZYYssId+G1Uf9COkLTJ9kNK1Vv1W/Hcffjoc7PVMIDbkVCa4u1pACLecwP8hZeNojKOm6Mh3KQOqH918NaQfr6J00kuK/DuDD1GbsnA5PCdw4SEIxG4jY85XVQBuT+6LcjRJh+a3QJpBcIIboQnw74TLT6J0c1RZM92pnZNyphI7JjwWCSY0RczDrlZrB3IVCPDsnuBa0jLpCZLC0SbwFgScIANMZkw5yCMzhEeS938I0t/7mpWoBd5Jw8A+6OQ5w4knSsJ7eR0XRo+jd+ndbH7o++YGwUF3mspB1TjBZB1UZWtLcwvRWm+p4bHj8fDdE34aqTRflp6Iud00CAnQLdT2KDvlKzXGhWbsVm7FMysszczuqe0w5FNVDsV3pJ/ZA5mxzGlUK4gBLdQSgc3lZH+3UgWgm91Jt1sZhS7MDM09PqmeKsggUHmpofD1QdlAuEBPNUibIf8uPLvSqcQYa4dE/ELZAh92zZzU3nbrsQgHs0e7SOiy5tGtsOE0INDeEYIuEG1sXGnkm+ymmbO0gI+7lfW0eE60hYfMdRIWDm/ykpsZXO9kWubb4SNk9mU1IzBMBdBhtKbGaIZnPg1qsptyi4shhkU8IgfVYNQTAuLoE5TXymEx30/dCK9FByiSAQqzSlampsgexU9iptsVPYqexQ96h1RujqtCulV3VFfl+yHqm+quvh4bjiaZw5vRcrnMAj4f/AGncrWUY73SEf7JOb01KEEudA22WxQqAHMTzuWjRMi1SmknKBA6qu7RJkn7rCY1sVb+VYWdl/wDdkPDjfcQjADWCYmJWKzEgy1jGFsuFsydmn7mqbE/3MVXWysZCAEOJLkAWFxO9FhMPNBpYpkxy4o3busTKREA0JT/ZhzaGJKAcwTVvlsrZhPoh4vsnuaDk8PWZWLOYV0Ji11jFsEF0RJkJvI3dXe4T9/1QDnFYb8pu4AUzbr2jCKZx7yAyGDm1k1k/1fFwupR6oV4Vq23kt68N+PTjXLisEbgNlNIc2pb/ACodLT/id/8A2jdoY3eLlMqQC4dVMxIkyvFh/ZaJoP3pomzmywNQUByY2V0GRmLaJ1a0j7IxSXHZPJZiMzNO6MGWudpmpRMaIGiJDQJcNJCHO+rumw9OPxT2qhP90hMLHSKiFORragVsoZhkV3hXlrWf5PohOUQAnvfkMPccTI3N8LW6wsoB5SAPipW9eAPK8ByqECM2XTZqPK99iJEkrDGckV1TZDYupwsoLCBTN5rQ09R+4RsS3r6JwH5ZqQgJ23WongF8SKAVpUujQIHyUqfd06L0U9AVNFlWVZVlQanZXcmYjeFj0ccpB1mie40OUOtTZOl7eby6otPKE8xhNAI92q94Rl+KVWBRsLFJ66dqIic8hxGg/RGWHEN5+hWIH08Wv8rM+ZqBXzWO/Nh05WxAXNakXlYxDbQeZGQcWulqrdEwu6NBmnyIRh+I8keoTs5nUoZMxgx0WNOaK5U6rf7rx1iBKoplubFbI+KJT65AZDItvJWI3aSg5+UZXwJzBfh2h5bMxssXKRs390XOIaX1F66okZRNKoDmGatFf2bbLOwZplzf93VMvvGqwsEv+J4zFOBe6bUaJ2CAoN0B3Ud1u5VlCusprH9j+ywsmX9UU5qIu37I0REwiO6H9My5zXgjYCFjOk6XWK/O2CJ6JrgXM8MTWEYc0f3Abn+EMrcX8Rnk6jSE52LjnwRZvQJwkaahBzYaTntXonAH2Q+yxAJnaU72laA79fJHXmaf0Xib/wAjR/t0aNY1xEWcbQVhvdFXZdJQhzpdE7CEE0Ob9Rwu5ymjGgdEC6NUS4+8It5IcsW6/wAprc7iDJE8x/hPbiHK3EcQ+Ib8IasR7AwNyteILhH2KzgkjDwnGY8pK/5sTlb+5TAGNy1BzA5aSqxh9+ZABzwQB+qFcmu1/wBVYu/+oTYGWJKbmxDFbp0S0mnRe9D2+t/6tXFNX+ysFp9FhN7LCb2WE22gTGRT7LCZToFhNWEyPL+owxmI1n0krEZWlVFBAiiEw4A91Qx5WKwoLWwHXBhObyjmy1jzXhc4wqch+qjNlbfyCYwjcBZRE0BTnNOm6ZzNvt3XswXul0OraKJuthqUwtZBBEq40T3t3EpycCxj6eQqVuF/tFrT0Tbireuqxso0mi/EubmBByuBkFY5xMLBLgzayA58Y/snzGG5oBNmkVhSHYnOem30VmMj1NVhtxMMP3pGxTvZnFHYWRz0hpAt5o5W9EeZwENAU8xOVpvNl7uB3147cR7ywwmjbhtVD/0nt9TCM+G3lwPDEcnu7p7k93dPd3WHmcTmfrbVMZ9UTVolVIOqAYC2pgtv5ozIKAAxC5pIXLqyNQpI2Kc/LMAt8Q/hYgdBgogk8xmklYYHSsqB7TEIdB2WDysd4pgiNk+SIe3qEwAdFVYrvUoO9m3xOsKIEm0r4U8icMFEudr0n+FMlhf8q/De/wCJxICD73Y0uE903DeGgzGYOFNWlcvMaDSqJyD1kp5LgLSAnezzHe6d7QGrh/6TfGQC02tJRc2jj/soZsLz+6r7NkTublSSwtP/AFfqi+c2RjiIlnknn6J5+iebdE93ZPKvnur6rQoDzXlwxGuk0afssOCNIhF3dMeR5VXjyifP+r4Svw+GZ6Lwe4f0Uy51hVYZcx3IIEiPIp/KZGT4TdbyE7Jj4evVYR9q3b3kXYWIflI2Rdh4g21Qc4zr/KHohOTFcQBsV+IHs/hPiRyMbAnYDVFgBMtBmQCsDBPXOUcR/wCUCGfRZYLw0NFNF8MHzuvhKbLvZ/qjLzc/oE0SaQa5Rt0O6wQQ2gIlAxHMw7L8S8GT7NsaH6r8ZnI93EFUyHAQ4ddU6c5BM9E3wnOfIIUALo6hMmHOf6NFe6FGtzOaTQgaWom5ZLZboQVTO4CP8lZ+A5p9CpLGanTpx24j3kFfTdQf0X34tBFIO1FMuiANE+Xa6I8CnBYrU4fZPbY6p7e6guLsw6ZfJANlvNiOsB+XqoGXX9VGdpQ81Sgv6qrQwfRQaa9vuURGlbeRXiDQM26cFUOALYNQ4bfqsL8OXloPPIdXyWBhMo08pmap2V2zqKaIxDaLR8+sVVxVaoeFhWESNHGg82zqnMB80wOa+IgyU3LykAG9dfJMJc4HKQbSU4nDPgBNiPd9QjR34Zz40JYsNmHNjOaUZm5V8N3cJwkGWk2IIqCsFrfc8cwDssGZEiDy9lGUVa0GanUrw4TMvrcrxUJ8z/V8SiVcfYrUIVWi1CnmsBblFUACRVSehH6qnNSIiE4hVHVybXNdp0iyjNlE0TQmCx0TAgEwSDUbhNbvAFPVH+4ecxsK/VNnprr3WZ7c0VqRCw3ZThQPPyVHF1nbBeCYAVHOpI0rdMZiDex+iD8MMY4vjUdETytJ5qzO6cKgPdSAg18A7FZ/FQyRQLM51hmdMIVFe9P04brQt+6YKFENBGu4UEjlJWMHH4WeI/snwHPAyTSNlSMRlvNPJD2YjJnXRUc2QVQhS4E5S3dOAzVAdTojH9xtQjD2Uza0WMGNj3cOveqeC1hqNT/CA8QTQmBNFk0JoUxnPoitVYIL6rQWRnKA0fc/VEtbqpMCSBZW00RgmahPd4TfrRPy6zVDOzf+U6RruPNHQ8d1iYgY67WaHonY/tDqZ1Tp/KfOq5Xag2K5XTr9171B5IZdZFOuizMgmM/KSI0WHB+UqRWK9FgPc2gkCUKCBBGgCIjSU4ehhMcR3QhxNuGy0/dYr8hAMAouceplGzlqboGG1lGZeyO6dAdmAds4mQURh/iBHtGOsY/dfgsbNuyHdiszMJpph09o87QFhtZiuAAwvgb1Q1qdB5oUnmLXCCPIr8QW4Umk3GllmmIqV8Q47cfiKEUojQpwqnBR5Lz/AGRsxvcyvCP/ALfwgIcRU+70TQ38xqEGnZ2/RfEGqappiKiFIAuNv4TohwzN+EjbzTXdk1ya7xJruya+ya9roHM0QsPP+a33TS57yM3QbBFzh8Lr+hWG6hl1Fh5hlsQn4uGPh8Td7FYrPLKWazpIWEHb+euy1En/ALcHL0HHZaBDSh1RDvMEH6JuJzDQApjvN1B9JUlxiXELM0zIcNwgHNJo/wD9pufJEODhmC/EfiB/1n6r8O72x/8AK/mcf8dk0Pxorm5o1TQOgELZHbTgdQiijoiiviKj0KIlNYDqwxM9JuFgR/1WEw9k0ZKvI+gTQCQAfL+UDVNBFom4RzbaFFwaVqZWghXKiN1IZib6D+FfXh8XDZbDh8XH4eN4dHqYXxfai0CNkaf0bFbN4b/fhuOAkHRYbWyKwI47orYrYcPiHHbiwE5ryUz7pn1KHPPNKzM/xcQsWRbma0/VAc1R5WC8Oavk1CqJ8rIS00IN/PzVWE0O6FuYI1iq5fum/wC9VcGfSxTpn9KcPi4bLbh8Q4/Dx97EdP8A1U2QVHD+gT0UUYbL4eGkcOnH4eO/DZHQcPi47cbZyt+AIjwv1b/C8PxCqmTRtZug6JuXfov/AMbz3WFP+TkzD+YrJ91hH2BEyBY7hE52CtaQ1RaTRFptFN05nZYgPKaaoiA51wnM7JzK1sizwzZOZ2RYsiyb6r2f1QbZNZqIk6FNZ3TcPuosTA/OVpw1RhFWHDWy2TG0O6Yw/wDZMb4B7yY3umN+ZYY+ZMENaZqsGmUEOzLDHdMbefEsIGOqw22+JMbYe8sISD8Sw23B8Swmx/kmMEmBzapjdPeWGPmWGL/Eh77pr6cNkNE3Ph7fssRzWt0AQxiR6fdfhnElpHM/RYGC30Lvunx/iwBPxDSlb+al4mcs0IGiPjcZiojUL4U5wMBQaJsSP4W5cmFxkUlOPVCf7Z+63RN6q1EDe6dsUaqCcziO6PDQD6CUeBqvRXVXJ1Zieuq3hagqnP8AoiV1C0RqLpwXwlbBNIOoutuA8lsFflnsiDAHCuvZSjpwHvu+67KVYheiwmvA1sfosR7DFncwCLTWaGaLw6eRsp+ygaoev7IQGtDQhYFDRHNQ0RJkz+gQHKKTum11TaI+4b9ChAOqKIAlQHeGidT7Kv6r43UHmnkc1SoJjXomQ4uJM32WK0PFxKdP1Tr1UXQUb3RAgQsZo6Eppf6QPqhBzwtAnWdPfgFPZfDRCCRZem6uBPdA3mY+ydUUWwWuUIdkNa0R3jz4bryjqmTJcOl0CJt/CrIOq1UIXNFFVSBUxFV/yM8PUbKpRp9+A94/ZbELQQCiaX69Fvy+f8IJ3+7I2B7pxByfqhSlJTeaKdQqlvhP7IjT6oPLvK0IGKoeIu16p4jWVjaR0RMZSK2VzVWb90YlwsnHzlYroX4l9vJYjjN6qMzjfgfEf0TwKRvRXLfsUKiNViAzYLLMaGU/3Lq5Asj6apg15tuiaTy+ivNYQDYPiQMmPoFmkWMIxFD1KiT6JwNkeqmW3jWUQObmJHX7oyLVpTyQjYELe6PoohdCENlR4R9niau0d5oU0IseyLbJzBRCTFgE+o9wX9dlRgsNERSnkjEbdUXGUZnRSIG8SiA0a0MLHIKxRI3WIPRYvkjQ9UIrdFxCEwhtwshz3tZNIUqVM8ImLoohTlg1CuRfovFp6K5usSo0T67+ae4wTVE9Ybui6hsaLEyitITrthD91iO9U8om4UlMeRlqmkClP3ThQzHUoN6CfsjHqDwCA4R3QQ9U8+SwcOQBXLEyei/B4fYlDID8IyoT5oJv0QhSm8Gjsmjsg1DsgmjshwqdgrlWagEOy3QCcxNYUGLJUxCheqIykTWya2Fl7IN7LKDunn7cbbhZuDSpTExNhT3QTUwJoX//xAAoEAEAAgICAgICAgMBAQEAAAABABEhMUFRYXGBkaGx0fAQwfHhIDD/2gAIAQEAAT8QGDCXLlwYMuX/AIDLl/8A4D/+VS//AIuX/wDDLizEWLFlyyXLIsZcuKS4sWC9MFG5gAyy8v5lpaCgoQDsgOyf94n/AEyf8lP+ahd/pQ/8VD/xMP8AxMrf9Wf8jD/xM/4Gf8TP+Jn/ADk/4n/4aGWG1OS3/iFGBD2EtfIWcg/Mf63+/wDHScITUpIzE2Qzvn/2/wD3H+v/ALjRf9/3K6oWWEZez8TX+PubqnIxh9f44izEbYRGYbUTPjotzAMpJvFjaxfML4CL2/LB2DaVaRTg2YZZS0dDa6ipgWFL5jh4aC3iBVoDTeM9wRdi3kqKXUpVbq4BVZMPMVdXFPmo90LWfOpVhGuWMsO2qcPPmBhVWfOJQUaKB53H1wWygCWtQOZGllhL4FmnVV7jV4EC4S4WBcSohQGDXEWk5eteIuxN3UWgDya4GAsxvdgVfUAAiAcBo5YbZYuD2I1d52fW8wtuqkej8bicaeBqIXNDZLIuFWyvXwQRjSN2x3NwUq+ZUzL9y8Km474bKRGi8LReUgZa2t1EWOD80FYymsbmwquHEsE2JFYoihzguJ21h0S4bQmoc21VCOLO4HOhcc1XiIBuOBvbGwQLNvmOCsreIHNc9LGcoH6GKo1Cq1XiVMot8ygq8qCwaoYpsgjq5uGuCD53leI3NmmrNWRsSi7YtmIsmfwQcDYOb1UvJGabZUrlbW4+LLctJuYuWUzn4zD3O2vxLW03lZaquK2H4leOWim6glqa77IfOUehdeY5FOHRdygC0oG49Uc0vUEAJbRbqMKbGlu/cL9WVAvEQWDbVTAtchhkedqyMOMo5qUJRu2rs9ythyQclZ5hggxkqd6JQ2W3Y1KoLNKkUlAAQyCYB2cRADnneJZ0KqHPEqFTdPKADaAMv5qYkoZ5gq6IZ8QwzhtE9Aq6hc7Reali3ib426j1T4goPdemAXArCMW7nC/ucjlow+6inAw05JxDiYyefZEEI+Ryy8oL8kVCHAW51Cgxzu4vL+ZjkgBiG7MrRUwZ2RPts17qbZ+OD/xk/wCYQdNhzRFFSeZuAl/BZEbdHmI/bA7ogAZ+GMyFq/AljTaV2SJC68wUt+uWk5cs50wnmWtyOx4h9fReypbQoby/sZmER/JqNfK921GzFdpVo5ddVR1e1w8JC0yuD/aDo3h5RsJ0cJjQTaBLKA6TiENt2umYfJ3ggaZvOaAv5p4mC76mA9DWYVMTfBZUarTq0IViZqHSkDafGS5ZclTFRzus8ERgPPOHjMSN6smRErORakRS9sh6g4EWAFF3BM1dXt9Qj3SohhMXZpKllc34SVKGDsuxazGJVJBq5DBFFVGucUJh6Eb3LAh4madNwVmLyZhs+BS0XAn74lNnf0HEc1gmbDgCAoAStG2CANZeOFlxBqwMTMGl3vmbCBRzhhPTK1W5vJyVeoaxjbR4i3Gk4tNDzBDyUVXzK1YyiAl51gzFMC0KG+cJ5htb1drKqyWMXScKyzdYYt7lCljarR4StUynOUBmfuAOA4jyoSl1ncNuiZy4bl8GbPZHaVsT8UwIW+AtpLQVMDz5YGA0qnvqWC8hAFbMC4d7K4ZQnMunFf4Ysn6Rd1qAKy2n0SjIFWbhAheSsYqm271SSvXlYLIPu7Bwqds4or7MCnovUFVUf0QKXRPpiWjHNuGCB9cmzqDUrZzG8dNmQeiJDqiA02tTq15gci6mmUCFiQc6HAN5ZQrNddsKmp859xCnIqHXK/Im4FfeqirXRdQczHsLMai4avap2TRHWenwQ9EcUHqOl57OtMq2RwZ94iUVrMbIikaSyS4YujGbGGbI96alVrej8XAJYLkFwdx2IxezPc9okyFkBfbQDV4uYx2sLBZ7mJWHncHSKJWVF2r8WKr5m+yrKGWqihEaunD/AKltZlVvlzFRlueGjn7gl6SnDTTxCxgyEBLhMFgw2UNqlQNhxigNsci6aKp9yvUOZtMrDdt0HGIUuXCsrwxK/wAtgJGwkmMjfzF6S5CYw4w5YDF0paMy7w0cAfRL8JPIsMoCLcj8RLObEpmaakOxsOJfUNNFWs3NOoC7TWNS7rkGdjVc6iqCcQYB6WDbHMAmoGm4NAaWuDxWJn/BVkCMO23i+wSj12PJDI3mjO4TqzkbltgbwheNxexrXScxL3jOUQDwOiLBcBLWI0hRgVzfmaAvFBdwoECDNNU/3Lopov1CyvRPdm4Soug4uuZQVo5bIbY6ZnitroXvcuimg6BBp+Adwv8A9CA19COur6DsmZr6Sf8AjSbx5cEq8e8hLWDT4dQCitc06hKJeaITGUdTpikN3gg+yOCHC3eHbACMXRLdGNYIrNEy47YBqbrRFVGk2cZhQKpa0QFUFx8gCy3qFwkwcAfUGbV7wqiUARlAYBsZ4j6TWVyKt1MUlNjLJZVZRAFlRFcG/wC5nKNePMdVpdRoYtifBKIxmGQUVsC5jl1gpXpKhq4qqhL2EXMWT/eXlYMbGKpjmtUrV0EO3OwuiLmNDGaiA4xtdZe4q01Li848ELytcAJRLA4eGqhLQOzrFw1XsOqQfcpQ2bJuvZ1CtjKZMcvM522Yt9T+g7P8Nifkv2TtKzB9mE/Us2mUWGq/glIsn95StScQlqhryfvf8WtlDmZdh+1YgljgWO4OAZiQRwN+Jy5E4MbLqoHqKmFOZ5DA1FoDCJy0QYpND6gRaEsmwKYAaw3Ar/sGeceIcaYCBwf0ylzg21EWzxLpojpWhgn43G4mRY7JWOoXEKJSHSKIINaDkQceBJUKln7mQip/MqASmV5nJ4QfROQWYqiPNW5bCoRFnW3uIW6jdPyQQKghssMcdEOB4WHBjMe/f4KMsSLStKc8MFKgSx2fUMN8vFrs1NT6zDGPMLUhxHmF2S3XyOFEua+IDkRV3gg7BDfpLV1BIq0BCbOYBYbYwcLgwfQiK3DvGmOS4HU4UUo9xKkElFlLMFJDVGaAP6ZWhRw5QMLNTRyynnC4JljyBoHiiZeDDewCUC0YBXu2maPNs/mM03cGo+LizSKU0f6iVxddvyWMRhitgVV7W+EIOTCubBKvWZsrEZWvQAP5g8HcAMxzAkwQP5h1A4jv3LVHEoAmLaqyP3eoyQRFbrm96gFK03jIJcDbbwlccXnBEEIZWNOeUKWRVJWoSw7XBKujOCX/APMhs7DAkvhCuBBf+Myh78HZ5jxl+iZXTRORKxoEQM0TfcCG4pWd1ReV1B2KMg51Aja/0wrlbx7fhZRqwVRrJZWY4ImF7p7YrFQiZ1YkpYlvtVviH6mBO5/wQRKLYNdi2BLJbkik2oNBuuBmA4angNQF5JQGrYaOUzcnQeJRLZs7bI7uCzQVrN8Wr8rCp6usLpnjDuVIC6g6qarXyGHwnJFapCN04fEt0oVyObdHO4Jrel7CmC5h8gAW6FbY33bg2yUPJrMPVQgqt65iqxgU3jUPG4wGZzlAAlU/mGB8EcpucOFtHJCVJCNAvCo1nCd5hRpkf5IxUasexJXoIs2u2PUeZIKCnjMZMRav164J7nq34twzOWH6ziWhNDHF+hxDZDe+FuPewgMgcS5PgVlfUtIKwN2L9FwWk1fdurbcxfbBA28mzMM5YCgLEp8JyjasQaZk5lqDmohVUwvkhqwLZI7lJk3uFahbwq2BaGjmHWqYWbGKZ7TamWO6ygqLrMy5NxbasgKgDZXk5izZU2KzIxqBzDoeotTlrHuEDFapbla/xxf3pKK3DjtdO6bSXW3F9S3rHKlPm4Uvg8J5PAMHRcxOCZMLpCUpRETpB67vcug3FR81tjAs5zt0p/McAg8VhBT3FZU2hVHdosJiwsqgPjFKzdI1wMQqMclghyRjaVSvPx4gdIO2lBa3CMzqUfpLoNyVoVtqDlznaFiiqxGpR6yOYOqWaOsSn1A6Lxib5EqsWL5LgugMdADCOtbzFFuoWiO7Ojy81H1hQioNZ51rzFfhWWqavkZYCFbKiwU9sd9UI/2QU+vKHOCPLF1gnklLHyW14EyBpuHFZXBbsI74r54uY+nSPDVEG2uzmEmtx0JEV0LJWw0A3ZiXYgq9pY+SWVI3BBXAgzUBbFHcEqr7oN1fMXOFHs43olxTBvXcSgA8GYByKRbVvw+YNVI0jFGPMIJajjpGF99bXj33LQIg+nvETgBHd8J+ZkQ4ONnep/T/AMT+paniH9v/AKmpA0tpfUbbgFHsNbuJsHZAMWgNMrzizPm9sHBcFlwcFZZTEeg0HggGqDCqHxnqMmB1hjwDWZwFjbbbMauHWNFeOKi4LyFdVYAkpUaJTOCuI9rE3yVxiJ8nXbKUYvBXVMviLCg32tky1eSa1ebiVV7BQd2y9Xdwhe7D5RXanKpDAOOig2VBqGcDiy+DARX/AFNhwrIkZ7MAq4F7qFdpgDxuMbNqWxeRxzuIAwZD3OrlvhKFojYcae1iKUEXIcg183FZe7kk3SssoFgbcBV22JT12CX6VFVkEStaaFE9ICVAEHsoVBox9FyXfiOfmn/iFqC4OFquBhj1IzBkvVQISpldG2oA0gWK2I6ZQqu1t/ECo/lfxHkGVl2eJcN4NL+JQRym7/xADuYNJmwIMOfUerJXLklrT/whhWjoLkdROyIUFtN6uKpG8xAgOQrfWfUTqvDaepSAXs8eiNBDYc/nyQ44pv8A7YTmAggiNkXINQ8prpRCoNqlrkiGT9Ccpu+iw8htBW7C+GHctQ3LLFoWoO7PS0wl4o3MeDQFqW1CkjdNZJdw1b9mYPyROOb/ANTDuJRpEDGRedF4zq41dgJW+PlEkiNZX3j9x5CB8vG3ghFugFAYINvVFdwb+sKJ4yRozn5YS3NYWFEChaFU4xMqrwtQhyiqfCsD7ispSYstlc1VsUKCQcLVh9yx8Vmci35ISjlsboXwv1EzkLcMeuhARwUO2cYoWhyeYS+V9AgUKJadHNjJVNaupVrCVgS5VSNncpp+YsK5ruMlJb0S2qWu+Iu2knRRblps3NOiG9WhUaahZTz/AIzQHIKWSIZpniHigy+AldUmYN1C2Qs+XcKRy1RCoaLcmtcMsHM0XdhxC4BGKrzADrSVdNO4niqzh4jFVkh6p3Fa+xwr/Iv/AGcIENKq6dLv4REUG4bpysYD4KAyxtB4BhYQDR9JbfuFjH1GSuljAuZMS9hwJXBqoLAW7mOwbQub3m6iwVMgWFjjywIFTawPYwodyiADWKmK8BoBP9wzPLgLttxD5Q6FNN2jCzJTa3rhO9jxaoNHO4/17DCIDbMWjtIXB6K0wX2PviNujZ706iqAcagzQBY1zhvq5e1ZQVM7y5hCUBwFkcE3O9Rg0ocQWV5XLB9WO1qcLmI6V6bLL7eSyPIv+sPkmS0WhuJ0CsjfBPEQAGaCrSQL+6bCvCQRdb9AftgcanHOZY7D+IUiuMPLYlTElzWOEHBWog3+zaYojuWTCKR4YhDEqC6hrS8Piglq4YvbCbdRxsYvEF1dNVBZjZ2xVR82vpogHAyN3sHcJnYuGTQkOA5WFXxTXMdjhdgmpmKvnlrVkS6N2oSjOjEMP7CCy+C7PENP5CH7uQpYXES0r9BaZOMQyK4nNx3+cRWgAB0EX4RxpESD50KWFkQu+IRYsLBm/NBqI3uGaPbXqniWaXLlminMPWqKEBVOSokAiizNQYQ5FRj3cdbFSkgyMeWrbgdEaqNFhXoSohDuWolVTCEALFsLtxLI4Wy71nXmWAOTG3Jn6mK9wKp6XM4rKSLDK6N5pDjel02vwxB8Gqi5M3rEaVSkOdlhW4JqAKJDSNnxF+ZLxbSNpbClgzQDIsgBnLxd4Usv7xHpwaFjqqoRzU2XxMWUaXwWlMsV1a1+HWWH3vVnbZDVC/JeeiYusoUMka77RFtwcPuLH8Vx3SrwwDJNsyL0dzJ5u49oolz5JvtHcpFaXmOGdMt8blbXi2iO6iXkjiXlcK0RQRXwk0LsdlZJsF2aMOTN1LVZVDWkJt5iwsK6xqpcCrgltVZVQUK3lrlhAjr/AA/ueSG4ANyjI82KbF6ucmFy5V3llGga9vRF1Dz6nimrOYsyhFa0waim5qKbWOVj6xurbodi4cYWqLwpwkYXBLjabptwhsi2QjbRRi4rwxRyBldcRKsKx0wVaunhK1guLgSu13Bs7tjyKYNZs290ckMwL6WFwWCEvextfUTCKl2wxUWtVcX6I1R6lmQW0ssoWxVaTaJWwUEssKbqPkEQmQCDg8BsYnXIAWhu4Zp3D1or3cJ8yxNLlkBNNxXqpSI2dnB05S8aS3GIwtp4y8kFgiwNAK2reghtvl855hRGACtZTLMTZfmYihZIqq6hIGeArI3lCt93mH3pYS5JjJqVIERuDarCWOyfytIiBRqN2vmJk4QYRZ43PRZr+X84MQRzR4HNxxUwcOxOJ5rrh4mAEuBetYmRq1T4PBxLiFKwEc9sRaLDz0Depi3qcV7RuydGd5PEtNnsp1mbAZJbkvSMvn/oQeiOGyJCm2nKLz6GFxvcDxnJ4iHqGanQ8QEU2N0O1NqjxUdqbZR2AWUemBSqVVwSDvrPM7oGB89RctFkHDWGmLtaxSqFGgZYPA+WM2FTdDl3bmZiJO0ulFdwLQIbBdlETS/muiRVs5pwXDLwGgoLbZiAeuvi8MVQSOBdRg23c2wy2UIfvcQTB2Yp5gYQ5KhohsOYisEJAcBo1GZYqWUE6tB8KwU+KvN4yJEWMkQLyu8zAmIm2mTbk4AR0ZDaclqoo3pcmUBMRydDbrliBlLYst3Hd5FStrzzKE4ywpfRktgQDkYREUC0CGsXtWAm0jvHg9zFWOc1sYRLDI7pj6RTrJNDAXfmEHh7m2k+SNall+iLDSOj46gvnHJ3K5/V95IrY5IasQzobX4rt3CXfXOn3FHgUFckLbQKrzyjQDwbgRl929JHLkp4uB5ZsKllLujySz/rT/mkJUFN4ziJAFK5K+ycIxQPEIP62ZHAiBh6werHpFdFOERA9GUWKVHcvIVAFp7heSDikKuDJ3o9b+RDT+qfjI056DV2DSxgVBRFB5Wd2Z8HGrvIlauIVkoMyy/JpuoJWLWoysW8BXhLA4DVduOtsUwgKMOgsZz4g6wI59Iqg6R4EpLdTMfI8k5mY2ltX7S4GC5QRXEBoYzlw2OSFXbZlgRip8KJbLxldDFh2wSxUMa1YNqTV+xK6GSK+WlXBO+DUsaxb36SAMMGwPaCuyLnQprMGQzwHARKPG8oUVxM0vd443lVYws5Dm9l+2bOvRtADHWQXV2VSUTj6RA6LVg7mNw+CFqzwIpOXBpwUOzUDVmm7sreblSStAi4cDgtunDeyF6puyXH2VEqLPFXvhRBbRtihSl52RY63QVy+3EYUHKhgJmq+ZgSnmnhLoIoQN9K/DCQ5Qjl/QTCJZEAaRu12i6lPWIRra1gO1YhDWy53IuY5zPc16RQF44CnwHIwilFoLa2rcXShuCxf4/Sm5NRqF9WBA1JingjdyfwipiyqSuz1cLqZr+JU6NALL9dSyXBnxK9ipx0KfAY6BUwdn55lXjWYDHKUQgp9czFtzQB+0lqYw5gLDadzJZHdQe6yGM8T0zQQxXTHvXdy+gY+3uL7LmFzXaWEA06DUBGygTYCnBgYNGfLyVjPiPE+YBeAmQ3FBxuilgQb1UJ+MoAvoXzCf3bGi5t4jzAfpHCYJlZpQi6SjBQ+b8TKq1sgF+KuwgIaHuoOgvTH+FYrYw5xKVuRU2nawcuoVTcAUMS8YIDq8rPgl9E2iXXELw8QvSHEKndYdZx7iIrIphq0IDOKqj+mYZXI4Nx0E6oCAZ0REnoKCA1Q5hjkxfjcYNqFGzd8wgpfxV8QC4C9f8AYoWmIqBUoG5A6kPKPgjWKkBRhiIUOJeWrnhKStShS95mMWQoeD8xqMitOqEaYtUQccU3EW1tFFFLR6mdtZZBXttIeW+GGAoDxCKIBh2qyWvLkfmGwik/mOOFiGsC4LgYaVcsqQDgK0cMY3BqicGlGHPGJ1RO7sVC1niLJdgMopzOPXw2M6RTFbsCgg/O2ERMuMgyUZLB8WQdJAKJYsaqsYU9h7rVwoWu4DaUpuMmAoJUvsRoinLrbx9pL8WHeFBhKepGbW6X4gyWUUtUUFXkJS2cyjKgp8glSCbEJSxYVzMAMV0fFwAshz4Dk5QmKXkMU3RZEIhpFFtg3A0TV5MYMtVFr/OXcpLCLwXmglO1tFht7Eq2Uy7hqThtgj5pWg7yuQu5kxRiW7lU0OpYwcCtS5KCnuXPoL3UXSjZF65xCl65RTq5V2l0512spkorGMEkc00lOtRpPVG28pQdkudxnRmlm2Ov2ZpMn/TJK6f4VUGl2ctfCYhagPx5282uIJpS4mceishHt1XxY2/BiHMckb1QlvuuRxxFuD4wNReRcQpQ47ZRzFt7HGHTvMNEVYzSedVLICashWKeUoRjMAO5PhgfBAa59FpSlsyk3wwlac4aM2mjTGErossNDuCxFtzcW4OiX4QbfZaDGRwN4NHyylqvCUvwOZHaJPks/JGw6oeCg8bj+JgAFqAfMNHh0EHI1BNqsHDYPhBjCuaCYTluLVYjwXlHUof23GW2oZA0HjJh4e7UJdDUFBqFVmlU9xTHEuB1dkJuL9rQ2KAEwFQzvsFWc8twga5rnGf5gdBiXRrMrDwc0ZFHuVLPRhPe9PYWQKAY60Le2K0hV+oMHv8Ac4uK4l4IAh21rMI5TjVMEsL5og0kyPDSQAtQWkXE3rUpHXz2RIkNgo8cbgbwBL4ZkCBG8PIribcucbCovQ3wvGpQniaQZe/2/wAcMp/Sy6whiQ+FliHQ4iuiFZgEsdZ5ioGrXQOf9E5/WAZKWXsalMqQCkHqXBlae1wyexCO2uKiA6ue2SDzC16T11EvOzhhEFXZI3lkZQXIIcs4F3zL1I8D/lhIvdNe+mo/FFHBhAMyAGEBHAlOlgpfnqYlmD+npE8nE26j8MuK5EuKnB5iDqzYAdqQRCvBwc4X6kO2u2NUNz5IsZNFsYtQ95ME2TsihLaVQeKCJygtuQLtbhKUqreuLJQqz9XBZefcpmFBSeZfvqFVUBDK3B5SYi6QArKWVntYE9Mdy0S2vkabJhkAwHBmPsiTyH8il0liI206HxHKtaa36MMuqH3KR0MvLTMp4wOm/shHc19VEpYLsGDC3KyVHrQzotq9BGd9/KfW51gi6v3hhLLHJ6c2YaMl5ZDxMhS1gUHiBRYsnjN8EU4U9sddfdjyjh33MPL5h/Ywfqygsba3zUtBoLABtfggS0iRvldeUmIKMBya4uDys+aCyi2Oux9aTAbS0xbA/hEqrUhoXvzUVgjRRS82wSV2E1guEEhLARYAPizhMMNQ4FoFDlDhzOylazP2jSXdQLHNGhuXOQmQ0sBCHm74PF4WnmO8Ma4F2JnqN5cwq2YaBgDag2hkClALK+nOULgNQ5NA/RK9rSp0MtYPmGHDoRZXWY1d3nCv5YI00OEc3dwTCYZ7NhlzyQQ/c501Q7B5I0CBwEPnqYNBq4Cy8eCMnCs1YFLlvMq9MrU3FxVYqsstW02x9VZCDPtIyCUbmyYsLg05PWd7qHyXjgVmgLtgoSwLrXFWlbaj8x4RIB3VMxy6DLh9TnfHlHDH3fxOQurZfhiXNZDH4zDehAU35qYNp1/oVKtbo23l4UzIFBoq8SgslHOFYTpBX/zKoSm1x78Tnzw8jpszUvhn2nI4jLoN0DZVxT9D9w3LxDJPAFZRcXPQtUWqdP1TSgKszYrkslCWY1ptfB4YeQw9hNgRacgArJdGg7jYDdFYQckEqCu6Ai7gSlCQaSulDOrwkTu70mmpV1cdJjmdHDq+3V6Y63IKkdqddiCyL0sFpJnzMI5FF3z/ABMt4+bVf8x4EsUgHVV9kMRikjqsErwCxropqVhVgeYCWzPGjHuopl6GZ4UY3EautAyynR2lXl1CBHhqKgSiCm0XTEBtbs9jTwETAjmqGQ8yvOyZlGUUDm7KMWxTmIogpPIra2QwW0GEEpQfBUGtrcV16BuYNxQ5F0X7hKrv3CyNcYMBwbhlV6UWCuOCUN+cbezM+CDxBVAB6gWMzhqoXcblHxlwyiiFhYagUjdXvnQ7JluE7BK0IFapmFZ0mKASiLaC8pLK1KtG+QVAZsKiAam29AYxd9SnCBqqMABQFB0XNpl8H7hhjG+1oHeVkuNIEBlXGIdlpOhgeXFsTtQ1yI6JN+bKS9as6j7rYGEocaYoCjzLeEEiRK2+kZXigHxAMhrjoSo4YK/wJURKCxXh8ywqmw0OGOzuKBTOb4Xt8yqlENwCgAdSymsDckuumlqqO6o6VyRL+G4XZmWgEBypivJH4GYaogzc4b4jltllfRjxUC+WlnxsgomtyJShUa5j42a7shgPhUlpCrM7IwsIJcBtdQwVFgTGouE9+eA3xByEw4eA+ITaOXm1TK3TANukCPa3TsNThbhN1xQ6bctMa7QwFnfaSg3kAc4tqEW1JVs4BVaUtMWq34gmWY6ja5m1/cZthgVicQT65rbDbxMpiK4zcl3uiCIfKXyS5B2BVt3YTIOHN4GLgAxVU0wjLIbqBoc0n158kUgl4GvTNgNUl9dxYNOXAlGeIoRE8bz5jd54JKpypt2McDnMsu1+P5QcmsA0agTKFGepfqobmo1S1bHVA5bxRWqiv54Rlq7vcChVV9Ey75gG193QiQDnYWKw5xkQ97Q+9dTp4qjyJWUIIBQwlfS8TNM+ZKVYZbGqKEHMG6gryU3T3H6Y7Ubkxh84mror6zLwQrnaDqKOgVxoyMwUplV9qQknaEO1YV1XJCc05roNY6sxuH7Z50YMwHrKRPvkz+oVukFLLsyipa1R7bNhDRIW4sncRXuNtC/olqxFuhvR8wpbtLqoxp8QlV681jQNJTssVZAebbBQcaw2YWnZgFSVdJQOmGiFK6HhMXoj3YrnWwHYkBKnP0M2IxljTX1wwLVbqFO2uO0DeT4VcWS1VOD+JTfaVqpZ4UpWra3REMy4XPkZ3n1yWAAgU2q8wxBbi6yeJYThNSBwWch7Kw+ojla6L1NjsqkqpUNdlynDPcZVqrPzFP1v3/kb/qZIsldmo/ZGCV46q2vJEIIwBy3QRixCtQeVWmEAOa7Q0HINagFtG6B3kg7FBWifwY4EUcAGiagnR0FxTjyZYOJcxkC/yeYPsy1lwfSXgnw189ws7zELzH06IrYfOq5ul23LuBAzOW+C8TAN7qgC5likVzhnmki/Y7X0JWOdoMDkQAeJgdalPxLxeAMcUvM4MdLat96r8rDhjMo4IcXySTVA0EohhXDtqxhm0gwAh1Rdxd8yUOmXcJWcK2HSNZAwohRMcwhCzAKdD+4S1eetMvbbS6Q6ITEXzmXqULBZSlSwJyjtbPTcM+JsGLFteZvN6YAP3G8rayXGsoQqSh4GMMTkOGIs33D5EtYljEoJW03t4YjtiioSxwxtjQODWFyqVkTn8Ag94WOu5UKexfFwucum6XaYoPW4ZufmH6RSg4eZfKDnLMqpzMPGw7gvRoaG+ZoY3q8/UGWkNN/ynCTqdkK/9COxdhWhtkOXREUxJmK4LlXcWSsBYu3l87lLawM8LSRsKIB23scdwUNnnx/KMvtbsXKZaISiEUKb8kANg1fJqg7DBF721o7H3TmXje7uGUr6jDrtQhUYDqK5UL2j14qZ8ONGZWfdTmjN3PTZw9RtmxlyyzewK0ik/LG4Gg2B+JS7QFfMryzhd2r/AKm+AgKy7MBPKPeYLS1ZloCJZCxSag+PkilHAiJRFQYOa4YXnHLOY2Us0QeHvGgT7Grgo+qOilj1WuY40Zpts2McJ3/yR3+mlgCAPZZkuoPAzRAAK97oh+iLsXbQeT7mZ9e9hnQcU+6f4EN3UR8D+46xL5YKVXSl2Ky/MR2ijDSVC4Mmi6vuCrU08NJKO3Ztz8YlKnFPWS7Igi6BRYuDcdcYEedVAKdKhr5REJCMFtnI1KymrN18lSiqgW+j51Bd/mBuioORAnsoZha/rn4MzhIBwXLdELgCu+II/UUdLxybIJBjAoLpTlI+i2rscqtQC3gbUYFLfDn1iNf0qcjNMd/OdBfjAvxqsSYrzFtXq9Pj0SvdIPC2gZ2AD7IRiDDrgTDm45cOYsqjLeoAC0EC6JdvKogS1llo0RvsJU7sXPaA+X/pCz8YnymIQz2fUK0lhFAr1gHJvEVM4AllQfOt1D7EaEQCKCgGgQi277wwkSOsANa1YoQdtnI3Yx0J2gfyQwjlDomzyQQrxW2peWtkG3iVvEvq4XUbZC3uyMQJngR3dh5i2OPW8+3MUOmjUF/rw0dPUwD6/mJxvV4J+hKW8gAOKdSg2YOa8cQL7wecsE2ve6SuWoiYPAuKeS4wwJWdCjuKVC/K9EBcdhc3sPcc7krVe19+IEXlBNL8u05mCWH3YbOpR6IEtPLLFLgUNVy+Li4NGdFnjWTEZLq0bX6HMBUHl+FNAZqzvWpUEHMZf06Jm3ZUvuDw+I6QCJBwpvBFUxvOQ5Adl8wWsMBdUBp+6dsLKozMKER8oV5qlxw5/bKbkGWRly7OpQLBKBj6MaXtRw2Q47CfAXKNnuYxuWsGp8h2PlileVoAkpbgcL/tBXu7CYuQu1oBQQaTtWZ/VngcPxARFhsrhjj5AkNIcOtJCK0HIgqW7EXTromNVNTlrKbMf+92kI9HgS34ethIbcNEN+BI4jpaytC2PzHgunXTTL0F2Qx9w1tQPbDRENWrd2ioKu9jNQy68IQjlt8Rw/63FLwZgliAoG702VA5SKGoCoLLA7x9watZyIl3fR/NwhtJV23cqbmDEbF0flgiFK83kfbBiUuC8mNI3D72OrV/eHmUZaCwfWJqNMysKWu4tq2OjgVf1LsSUrjgltbrIuN6sls2KYfg9weJmdV4HhAswd/ihd4uPBBMzJOwcQp83Q454YNi2ij+SHA1sWg0kbTkpOgcwpWlk8jP7inVA2zbGvrUc3Z2zIpLtD3Z2HWpiGmrFYeXKNIWnRagG4W/eJhKgOjKS5znoJenuWx6ojXOf9oaRy/dDLHtigaNDYk34uPvQSUBFEoWuskPYlbr+hJl+GbQLToODxLTlBLjUppidSS0Bv8AFhucAQFO0u60StUukr8o8GVCgnpqE2urCFbQvnOWJgOrwT9E3blwwYHYpl1BTvfDKqNG0y/OPTPPvhmU/G9xOW3hn8YMZebUJwRpsbGtL4hB1gDnuJAezXDy0s+4EYCzLUb8mJsNreMIGXYcoQw0d7mLayHBpPaal2Ju40PMZZdLbOrHXcYoRhNAdeyW41znfutyuzalfWKnQOd+WMWO08EcuANrPs83zAZYEHSzD7UqJKY9jcFIz5X6IJKuHl+pT+tqFQH0wEovUp8b9sJUrHdUB9kEQCql5Tg0CFuag+pZUqqiTWRCBdrerrMwJzUsMoAjT87UrzI34qLJM0YQfp/jX+zmFQkwKUWJGweiCs/EIkpR/eCVoNKhxumHwH9UCK1q7qlyziCAZV05SfmBXmKi0QWogcYSUSICyl/lElVHBWaKsdKgu768TGNFy1PWCDXvoyHNUEolxK6DwMEvRhX0Kf0wLbarLs3oHohQAoqgL7CcY5pHQvQ4lNlSw1Qa+GI2AXmQo/mJwQP8Vw804DqFF2tD+1KMBNgaUE1ussTTklTHnwX6Ibi+9E8uv6hhFMQZ+I/bHXH+AG5XollhxNL4M5Y5faOmUq6c+GXlSou8ePuHZKrjtmlJLpthBW5K0FJyshiyRi92fUEA5Liy9/tLMI6+aAliz8r+iKQsur/qcpN7fUD32ExrJcf4xBoVsH7jNxx/hRg5ctQ07CYxHE2Q81iNqRIJ4vMDC7BR5HiJ/dqfcjm6HAA8I1XZ8lV/uZ0+SXLhZlbU/wBy1wTgQHzcefJFSjUhZl8eG099kplpay1u43Vm1lQeF8SlrKa3o+ZfHh4V21fiLxNFYygeDV7/AHLKXbmp9ZjxVVcWKQ7jdpRxYufmUFfQGnXbmKEcazn+YVN4oPSFRTZ50OYGa9W5CPDyPYiLQ+/MY4L3/iPJ1tFlxZFAiANRlwYRgtGVWg79Q/8A0FlIDjXiIcVn8NEFApIJpa3rQ9TG0AXY38Q0svyA9RxEHC76fUK7s8bfqG7+r4lSGgc+cYifDcApvZriVBu5NfeIC9l/0YlyrMGvnRZABCXZ7Y6g98L7d6meQGPIs4lP4P6Ncyi7yP8AmAF7AbrRqX1mpX26lUo4vx/Epqvf66lbQNA8rRBGKRHNAQybd8FbPMQBae86halVjcnmGehxdbWD+hGiGcOAM7Jj1OAh3+wgwJPH+uls84sRONE1G5HyUZTBgVaZfQKgHlGWt1Hga1YRNGoKVrkmbHwME+ai8ZWoKlvPxlqItCAAodtvUuIuGz3wNyrJtl9mC5eXt09ViAQhA2L3xKuQhADrmXuNRS4A8Y6qKpHR5OMNxOKtfNOjeSPWFPFobfJGmE8vJepfHbtTdcRxBeDxiC+eTVwXVLuFcxy68SzpzRj1kjAH8w1SyjHbxCM8DzbI9QtFAbzouU20H5cTOZFcboE0diW2jRf8MtzKXBTOu9pHjW1KVz2EtI0fnWppizOPqbpuguprdu0VmNm4ATa2q41BWDajV5V3vVQFG+1dviKm5u1xbuG4Vrex+0osgDgzHUb459TDQChfcDVQN1cSsxt8DDnNt+Mcwg5FuDmUAKYx4DcIkLDVYl7s5D4YcdO1WzcuAhA/TaQZcUqAb2ZqCMEGEGMPGwvd5FDihaA03qL0scgN+JVIQ1S8nZ1UNJUjqtrMMsZRvXEzuFWtuskow6FrS+nmWKkVH6JdEoNhQl6BUSZ3lqVGSxrJnN4l8pNWWgl60DFrpusRxVuW7op4galYXOXBUuo4gbAvWYIoPKs5ZHF2xd4VgF0AiAyLIygzQCAaezKdTEmSxctOoEFbjWpy48RQNaeiJxmV3tsbeoDFFrGozpVg3qclK4r/AHHuApvnl/giWtChVtG35YRLpWgLz7lZpVV+RNUyEV6AGBQVSN3e7uXYKR6G57Zq+DmpQrrmjd0kTpZoWwt9suiQ/ICtEruFVdnDDOPARKBI+zgvhgRIIRpyVlxErFgIGF5VgoV77N3cMvK6NJeOJZxBeHxHK+FzjjBKBdE1V9lglBuladupWBLqDw+QlzJMgc2iWiprybOWG1AhUgKmD7aZQWh5YeWvE3Eqig64hXFDdjFLVMjcSZraDCZXSB9ILFGg53vscR0oSiCC3bmzKsdWynjNaOggajgnesISIuoumypzhJGLOLj0wxs5T+b5mpcQPpjxDqmz8XjiDZw3nIO7OElDBmKOxvWoT3GiZG9JRB0qbtj+JTF3InShBUJAAGFSymrJloRFlUsXxGo5ADqzSS4ZywhhWxKhVkWrkHAJezt690KTwSyrRcAWkPRAEwuC8JnVRS9sRgnGjmA4WQdwdinMWkhgyW28sMEqeKvUXTyAlPFR2RMrNG5crsOzLdpewZEpy4bIpbjisDtR5IBtotZt3BnCyslZgfRiRuwXowHu40vGz9AXUvF2k4XVVc7rRCpXlBigoMrig6O4CMYCyFHKoO9sLFHRCnRFTlFvqlvXZCZgj2rC+I92HYNK8kRQseBV1ZMForSvkWXUEheWieIRJsDuvEZEsWiinJqEKiJg8BT62RUHl2FIqg4YNWQ2AilY5DEkSzmMjArSkRTouLi0CYmkfmXKa2AdeoLwayVNnmIFxQ2Yuo34Lyx+L5mWwjUfMOEp6YLJ6ysoxwDm7uZ+XjM2VCDDUwv21G/XBYB0fzB4AxAgCEVfbJ24JbJoN3i83ANU+3jZSN5iMtcW0WbqPEgKOztZeCYjAkTA1wQorwZbHf3Abr3mEdaxDAe+t0xayzF2CnWrZneF0ZrOmDXQg44ImSgFPBrMTQTCzMy1xnBGgaV6rbAoFOrDRcHLAvOF8zGA7kpOC5cwBapRWA9y8BjIJbGeCSyGhMq6o5uXkANbGTll5lx4VtFDJvNbses8rY3AL9sMsUkHgSaKt0bESrFLAy7SKqduQaXbcO1zlWB60EfZCj5mUftoTxg91F2Sql3WtXiUxZmxZGAxc14uNhuy66iQownHVLRSvcG8ta1l7WBm6KG66NMoSnWg+8tXzFVZvXuMpQcdTx2FU1qX8KSk0w4VfwS2qV7YW29LuKNMdjn2OGVgyXL4C0ljNt1/7IfyoKX4iy/eQqK/zDKqGaWF5PpKcLG1IiAJ5FgeJKHES/6KBhrfYjaNXqAfYRMpbsfULsDcPPgaB8xpM2W4u5YgJW4wroi8/MhQA0VUJSFq8wYkG4PeJSAVsYAoJXcO3sRG7ZrKsHAkZGjWCbl0I6XcPAmZT00Cpjr6o4ibOkCh6ggIAXNVAUhOZwIwUK7iV8RqDJVNkHny5Y2tHxc0MsTjYLkLVBXu0xdsxb6S21mLsy//xAAtEQACAgEDBAEDAwUBAQAAAAAAAQIRIQMSMRAiQVEEIGFxExQyI0JykaFSgf/aAAgBAgEBPwD6aKKZTKZRRTKZRRRTKZXSimUyijwXS5XVSl7YpS9lv2XIt+zc/bNz9lv2Wy37Zufs3P2PUSauXJ+pcqUhSfsmt8WmyOlqOXc6rgbaXJHUk3nFrglCMpJtvBKMZSVrJHtVWbhyFqyUU3fJPUe11yR1JvDXgpTq3wf3bm2kjful6SFusyVJ+SpPgz7EpPyzPsp+yq8l/dlv2znyzU3JYk7N2rFpOjTlObbukUy3fkjck2PM8TlfheGOTjSpt1kUripO0OLXlkpaieE2LdJ2pNJGtLVhtI7nNPfKuRZ8uvZGL3SueHwSxUXqZNkpRdTkqH0vLVdKYl0of0cNmzdNZwiSaXbSoTdOjd3JWVXC5Y4O3Vt+By1k3C7NGfZG3m66O7I2/NonHc9jWPYt0E4yfLpEFKKadYNBNyecLwar71UU5G6nBVzz0+576eDH0Jj6Sy+SCXPRULUhvcfJqe48+yWpBVB+j9xp4wyGnprKLaeeDBFJG2O/d5NWEGrZBRcU/saa04b2mJ3l4kKLem4q+lOuOmTwur6vo0cdXt71HDI6srUaRLZGajQoJ8oUlCPNkdSOoJZJScVxgVLgfquRUsUYjbaMOnyMlVrpY31ooSKH1StmMko7lyKKU3bZJJaiySp/k025SXc+BpO05MhpqMiW/hGzV1FmVEW23Fp1RLtg6YvA5K6ZCDg3klqtycFGyvovHTwhti6MvpuHdcHfwolOngenzfJ/FcWNNbWkJtOWOTTtRSJN7o45LdrDFqSWqKSlGVrghJSWDUnJSVG/+mpeaE3d8Mb+iuB89V0fS0LwSqiGvGWnafDpjbrI9SKaonLhJl8fgTu0/wD4Q1aeXRB2hU0PmnT+5DDdsTSbwaqymar26aR2y2pLNjr6KwiulC4RVMY0ikIcU0zV+P8AK0tdpRltcn+GLXnNJSihxFyhLA63PA6tEEtqKVEkt/FIU45JZbIPdFNo+RLMYmkluv0jFfQi3Y89LaRbsYxt2K8DujV1ZS1HxS4N1ZP0JNJxkNSTEnXJFO+fBm+SKbgsiUr5JpcPyh6bW6mNSpkcRSNS96b8s0YNxn9K6X0vHVsksl1ROaWnN/Y88EcqX4NCdx/Do+QkpJ+xPtE/scMWs0qIaikorySqT4HJRUvbZu92N9l/Ym3ceS3p6deWNXxRVCKZ/bH6KweRnHRujWk5abSRwaDuTk/B8WS2/lnyU+1+CPCLH003tdiZOPef2DxAjDKk+ETlJyssi880KC8TGq4YkqQ+emDwJIaQ10aya0JY2+raHCv5P/WSWpJvbFbYr/p8V5X5r/aNSClBoSVeRVkaKzQkrZotcGtFCimoj4NaWIr2NPo1xkTox66PLY76ZoV2ZtmSnVkt2MZG2k7JzaUhc/hGi6r/ADQnaVDTWMGciTfBnBmrwRlKM1waqe0W6orBfa1RqPdNHHPRC8jairIyU4SfDTVG4bxa6Jlqx1XTehy7rVMcbi8InadbULBB8f5I0JXpRNVJTZzeenNEUvLKipLgUt8P+C5ivKZOVReSTVxplof3Rjx0bofRc11ofRkuUamooJInDt3OukfH5PjfxmvUmanKLSbHVdI8F95pupNDglKzU8WalXH8iUWX4ZTrlDSfkqP3EuRoSyjBgoaxyPHlkk/DYl38mum5NrwQi5QbbwhkeV+TQkpOVGtdJ2W+dzG5V/Jicv8A0y3xuZnHczRk/wBRW2x2fIbVZHK/LE7fRMY2zwxsivI/ptDXdaP0kov78i0dPMUj9nO33RP2jjly49GhCEWzWjem8jU00qNSMYwTVpin9y/uW0rs0Zf1I9PlySoTZdlFMoaTNmORQihm1m02mx+zYKJGGbfHglKuSHkbS5Y56a5miLhfbTRquX6Uqrg0Yal7m0akd0aH8d7qUs/gek08semvEmaMEtRHafJgnTFpig/Z/8QALxEAAgIBAwMEAQMCBwAAAAAAAAECESEDEjEQQVEEImFxIBMyUhSBIzORkrHB0f/aAAgBAwEBPwCSosssv8MFoteTBaLX4WWP7Muyumfx/szPgx4KRSEKvBSKRS8FIwUikKDd0uDY6uhxXghJwkmiWrBRuKvyKnLirJQSWM/IpSSaE5qLp4JZZXwV8DhG2Rh7lfBKEVleS3FYRdraksm3bH5ZuVG9Dl8G/wCDfngcl4N78G/4Rv8AgUy7Xazc0QdvhUj/AA5JtWalRSXLNwpKuVZNuLQpNQzGNd33RFKWdySuh4k44Ypojtay0NqKppNtGjsnY5JQa2xvgbca890Sm6SUMrki27koYFqK7pdWsXfS0WqMMwKrKVDp0KilKKN6hBqssjJOT3W7LWMMcPZuqkXuX0jeqVpV3Qo6LipcGtp++TSxVstFqiTSpU7RGW2O5Npj26klKK4Vsm4yaau2a7SglWX3NNXF3aRtT3O+r4XSnbwU6QkxRYoW8ldKIp0kSTqhJo2sejPYneDST4k1tI6U5XNeT+m1M5ROc5YZsTjjkppk7lybpbdvY0pTTpdybkpNfJqb5uCaHFrjMcDdTTdfRjyY8mC/kfJ2I9+j5Ed+iZl30z2I7mobsoejBRcrYt0oOVjm1VM2/qSuienKDOSKTddx5Eh5y2ZdZFuV2Wvxby8F44IvkvwunbpfwWXgTeMEZbXwb24KkiDctN4I2jUSjF+1N2J0rUUS1NyyiO3ub9KDxGxqKVqrsjmatD5KdWic1NLHAtNbFJuvxtWVhZIowlyP7KsRWBcIrAqtCUatyMWssWoYk/3UJp7k3gqLSzwTpybFFNSe4SW3lGyP6WK+0OLTTTyycdry+TShFwpmxfqOK8lYqsePxadv7OyI9GZEUyundGr6eUNSqeVaKTZHTlTshCrdFc/Y1SVeck9O1hWSWaGmmRutytfBPKVIcW4r3Gi8Uafu1JMdxUnZktlstjbLlSyRbE+j4ExNieBkW1JNdmaXqvTamipOUdyjnyiWjGLbjJ89yMsD70N/JnanYr2kv3DbwQl7ObbHpzwQpJI1LhPDPTxxKRrSe1Ly+ncfR1ZapYFV8CrpeBVYqElQ6p9NLSjHTWMvLNti1oqTTiJppDq3gk8ZXcxXBOlJvsWn2IeV2YtSOLRFxtE3csmm47Gl2o1nUo/i1llY5RHnkS6VgSyJEXihrk04OWpBfPSWGvs9RDbO/KPTtuLV8DXu7DWB57ktFMnptSb7CbSdCi5uPhJm3CqhJb/7kUkpPB/majfbq6MEjsvsX4JKy+kVZoxjGabeaFk1VhLyerTtY4PStXJd+R8n/ohmorVeRqm0Ql7Cql9IjUtQnqKnGPLIxjGPW3j2lDbG8FuxytCssTYhPgTNCcVGW5ZbVMUr4IwjGLlLM2/9Ej1SuL+jSm46iY5O+w7wWOTVsk3g1V3NCTx9jk05/QnbRpRzJ+Cx9O2BljVRTvvwKj2ryX0TjjIqMEdubZFLFZ+SEIb4q39EneftmqrtP+LOHXhkWpZyYwhtGKaMWTjGUHyaMktRJntTkxU2QjWm2WNFMfKKbGpRnFLxkaIRTlTlWGbWNOzNckUJCTZGGGRlUkk2Rk3H976TV/7WayrVkaduCFisPpRLdeEe6u/JKLhqDftcvKIQbmhXUsDTsXwxX36JCH0pWSWRLBFZMkbx9EU0jS0pSbZpzzt8dJL/AIPVL3QfmJpPEirSI/8ARkl+4zt/ua0bUZH6ktmw0eX9EL2zG5KheUX8Cb8Fv4G8ost9b+C/hCz2RGSTykbnt4NBpQSbJyUZJJZfSXD+jXg4qNmhW54XBfwhVf7UPb/FGLvajH8UaqX6bwkY8Hp1dqkxKuElY1S8itGOlC7FYG/yoVbUmfqttNdh62piTF6uFLEj+ri+ImvKU0aTrUQttXZpzlKcl2XA4rwJLwOvBqpbGNHpYN2NDWfxv4RbfSyy14L+BSLHLHyKLaJ8ISk+BQ1P4ManSvBCK/UiarhSVGm9srFrLa244FNNYo3vukasnsZUvJ6eTV2Of0N2f//Z", Q1 = "data:image/jpeg;base64,/9j/2wBDAAYGBgYHBgcICAcKCwoLCg8ODAwODxYQERAREBYiFRkVFRkVIh4kHhweJB42KiYmKjY+NDI0PkxERExfWl98fKf/2wBDAQYGBgYHBgcICAcKCwoLCg8ODAwODxYQERAREBYiFRkVFRkVIh4kHhweJB42KiYmKjY+NDI0PkxERExfWl98fKf/wgARCAFAAeADASIAAhEBAxEB/8QAHAAAAQQDAQAAAAAAAAAAAAAABQIDBAYAAQcI/8QAGAEAAwEBAAAAAAAAAAAAAAAAAAECAwT/2gAMAwEAAhADEAAAAOJVK2VODbbrVCCI4ihCtbY4ZDFpPY0d1uNtaU+GMEGzMG/i03Hl0+y3apFzkdxxsSn9SWR8mJGyvGk3Us6G+WD3FLzZeanZYXnEWfr+2QafAnOvZJevmcuqU405eGOMSI2gzWpRLLLsPTKWxvACvzdy3duYRG4f3Lhw6UGLCKI9TttSpbbdbBoiOJAjMxjxMYQk9moxM6PSYEpIghvbkT5r6pmi86mvV5SK8O57Lp0ku1ea/RKZGWBIDKZES6lbjrm14ytUeIT6tvy8WmQq/hQDn3o/zncBZw8hZ7JNhDUdD621MU+xJEyiVFIaizo1QlDjaaH0Pq3Er08ofBe9cECnCSYppNSttTYpp9obJIYVBlSXWbmRJSXsHZJU2OefosadHa3QBYZ53Wqns2ebmKXpxHlFTrpfQfOSZr1G557QT6XLcIQLvW+J99z1FXUXYbyggpAalQqRbKRmXnn1tsGdeTyEmN0Z+xzIo3n0pWvGt73g3EpU42zJZvFA+alVHmx5EveKbcQ+Cd74EFREFRNLKpaqwNbElgIpQWVBt1CmblRpMz7nUjFornZodNdnrtZldPPUeR9WozjkcW3V7n3BZOhgpUbUXYpdasEu8c77UQl2joMeRbySGkkx25EYrlvIut8yvGyXan2vK+L1S60rWPaRoGbnof0jAcxOM06244yFLjXkzitK0LWynLxGGUbz73/z5SqoYwHYqtWcCm2wRjTQoyGOsjOZIE05vJXuCmQ+lu6/YbFD6uaCPnUvfBFHE1QCFPQJ5+iTDaj8+8jImZXIkwFsuF05CUleiOk+Uevq+pI0q5bcjSR8S5X1Dml43O31S656cVptvqVx7ONBi89MlO9tN6WlpxSdkJZeZuM005Y2tLmVLQ+0Zj/PvoLz3pNUFFBLTwg2Ey0ehyo02EPgD9S24hUinESWesew8g6Nlq4Cj07pwZqJYBD58BKCaUSBYQ8UP0/gIWZyLAmhZ4c5ZMdWbtgrRGa9UOxZzbD6cdcDotyoNYXK+0Tqed+eqrZK5pHs0uJKT0P7QppSHGgfU2tzHjyoNSlxO9El1O86kNpxRA8/9+4bpnRRVnrVKWAP1/HVbeJig5wGcta3mQLfYeZ6x6PzrpOG9fo93oG+IMKYFZ1zcYZF65uCDYaaiIc0SVVtM2FPgDrdlgERNQ5LHrh+rCfKdt9Ujc2ygVy/oVKvIzaqTZctOYALBUrj2sS8/lHfak8jBNd1icghi7PG5PFa6wJ4iFa9Ew+FCWehGPOzcnoGJwZIdmr/ADZFq9i6vgXSt2Ws5XrS2pYs2EMUO5iJl1+LJZ6y6Vyzp/P0gOfX3n2+IYUVGRXOxhMZpm+KLiZqHrEuTe0LjQEcBnmWMIZCOHX2pWdvyqvbdcgbaoVzqETHN2q4Vqx5XzSqWqp3JvtVJ6HlpziHY+Y6xMiyY2kuuipoFIgecIpMpktOYGstaFvSdOVa1pVpOsKvFYtNVkxtTSY4oLJsk62gSiQ6Sq9VdO5R0/m2B88vvPN8Ro+TDiqGLJjdIfEGBc0MxSXJhxK40CHQB9hwQZDOXJoszjYG0AbHvlW0nxdxgw3AYcudCP46USrnz9q8lGI2Gr3MuhVLSayKB5tFtFCsCRicJ2pphUtLTwP6aTUvJZ0N1LeDv1YKQ5mGhxtUOJjCTJiH9uGJOPC9LdN5Z03k6wXPL5QejAfHUiLoosoNuHBZIamNSvBG3ErjSuHQhxo4LJjRRz1btGV1K+Ui/bZVQa+L0kvGlsASuNLtMVz200roYWgRNgRb0OREDiq072hKHEAtt9sFo0oEpXgaTtNGZmBmtpA/tl/MRFmR3IkhFXTO6FoJLLDSGej+p8Z6ly9LFAulP6MBLTqMrpg0nCuUiyw5MRjmCMONvzdbPAzjRgSYDoh3aj33O6b0CnTdsBkXpM3RcxX1U0jnlsu1QiuA9WGzRyWZTUuKy5pnENKzRZpOA5mmgWlSQxSZINNdAJ1PLl9Fk3PNHepyhck21vO3Nt4C9awe05oa3Y7gdl7DxLquTmU20VXWIKVLyuoDjom5ZGlB6oUl1KRdenp0rJsSackxZsKmNvtKsUV06QME3N/GiL1c0gb2MLFUFZwTLYr9kr1TrIMgTUaRXg5hp9nZL3tKE6VsG3VOjQy7a0WayOxejKxFSpBIEiwpDxul9vHVG5LAa3LSnHyZiBiyryLv0jl3QtcrTWy4qkKc2xjoDHzh7GoZGFLEIkoAhMYlToBlsNEngzzDqPHcTJOcjLy2tLkYRrmTu0+xayZgvZU14Fc4yXNx/YBknO6p0jiUsLrbOsyUM7BW2sBam9hZ+oiDiOgiYRXbJNvjAcrtjgdsPMc7skhnHZfXHWuUv9PJNcoIdQnBzcxdoQ+VzDdIIuUbncOa6FBpqIdpgVyOO0QAEOaOR6+wOztVdoDo4c0w3d6B1uGwrrVm3jz873oNnpz1B0gnAjEbJ1c8ev8AQawMATG0RHQbPzoki58VZquGskPc7DpHEZfX4yOdgr3IiuakCD00TvPN0xXVatUCNxca4KYatIaBAF6tdd30Zoc2hqRKjoTlR2oA3YcyNcIUtBOD5m2VwddGU6FB6U9NcjidhaT48x2Zcviie2OBw/fclS+Fr7k2Pkxq/bQKvlYBD6sDokan1KDxTYuqxeTham61AfCys2xWS4poAyBi5xOtk058EyjTOExPDzW48hiXIfZUOC+w0I5BfZajxpUUXrHUx3aBbk7EQsloGwl59qCgjGqW9SdshIm4AtUnBR3MhhKfrIYL65yUJL7q153Gp+ixvnvIrtIjmCh3YRWXJJ0BcZNeRWAOsSoat6UGINPrSoobNhz3E2vlxqB5gIfBmw1EwKSELgwIsERg5sCeLVyopGGQ8qFJaitqwPYyoUDeTuqoNhXvfKATO3NefhovRMTzlAT9FivPex9qC802i5CQe05cVOpeYpAOYzsHE6SD2N7Be06BW04JacaCEhpbuywpCwFSGsip746SEbRKEDjkUmFdKB51Qqa2+EoOUGCKiicINx3WRlIjrQoi1tAzm9CsA8dpt5nagbVpaNOJ2DbmIRmZsN7SpveZpLN62CMzYZpOApWsYpethmZpGb1oFRnYwQH40mqPy4ZGGHjEI7GXY25ZZMUjQOKDpaAzc2BeZIgIMoYjr2E+I6osatkgRGRjLFt6SLMzSN5mKszMFpSdhvadj3iNgrE7DeawMTrYl5rYZvMDSFJbVmkpKWhQbVmBicwNQpUNuHMhTwLGgRlVBhkxg4e1JkdIDpbH2nY4ahkRN5vlBRkUd3cFOZLjz1Y6PIbaZjK0LWt4TresBOJxUpSNA5pChbzMZm9Yjeswek620resQpSdhik4CM3gb3iA2tKw3rMBObSDMZ+M3EJDCAyJkOUitQpsOlDRIiIkqVFakzYMwNgz1fqSUttsJcCXETnkRkwEiTQIbEmK65ViVJazWw//xABNEAABAwEEBgYGBwYCCQQDAAABAAIDEQQSITEFIjJBUXEQEzNCYYEUIzRScpEGFSBiobHBMENzgrLRJPAWNUBTVGOiwuElRFWSZNLx/9oACAEBAAE/AbV2D/JHLocmp3d+AdIWjf8AWNj/AIzUcao4bs1wV0VV1FqIQoqIDDooqFUQCARCxWPRXowTqiDEfvXLTsZfb49egc1gCfT02y+E7fxCPbT/AMV/5q17k1Wf2mH4wrGfUtVUOgZp2SZn0FA9DgnBMCAVFNsLS+y9M7Fd081afZ3+SOXQU1Hu/COkLR/t9k/jN/NUoXYIrEoBAJ7U4GqGSd6qO/KWxs96Qhg/FTaf0LEaemtf8DXOUf0k0O91PSbvxNIUU0UrA6ORr28Wmq3IIJqoqdGKNVio4y57BxIVqb6jLvVWn45jaoywGoYD+aMwf6LPTPq3/I0KtUfVW62s4Tv/ADVr3Jqg9oh+MKydi1Nr00VEBityKqq4KqugoNoqKqn2Fpg6j03sV3TzVo9nf/nejs9BQR7vw9IVg9usv8Zv5rw6KJoQATgpMKngrbpfS8L2vfbAxzj2TDsjyUk1qts2s+Wd5OFavKOh9LMbffZHNH3k5kjK1Y08sVDaZIHX4ZXxu4tNFoO1S2nRkEksoe/G8fPf0AppV5V6KIhUVhjrJe90K2HCnBfSDrRaYKAGraUOCsj3SWUsfg5hrQe4c6LTUTm20zZiUVr94YFWrcmqz+0Q/GFYx6lqAQCIVFREdBVMVdVEMOgKin2Fpg6rk3sV3fNWj2eTyR2egpu9Hu/B0hWLC22b+M381gTRVGeKD0Hq+i5admfR7ndhEMR/vHnIKw/R+x+jsdbIGyzu1pCeJ3eSgggs7bsMTIx90UVVaNHWC09tZo3HjSh+YVo+jGinRSdVDSSmqS4mhWirY/Rukbj8I3uuyN4Hj5IuQcU0noBVUHIvTavcGtGJUbGwRU/zVWmRpHGpX0hI62zkt1bp+asdrbGQ8A4Ec6DNW2yxWqLqq4Sa0LuDvFW1j43OY9tHNNCE1Wf2iH4wrH2LUFVVQKBRR6HKqBxWaAQ6J9haZycm9iu55q0dhLyR2T0FN3o5N+DpCsvtcH8Vv5rEkYqj/JVug4gBQh01eq1+S9GtAzjKdFIzaw5laVjFomsLA+PqY5w+WrvdyTrfZG7Voj+aOltG77ZEvrjRP/Hw/j/ZfXeiP/kIfx/svrvQ/wDx8P8A1f2WlotGWq0zSRaQs4D6HG/n8lZtLaNbZYGzW+LrAwB1L2Y8l9baI/46P5O/svrnRX/GM/6v7JmkrBJsWlh+aBvNa5pq1wwPFUKATgVYbN1Tb7tt34BTT3nlo3b0+RtcFppzpOrqzA7imw0cMVZGtFbLJiyTGPwPBadsLnxufT1sWf3mD9QmqD2iH4wrEfUt6SgEFXoPQRgiE3oHRaNhaYycm9iu75q0dhLyRyPQUN67jeXQOize1QfxW/muryXVI2dj2FrhUEUITIAzSkkDJpGM1aNaSNyn0RAQPXTVr7xVp0XdY9wlkwZX/OKisXWxFzpng1orfZxBdpKTVPrUYqRhDna+XgtahoRmo23jiQpW3QDX50TGkitU2CPV1ziE6IBzgJDTyWhbLBJabM17S8PLrwJwwX0m0i1z22aHVZHuC+jL7e+0tj695jDLzwcR4Zq6oIg+ZgPP5K0ylkTnDkrwAxzOKvsG4rTUrhaIWtyoeafaJGurWgBpdOajkE8ORwx/zyU9JrHDPUONBfP5q3Wf0a1yRjLNvIqD2iH4wrG31LUGqiogqIoBUVOgtVEFRFTjUK0zk5N7Fd3zU/s8nJO2Sv7JyG9d0fD+v2LN7TD/ABW/n0EIKznrdLSSitC78Mk4xuCkgqCA3DJWuxTWcEx0OOS0k+aYC82l1SdZXfgnyvJPiqlBxacCnPLt+SY+m9elVpgEJWucFYpZIiwtdRwvHlVSNlfa3CUEODtaq+jtk6ixdaRrTa38u5BMlEU947oyrRO2SFob5prr5Jpvw5IOruWnHE26zMHyVp6wTktFAHYb8lZHCrGY67KXslowB1jtMReS4PukcMFpwAvsr+MVD/KVZ/aYfjCsfYt6B070UESiVVVRTUOifYK0x3l+5TclP2EvJHZcuHIJyGZQ2R8P6odACs/tMP8AFb+aCPElWi0XwY4/PxUERjOrhxTDJXbKf1hbtn5q1RSurrlT6NnfraynsUrDrVqnWZ2ZToUYvFXCriEZVmjaHNJKhdZZg2l1rwKc1PouG03OtFP+Y3eOCZcuNuUu0wQU41mc/wC6drSSgZUrRBXXAea00B9Y2c17u9Wt9yWZpoA5wNc6KxSX5omtA2f8laIe2QW9+RM34LToaGWCnuSf1Kz+0w/GFY+xah9k9FEQqIIodAU+wVpjev3Kbkpuxl+FHZdyQGHkpM0N6ZjH/J+vRRBQ+0xfxG/mnPYxl5xoAFJaZbW6kYIYoLBg2oTbLluXURhStYBgSrU5jBgVLbHNB1laJy6tVI81Rqb2BXn0ECmYQTXkGqgtd2is2lXDBWPSWbhTxaFFI2RjXtNQU/As+Ifqne0SO+6EFu81pp5+tYeAWkMbRIMtysFRaIK7om/ktCsLbHPvBtOfEUWndmwfw5P61ZvaYPjCsfYtQ6KI/ZPRREIdNo2CtM95fuU3ZUvYS/AUW6snwpjdUclOKXUMyo+yd8H6oIBBR+0R/wARv5q1yvtVt6gdlHn4lWCwCJlXDE7kWhONE+RoxvBWm3htbpVotbnuOKmtGs4J9pzqUZsV1pFaFX1WqBor6zCaSo3POWagtLg8VJa4b1oS3nruqdk/+pSkavxBTHWNfdCbSpW9q0q6ulIaefJWppNrn1cc1ZABOziIxXnRaMozRhumvrzSq04dXR38B39as3tMHxhWTsW9A6D0DoqnFXlVFBbui0bC0zv5qvqU3ZUw9RL8KOxJ8CZsx/CFaMmoZlQ9mfgP5oIbXRC29aoR/wAxq0HEx8ocaYCvmrwAJUj6Yb1aJ2x792KltL5bxBwVqdcYSVJaHF3mnSHFUrVOHgqLFCMldU67WiAUEV40JXobm4q5ddWmae0EA71YZSx4NdmhCfRzA7xH4qTun7gTW0W9Wt4dpWnu4YeClc3rrQd9TyVnpfcRj6n/ALVAAzRVmunakc4LTh/1eP8A8b/uVl9qg+MKydi37B+w5Hop0BVRKnOotM5FHsU3ZUvYy/AV3H/Ao8mfCFaNlqGZUOx/KfsWX22H4loNzaykeCcdTzVok/xPmtJS4vzyChfWBhqtKO9U3mnHxTio7tcRuKeAa803JBMOqeSr6h3NNUOSfQ4AnAKXJqefVmmasxpJ/Iv/AGzOTFJu+BUTjQEqS99ZSV953mnVElow4qIsaJ7wyhNPknRiPRtlDMhGPxC032lir/ww/NWT2uD4wrL2TegBUVFTpcFj04Ko4q83irzOKtD2XVpWPrAacU6A9V5KhaDgpOyl/hld13wqPZZyCn2W80Myodn+U/Ys3tkXxLQZweabgndn/MrR2/mtKV18O6rPX0dvMrSQPUt5pwcnKEZ8inb+aC3pmXks7OfNNUSIzqTSinGq3EZptCKY5qA0ncPulNJuWfHC41SklraEbCaXUxpVWkkQOUsV+RzmUrfRFX2rzqV/vjep6vM7slDa7TJGGukvNaxtAtNAttELScWxU+RKsntUFffCss0fVNxXpMS9LjXpsa9PYjpBnFfWTOK+tG8U7SrAMSF9dWcuuiaOvxJ2k0dKlfWxR0s5HS7+IR0w/wB4KTS7z3wpNINOZTrcKURtDTvT+zl+Aruu5KPJnJTbIQzKh2fJ3TwVm9ri+JaBLS19AjS4PiVq7fzWlP3nIKy9gFpLsmp9aJyj3/CU/vY7+mPIckOwdjxQUScQRh7uKtB1G471FtAFVu2l/mrVpCVmjrw1SGR0PKi9OgebxtBDgKHgjb5w1wa6941/RS254sjhJKGVzUOkbBEGNY+9VS2yH1lK0LsVa5WCJzR3wB81ZagM8eqC0469bGu95hPzcUwgPaTlVQaUs7Ym1mUdvEorGHuFaVGSdK9t4uBwzxqn6TLZLvo0jgM3AhMtUkrXFsd2mYfgja3texr5ImlxGDTeNCp7Q6+OrdgaUGFcOada7UwgmJ7CdmgDq/PepOuewgA7QodQfgUyJ4fkC3OtP/1XWBoLw9+4e4MFJarQDngcl6TOe+uvm98rrJfeKvP94rW4rHiqKif2cnwFbvJNwDQeCl2QhtFQbPk77Fm9shz2xktBk+sR7PzVpp1+e9aUGMmPBWUNEPmtIUuBPonU4lQDWz3FO73NBb1FkOSp6g8ymjZUQ/NSAC9jVWk6rOaj2/NOH+NI4uVht0trE0E7tXVa00yxUxHXyUqnTTskmLXOrXD5q++R7y91fBQGO9Hq8SrpIeSML36q1g3mhmOzirG9pcxtK64/ALTVTbGkuBPVDJUWj7ILVa44js5u5BSxMe24W6oOWIw8laJbcHSMFniDWd4975lGecFl3qzLiT6ytOVE62BzqOc52Os27v8AE1UkT365IYytGl2DijC6MNeXPdTIDd5lRxzk4MfwGO1Xhkhei1pYLwpTIVULo3vacKVwYTdony6pDonE1OtlTz3qKONzSL91u+rb4/UJ1mD+se0tbTGm7pw+y/Yf8BTcvJAl1HHfipMl3ioMvn9ize1w/wAQLQGy/wAk/Y/mCtPb5rSe1L5Kyj1C0gPVKQCqKh2wfAp9av5oLeohlghhZ3fEfyTe6olIcHK0DswmnXyUlfTmeLh+i0ZUST5doz+pWm8JXHHJzfxUlayGpyr+Ks8eLwa7KireiDXHVCuOpxxCmY4yxsu7V0LR7HdZI8MoNZwpuwpitM+1R/wWqq0FBdbLMd7fkFOKXXg+C0lY2ywnDXbl5p0EYD6OrjtUP5KZ8UTIW3bxu4gjKqc+K6DEHMvbT11kmN0YN7zQoxU9ZK6tBia0A+W9N6nNrnh17DVy80WWgPLoZA+mZBFV1sl867uZx/NRWiR7g2R95o8E62wsZND1Pdwwrj81gRUfbdix/wABTMvJM2W8lJku8VDkPNcFVFR9V6TZmsa691mJO9aCFBJRPGqDwcrQ4dfnvWlHa8nIKzdgFb+zTwiotrPcU/N/NDNY1UQ2VT1DsO/+ib3VFWhUuRwU+MjE2lSpKm0QnxWi21nlruez+pSyODJOZz41T5HOvNGfGnjkomam0STXDgmQydbTFtBgnRPYW1O8KWTq7VCb37xtfCqs1pjZYXw9/GpH3a1BWmy020U/3TEyN8jwxuZUMXVWaJjQBRorRXqYHfvUut1nAj9FaLD1cskooAaXda7RT2mdsd5zWOaXjfWtF6TBJIXSWZn8goharM4OvRuIB1GZUU9qlkbcF0MrsgUyXWxgNuxDxrirwdevGm9EgNBNCNyY5jNYNxTnlz3OONUHU+1VV1XYd0pmTeSZsN5J63lQ7vNbh0AAkAmiid/i4nffatAOoHjknmrBzCtXbrSe26lclZuyHmrdsJ6Kh2vmpNp6FKreoty/dP8AiTdyi3qXPyCm7VqqRIpBSaz195aEr6TOQK4t/qT2udFM87IH6pstnHV6hrjeXWOF25G4c060zulIywTuseW38BUBWsSXg4e9WijZqvkqTqEZcVpj/WE3DctARj/ESd7BoTKuIbXWpiiXAlvA0R4V7uC0sGvsjiaalCPyR3LkVU0x4ppFfNXmVFB448UDGCcK8kWjq6iuB4YYrCg4qq4IlVVfsPhmjreZhTMZKPIJmyE9d4qHdzXurcjmoh/iYvjatCd7HcnHUBpwVr7daSOu6rdysvZZb1bNhO3p1aqKt/yUm1Ihmt6h3JvZSfEhuUW9SVJHJS164fCht4qYdg77y0e4tdaiN13+pNma6zyE5BuXmmNYYcXUde/AqovDWrid9EJHh3ZrrS97b1W6worTfNoZwxULn3GjClP+5aaP/qMuIWgvZnnjIg65KZG8cPkiQJA7O9h+qLgL1K7vxVopJZ5qjaqG78t6xKadrAK9hRcFuGGfQDgd44IYHFAV3EnoP2jaZz+8d815KPZCeu8eSg7vNUwbggMFRNxmZ8QWhzdwvblIfVhWzta4q3h15wGIorNhFuzVrrcKfRGlVHteRUm09DNUxUIyTB6uVDNRJ9bw5b1P238iG0njVj8HLRrL7rYwb7v9atdjNm62B/AgKsdG4ZVTwBJgK41r5rqm9aS43RXP/wAJjXEHWrrt/NTOeZxUnwCsTaCp/PgVpQN9Nkoa4CvNaObcsMLQcbt4+aODHA7lLUuYGtOH+cVI9rS5uAy8k9wkilqcAC2oV4jDdVDA4GiI1a4cOhtBjTEZINNPxRcaI0pgggDj4lHM/a/mPyWGGaApkpFvPJQfjUI5Dmq4K8OKjcOuix7wWh3hpGeSedQU8FbAet8lbnaxBO7Kqgp1XmrRsJ1KlFRbSkGs9DNb81BuTcpUM1FvUlA4U4KfCRvwphxTGXo21979FoivpFo+Nv8AUtJWkT6SmNct/JOZEySjm73KQ4t1RSurjkj29XNbnmSVCDgaN2hiOah0Xa7ZJGWtN0d5fVbbFUPfec4Oo3wAWkRet1K5tjB+SjutLWtw1QPIIMNxxanA7uKJvPcSRkFM3/DuZuDDT5LVuN4j8VTI1GKrSvirwu0Fa7+C3JtMcslhu6DzW6hTw69jnRUV0q4V1TkIHcEOSxVU/FAYuqaapUTg04oSgd1Xx7qvn3VE9/XRbtcLRMhL2V4YJzndXshWm71rTRWza1Q1QHU81adgp+aPJRYuClGs9b1vUKbk9DNRb1JWreStW234UytVZ6dUD/zGrRzJrNarRIWEUebtRmRVGJ8s7wxpLi3JRfR21zVke8Nzwpjij9FQG+0Voapn0aaHl77RRqisOhrOWuGtdzpvTrU+l7smDdvKe4yzkvcbxjeQp/ozbLW70iF8dDTVJ93BVuHW2gSPkjUNO7Af/wARbRpBJzQOJKIIAdudVHB2rxwKBoRzRrvr4Ld4qlSMlTNBVpXPwVBXyRJbd5rR+iXW+B0zJYxrltw5ofR+20B6r8V9WvaaOZQptg+6m6P+6hYPBef2aBYdBpuCi7WOvvhaMkpI2vAJzvVNOHzU/aNx3cVatvWdSvMqKgZg6vkp9g8lIBieiOvWN5qQazkF3slCMCm4MkpxXexUW9SnBvIK07cfwpmZUDHPgcKY1bRW6tqhszIY9ZjXXsPBQQS2QkxQPdNI0VN2tAEJ9KNFDZn+JonaUtIFLt381JaJZY6u48VZjdvuO0K4cPFOvOI4r1wkvBtQIz5IWh7aAP8A8lE3nzuzN8q8ATjuTzdo7fvCblyUrvUPcPvU+SoaZdFcAEbtBSuWKFQL3iuGHQ6lxnmmCrbw4rF1N5ViszrPAxldZzquVotTrM+JjS7ZxVmLrS0yOCEAQiaurFejBVVekghAHcFQqPCRmPeCsJbeafE4oSepaBXxUrxVpxy3K1YOIwUOyp9lSGh8D4J7aFNBvBS5uwW9d5RGgKjGEhockBrKEZqXYYrTiY6DcmihTrV1MYuFD6QvDTi4mmGKk0/aZA9rXOBuKwaWke+zRVzqXIWls+EjWH4hkjJZ7lGxWf8A+qJN43dH2Qn4ladJWmAO/wDSmt4G5UJulJ7XDMJJA1uqKAcSm2US+tbaYgD72BUkPo872Xmv3gjGt7+yEjb1EBV1Xu7qa6gIWkZDFZpLu913yKe0XWlp581VVFw62JOSy34rLMY0VTjXFOpdZgBgpBUNG4AfMqrRqs+asFmaGttDs+6P1VljD7rnZBelwumkd1VRXAqyQhsDKUxxVzwRiRjpuVQqqqqhU7kOSFaq+83tbPNeaaQHtPiFZKNuckHgsFMCiD6upHyxVqDQ4/8AlM2fNSbNMFKdatAnU3LfkpMyt+apioszyUYddf8AkhgXKEYFPfq+StBqWpzjgnuN1o+8m3muo5NlLXNPA4rRpuWmtK3Wv/JS6QLK+9VM0lacaOxdv8FCbQ1sTCOq60gfffyHBevhjDY7OZD4n9Fa47sXr4GknO4F9UwTNvXJIeGsD+Cl0TaBQ2WaN1HVLTgSPNTWaeJxvMLeYTHu2mspU0xxV7FxIWlXXYI2PPeJHiquoBXemiu7BG5jdrTcq0x/yETiscunRdikttq6uNl660uIyyTLBbb1H2ZzRyUFjayC64UqM+Cfo2NlmlEMl+QNwHFaIM8VhYJ2uGOFV6QxXg7cseCc2LaBN3cN6rHU6hz3lUq6ga0AjmqSHJp+SjZMHZPy5L0eU7x816NxkCMDNxJXUR8CvR27oyhqPZwo0/MKA34RRY0j1vxVoj1zishmnqQK6gFKNYrcaoCj1ENbM5Jhwf8Aoi+hdgrw3lCQHgpcQ1P7h8VKwi54lXrwoqXmqNroLLLOdq5dbzKsdgtNtkuxNy2nnIc1ZrFYbCWta4yTnv5XeXBQ2GyWaUzmV0kpFG9Ya0+Sb1xztUd47mjAIQRtkrdle/ecafJWm0WuMYWZruRIP4q4JGmSZtHe8M02TqYdYukvfL9VLo6xTCod1T+Ddn8VLoy1xVpR8dM24q2TmeYitGtw5IZOF2p49FSsB08OjR2hbTHD1119ZGjCmQTrTpKzEUMoFd6g+kc7RSdlQmWt9qeHQPgdxa5t1yit8uzNBlvb/Yp1oZaJ7kNncBjV7X4+bSuqtNNpAzjN5Qsp/wB21Nscvuj5L0CQ7z8kLBIc7yGjD4r6taK1UejYzuQ0Wz3UzRLOCj0THwVq0eLPPmccuShlZGKFwp8kLWzDDJTWhjscUHsILapz25VTrhrijQDaWNVIaE5LChyzVRWq9IDcghabqfMCaoyqJ8j3ho+ajsckgpeR0NM9m3keCjsTnuEVpF1jcesGPlgjYYq+obI/xu0TbM2EgyCrjsRNzcjY+thb6TJdbeqWN/LwCfacGWeyjVByaKAlMs5srOsOtKd+Yb/5Q6ySpcXEqzWd7WukccaagT9HWmIF7ZbxrePGqj0rLHhIHHGgqnSx2gYVr7uAvIPtIdrMLR7pVhkgqRQmSu/9FbtJMgbt05DFW602O2n1tlBJ74wcnaHbT1do/wClSaItQycHJ1kmjPrGlqZBBvdVegQuGqSpLJIwoQ176hdNZZL7HlrqUqBuKh0jpBrg/wBLlPHWr+asenpes6u0vpTvUwPNW+22UyYQxvbdqaUr+Cssgm64wNcwtxH9lBpy0w3o5SXNcMDvCdaZDIZGOINcE/SlrdX1tN6m0nb3Oum0PFOC9FZlh8l6K3gUyzvFbwZnhnkvRoyCLzRyTbMy/W8D4BqEMPAcV1bDTUPyTbOyg1FcYKHAHHxU1ouijcPEq02ea0N1pcRl4KWyaRjwNn6wfdP9060PZ2kUjebSF6dAe8vS4vfKNrBxvfgvSRxHyRtLfBel8kbSjOjMUZSusKL1VQytj81YLUxzWmqgmhLc1FHCQn6Ogk1sipbDJHV0QZeOZpinWC0TH1shAHAKOKGxs9RBfkptOCdFapSL0TnmnGgVmsfVMFQAfyTmtp2ZkT5WQv7O4rW2C0x1Go73l1tohkuvp/dRaQqxrZLpbuqndUQOpfRwxAOat9qLyBvUjyA1RzUbG6mFNYcVLLY23SJJKO4hMMJqDKzlkrVYLL1QeLgJ3LqoWHBzgU59mewscceKe0Vy5rCjW0yzQYxryBVPHrR4tXWFkhI4qFxje57MjlwTsYweBoq0LaKvrD5BP2jzTY6AUYB5rqcRQUC6oU7vyQhYMBRCLg1NDKnWVWtJIccfHBOe7gi2pxCEYaKNaAPBNZT+6wV5m/JPgsb9uNh8qp+i9FO/9rH8k7QeiXfuPkSnfR/Rm68P5ij9HbDuL/8A7I/R2zf875o/RyLc6TzR+jjKYPfVf6OeJX+j3NfUBG4r6i5/JfUfNfUrUzRDmYsc9p8EyDSEWzMDzTLXpOI4xV+F391Fp4sp1rHtG+oVm0nZZxhI1SMa4VYFgHdrK086hXIjiTeP3ir5qQLSwcAMEW23W9cDXLWTZpddstTwDhVW7S2HVdSwJ9sJaI3tvN3eCjfeszwDs70JgW0rRStAANSpnayikN1NkvMLHZH8CnsaG5mqAducFevC6/ycmBgv1zUpxYdxwKGDiPkpTdcTvoAs2tPBPwvc1DI9lQDmmdm7mh+QUdR8qlYomOtb1Vf3tFeCv8WUV6/jQ0V4jIFF44IvxGfyTOraLragK998oupk5Bzq7QVXa2s3wqEDVxq+o5K4N7nK7H4oxx1DsfmqR4Gg6KYb0cN5WtTeseKo7iqVFQ40V1XRxXVhejtrVejtHdXUDc1ejx7yFLZLADV72AqK3QWQ6mkKj3TirbpeFz2SQOqCMvFSaZ63VNWHio9JVF2Qa3HiptIPu3Q8ngVHpW3QntXclJNfq4tFDmOCIoBzWN5wG8oC62iBrVtTipsgo3JpqVExs4uEgO3E/koIrrnXqYcUXNLjqrB2PDNTAdVhuIUZv0G8ZK043VCRUjipdpMKjPq5OScKsd4tTsGnoAlBrRqpM4Gpoh1o7xV6amCvTYoGamJar0tNyLy0VIqmlrgKtV6EGlEHMyor+eoEH1GwqHEhoCDxwxV4Fyq0Gl0rW3NR6zc0L+ULyQ5LLgjI0DaajbLMM5G1UmlbAz94FJ9IbKNkEp30ld3YE76Q23G61oT9MaQeO1onWu1Pzmf80anM1WSgmN2nB1Qps73FVNAr24oOD8CMQmeO9SYABA0cTRMDnhHirThIfHFMzTNlRvo5Xo39pgfe480Ka3JRuo7wTgRHKN12oUQowvT9ZjuIxURxCnHrOabvQdTU97NP2AOP6KR2QPBVV2gQGGaAIKz3q5eGKEAGSbDL7yDdyDW70WYmiA40XVxrq28VcFEwUrgi5oO5G0RtzcE632Zub1JpmxM74Uv0hsw2cU/6R+6wp+nbW7LBO0nbnV9anWi0Ozld80a7yUM+l17DpdXcpK0UG/mgL0fJE/JAppRKlxuoYHFdbRuCqaDFWodm7yTM07ZDRwTTRR4t5ruO5Les4Xj7qfgxjfNMxqDnRRKTFodwQ1WEoVBxzTjWXkia3jxQKogAsFqBX28FfV/xRe33k6aMd5G1wDvJ+lLK3vBO05ZW7wn/AEji3BP+kbzssKfpy1HIJ2kbW/vp087s5HIknMlEdNUT+ylKh/VR5+BUg2q9FdyOIHFN1m0+Sdn0NcpW3oHeFCos0TrVTgQ6vFV1RRZxqgoeab2fkV3+KaaE81gJXA5FZCh40Kp6xwOV3DzW8tKdi44cj0m0R8UbZEN6dpGFu8J+mYG94KT6QRDvJ/0i4BP09OcgnaYtjt6db7W794jNM7OQpxPFD9gXK8qquHRX7Jr0FPUWyocgpRiU006KlMcntvYhEb+iMXmubxCyKvYBqzbyKeDcHzTNlvNeHzUWIcPBHaYfBd1yrWhp3VLhFzAUbtTW4o4SSO4YhGrWjxXHodpO1HvJ9rtDs5CjJI7N5Xn9k16CK/sK9OX7J2ScotlQKUbJTxrLEKvzTHUGKjdQOKeNQEceiPVFU8XJH8+iI6pCf2NU0+rdyqmZ3vFN26eCcME47tyaCMlPi5jBwTzTyFBzR1rjd+Z8sk43nYfaoqY/tqY9F0/sqBORUeyFBmnYsPgnJ1Mvn0b01y/drePzROy1WhvrK+AW9NN2vJRa0bmre371QhhG6qs5rQHcgKPdwVM/BG60VTczI5F4AvnfshNq1rq7Tj0D/YQf2g+wc05R5BRcUFkcU4UJR6ArxDKcUMCq4q0/uz91NFcVu8VDUNr4qXabT3ipHVDm781ZszyThteJRHrD5KTE04KTWcyMeadrzGmTcAi7f0b1v/bn9jT7J6HIpyYMkwrwT86+CGPmjmggt4TsEKlWns4+jaK2WJ203kiVBg0eKdmpqi6t1eCvFrC/e7ZTG3G1r4Kn2a/7GckPtnNGieQinJuQUeaGL/JTYN/BM3pw39EYq5E6xV6uCY1T4xV3AqtSoBrEomrmcCnGoveKdim/u/hValSCoW1qjf8AknHrJcMm4BO4cP8AZR9s9G77BTkUUFHmmZqYZIZJ2DegajTxKx4LKirh4J2NmfzQFChqMpvUZ238Ahs04puy4I4CIeSO0sxzC2WSnfkowBjw6d/T/8QAJxABAAMAAgEEAwADAQEBAAAAAQARITFBURBhcYGRobEgwfDh0fH/2gAIAQEAAT8Q2/V/3P6k7ZynD7nKCvTlHX/XsoHfEw3C/MotVy7FLmbF58R6bZW8QAPM6VLbLsqKh3ENRiIx7IUOIHOHMRAImtm1mqV9Et8C7b1WXBTkfbE/kwPj+2PPR/4/mB9RAMQxqiU9HyfMqyKBcdhpFGPZMm5zg3LHyTEDB/vPzKfr6+H3Of8Aim2Aa6uFeviVRLeIrUSn0zIID/8ATumtxUmHjfzRA1nw+dCYEP5I2wH00sju52mk0yiIp4Gr9wSh2g+W5SrOO8YRBAnHNqH8xFTj/V0nGeU/7fmX+omkDcnUFZLJKYD0cL6WiKGXKmCAuckFg/1hL/PB19evv8zn8foehU0zTQNtVlW3z5hSipr6K8gDhhdaM95cpuPte1yTanBJsN893k+wlUqXV4/DDolyn+Igp1FFzBXupdvM9z0DrDnDWAuFcBUt+v7GH14uW0pbFBG7WBfbngcdPDL0UXwIEeRyn/P8w34iDAgwMMzWLUCxlwjSwloG5wlLip/Eb7Y/1neP1v6JzTz6f6T+b+whzORFY8fxQX2S7gVgZywJsWXNbBSFugybTi+Gctx25vWniPbhJ/zCvFy9XX/aDDSzdcwXXX281fZRj0tKCkW4d5vcK47uJQQja3lfMKLFUV5rmAqdag2FA2kNPCF9lRU6AY6qss8DxHrXj5EnKf8AL8z9YihLIw5SoLlZPKoOoMJb0RGrmUT9qL9YOor8Q/v+E/0i/C/symA+Zyjr/nxKSeMRHmhrc21AtXoJfMDldkDHIg1g8UAhndVIoOncXxLsD4H2wLn88sf9sl8/FDErDQ5p4loFfDEKu5K8iwT/AEwtMDkIMFAS4D2RAYj6YSPCSj85Rhm6yFky7zFYPzFJoOUKu9pz+ygmhFyq37ziiAf5kVsf/X3E+ohC5aiYxNxi7YslDAhLiRgtS5FpuLXxHfzQTW/lNN7JTadEM/tFUOqv7r0HE7n/AEfGP4C44u+YS95ZYj0whnsKFheGHhxqr9fMJAFFVgbBAY8nyxW63ux6+5WFd5z/ANleDRqI3SnY4iKGx4CAM7R4dHqp5yi8HUHbILtIrAO9fjJimrRJziVj4zEKjGXn8uAdIe2DfhaPaAA1QfEAbYOjKl2hFea4jM0+K9Bce124DCckemeFtY8UnFplMkHky0EZV/3ZP+35n4o9Ai0CQ1LXLY5mIawquYjGFoN9Cx8kX6QbcK9fb+Z+jKuvh6OfzhOIcwluf/8ANCsuWDK8ueWUmJqXsUK/EuB7MriKKvmmNIB2QRTbZg1QuK3hmSQw0QwHAoPBB7qiGno4MyUpd4tHPtMlj/FFbEGAr0SUtNx+wwwbEi8A91vP1CGUAW8DBsICFmjsqArXG4bVX2Vyxm5Q5BBWnmWcKhJwPIkJjtPAUFTsOze8P+v5n6BCAlHpxHL0hse5iaZaiIijsx8U394FfWafy+gn8ErIOZP3fRXInXpY9j+CYq3AjAwFasd5jiORLSbPInLjj2w3hH2rHsb0Wy8srYwofdCe5+pTbc8UMhRjNm48XF2iFXAOIE0ZQVuuvyRuzQCvAGBOUZc6NleSKqgYHQshpfNQ0Cr5XBcgrFKiWIcHVdkAUVl6sMFwVCOPjDVS47qt/Wf9fzP1D0aEtlwdmmdThN40nKVqWgNPozC9/OD+s5flm/mQx2DekFDJzkWPhJAbODDpM/8ANiMhCKwp1OnKSq7yZYB5mnVYuAMY02GFQorVdE5lsL4hEWl+CIRw65xEVeMc7qaV3sCReFgYMRUabncrvpp++mKgkc5CvKdMqxLH/TGor/8AOBsov26KlG9vJifcRRPAywgaQrl//ZSrNT6ux2wCqUhyZ/xPP0WPwEWQ0hASEKmVU3SWgD6aIJWSvRcPlP8AWc0MSrPgRHHkyx8H0Jv5sDZZxAWTP/JiCtaf03/4QTnioBYHEBa8S9okNNiXC5fNGXzFrtDxcO3+CG2rXs7gcJSU2xWMSKQSDwKlmFgnnmJbDTqIFsdTrYaFHIKToHCezGUf+bmByev2mPxQZUqgArVlRfKGbpbcbjJ5cE4lsPAtpiNUJrXAXAflX7UEs/iITgQu/UIjKC+gQShh9CTnnCVPwjij580g8wbDz/Kf2+pexU6LhyTaauxOQG4ea2e/uiDVZhCZfXMtMWWi6EWBAZrlaxx2FiL0Pi4u5OrYHlks9SkOTgiNi6iXvEtKA4xSFFOoEhhfiXZo8Qp6sPbk/CTM+XPgLCr2P84NviUfhU60HRjhOb7bW2QE5Qs9y0vZqg+GWviX7b6b/QIJBgzjCHEeIKuahz6GNGcYkdUf5YMfENQbH3o1VX/Cb3jze7fR0uf93AniHJLoDTx+aYjlGycVex97x/sQptQ1tiQKclV+4ylpFq315qHve7NtidTPsiLGRUsrplbwapzNlhU1pEbVVBVTGtbBFFimpYbZSpa705fNS9VKxCCWaruGyKSzdaQOFLtz1cuLtVM0Mo85n2siXsH93pY/igMSDlqlxgNQGNUC0Sp9yvMlME3ni2L6hBMErUVBXLKxbv8A6cRcEuIttvR8f/OytnidktinvfhlotawVs6Z9y6DSN6Lh17wrQqGS3z4lR4gbqv1EtJxVBZm55FTLwluCQca0trx6Fj8x1udDqdOSUC1AgIFUFRJgFb80VGAilvmB0XZMjj8fhiAFUjXJVVHrBgfsbIAA8I0q3LI09F0bkPs2te2iBlQXMPk4O5R2RPxEPET7Id4RM4x8KOEYcq1LFLOAefXDHzj8w//ANZ/72HowBp2PoYY1Gy8/wA2F0P/AGouPxn7vozYlUDiOx4d5z6mCGBQeIexdO/eCzaUcJawuELNiXbVRIVnN0zkgfTE3w/TNv8AxyAEFqgNGXTCOnaCvIq7L2RAN5sOc0p8oTlfOVWHkhX22oz3YXsUE9qK4PjbLPRC/Zd274hs+aRTGpgIW3xEACpOgC2Voaa9OuoSvJH2suES/oWB3cBYWUUcXHfz+B6uCAs0LC/iNiyppS7xOSutBgd5cqrQF85RRCFnWFoaK4q+4wtErlzEUQqbhnaXxRsrNkVAXXVYreN0LaefJxC1s0s3keYopBaS/P5pa5cTsp8vR/wfDDnuv+sKYpAJP3PQvEHgYReJzOnuJoo6lDDY0c7UILQgG7FauKeUaS4wqEjefDn1Beyg95Qqb2OwoypfEAtB2LqcOrf9cW45OagFlVbhd1PiGDjngQmqgR+UgVdmWW1GHJUbaDlGoBgkgcF4wM3LyqqPHRHCobDxBlSk1u3pK/KrxXZxDeKWr0rEwgr0NfTYbzc65ofWAW4oeBpkVvyLYTi1mvaCDJhKV2HBKpZGRtOmpI93Roh7e0SHBeKeN0qPayhYl8FnUrBjQGjWtp9nEHo7zuW+kMioaAWRvLRXyiD4ti5PIAQosLoC9i6RfEqUS4s8RYsWa/7cmh8P5DKF0Xyx2Yfpiye3pvYy25FNw3kDDe8BhKbtzKIBTUAnh1z7hB45LlgZxmZCvjJaxnse05MpnL1K8IDsVsScwSYx9pcvO+ZYQNVt/Eus7YxamQWq5HjuEkcMXl45KdxYRK8oHYFuBOYZVt2u4hctAoIFrT5uB6oXB8sYl71eWq5jr0BNUtf2T23/ALvoQ0WAKN9FRE1oI53/ANhqHna8dpepVha4eh5e2KpnervwtW7huBpNPj2IcJr2txurj9wjSrn0sL22iYkIUAp0gcqEpWL8N1e6MVNub0RvtAq7DTa2swpYiAGA0L7bxUEfn08P+Cx9BT/5qKz8P5N/Gi/aH6Yj7Ic+kU0vivxMKWPxGhQE2aSqCABZeQLlYUwnuTZCygnLNUvsybGcQ7LruhIvPcXRKslD7Lhh4C33jhwhoPvKUlYgNtFRUW1v8SxU0mfJC3qUp0TgB2+5J2PZwLyswi1LCOx/+xbFA2ouuJeb2F3txLL3OaUI/ULVGpciXPwu9mbOpXse77EtXljumr73LAubW9oBtAo486uoBc1upWWbFBRtRfO/gh0IOxd+MJxnMQLOFewmrjgCPdUQBG7sbR221UAT4aCHBiL4kvkbo26zmbZmrvbORQ79+qxZZKSlWj4OvQa/QiufynD5RZyN9eKnRzKCBS3xArFU1GRNygpB3U3MYBS9gtBs4E4jfMUa0bW9xKvLKXz9TynUVfDcEMHs3mA5vF2u7J/SACdK23T8Sj7BBDIylZR3vSI5k1exA92hDxRupwSGd3aHO9rFrrFFF45bUZYkwcAnQTEyoNVSNl3PdK+YouE3ynWluVhogQUQstx8AdWM4LUQVvMd6o9oq0ndh1aoWIwC05pICUSlLs8MGkdMfuZjkJPMqbqta1G1MA1tYve1Gul1y3GnYFj+Azrl22KdeKohxYLorjj3lKnptLfU4JtW6sn6ZP1/R/GP90r9GFxZtP8Ae3yR5ZqESurhKlrFUJz9S7Q6jTGgo0MislPMPsyarCPS+03l3MjJTeGCNhrQ/FxoxYvYRWCpXKTqDBZG9g95YA8Uxvio1aKVjU0MidHN6ZR6ShWn9Mmci5XewcXFlUsHWx991YVLVXS7tq94gRa2NvzxkU82iHeCXophx1zjBwat17oIQS/MZlJSxpeYF3RYIla3R48vNQh2l8VYP+0UFsq7qv5GLCACmX4yCQA5uUJ5bcShBf5PtDmVrWgtqGdIeH7nG2cCcD80zk3v+LAHQTi8AsoG8HUF/ZBSzSDlGxZ0SC/aVUrJxfP+2FgkTvy3NzeorqTmteIywTmsD2KesSsTqqmi25DZtQ0eWXflafMsuNcIhYA352BxfDDVsKtXj8MgoZ7IRY07OaKEr3Ki88oL80I6ykNAb3LgwZdHbANj8KtVWm4cHYbv6OT9QgAajtTjDKjaWXy3cG0apt6Oj9y6bkXhckNaui73zAMrDzeS3hcECh5NShCBa6TwCfGr1MvPqAMnJTHY6DP/AJH6R4PL5muwWhBXHYFVCPcu+8WQ5dYizmzSogBwM/e/xbgHf1COaJe2zYAo0TlKWrpLK5vSPMRaPYmF8sZ1oWW4r3l6iUy+km8gJQuB5JCXXyBjDF5Zrsehswh5C5lkN+8onHh/kowfj7mxT3KF8mKrRgbe3XzBy95U7TQlK2/U2Kq50vvMMvp7W5gHNf2JlkIC6dpol6KWNpSHIRFaAgZ81UgdC8EIig6c64KmdbYauRBaaAwuC+9wCqLB4UXEIhov1EKg5RbvOZfUY2my1f1iO1SCszd94KbDiPFLqX4A+Ozd/UsaFLTn8xSyFL+mWYCXmWOqIF6sQayrIwd1gtqNG9Wfupt1WYwF5Y4slVUpvubXMLl4QH6YJ0xHaJ6EHWEWPU50D6g1h5Xb4gBDV8ECSyJW/wBJ4mzxkn5sTnmANcJTmmNu0Wcbw+Jcg3WYlSllGb2p9MRbVF9SVoz6Ze2c/cD2W3PkgR4K1cBshgPebewlkNr6i/I7Xt1Alc5l8CVXM5961+JhqhLRKseWfFVLtinmylQr2mhajexC98K1FWwq9ssQYsPD2mxGtrJ8rlNwTWfZyCsHvTlU/Ezu4KTcAZkrByKpIA10nuhsBfgpVbLLH0RyGP5jozYrB/AOSyXSYTqmHlYN2ewjo7WsvoK1w1ySgnmrhaWoahDVoMt6YYkdxUOuXSV5usqLeS41cBgtofAl2wOk9UKust8vW/eOz2ZVq9Gm6Dxdym6jX8wrZUDC4CE5lvL9za2Lt0IhVdGiBnudwKOdzj+yq3MAAcGluaUrl5bAaAhKAll+GUq5bFV1o2o9AOh3DGjucYDrs4PiK/cUVcmMEa1DzDtFqckJKfGIgTAnFKHW9S3b+yqH5i9VFUcsIyQoUtiITtiqW2FymlfLz8S8Kqur708ThWwW73nY26vEqt6/MHPwTuutQ7WDKaJyN3oUaVWGWBtRj8ymJbvF49d2MZt27fMFNVYx0na4egKbapbyrnlQ4d+bIpDQwr36lJr8aUqvqPRUuTly8htD8Tl1BdR4hnoPofD0WpyAkXalHLXEuS0N5YhYbHMs5nC/XYLOZjGE0D37S6ivJ19PMYoYLtoqKsWblOR7u+L4iMUuzZOYlaiGlMClQ22M+ageFbVE15MMao1XFw1CCuOpaynmECb/ABCDUoVh8RX05SwVoZbnLq9lWCnwe7LXQI32JClTU1wL+2HoG7KUHusAOrAaC+MnGP01VfpCZZyjHPyXK5TQQVpxATgGKis0Ix+cboFf5UGnVBemlsEgFjQ3SjCNZIU1nHUDjXOOkYW/CAO6EbKhQmHMBMfIr0e8BZwsIY8xC57RwjLiijRt0IS5AFzEVrtiDiCU5hbG4DVcuWWk6U/bLRi+axU0lEOjJwSC1cbCykAVdSxTHKu+veaaTW4dRUPJ6ieEsO4m0qtOBqfMXicb9xHekaaUit5EdUcNY/mItZqtTHmKuQhINatxG8gzOuJdsFAj7TOhnjxDciG+MjxrAQJrzksC4vZgANWyhZ93AgR7yJodRqG0YIqQmC7cWiBUG/fI2fEK6cY/IHh53UdBvkV1NYkNDhTk7B8xe2gT/cA8tSg1Sig+K4EIKGKjXwLVwzcTDZ91WksJ7g8wQHsrY5L1SZFPeJwEUjY3xd8BfNMsNFoDgRa4qzXVuXCTaQW11Clih08vzACgWjX+0Zu8ufcsGnzXxD0ElKolj5S8JuFx9VEKGovCEbruNRUh3mlEUFooNmD7kb0zwOanJnzKKFBNUZ4ag9FgboDpb5lgpPtSWRIsNJBzBPeA1+vsGKj0cQbj88C5G5bAGxRb2Cr5VusBtYb4tUtqzVpsCltrXEYjV8RawOYm+/piWcVLKDYUJ2eLnYZXHDHVdna6gadNloV+DYsEqrnYcKo2N4TTAlrjWAtMBgrH1epXXxBYDaRLKp+Zq5cmiOAflTAgN3Dtk1moZndUuK3QWVQ8QeryxV9wzGMXwD5BBeSpF67T5JZFqOQ+tRyR1ugPci6m9zV9mJHkH0Hhd++sol8YPAc5AzR4z0EBu7l8Zst8QYEXb+vMIoWK0eXfeUsLhYJSLdyBftzAKdYBfZA2WiWn8hoTqEgO6EC+A5S6PhZY2/gjEDgeYqurwYCpDbsiqF7bIrn8pvXwuqWD2NEsaZfeCOe/xH5g9yBBs7XEdCQLb3CpynMLBkV1d/2XY1Wku0V3ThIW2xMSKl4wZC1EBAEHGApaM4V4VVUanMJY0t5OKlhAK83vpIq4xU6XnwIdWRxQWU0xffNfEKENpPDwtrC0A86In7he29+w8sElQOVUM54QMbWLAe3cPX3qZY9rx90ViFtt5uJktTlBe0hlkdjVk3+ZKHsThi3mh8GtYvbRV1WVVRN7E7Eo8vBGBTO8xnVAhq/s5+5X3t3yBPlGXb92jRM43mrPyR1Xfao3RFMpjI1IWMfJkuz7BL7KWIM60l0+SM4WU0sHWkG6nkVFB75r4gWxdz+x7ktfg0iAbrAIUXlShkrQqqiBLYv0qoDTd0gZ81FOy4QfK+4pjO1cPkhnWpaHnzZrOUsleb4sy2FZd4vF/cLdgrAwJy4GgMXEUbGA1z7SrI6N0gNEPZL+KMYTzpMTo78LDOsNIggcOMNRQt2mLlFqGlZiPdlR1vD4i+4iPklncZurReTB18jww2UrIAAPFS1qdCEWID36e9Vf3LsDUImfBs1R3oB8EXO6LBfQEDu9bbICwxLYYv3CAhcrv+yObuUHCnmyJA2HHwrkYwNAUvR8PJL5XLqxfZV3ECrZvxkoH7lsWQByhDluojvy+0vyXYW/a4UdvDVp5yPJ4quSYQoIDhh9i+KeXvIpfYtR3mE1ZyrsRlfdVDqHiXAJtdo93UF7yq+9irSqmxdPwITVZliVCozn/oilABLNbO51kacJqXIHcrP5BMAPAZAgi/C//I6kHuHsR7Zj2C/1L5+C5UajhXU5DrvClDzF8tNNQjSiryvPuYP06x+Izqr4jhge4osxZJ9lv2U3U49sqtd9xDCxZtUoijhoMQeT5iC5muB8xQv/AFlV4v1FcY5xcpD2M1+UhhE9vJ9UiJUUWSGW54suUmNmtx/RL9BhWqHC7vmovmNpYl5JOjVfcoZDoFE3fKbBIIc+fgzByzaS/idXnDef+QRtot/j7IgX2yUNvEDkUPwdkZFV93IVP9RmA9/AyptBWQBpYfggbXmleb4Yjt2N81srzbp+GL7MQTM5nJN++GKm3hF+ohvEqPvys4XV7cLUUfK2xVrmZbJks+zasqQEGx0v4qocIlw1K0lQCO+1zSQKgXVrrEWiNmdQ6ujeLjFHayyziN333DEEVAACr+4UaN9oC6Lp2riehui9F+03Dbh5Yj0Gm4RHA9kxsT2C4Ls0vyEDG/ipjl65PE6iNuHFsbY+JdwY2ooNXVR49liYOFcEaMnspPeFFg57kOND31qMNevpSGx6GF4YCGr1dEwsbvpMnV2tJbtj5rPZKhfGH2YM4V6EiW6OnUp7g16BMaBzE3wfGAERte2SvaW9TO13j4cXOVWUHx1AL49r28QanTX6njEZ8kDl8zZb5upVZ1AWeEblypq0Ps8xujY0BBEsFGyo+Js4qPYLcUF+IaiHuoEi8cZGCRW0RdcOriiFd81AYlDS5qCljPEpIZYy1tZ1gJnEyifWQb1jK95O3HQuiZtmcKpCrYIvKH5mCQcxHVScnsrS1wWUz8BOambDUXT5bmFZZ25IVaeAReIbsvxC8HF7ywpo5EPyUc2NphduMJQG9KY6PVPyjqLDY9L3wyuthyheIAsOCSyoVbvBJzkAb2snHV3R9yqqoCEGOnJubQJvOQ2IqzKmTtY9g4QI/kAh4hAuNWv2d2Cbopg0BY9rhLtkouFUnAULW9wF3cihaWktU6xXVwwJKNjHjHEUWssqv2zpli1Dl8jALfyQv+RERtM4+QYFFysvxZrr7W4QjLhWkCy4Oy2+JaTW6kQ5xZAEHtGpvBxEsYPM1+rmTHESZvdLVSKSM695efIvrZq0Ac9p92IhNL4ia7yzsW/Jj6uUXlWB2qJJ5W3sHFz3kQywpdJDTc5ZuQulCMCrbbcdQaqB/WX/ACLJ+xlwp9Eb5lXIQ4SEcVLHIIB0yyszn45v8kOakfmfgjzBa1EWVrHbd9xC1fcArIa8Sw6iSWRbCG1ChWpUs8wqKmQq+WNGMtjouK1OnIgjhePiBYQI4+YilwJofNWPiFJSkqKDcCu84ULPURV+eIQJhGNOIutS6/KhOS5wTNOn+Upe1i34iuDzYhjbWfDFt0PxHRgbW2DwqDdZuvcYxKsujyZscbTPEzN52VeMY4S/v0EeLDL7ufT9TAQ7US4u/cE6n5YhLmVCq9B94voJXvKDCC8S1xhdS0WyawW6TJhFaXeVsffgiu5zfMah4bJw3ZaSy5B3PxLrrxEvTfMNe1b8x0kvhniZSAh5MiHwuYFKllH0wXuWviN06/gnQDbWLcJVPyQNTOK+4Qq9avl81NOkidLGC48FIfWzVHP8nEOjYrrvI4L0t6nSj5s/cTIKhCvRWhdegMKm+iwYtPoPYXE95QFgiTqVkJtbHYF8xuL7xPaO79LtPtypqeOiBY9TJcWD0/cRbct+Za/jAoibFo9pUDW9QMdyW8gYBBVBjIvKB8cMF81OvuYHTk+biWca0CcRptvuwmlZykdp4FkCj18wo7Xlq+HFpYPCqPqNpB3nk9Khk1MQphAPRipBZUr/ACNGJFe4eGVRC2FVUcjVfMxJ16WNhsc4vpEEGltq5sCEUTjYau5ZS+JgmkQb3VcJHQTfCUFvdrOC4WmfHoiIedQiP19bBu7G3DZPBx7uSjyLP1Ll5bLle0k0RwZ8kN+UxjAbVXn92BZjYuZmTVlzQKMnH+PBCq/zrY5Ef8Lz0OfS6YO+gXjAcS6WoMHlI7U4sNTwwh+EiXGgyFSgqoXRFRUAcWpTg2phvazKJzT8MPDkvPeO+09xeeoEFjxsP1KkKCL3qJV6IDF/+MMWsbfNxtTjVeZdvlXHBxAOE8qMD4I50VBMedhZniv8VhsrfRWXLl56XFc4Mh/gwl3BdwrZcsyDpFTFio55nNnFmA9poFwePZcJdcaly26oaVMRFSJF5vmIss6kOnhSA43R1LQDY2HsVAAVw/zzHBt2Uu//AIgr5MQIbTEjQvBPNfXwjd0jT3eWAOthpjls5GX8S/Rcs9Li+pEnJUvPSypdwPR4hxNQYASpW36ZDmM5T7JaoLij5ioO02DMYnjEdp24gAXRKq93MyU59sBr4tjVa68wrvoOZRuhlwFqbAwLZXDQBPaEp0LzFR45+5Q8eUaI55+51HTftG1dnJ8QNmSBnN5gr77mc3UweW/E6v8AwKjNYf53vHpXtNIv8FqXWHpbqB5hBDmIL6FH6XpN0jbPvVRl8AjpDCoJBmAYEsKflKBcu4JdfIlAOY/sTQ26qARcufeWXVxHjYbFeL9MVNOGoznFT6DcVfOoVvxC/GVXy8EcBj+yw97b/k645l0OZVWW5zKan//EADARAAICAAUCBQIGAgMAAAAAAAABAhEQEiExQTJRAyBhcYETIjBAQlLB4ZKxBJGh/9oACAECAQE/AEI5wn0S9n5Ywm1ai6Gmt1gtWNNPFKyWxHZew+l+wnsWS1R4aajWGhWMefLLpl7eSlCCk95bEpylvr76mb0LFIcsLIrLBsp0eG+OxLpfsLZYoenkW5HnHnB7P2KJyyq6sXiR5hI+p4bai4ytabl+Et4y/wAv6L8P9kv8v6L8L9r/AO/6Hl4j/wCkY5oyldJYQhG3J8HiS0SErQm0xu4sWyxRV0PFcEVv5X0vCnO0iHhJJXG2T/40d0qY4taNYNIdCnJLK9rEtC3thAl1P2E/sfyLjFbj3JNPZDVYIX8l0J60SdV7obL0fsaN0eGkkRTJTiTlFja4WEaGhaCq0Mj/AASWr9kR6H8i2XkiUh1eERD49yPUT2GcMjKrfqLxHY/GnKSV6Dk2Xrg2MSTSJLTB7i2JC6H8+WO+ElrhFaCTsfAuolthwxCP1/OHOD/ke4tkN2LUysUdNyWxG8i9hI07n29zRpCWFRsqJmXCM7HwLcktGVZVJ+wuRH6/nB74S49xi6UXqfq+DWjgb0iiHSTf3aEGpI9MLMyZawvCSFuPYRJHIuT9WD3+BjwfSjk0zP2L0+C9BrWLLyws5IOmWWPVbiZt5JTzcC3Htg1o8Ec4PdYMZwPqQ6zNCES6US6EhL8JiwQxoS/0Pf5we+L3R2H1FfexQkZa3aJ1l0Jp6ediTrVCgz6Xr5pRvgXHsNa+Z8DWo/GTld6mZtaSHb11LV8ks1K9sVj2EQi1G26vYzru2XDuWWZkZ4dz6kRrVFf6Hv5GIYykyOiI3oV3R9KLVpJGShJ5tV5dmnVofjqXGXSjK1VMquD6C7s+hHsfSj+0yRXCKfA4SQ28WrKZlMo193oKMKWpKGXVRsgrlbV+gqW9WKTd0Ok9mmaNdmSk06iLKODatSPu7ozMyp8Ebqm2y3l1ZdmYzMsVCdGYstFIcUUZSolLsadi+zZd2xS9R+LHlX7Dm3rZmbHua2LWjnHVMrbGzXBFlllmahz9R+IZi2ZmfJw8NcE+7OTkVrYYh+e16GZIzjn6DnJlvv8AgPpE7VknhQmPUVV58zMz74X+LNfa0J6DrXBeXT8oifSRxQxbeTj8pPaIjkaOMF+B/8QALBEAAgEDAwIGAgIDAQAAAAAAAAERAhAxEiFBUXEDEyAyQmEwgSJAkbHBof/aAAgBAwEBPwD0cPsZ4HdKoloTZLNbFLIZVs0LL7oWFZ0poahlMHjC5NIm4tw+x09PD7Mncdk5b3hLn7Hvy2aGJNmgVCIIpSkqequEYqZUokfI71S0JwyRbLce7OGT/r0twn2GUqWpKqOlSjsypOJlR9Ip34k8xL4v/JqpT2o/9PMXQq8TS6UlLYqm5K6ntSeHRLbH7mNSjhk38TFqclbt8R4/XpftfZ2qrVMSVeJL2q2SKPHeGymro7avq2lPdZFSoQ1/Js2K/c+5T8e4/RXamEZVqnsyr/giHE3ftq7MaZ4jljKaHJRS1gSsxNCZy7PP7KPj3Yx3qwQ7P2q1fyHn9CPiU5sjSnCHQheHSqcEIS2shDlMoe6k5YjL/bKV/pjw+w3DJRyVRBOLJwmiGVjdp/iynKssoWUM+Nl7X3tThlI8lOzTJ6mqklSin3dkPdMdab4NTJf2S9zUyXwTX0P5Gl9TR93WRuIF7zlDPi7L2vvajkpHkg4QoVSOTdNvjFqVCHs7x9ml7D1G75FTalzdrfIoFkZxZe197U4FyfI4OglD/Y5k4qQt4tUpV8P2jslF6VF5cC2YirgXtt8X3tThlPJ8jhkjORclJP4pgW9mpwQyl7jFi3DtTgpObSszsavpkt4pEnlspah/gdST5PMR5m+BqRSiL0VD/wCie1uLIQsW8n6HSk90KY4GnpFEbLePwVuluEpg01EV9LQyH0IZDJyTsJ7WWLJj2ZTgTT/zZqWPST9mtolGKfTvhODymvs1Ik81nms1PqJtkpGpPgVKIsrSSTCNVXQVWrNUFThQhqpvbBEK0tFKndjkVS5TNhUkxyMiWOlEIVIqRyNSaVOTS1yfyXJLjJLJZLJZv1FJtyjsNOMCobwzTHBCQsCwPYyhOCNidiljyNCn0ReSJ+LND6Gg0/bIR+kSLJJsQNORe2+BuRMZtNkfpml9DQ5yjSaV1ZpXQhdPxaXt9iRA3A8CcDGxqP6iNp2HmTfa7vvsOPz8endQyke8HK9DvS9h5wRn+k+hSMpwJyZcjaauokWSR3//2Q==", L1 = "data:image/jpeg;base64,/9j/2wBDAAYGBgYHBgcICAcKCwoLCg8ODAwODxYQERAREBYiFRkVFRkVIh4kHhweJB42KiYmKjY+NDI0PkxERExfWl98fKf/2wBDAQYGBgYHBgcICAcKCwoLCg8ODAwODxYQERAREBYiFRkVFRkVIh4kHhweJB42KiYmKjY+NDI0PkxERExfWl98fKf/wgARCAFAAeADASIAAhEBAxEB/8QAHAAAAgMBAQEBAAAAAAAAAAAABAUCAwYBBwAI/8QAGwEAAwEBAQEBAAAAAAAAAAAAAQIDAAQFBgf/2gAMAwEAAhADEAAAAPzT99Pa+HRlxgs/tmwRQKilnWSum+Re2gP/ADy72Dj+qwxvoDDp8zPfn/1qMt4A0Gc3NLZdrE9SGa1Im5EPGA0/N7xYjfheI7YNG0yJ0gMFybSjOI1BVPs9Wou/SyYAxmvaGYVs1daS+50Hv3Ptq5w7jL6Px3w91Tm+VdiPEUkYsP37jkEuq4kSPOtrXVVsFisZLmNpovwJnv8A+e/UAk/d8Ao5PqfYWOdW+j89n2aoXh9XzC3PNLA7XZTUr66dY+y7eDfnjKZQohd0+ePZU2MpiXhyP1MzbzVEn2LUB7XeupaDRm5FJFNYZNa/Su1Up8Ih36GbnefHd7zhMITg5urGrFLZjQJt+H+JnG0HN93rAi8mEucXI2AFBG6+1movqr2/R7z84+jJfZNMxRPt9G/PTRJflQaXMaNH1I1NqdiifoGHTqz0jlm8LoF5z80ZEVwcaVllZcOCZWkvbVQga+RYQpXd3jYisZLWVKuArs0qEicR8L1sRCmW3fqpMZxr5tZ0T7UvNGtIEhb84Hqu6lo6dXGSc6CUdJa+ROXkuWEou12YtilzU3FdERSPF/zQdl+nG2NSubsr7DIZ0VByCdVX0+S00czRktJAlac5E9HNMypRkYCrKos4tzS8UfjpAbluOs47HcC4SbES3a6uHdrpw4B2XbNuVsiFC4dso2OlLiYOMo2IBMOltCmnRMduHGbafO6VXC0rh/uiAcvUPT+/zfzxd+gZMfE5eueZ7tSagC7x/W0BuUKHJo8wYDLlyvLYWFxFvRiLh14BVKkUs6glk2tGp+zzrCgznUC8O7C0h1F7GBHbT70C+LKzZZZZXiRdpsdB7wmd7oGScqI6D91iV2PV1dF/KLtTt1oPz/8ASfIsh+iPHe/i82+mb9f8Y1BZr1jXWITVv0RvsBru/hrYpW0PfE8b9S8z7ZKrWcfneem8n7l0RF+btCXFj/qUMDRZk6Eaby40Q63xLBMxGHKqPGWhbXLq97L1Qzm6PCHdR3Rx5wYyumgPcSdyD+6eQtCrVEaGQi66USTo5bZ5FxKg4En6UJ41RsrdP0zt/H9X8f8Aaarwr0Hx3pjmHanYehw59Xr8n6XipJxu6W1THGWbi9DHwl1l15GTs5rb8Kk3z+ykn2LL9HN+aBDL7sr2YWhmdSs0wwl5wQgXUc0PlJMdHntdz1keNznfZ+T7TG0T3Eby+kP8A650c+TLb/Ns8fQ42qMaMeG6N2t9IlTMpvSPN5NRevL9PgYYvXZZh1dfFzRLtmNMbfnmHMQ96NFuhYQCYH1vyJrdLAZFMt9ZXTTM0egnske2v1tlkcud59vQY5fdPHUKm666/nNlMXKT6h5X7LMBvfL91SeNXa1Flzag+vUyjIcu2LifLlYjO7/Dk7J/vEfn93mr/PNrwylld3Zyo3qR6+0JCht5913ofme5h1PPONzg1ARwJnp+cRldhjmAtL1RTVWVWnVfdi81zNxRRtI18v2cneecnJuiRp61tB83ybMsDX2xc4GKCGGNmcge7jzP0BGZ+Om4vpEL64Yk+peP3Aeq+xeD+0czJMl6H5bWCsQwaXTk9rhGR27lntPw9Oh8Z9p8SoPdQUL2VPNHuTfejxjqCFQE9FnXRVvPlvJYDX597J9d5rpsg6HXBE3gd5/ssc+mvuFsJ203bQjOLz9bA2XkMymvpr1LVozZhoRWyrTRNkhpqUKeAgdB31Ct53dus8VtMm8dfKg7x6mNlVpaqz7g2t9x8K9x5iw8e9F82K2ZPaZzHJsJGUVhpkD7zuvT+He3+IW3qbFeVZPL7hWrBLH606h4ldopxOXc8t9cfgtHM6jz/W59DNktK7OOvHbXFUWgHQZy25YN18TGyBT1nzK1RFzCVo7n5urcIGgnKaqkYAaNacUOFSqE+QvXu82abXzjiyGg53j419FtC2m3aX33AXfuv569jgyDPTaKueRAfdGeNc2XG7/RY3X+fbS+L+w+PWn6cWBoxfyh4odWgPktVnrcw7JZfjffJnMiMFVcqeyYeHeS1M5X93DXktPgqLoc03T2NVldjkuwaaoASIxLrPr4thNLnn0iVTZwIl1eQ1iUgtIiyB6TLa9WY2KtNgVYEofefhMF9DXbXaTL7nw1vo3nO9jaMiF68/ncZVdhOcpdFw9C/T4dkF12K1WVdPSNP5qfDvVavF6mvEtzTpFWVTNJ822JvnrFdtO5UQba3YbaAT7ZdLBYT0LzyoboXyGuhKMna3katvSEjsKexkHAeA1kZqWHACgql6jJLAOFBFB3ZYTaphvQvPPSZN5tTsV3cuXS6TNw6q5Rk/PL77g1vonne2mSaHWekfP4d+75lPENvJah4vIaW3zrZZJWdWWMdnjLNapNmAp00wf33XwxwBRzAKwKaz3WC0u2qKRueY8839C85rmyN2ituffTdqY/fbOhXVnD66CD8CnOm+YEU5F5gs2kCSCc2qGYBEd02aboWetuQcz6xtHOMovn+zyzhVUSLVu8lWwK2+S30swx7ZbNMDxkB3Z3rMboYjNim692Hd5FVzjd5lHwq/LysSdiobpVKz6PatSSKSScqZL5zpepX5LZ/ntHz6jzr0bz6hZI3iGo+7RF3sr+rYamc+cPoCis4vFTxxZXmVGGWZFQ+lZnYf70Xo3m1+/AzH1KSot6L525aZcHitjma4WX31T9RfDYrQZt5LL5PlCI4QDQFKtih9ZZfH1Xoa2qpQr4nLZcMdo3tnEUzlAVrns4yDCGDEgWhHBJP6dBLvo9PlNRzifn+/8APHLFC7SVNH0eu0oT+YastaTweiQLKjCcIy6eMuykusLCqi3BJYDyixsuIsABdKVLebVenkxPgYXvHiqOi+Gtz2fC9OKLUWAvB3Z01zPNH1MF6N54fPEDRuoMEzU6ejZ7aZ2KpZQ4Q0lDkDNYOwRrmBMt4NNWxpVFjMduWZP8g/iGXnm4wTFsjaqKajvOu0jRXBUa2M49HJTkGqs5a8pmimOhpYV75gevPoWhqOzZs1RzVNKSkYBL/wA9fob847Z92m2wfDfffAyKFuG07TjYKir1WYy0UiUyZqSpIU3o361gvuu5qarJWW8xBuKtqiVxbEq8Ny0FG1CV6EjI0W1uxOlyGqTWea+hedU1ov31WjGyonrlOyy8hfJHGI7HEiELSLLapkFEhlHHFqz3LG5RLZ0+yZATZIw+ieg8N9R8qxU+i+caEujr73G+n1qlUXXcULnSL4fYGtz8GD0iS/ArlPSFo+htxy0nQy5dwmANHxcENFkfiCH2V+wsqnBiQ1R1DajLRDbcpnGpj9Z3GtiIRgVKFsbx+n3aMozZJX0XlSDlhDB+xyxztpT8ixZ9CwzFqz3hHnh+hvPzV7P4fikYLnq0RlBlnez2jq0jetKCXDglrg3O8hNyapTRxqiKWFcZUPiyYAlGZGe42cUhFHRCcVJkYjaLlX1hzEPhleFXJwJ5DvMY958dZbSRgR99JKd7H4G2PPmS6dV5E7hzDulQubWX09JaOMp0LvzfP9Uy6TzD0rxU5DDn0sF2UyzLaLn5UVS3CQZqDcDNLsKpE64FhJh4VjYmVSo2+qtHrP6EK3N3RLNj/hpgSso4RwEkJjZ2i7a3pfQFUWlZIHxNWMJ0yO//xAAvEAACAgIBAwMDAwQDAQEAAAABAgADBBESBRMhIjEyEBQzIzRBBhUgJBZCREMw/9oACAEBAAEFAfovhFIEbjr+e4ONjbbR3Skf36VgnLyMi6vGpS7qHUbKehOIfu8NkarKpz+nW4uVmho6MlR4sr06xqskpVkd1rA/hfY/BDqW5daQve8ZnsiJqMeIWednwD5+nsqLqV0GAADN/N/I/wDwMMWNLvyv7f4P4+n/AFVSxI/Tb31qVHy++X9N0BcTrTl36XhpTVdWUb7dTTRvGzOu0lsfKptc2A9rtjlkMVwui0C0dXRRcibQjTW5VaBnucJUBCeUrXx7Rtsx8QemE7PgRFLEVea6l2sPvmfn/n6/x/gYYvu3vZ+Z/b6oPJOzANylAtdnhG9/JlOhOQZv6eYHA6mgoz8GxSt48LoVZR31fqe/7dd8LtdlflnM/wBn0vS4+Y7NcHtCWOXZKkUD1tY3kJFEdtt4AA3GbZSkkJVsrSBYiAL8YDP5yvF0/j6j66h+ijYYtvk3db6gaB2tf0xgJvUt3poPYeqV6n9PZgrt6tgi+vpeea5WVmXm0YqdNouuyf6hvJTK7tccOEx67LWt27d2qs2Xdy2wkLWkY8y5FSIuoo1HbX007xaC09CrSjWRtVMg7UrPhjyciaMzPz6mhNTX01PH0MP0cWRe6Hd9g27ncncWIpd7W5P9KfSNqXySpjankzj5CCVua26Z1arJru6ZVeo6Raso6MqPk5NGHXktfdfls/cb1Cr4338imMXY1iuebXtbjFARfNjosawCKjNF4xENgZl49pnKeYWRSOTNWhaEQe5PnKPK7R3xmjDPM8zRmzPM0YfcN+paQpqTU4wr54xDxWe8rq2zAbo13H8s3stJhrIA+mMxCYvXbaF/5VLP6gybw1rNk5REy19VKNFqZx2vNdNdaZhFtlg7KKkfdhGO2hWN2a1KkDRrOVSVqlZVrAbdjhqL8ap4DNeiizMBFlrGC1p3p34bfHdE7uh3RDYJ3FhsELrHMZg9nIbZx9CYTtOAi+JWqqLdTHPrb5N8a/hZ8Fbf0qP6fbHGum55XX2lttCXNW7mrHHLGxu891QmLheOoHtHtV0V2gu+xryDUrMNrXLjFQEAlnqCLUPjbZtE0AzRrlUNmHT237Z6tnJMZ7Ghdtta07z771s7rCCy0nkwnMk7YRVZia24tVwrp1oe9ntDNj6U1iJYz2275Ya+q9dFvjR+N/in0qMJ8VfG86Wyys3Yw51ohYpxrSitTMvLrx6Wzk55OVbe2vSD4AJNmlG468wV2tde499SKbiY1oE+43GeyNbTGybDC05zlOR+mpxaaEHuQZ6dKLDO2xKVcGYDt5OgK4PlZ7fz9K03FdVFZ1Y3k4z8HYtbD8abgA901qHlKAEBuLGl+QuO6xUl1yKqJT6AL0U3dStmezNX7w65njFAg/Javp0ssbx3UEtzA53YYSuyyrN2PDTWIRUJ6foi8i6gV8ZwOuMAWcGIrq7kWumcqRGv9PLziasyGP6eX7r4dfd/YefoQIHIlH5Neo/EDxRZwxqgOGPVuON2YHTVLD+nq4P6fTX/AB5SuT0Ba6bKqFrr4oO4SWL8vPP0tMwhqAP03Xb61NKIb1525Bnd5TmTG1yLtNbChd2MFcWvCXM4wDZvo4QAibPbQWaFbEFaVHdQDvkCsEx+mJWO2TYmMxhx3D4VAS6x1C22921F9I929hHlHSldP7GkbowWZuKMeFvSh9A/CnjHo7naXl3uk44c5d/2tdXUe8BkWTOywtGRSCnb1K083KQwU8FrEzFHZ2dWOATkcp3OQd6yBtZyRY14ncJlADxkAaixKWsPcdfcIkTFttArblleanXjOP6AtYnmxj1NoUztDvqpEa3LuFT9sjvMWruDU1oLb9dqleMMEb4CNMNB2Er3LKp15IV0mNQHp1xX/wAlZbjWP1ekZNVa5NuHlpTRhVTWPyzvs7KUte2ntkypfXd+RrU43dRqol/VO6FyUaU9Mysi2/ofU1DYGYqHFylPYzGj0WqQjcUG4K9zSBq6nsi4LhK0Berp9AWtPJ8XZqharPY/t013a0MSqCsQCsHkstuBJ5mLyhrr1UgDW77Xtkfysf4iPOn0I2NVRWhtx0I/qVER66O89Va46vURlP4w0bQ5NMfJvQJ1O5p97eFPVLQz5txr6feGra5REtPLi9lvaZKbCzP/ADxM6VkWKlAysirMvGI46u/MdbyxMnLyLilljV17lFPMZNKLj9NHodP0axqyt2VO/Qk4k23ZLuGfcff2ygmwF9JZZtV2bCO+uBYYvTUMZeD1jx7iv5W/hu8XH3Hux8CPMPqNaVp1aiW9Wp113KW+Ylhrrwsdaj06/HbKySOzXDFsMBKJstFP6d2LfXRjMiynuM1eBll8bp2BRV1rqeJdiWncpxxYiIQek4JedMNwxut4TNXlYt1JBjcuKAgVzGZRXk2I9GJeaE+/teDfJr3YFl+hqZpZWKpmecakbvxq1ePQqV4o9YTeSPdjxVyWvR2aHlwxh+rYCaHO0cDkB5YDisf2YeARrDQO9lX61dbcct37mGQt78Wf4tuDcRGYihVmJxe7LxBYiUOzNgIZj/c1vkq9RfHW1cmj7fJqrCK/idJTj0XAasy3OTFnU8tsmzsVzNrc1PYjUiIZv0o1rCjFZo42MXpQdE6egi1qOoXBBXluWXPH6GP+4wtbcF0oQo9f5h7uN1uQ19Q9JA7VA/Uf8OQhUggke7/Eez+zEymsWzygwsIvZ9iiNm/usYP338ZBPGwtKaauC9qtMYrnZmZTiYN/91zDE6nYKuk29zKs/e5bc72tWgdWyq8rL3zFJ5WtdRV00dxrT01ra6OjqY6du1rry2ZQK1rTZRWldehXrjjDxqYmA4wGRw1jmvqDWWMuYpWZ/wC3xv3GECWPJlNgQizhkjMx4MzHjAq6K/HgSKKwrnXas+TfL+X+Ij+3Es1StW9JWyYtoV773c2C1Dj8u/YCMkKpyLVUPWzlV5kYbmm23lk5HDTrVOjrrLu8Zefl0V25/UbLz5lblDe4c9P60j4VQ/26gjLbqILDmceA6kp4J74t1QW++pqemgGq0Ds/xi9Qb7TIt7Rvs/3VsNi3MtlF9ptxcf8AcYHzQbU1qt4/eO3C7pvUWC5L8rAFEHyX5a/Te1SxO5/L/ARvbplam/McHIHfCY+sSg57k3W32tjowe79yK+5kW0mk173XyMqrbnQGNzj1hTpOajHSxz1nN+5zPrqCdNua1qm8pWzDIZ6s1lczqXwX50+/wDHTPw2/gb2wfK9YQjGt/cIeFS2G2j/AMWN+4xp7K5ByFx7O7eB3ungiq73/ULCq8nVgZ/ZDtp/L/ER/bpWAMfK/qmnEXM5AzvO+RlBFb1b6bWLMi86uqPHLutayMgrrpi+Ww/zFPUtNrzXAW3djDsHCuD6MIs6Sf8AYpPqo+GUf91HYHJ3yT8lXy/jpn4bPwN7YP4Oqhe1Z+4yS/CmzVtg44uN+4xjqckYL+4TLT7d8dntsVgr1nuVjyPZuXKzfZSqOQrcxGcEbjGZoBw822q3Gw9BsoE3v5Cr+h0rxkZIP3Pj7ripNw/TUhK8LIpfIx9d0D09GJNnVWX73O1/a7dk/wAj6H2XYnSzrOrI5W5BoxEyS9/bYte7JFubuAHvn49N/DYT2G9ulrbYf6iAEP5uIsW6iyqWsHxcb9xiqWNOwRcrWtZwyXz+a1Xh8lvy1+2/Ty2D5oI4m78ywzUb2pzhdiEjt4x1N1s5/Gn4cVtNlMyAeLEHi/8AFZ+2xvni+ybI6Zum/JsTv57hulWnlbF+o+OC2s4MqS/qVVhVf1L+pMFF51gsveosD5RY8unfhsP6B9sC6ymu/Ie67K8ZmH+XJq/Q/wDFjeL67DWEPIV7L3Nq/ppsNw9z+UBoFeJ8SdVufXb+UQwH6PZwCEtK2ClnGj+NP29DTLO6R5ZlCVX/AIiN0U+lsf26dWDKayl92K3O+3XRiujF9vp/0B42dTI+ywqSaTWKsL+bD6qm4WeQa33MCxVx2dHob2wieyjMWyNtnYyOrZp4JaAMXHA77H9LDXVK4+zka76P2jh9QcQHlYID4Qjj/wBTsNb+UQxTCYnrdARF1D6m0dVHWPR8ckfoDw1+jXfrtaXtKic+CquK/Fa3ex82rJ4PW56TdvuQfUfFpmO7dPptrB6i/wDrH3eCZA0lTerGZvtqjdpphfiVvXYdZy/jzfz2fs6CBdUqPXWiqNbLY9Tn7SmfaVbqUADlwr57E/6P87PyD2MEMqrZmTxTUm2tH6wHj/zY/tlfiI82/t8k/ppxNSaD2a4JcKlwaLe/1TM7EwOqXXNcCLP8B7N8VptyunUqN5dQCN7n2Htd7I/qpy3RacxnDalOW9cfJusVvF+NaLXym3kPv7Sv52fBZWx7tzut/dun3F4mMd1BTrgZw4r/APOz8lv5B7T+YuBdWcmhlRq2rqdAIq1mc+QoPjJIKN732r2uTRfNSeXf4XfEZq43T7Lqr507avkD6D3+gjfDptlv2NJ/2cz5t7we291V/LFYlq6U4Y+MtsbERRSncVsW3liq1LXlnN/4afzXeyxPFmQf9nzxmH3O0h2vmWeF/wDnYPXb819j7cp/NfUWUZGXS8ts3Wz1NDWjxV4Rfnka4urCcPTWOTGziiMeW5avKJjq2JkYdCUYWM/9vy09MI+oh+PSruOLQq9nL/Ofovx5W8qa258XldtdKlrFUY+ReOGQlX3NqHJuAo3qi1SuPR+a+CKfVed26gI44uQElBCqplvw9lt+dvzX6H5QpZGqbfqWFUaeRObRbJe4ZGJnqapFKudFhwBqtDR1cl79r9uWbEqNV3XF1euPYTahRh9B8wBrExUSpwtaZH7lgQZjY54lasGX3d1wCTh9MYNxwZfm0JWc64E5ttgosWyZNAqxcrj2Kvy3DwIn5L3XveBNblCVao0INasA4Ey38ln5BAdFyC24HXQ7RnGjiyVwaE7VbQ1iZAUJKQHhVtcQJ6Zj6Z6Kx9phIXyMgZFQXqbl+o3Ndb3UMvYMw+ns1NYsfH5HCXLpul5AyLEsd/YrmWMuTdZdGqHHAeiinJtyLLizIDZVO+oHddkp2bsy+vs3v3MWr8lu9CL+W9AL57nGya0XG2yr5V/i/wAbvnb89z+W94LLN83I0+irTi84vFJ32K7CcGwE41iwFgDuFCZSWRq8gfadNqZMjNzK66AUGNktxf3+mvo/tvzTlERsVWYY4W2pKeGciK/A9zIw8prbMPIQ+pYassJcngI5PFBKjuO1xNj1fb73h0/lu+iKRZbxLeCSUM8TFLRDH+L/AIrvnb85/J+grHLgYfCzU1As7e4quIljwfbxft4WxxLba+VuY0TLqaIEaIHE6sT3bBxX6t7IfSK6nTjVQVJd7aipexSiEWXN4mY1iqz3pdfeXlpJBMqrvsNeEyk2iuq2koB+2p/Jf7AGICWba2P8W2DSo1icuK+A3wJ3Vd87flP5M9yttQn3KAd9ZySFhOZitBaQVubiLTBsxVgBM+3Rp/bwY/R+UfpuRXC2cldvcY3A7/wrPpw61tltdQZjSLLNFrV5rjBzZdMutsgv07KBuRqymO16miwGrLCVZFqNal3GXXM6/wDlr+d3sDqVH9W31XNoPKuXGjyEZQH+J/Hb87flP5Mx052q+PBZiR7sfRuQzueQ7aV7AFNmtWMC5SU5FThCsDoILkEW5CO7xC5dTKVxWFvT8a0dVQUZXJptuPcacnik79pip3KGFOlA5ueEGRarHqTuMS+yts/ItortdnOHYtYsYNZUwFuRQTXwYyxSA41h/wAilrV+1vArRluuRzb548NwLqnH78WzIULbzHtW9lXK3RafyZjgBOJnB9aaHc9UG9K4gdYlg2thMKKxB0UJgfUXIiWI0UUmGioizFp11b99MejuYx1sRRuMPGMzIX5sfXvh442T0qa7HneQxqcN4GKmxbbSlIVUsQ4e5YjurI5x+y8oY1omRTx5oxrpVXurMfWmJXGxGUr6YdcH+Fg8H/ANwr3AYvAxuM94sBIg8FdxXMUkTu2CcZzM1j3T7Rw1eOdirR1udUO8/c+1evoRHn2iwN47jJWbccxLJkduknJrgyOU7VjhNIU7hYqDPSZrU5sJ3DOaz3mp6xOTzxyqvKvfLTG84mL7kiA7QqzQsTN7Gx9AfNnisAMPG/BgbwH8ag8QCDiSo0VZuAZgE4RUQzsV8qbbkFluTwq6pmNEzr2GcxfLlt/c6D7fRkeua8tW/wBilqEHsNLcLk3YXZpANCrvstpljr3AcZ9svGcgIdPNKJ5nmbM5gTmYC0fMrYOzsQlhWsWVk3XFarOS0n1Px7n1X5X/AB2dnyRrQ4zQnsBA24GXS8diyB2nK2d64QWZGvuchRXmWiLltzOW7nN/cSp7DgQDZ4XTVrSxMjjWuQKj9wZ/s77uS0AUwc5q6C29QuWhnOliAePBNNQhgoeEagULC3j3+os3O60Ns7p0cgwZLCCwibZjxM4zQ+lzHjoTSz0zxATNieNgDWogaaDDQ2qrtVBigRdRKqzAqlmro49WUJ1CU2capRvvfe87GHMOodXEblOPn1TzOMIP+Hq5Cy2G7yChm2KP2yeCzhYs1xLrYx9psTzODGcBOKzxNn/Day8T069OyVmwJ7wECb3AZo7AsIQ5Ai/dEKcnkoydgXCdpirV2q9RrKChQeofvJSn+lKiFtexHTVG2dRGZBLLap3kMNk5CBjsNuMRrlDYsFtZg9zxELV7GuPes13htq1MdXSNon1LOKzjODQq08TX+HmcTLtGv2+ntPY+INTn55Tl452b7lgHcyVi2ZML5gNT3gUtYGq7JFWNhbXGx517AxqXegAK1laBdsQVNWZYkqVbKNFBdY/I5Op9ypPKcoDOQEJnFZwEK6nI75QkGeNLoH0mc7ArWsR3U16TLPQvenfOg3Odny1Tj6bMDznOXmzyn88BOGpxngTXnxB5IgLGb3O5asNt4bv3xjeR3LRBYhmNk8Ety6COp5LXOXJgoZhwi1gz+2UcKqEpqftzkAHbyVUgq4M9crDtLeYbndN3TdnJ/A3uHc9U209UWeZ4M4Ax0Yr2mnbeJyEDLBxh3vghnaWdp4VIm/T/AP/EAEAQAAEDAgMGAgcGBAYCAwAAAAEAAhEhMQMSQRAiUWFxgTKRBBMgQnKhsSMzUmLB0XOCkvAUMGODouEkUzSy8f/aAAgBAQAGPwHYXewENpQb7oqUROVjBWPoEWYP2eHy/uqn/F4ubkUHYs4jPxgbw/dFroMjsQU/KaRLZWEHXlMrITIOqeeSE1JbRqJxfwoRwTtlUQKu4BZiY5KX1Uwualc1HmoUDZapUu8kQKJvw/5hTeqb8KHshu2AmIbSn4mpK9G9GafEcx6lNaBojEVUXosTA93xs6G4TcQCrSg4wITKphFDKxA5kUuvWPNgmx+AoClk5QKu4BS45RwGylggpOyFKgbABqr5oXRHvsHwhH/KHXYzqv5UPY6VROyAnnksNDaYWXg4r0R8bogeRQW7dALBA0wnynZrwnJnVM6pwPD9EN02unQc275JpOVojiozuPyCqp00QYO6A2RptgJ00QDRVNAru1Tvi/sI12jp+v8AmGeCZETK34tCG2SubtpKeOKaCLbSJRXqnGj/AKo/I81/h/SDleOOq8QRe/E6BYnpOK2C+w/C0JuAx0alNGe6ZJlNIFBqmtjN9Fke4OcBbQJ7g2aQgXGeAUm5WUWXNSblc1A2W6K/VUEAW4nYxovxWZ13aalZnIfhUbG/Cif8oJuWbJubinSROb6K20LptqmwmjZGwoEFNw8SA/6rwghQzHx2jgHyg90ud+J5zFETLjYLEecW5TM2hTJXJDK8mOCMdXFGbBZtNFlF1JWY20UnsqXUkwjCaToalbvh+qDnUCyso0e8rSagLMbodiqLMdk8kR7A9pqZzCaeqE+wTtCdXZiFBTKmUdlE0Od/Uvup7pwZDI7lEuJJy6piw4qmktWZxogAFz1Xq8OwupI6BZnaqADGqFuiOYyE2BCaCnaNWVlvqg59zZCaNWTDtUSh1QC6lFcawnhtUHFruWirmle8tZ6I38lf5Kh+Sv8ALZdCquEHDRC8BWPkrnaBCsoCCPXZidEEEUduYrgEamq/lTH4luCzHso90XKhtgszhVDDZ43fJT5rPiGODVRuuqw2tHZGaVXZAqttSi0UAW6JWZ9f0UWb9VOkpvJXF0ctTNIWaA2lJT5cXnQ6Stxobb5KrpXiKq9TNVcKn0Vm+SJ3fJWB7InK1CjaoiG3Tp/CndVPtZkORTkV22BOR2AbZnVEk+4moNCGG3uVmPZElwTsTxvOuiaCacAgJ95ET7yaRxUcEeiaAgM26gTRsVX0QJ8kS5y3Wk/shnxGtg96o1c4xSeKEQ0RFFUk+xfZeNkQpLlzVGqCU0zqgeYXkndjsHUexKyC5R6pxXVYhFmhd0GwiI2UBWYiV4NsxTKoCnUoSZUNGUKSZ2NTRzW9+JDghWK1UmvWyaB3QJsNFAtyXhDepW9iE8hzW7hi9zVQXOjlwWq081RqsFHJNdx2TlXiRVl4gjLlRsoigVJQaRoZ7IdU0ck/lA2eSO0gKU7qipWIzL41jGFnUDUpjSBJX/Smnkpp5Jz5sOCdF5QVEySp0CaU6NjRGiYOIW9xQUSBW11MTzNF4vIIuy/1FeIjoIVYUQCiGhUoquJ2RKYRqFIld14QoL6FcSt1qyghEWQoTLQQnjg5eEpsRWnkn1qJUTqE3JoAEfZaYCsFZNjUopwTOixkYTOoQc4+FDEeTEgUUYbHnsP3QGR3yTvWh0HkvWNs51NrKLqgOCcoQI4IBslGXAVQALisub5LxBUJVE/M6sIjNMImJkQiYhQhUnoixuF3KeLZQVgnLF0UTrKDZKosOt2ArVPgUBWnYJofiOMC0rGbrmEQt3D7kprnPa2ZFOazeuzOylRFU4AWcnxsO1nRUVUzqnLHedBRYTeSxOqiaJlfeCOcwsj8SkzdQzHcP5l98Z6p04mYgUElBvuh1NhCYjKAgqGjzogHEsX2IaQGgyTIKc+GAcAs+QQTC8Ck4RKOZhCJgwrK6tK3GJ73OsLJvNyaWt0Vl6X/ADL0cAaJxldx9FXigro3U0ViUCzCgBNIAq+qMvdHlqhu3RvbimfEE8cQ0p2w7AsGTdGETKwotKdwWW7nWaoP4ao/ErbLhGg8lMtCgGegT5IFFHBQnGym6fiPaYaJsi58112SvSMMOg5MzShmx3vQwnMcTEwvuhHBfdshPc6Kp7SaAKiDinENATlifCmfGm2FFvYoXpB0cTBTGvIBbSERMqecfJEc02g//F4lqTKe0Cub6qr2/Vbzz2TmjR5A2MlHorGjgmHoPMJ3ssbNuaq9UcmVW6Jc4wFi42O/eAlPxcXg5QNcQo7ZBqSt5xKIF5TXvPiVzVbjPNS4Njkm4jyDS5KxvRcIG2abCi+izEm9kRlpC9MxqAMwSAOblhtZAk3WG9svxM0IF+GWnnstRP6IoSQnNaZKIyyUW0A1XcwhOIT3Q6bJLfkm4hbYhMMRJXdAHTNdOtdT+VOP+o3YXRZYxLSPtbHRENaKHUpm8B0RzPJ3V5Jpud1O2H2AndEWpjbQUW5zW6FNE1hF5Ttuq3gUBl1CDiJyiyacPCDGg6rMcY59ITcN+M6SQmgGaIzBBEFYmDiCxoVAWq9MxdX5vkFh+6EcQjOLLCDmUNVDWhQ0UCcctY20FVwTnT4aofGUx1aoSxPahBN1it4OCYv5ijIPvLKFWLJ/8QbHji1yxHcXygmfGfoj8K7hUFDlPREhBH2Gg8U5mE2nFVuhJ0WJHFMWF0KeealMMXRcI3Uxh3Q5Pa3FlzSiBiU6JzXSXeSZJJPNA/mamAGzZTnueMphOxGAUiOYCzMPZMZiYjWBxjMRKPo2HJhkTCZhCITGufu8AnF2JQOWIxnulQ3wymkaiqPRGikhNnisbLTdTPjKwHjE90GERS6xNSgHMgSnyRWCPNMXcrz+qdlFc0U5IOPROGnrAjvIbx8lij8OIR5Ib+nBBsuMVRMVylU4hDoEUEdoAElQ8WUgwAnFqfBUObW6asOeaM2lGLLxGinMa8013BYmIV22NRdNMwXrS6gZHVZZhos0WGynkmkWT/RfSfHkjDfx5FM6IZnwv5ysZjIkg3WXgUyvursqwi1oqvCDVYhgDdTP4hWFh5tLJrnu8YlOeKqosszmwZp0Ck3DoXcr+r6p1Y+0KYKkEar/AHQjlApEUTnFjH1povSXf6jkJlQBEhT1X96JsA+EIFBHbmImFiUjSFla4gFHPWUcjVmcsNx4rDRbzUZZon00QCunhDognOY4gheiZ65j5rGy/d4ctZ9PYOxma7aJoTiI8RT4NZKEaVKZ8KHRFBHqsT4Uz4ym8mr0ZwvAHyVfwhOdyKcTey/nK7lef1XLPKw4Xro3PXgd07ojN8y9I/i/sjEXuVOcU5Iy8mvBN6O+ib02D2ML1kZX6pnqYozfjRANvKDMQ0CAYuSh1gEzjK7rEhdk1BYqBW4wlYjXCDwWDii7cMkf0pjdXbxRHsuHKU1O+IrF6lGNViyTGiHRFBHqsX4Uz4ygvRd+N1dgmMbYmpUe6RCI/wBQruV/UnQRZYfQL/D+/wD4ue0BF2YLJhANlYkutiHuVF6rw3aCEBTj8l5JpJmWhRCsVrtBF4TAwVb4qRVTzWIUDKbxKeeSZ8S/mWPWyb0TXFDPaCseLSYTU9lIWMBoAsKbZU0m5ExsO0dEB+UpqxXtiQTEozgNLnVJlCwngnANF7lNbSDyTs10F3WL8KZ8ZTGxu3WCOqb8IRZME26ohzY5oO/NXqu5WUCpDoTp0CaQD4U50TGJMJjmAjim5Q6YrwCx/wCI5E63UL4aDyXkmj8oR9lzTcBYg/Nsxs34UExPQcNSmk8VjnRDohsxSmgXTxFYWL6zDkkrK0Gw+ZR4Cg9liwDxdH6IE2TsI+j+shxhSwZQLoYeGKt95b/iTi4S6KKSERpK7rE+FM+MpmI3pCBIkdLJ8BGnuWWIA6amOyZ8ZXcoOHP6rFpSCuENWJ8ZVCImuzH/AIjkAHRTgvvD5BE8/wBEJOoXYfTYUNu6bhFqMpxFygmpyZ1TeqxQOSHRNGzEWc+6ji5gZWNimDmMrFZkmYA6z7QWG7gZTinu96E6amJ2XmiY4cE4gxBQW8aSsQs4JnxlMWWGWT4FU6kbiwAObgo/1Su5Xn9U91a0TCHRTVYnxn6IFju4TfWuzA/JekHTOYQp7oUc08aiPovJRsKG2pTyFJRRQlOqm/Eh1TyOATZOiYC6E2H6p0J1aQmsY90rDDHG9V6Qwtq0T5GV2+XtNXo1aFrZ8k30es5US2xps7JqtrKCdCJrUbyb8ZTKSm5mZRCdCceVFhtdZv7JnxlTzchmjVNy0rxQqVmIO8ZNVEFG6fycUIvkCObsnn+7Idl5bRtonF1yUTpKdBV1hpyZ8Suj0TKqugTUFXVNxCN0rdfWbI4DmznBBPVOGoEH2mr0YYY8MhNBAzRCwsM+GSjsb0TddwLooFll4pvxFAA2UElZs1QAoi1fJB+gaSU2f/aUepWH3+uxkH3gngPNHqc7onivvXIzz+iG8ozFOrMn9E3qF2H09qczTTmgDHkndUJqSNkCwRTOuwN1IVSnRwTSgmJr9YsnYj7lYmINAsQ8YJ2Hb3XdfZiS15noUD+UplaQSj1RTUw8o2AZQUPs6qc4mTREuxGjqpZZE5ZRLmwMpqnR+UE/Nf7zl3KZ3+uxnULH45k0HmVZVDY+a6bD/eib1C7D2oxCVRxKghCioUQVU0WGG8dmc6BALJqmoJolYNBMLGOUSViFrd8lVEGKjp7LtnpTeBBQfxKc0G2HTYUFlb5Lwh3Wik47GwVJ9ILp1Ryv6QITnNBdFymwHgg2ATScw4iybUy60rHc1x8dk0EyfWFDqUzv9djOoWMc07xvqmz8tEZnqjhZDmhMgzqiroSNRCHwt+i7lH2NdtPYw4V1llBGqB2AgUXorWP0qoc+6YA+k2T4F5Vd1RM7T0Rqmuzk+u3SCKUWHhjSVaJYQoKKGK9u6LDiji4rc+I424Jzg0CUGtEk8FnxuwRjeI7otAg6RRD7Qoh2HnHMIsxclLApwY0RNTN0zL+Ndymd9jPiCxTSrzzUZkadk13rBmrLTqF2FNm9z+iBPKF/KNhQ2iVU7KKCJC3djMuyM0FTf2MQ8kwDgvWhoOULDdkF1mIihITpoUIFtrUGOsZleizE4Li1wRdmggLCecRpErFflkB19jcN1QDRepffiAoZFJrN0S5m/wDVPJe7LpCIkN5LioDU48CmTxCcy7qLCcNXruUzvsaPzBYtLONEDrqpp0CcHEWMKorooXn9EznCFfdbtG2wXhCt7G8FR0KlVVqiF4VZWT2QZITC+lE9uaSRAQwgx+ebqoq0KTx9gKRqFvGGuY2erRlQyOosJprN1i4ZMAlNDbQsPnCz4dJgXqnZmHlqtQmkl2UiiwzNS1RlVXdgntA0nyQABANoGiexpoI7uWH/ABF5pnf67GyNa8ViEOJrRQdEelUGsrQkzxQma2BUI9D9E3qEPgG0bQC8LxIGfYtsoSt5srew19xK/wDjlNOHgdU2MEthCUCAFcJ83IasNvf2Wngi71wgY0cN12qB9c1wKZ9oG7pqnb081hiDRejUIqO6aeBXouV8Zv1Xq34bX0lUkN0CwDPuXVEMrCeyJcQCmtBkhsAqSdV/uLuUzv8AXYBxWI2Duz/ZTSqp3WOUJgPYqqcI90odQh8Ldo2BeAKPVtXgFlZWVl4V4F92V4ChLVyUKrVuuVgvs3otODmP4k0v8UiU2nslPwyQC5u7PFMO7BaCYRyslsIANMBqw8o6r0ZmTwuumCOKwWsBzZCWxog8Y4L8vyRY66wg0ijERRYbS4CmicQSQUYaiCAm/wARdymdP12YfxBYwJpnKIiWwhRNi2b5qtTAPkrIwfdcu4Q+EbRsbNgarelVBUBhlCGRReFaKYF1ZajogYc4K8daFWX3bkfsn2X3bhKJg0XgzaWWrSpyNdHmjhYfhAFDxK0TjSkLRXUE0lELeyw0xzUNqUAW/upiiDg0QOKDjhiW80/ELZb6s5O6wmjGDy8X4LM41KaXH3E4gmpTardYYBJnkVZVWBzcvNAg2CG5Kw5aRvBYrspj1hqoiOapwWYGoP6KQW91XCaehWIMhByG6HVA5h4QqHYNn5nbKKqsdniVSVcqJKEOiiGdzT2XVQCqb3dQYBUB6urmvNDexOxXpN/HAm+z0t34MpVNrHdj1CAnxMDv0Wb1YFdAjos293VwjJ8gvs5AHFb7Q7ouHyW5FyKqXR2Tjl3pEItLhmyRCsUAGG6wmxUFdyocwnmEJkdQhDgUYLhmuAdUd5/mtU0CxzFZddmJ8BTeqCHT2MQjgArr7xb2KR0CGV0jpslD5IiVp0QNx9FIb/2qMnipBaDwTc2Q1VRkdpVEmesVVTX6qcrj1C8Dx0XpP8Q7HYpp6zFaf5bBW2BOHkvQMQ5XBrcuVw0dzU+qewz7u81FuFi4R/4u+ac17odwurE/JWAEaqQwRxDpUObJ4WUCMOmtETA6xtha7aRsupLQSm7z78ZRRWH3CZ32YvwFADQbBtHVN5klREO05oZZ6KcpQhBN+SE5lqVO/Va3QpNpUHDJ7o/YnzVcF3ZyoMRusTRZZxacwSnFmK4QNWL7y/5V43eQWOTriOOzCGarS1vkUdkPYWk8VZZYIcMMU5iqznCaS8Colv0VTll1nCRHULM3DkGu6ZotVQkjjCqSFR4fyKh7XCDx/dAF9BZvhW7Mcb/RHemuyu261VlYea+8wwr1RqFGaiEOXhaVjCCPsyg7mnRafYCZ8K8VhRTmg8lBcY4KIQopjW6oTxjonXqhum0L7v6qRhCeiB9WBT8Kn1c1/ChLf+NV4T2aiMhsKQqNtpl/dF3qqm+41NnK34WNWNzeeWz0jDzHK1zXR12AcVHraAfgC3cYwOLE6cfT8CZGIKMFC1RnZ/Sgc7R2hNz+rfHFDdLeJDv3VXxGsSVDMQOVQSCNFVh5wF447fspkEHo5QWeR/dUfHxD9lIrT3aqOU8FW+wURAFOC8IVMqu1XavGvESnRNRBQR2X2gdFFUd1eELwgcl+mzgug6qRPK4VXO80JBEO4/VCZPa6mtka1JUnTzqo9X8uCo11uCF/KQe63mj+mF6S0f8AtOz0lv4mAf8AIbMOk74p3RY/ADHfgc/Ke3FWE9U5vn0RtRUN14zZXVdlVQqy7cVcLxU4LwtpzVTrqLeSvItfN8kJw29t1Hfc06yJVMruhUvkcl+WdFbZQKqvst7JhnzXktVqhRT6sKy5qIV4P7LopE+ao486rxuppKG/80Z/+y/We6ml+Mea3bD80pjXOawyOR71UjHc/wDmWPFs52elPPFgHnswyTZwUHEcRzg/ooDGxxQEuRIdXqhJAAXOFF6eSE+x+ysrwpMGVHAqluZUwgLjzW9hC+hhCHROjv3XUcZXhA6KDKsV4vkvEqha+1JTHT2UEXVlZfqv7oo8lObuqHVTL+qaWt1+aMM7zCtb9VHKaozkkclv4gFYKH/kW1hfavn+5Ticdk2vHZGMaOWcLC9XlBcCXGboQa6ysTDDtx1xooLlB0UFrHCNbprvUBnAKBrx4rE+yn5URztIPBeMiV41e6uVbZovdVFw2xWF70KypbzTZY2OSue9UbHv+6mCrKICq53ZeP5rw/rttssqWlDioGyaIW/72GgtVeFvBTAp+qgDMSIiEPs6fCvu2isqfVwdBGiAyCl510QMNCMsw7UOUfqm72EDxyGE3NhsjSGaeSgejYc8IFOeiE4bRBNA2Aokx1RcDQarqh1QdvVWTeMGpPNFsD91QmTrdRf9uio0eSuFQhaKJrVRSeF1Ay9YVWt8lBGGqXiq1HsWEK8LRV/daICVZeErw+aqCOlUMrh9FUTXWq8B7KjvNUr0VQoX/8QAJhABAAICAgICAwADAQEAAAAAAQARITFBUWFxgZEQobHB0fDx4f/aAAgBAQABPxD8fpRAA5W1iRR5lDtRKhpcblmqsQRUQL8yxZeo6jREeU6+y8eRlkPOYny7UyYObTCwB6x9oYEHw9pnkDxBo7pRxMkDsiVe0sTMWRrGI1Nm38jHhgGFfPgj2AWAxDCHWLZGIfEJXpFLd0FceNgig2GAIQwiz37UF5R9qjH/APRlmUwsqv2MDgxHpk4sceIoHrwgsAJXDwYbSlQ5Y3HWOoXWsv4xVy/E9JnT2zcWGpex4xKHTn7Ud/kGYrtGff4xHjZmVD4Y7kAiQrMsujDMvPgxMtv2K0Q59AhgwbPURy4bM8X6ukqRn0n04ZR8SN0bP7Di9eotdLx8kLjaQnY2z7jHHJAulFbhtsWIHrLjmYV0S86YjzLbNEaDoI2/qMAIQWcuoxZGUO7YMWcLcEPPIvRrqUHUASxReDKKHrUxWBiA7/DxG2Didlx/HKaDwmBbxgfw6yzqVF3+DMu8RaN2j+EpsnNC0Pw2Okh8MCKzqIiLmBlZIi+5ZRMkJRdTuK+F1Oea/VoixYUf0mUKKTh/Z+ig6MLY+UslKjBo1GEK03RlAqxNto0d00ElSDBbBVShp4l2zfoQUGAAcEqg4RtPLLFsSsV4CXQx3ywbcY2ucTMEbL5hGANW63eEQ2qV1FTHb/ZXxthppzftTn7gUPxj8DBLLfy0ZuvcoGCiOQ6VOrImwhdGprLv8LU44O4kXs/X5rUFwxJDNJpUrzGUlqFCUBxHtDR6Tz5nphq5jjoexigbiWouDyr0ERccH3pHtlvNYvglk73psmIMBK6b2rUCbCPj5sBLgA/wgUkaOAlyYYkuc0OcA58sMYtaPMYOeThvaVubmG7YMvAeUxugltBEVSpVqKanv0QhNIa6cPtiJe8TyLgFDLo9K4ivORUQQRuOKbhEE1WUXyMCNfgzWebWBdrCiYmTiWqaRxpwsY39lNSgWR5ZyS7IVgBvhMbPEp0wozcAbsMrLCtYEqVGLnmObLjtuQzDYqAhaBoDKmTH/CI2bK0kbOh8eZHme4ePSZIodUgH3CqDzQ9cEEJG0OWeC5vHglNpWBmNWMYJiMgOFwRhUDwCB3JguGEEscHWKLsjPgjjBRB0o/8AGEv1IG2vwlQAN+WIKNtG4xFYkiKYB7q5t9QWLS/J4mfAFH/AhEKXiiN3AZLsNwALtTwZlyhKKSBGnGJZZ25fUcA7gBDzF8MSs8y37m0V0lWY2ajKgS5bMBeHnWQR5dTJ7O/mXEo57lytMy/ZEG1W/LLhawRwVbDrwalhxxBbcEq0xwcx+FTh3EzwiMUDWX7IVoA3kgWD2YPNWarZvELcxErJVxFmUDnRHy+IaGF8gWglVxQy5Y6K985epQZGu5mZe2E54uRz4lrUBlhjJoA1FXfhqrIVVCh10RRtBf6lWSAzHAoV3Uer49MLVFT/AAIgrm59zSQ06QXPeJyePfiYY+J3KxUYKvLzmD1a0bSeeIYa2c0RdOQ+QgqFeyhNZlxeEOdXCbLHph/9yCpEc5wmIpWP0y0A1z4mBxQnvRilSLFEWH9UycF6KZeYAQLMBBNRVB5WCDQu2AcbvA16hQXmFgqZv+GSpFxK1TuL5imAhda+YTbFcxCu9SPxScCLRW/oReLnlgDwBHNgPohI7/Q7g2nynlgI40WUIpdLaX0ioClcJislecEKjm7Q6roag9wF+qDn/hVtm0JGjt7eiGgtrrohmzxAcwbMqwojZLYmglkEAD7jDvZtkeZmo7Fmd1cBR8vvNrLCDaFWm12xR3txATHqJoRI1wqFGDUbbS+CCm13nIq5aD6kHpW8pRI2B4GkCpTd0kKi9UCNTBDWxsuILdtgogHPVYiwzRqDgcFw2/lXRQ5ghWwuWtghdm5iL+IdQblY+2WZnF4gqEnrOZSQZqYA24yZqEYLMpV5zNg7BoE+ZlaeDTuBtNYO2HcL8rA8EKjdvUSo6RXlxFimUCGEZXsECNsDn4uZkUrnwRwaAu+/MqB3rc1yypjlMOWM8Aa4Erlu03qpYOObVMRZ1Uc2JA9ilggIHSzhGGtsXy3FfEbxRsCb39Z4EGux+keBWJxETvMVFRoZ7B+BMUx6iF2QzGBbm9sGg0mPzBSOz7pX6T7V0cL3GajXTB2Qn4lleHD1Fy0NxUy3F1OCLmlgptsBaBH8UB2XUxSvRDpTJs4l1ppzGbuAEBBFa/8AUQiTsEDQ9Byxi5WOZgKPBE+MqOoKoYMUYyo5g2iJoJfSLOzK1Bdbwi5ENtNV0SjfRwsAEoW0aQ3cQPKM8xmPHbg0PIiggRdo8kGG0BoWjeX2Wb8fpsbPBEDNBAehs/UGxmANO/RCxoNrA1bT0VN0K3jmIlOgbZYUwVbKabCjcF5/h/uWUbCnl+iZGjfqPAu3ayFWQwf6Sh7D6IABofMTlqNv7/qAodxKUYDiGAjpp4ZR9yfvx1HhjbZavVRTQ0YjkTqMAZAPmJ5KUsXXq9Ip/DhA21vSD4ZWqQxeVElCwYmma7mYGeJSFqOLgrLjpwg9BjAUDaXBBWRlBVxZguQia5RTKGgh20iPOvDLh7gRLDqBRrQaqYl88nPcZjid2kwwDDc0afgsCM0HuUHQuJURjJ7lioaq7ljFaIpK0G4BEAsW5644ZGtuIB4A4LlIYI5uIZaU4M+oMWSissSKzeKlIb2ybpyX9xNUufYmH5h9Ech8xay9hrGVjCra5fdxM3vjk/s73AUNRe3JBXEs+U+WKUVszERgncScHaoVXmLS0MtvS2WcNSs8wHA8ALmA4IwqH9hpQB4/2lOYqoD/ABlMEujwxqGI+dxEyuDfcULKtMHq+YBop5mkSmWXnKbqDTX0RbWOD1zkD6IwqztKQxxA8XF7MLTQjo6UWYyy3GOSiDZC39x6lrUPbGtu+CpUTGWtFc+ILlWcHwEoGiwgTqP0kAlmuoLof5lxEXFdqkd4UcMPIahGKY7IUUAFQAOibMbgHiO52RD6VYNIvnuoz0Qg3iWhWwprzLRmeUH+HtnGuo/0f2azUlg8I+pWACCUFZK7uybGGB5q4BTd1IYXubEMtqILaBedqS3qEQ4sEOIZTF1Z/wAQDqO0rKsUSoYWr9g0SjegSapDR4IEFTdYlkMuQ5fLCwW4JIT4Er3BenKw+o9t4rByoH2nZI8REwQe4Fokw7U3LgZMZZBLIaO5ZJUQcoq4QpdZPuB1urYXBHBPYMNAH+hEqE4q4aZ/wwAng/5DlsTWQujalIiVFcxda9AlEiU2hMKrgVdcWMvSnJAezqZAWlN5/srSmdFkgwKpsj6oPqmZ7fPyw/xir2n9mpMISMoJdgycxvi1goy0CkbGiK8n4IFbI0cCz5CUYLRRMVAgJZbZZHiY+l/uUr8Sn/candbR/wAxOuvlEyoBRBqq54iyUPMbCIDHBG2hupdBbNz5bApgGquYjgjUYMTFsRzK/nriY6KeEE7q3g5lQHjSoLUEDQSxjikVXDHMPIXqJZJfVASeVKQcIPuAC4OWLFK+4lAVvs5hMNcDFFCw8MDLKx+kHw2z9S00Woe4ahoHRF+vVf5EZ0rqs6TRT7iot+AEN1i6bqxzAs9r/WF4A3qXSU3jEPYa8xt7sT1C3sf8xoiJePBOEVTKRlq/cxyPzH6JRisfIuhgAGgj1CNQlwpGhIdFxgwxGoQ3x+COUn0iylGlsRPlPAuagLu0CCxS14zbm22tiblKzYgUqu7dBFTbhbX6CINkATCoKGbjQ0cXcH6JC0x13gcMWJy6GyOmJVZdtLC5EjFHiVModThCUYJLdLcUlAsoHZ4YZVxzAlFq2wXBugDJdLK0Lxef7ZWjZkE0xqpVieyDULV/4x2rSX2JSy7OjUqYdwXVfwIcsQmE0WjbGQKr3IDqFVFS4HERbkWV8ylQ77oCMQcr/Uzog2vdiFQAQ6/jYKISkC0yeL1WAiUMsp4USJuyXatLz3GTLKDnWGIUKtKTLVxZAQwAvRN4E4hoYKpXg4+E312HMJqK1ZUKlFZzQ+4JcN24YlnR0y25XClinLaR4ZtV4mEEYW7qVM0m3lhO7bBcAv1EUPMHShdsECXhKqwX6iyMDOFg7XwWapfUZv2LZlLLLG/mI8VeCKJGsZepQygHXqITFGyopNFI2zGMQUfH8JsgVYPZK1ojhcGpXHa+oR/78E3SvdgPdYh+Na+QZd5xZeOdnikCs1fiD/p2TuwvltmlZYpDVvEOE1RWI46jaFBhY6xG5LbCrWLMVmbChBpq7IETuGPLymHCPqLEJI6XW7qUKLrgwFxP3yOrlrIlwiXVDSACAG7qqWXOASMFG8PVwi1RbouFA3GFPMZcdza4Zu+MwH4i6Ehsyu1guRUUZ3s1VEabsAGMEMbhcheJt46jXEEkL/lBIuosUe9xBYOYaVqtqVX0dyOHl/eCkz6hiebWiEBYgcNwlhWIGbjKdRl7CBpbbu+JSSspfpLstLLUopezX+RAQMkXoAlz/Cyx2O0Vn+CjjAMKH9YU7FSmm3uoFkC5VYrx3Vx5sjq5/wBdR5Kq/wDcE95L/V/ZofhVGTAExe2FIAggQi6xH9LqipjmRnY3HZZcbNQSvbDp3CYKhgupQJTFFZlgaUpGs5jVL3aAI8QFwKJrEdexByW6n/HQDyxOUtvy4M5LtJzcRwok6NY8/TKFiyRmiEUCuInJiXQCosUZUfjEsZhwhyrdIPHYIPG2mpYWs9yuMxoi1/y5gx6kPSdDZrzAMQwnm4cQIPM03eS4NAspOa5j/wC3UK/D+EpduWbzLlIMK8w3SrEG/RK4NSwUSycUQGvomBgtaOFhoFxRP5UrfAJdu7mJRQ7eiCHRnCelawyeoB6gmirHHzGt/BGth1/ZhHgZjZ1OCOa7UKVGpoZCMSqeHKqw52u2I2LqsGInWGLrvmKG7ce6m0eJQYImaZR3xYPHu2Xkbgn+iLOFxIZsIXvJOYF6XANYaPz+GneqlNZfbHpyUyzpSIa5r2QLpbFxAbIo44WTDqsGXtx4oymV8DD9mHQco/8Ar5lOXCm9qPSmNQ4MLc4SIgptenTGgy/5/EJne/5Sl26yKevEVcqJU96+hF99OPEO+4yo5yz7RBJxmFiwDVQ67sMMtlUCqmNRk/dD2aG1m+YH9YxCL4/sU+iNlFYpolz7BRWKVB3RF0OpKbiSBeWo4KptHeZaHTADWTIqPnMqBXMMhSt1g3lqHTBl6uVXdkJsEw0QVNO1iIir2papfjbK+iiVmX+c8xKs2QD8hGO0IvbxG4yBaK4iY0mAzHMGPCC5L6pT8bKfNhv2Y1xef5gLcXjMWY02lKg3WaLIT0IIF3Fv86Yqhknn/wBdRsvH9EuCl4sFlUAk5XxiBbEaI5XNtMUdxFw2k4AMxnmP70RVlsDiyA2KK4azdg0tcH3iViiQj5liq8uM7liVg3iAQLY4h4TFHrKPIRoQdKmTjzK9F1JLxpxAoJe4Vu0huWqRMJFBWwErcSPbZYlDXc6wAhDU5moyt+Y64lieIyCkuOxGXGlVUX6ImvbdB0TMvPswm2MPKB7j/dLSsfFtBUOYOPyiL8hfygClUgZxFrAGQ5Su000VBB0veForeHm/9ZWPgJ8EY1lW91CMIb6kG69oe8umoAtv8gzP/rqAVIIPcCxKWcdQlGrCdqCDuqrWmW6kruiD45fo51wameCkq3uXqe3yWZei8qL+ZlDAJ9REEZ9zczQOYBMNwYTHukR4ajzcuWlrmLNFaX/iuYLWYNUVXhjWlwNg3ZYiHlMI19MdFrQyvYbgFlWCWq2IzsayatRjwUEwnQegnLKZ/HD6mbLLI0H2GDmh5QAeiJVXuAmuUV8ytTcZXLdSAavK3G5d6xQHGGL7xUSN85de8pq1/wCsFFWrPSQneKhwigg8EveWBrteINxuhWwRxH9TGWrRX+pvyN+YBBggRND+0GBnU4PgIabqgS8OYAwAhH/mxBmgO1xLX0QS3raX5uQAOXD5JUvTF7T+0Rn5ITiJYR7qWh8xaiXiwRiWSoiqG26GWDluJFB5EKCvw8u8IFQyahD0S0K6YIy6HVmLmaxQMYhIWBvVNRmtWxT+XOZsJ1CH01ccjYj4bnlyq+YZ0EqXiGeG0vLLAq1L7K4GAE4D8wzZZjsiKG2IKI1YMSW/5dyx0DCdpLXDnVaCMy0NFg4235WbSAxrD6YijqdHuSSmZfEuo1sL2CqozKrOJMbdmYVDKL7g8JZ/ISWsOFkDMZzHxUUbUvucpXuBvqop6xzHGvtNPhMEWJonYzUuXsgKWqluSeRhj/xrlAmoVvozjUwDCi4XoDhuDGy8skWnKPdYs6hYg3bDX08vE/cQOqLlroaoR88zd9zmDODxLJ6pHcH3yCQ2BZQxakVftKYpHHUvROiG4bC3PqXiJVMEG6sCppnVhmv/AFzMFGq1L2IHl5jeHdRWLac+FSM4/fozItl3V/I7Sf8AwlcVwt8y3TZ2EDQrl57g95sDkwwYJrMtRLvmU9wb9EubLAXuYENAWSr7h9xj9Zn5ZoIL1/E/u/1m73E10xFTHumFKN1eoSyECiaQwEFss4RO5gTNDUCGlslAPCElAPTJP6lyvkiFRvcCIsFRg0JqpQXpoDKPGAqLg2zpmIVdeVhVv4VV5zKiG7zLgjcHwpHh19ubMRHLtNMJWaFCCl4xFfgila5IsIGMhnZlyQSjGMq6/wC+Gnp2IGKPBKMEDZIqRpA8bS1BfQNXF2ir7slkjbMp65NxlhVS8QvmEsilCgEcwOwG1Q1vtiuVrZe7E39VGKI3lL4I26k13RVUjhuGDwzmbZ8/1m73HRL0izqYNQdz9KDWh6MASRFdx+3AGcQUdMtZ0HLL1oYKxYZciiSwuiHA8kstFULzCKHZmAI9pGGVq/sSn20f4IW/h/5hqVb8Iis9glwUzN1QDAVORIEDKgigf6jZi5gX0gt/Me4nhJeKBtsY3qc/3MHLxpccXW6WeJXeauHiZzE2xmDZoXiKHCXsYa/oTMFbn1JLEVveb7ZRw2gxdGMAZW5ertG1So1l2Ib0GhVysmtalgeUixoMH941b+PyTM+b/rNnuJMCKlqmfPHGyH/aMHJB0w3ShSxYxLCfLIUFneFsYYdZdOIWKj0xVEUvQJL0LwkQYFRssHJriI3NpVYY1m0kd1cYIgVQzbgSh0tm4GLG4s39hma8pASQ/ZiR3OYHxDeEWAm/zOZUTLHopD3EZwqQxY4FOf1KSsgWsL8EecBawRcEtukb3HXMjPtSBvDF12jUO1BXvbBhJqUyGMMzUiX6/G0VSWsTfpPWZjXZClfSUBbubVoOyHo2UT+4uw2tlt444COgBOFYYVUcZZl2ZT4FlIE2ocReqAV/0ys0MCxIaQ/jEtZOynGtkDtUxFwxZzDHIfMSBVRI5xa7Aio8ESjozMHMxHREpIMsd0M6HogYzC6Ql4h1amZQnaVCVyvtmEcI5r4ZRY+JgHf8xANA5i8zgAF7xKaECxAFb0ipQBEcjDc76osxd0EGxoU7moxHrM62QFsB4gLHd9sXrXfWKcsXjo+iKeU7qAmTwQioUHGE4SAws1JYB4135xczhA9f9TUiBFwf0gTKMwDB5mlJunGYKwVZaYi9oD5qENYVVxtS5Y3cxmOQNYHtRKQ5oKxhl3I/+JNXz/WNqMoeYpaiYoP8IrjJXiKZJfxKsXmArWuMkK43LIZ5JakssQQisC6lxUlFMQ2KqiHr5/A8VlrY8TXOsMHWFBMYES06RlogBp7GIu5XMbX5r7jeJQR1Sy8geSQWfYjEiDYj3cY8KlepnSK+EBscWWR5UVBjNxwUDV2Fizmqyo0lVguFLbQQQ4Fgp4iGuuu0iKtcOZgH7CeFQrwxZ3Iw2xwNHth8idwXWJFjx/U0IR4T/SCOQIBChybUOA883FGVAyYKHOJagUXyiOiuGJrUFYNWImbZjXfD7Mtdpo703Fisn1Yi/r+xrdEFbu5tx+LhPuiwfui1KS/HzQFxcDskDDKNPcyCQ22+zMKaBl+YZsNxutypjCxJViHBuBELB7jCxLhiWC1FD4uIlK7yfLACuptLhRIID04PaR7d47sUITrv2TFhL9IMfiS+Ig2FBlB0WqfcP8ShRRwfd2GKQFbzZAgEOV43B4iKO1uUolJ2Z/4zGFVdX7QeYYUXDklrtM8ktbrap/WTj1gFJeoRKUVcCGxS7rlmIlB3VDz9xmzVjLfqWTHAINMWPqKBUWsWFVVJEtQVW+ZnnyfvRKwFaD/4woM9/wBjDZ5m8qVqh5lioeQmg8xFZaC6/AAtSn/yCAKMyxVbrqI3a+EaGg9Q1i6NQgAdklKSJwzKllgB+yDNCAp6l+VdKrzDU2b1+BfrmJW2v4wnOrSymh8xKTqY4SBaos22xIQOL7jFsKKxICgDXBhs+lfohK6aOL3m4DY4s1HdVy64iGVv9IpYkqDnscIALWIDtxmYOiThCFbnJqPD0jK3FfR/SJrJibrKM7YM6aKUtdWiGkVeHFBWtEow2oO+EsjGtt4Lsz8Nks0bfgen6lsrnDGN4V/GGin/AEM6Zj+Ux+/9fx/Ug37gUO0iDbHFhiCg+qIoh3Ri2pA4rMSSi7DUri07I9GD1LRz+I2CZ3FoQylFYTpiOg9zHMDwyopBO1HpnWqbQ1oij56jUtgT8Yll8xFvDVRjxrEsuB08Sz1CvKNVkKKdxUfJA4uVxNcI8sL/AElS4tmPmo8MEFQhoWHtSBStMwfMUH+wOp5fcc7cUY6HCPJSZQqc1cr5oh4gARcBycw6N1Gj7/8AUxB6n/VcwhYB/wByveQTN82SlBS7cwOs2ojytS40+xaMoK4r0mT6jKArV0q2Fa34mj0/1/B+z8N4VLTMNSUkPt51Uxbh2x5WqDKorhkmmoviPr9imGyNF/uJDamRWyNhzFGZSloapwoWpyJmIF5lLj43DNbhqqzFlQqZgzLAoXgK4OaodR0m8jEWuC7kQITDWxXDu2p4Yu4noiC22WcTbob+SGSLi1ZVnMES9MHsWFMxRRe2M0/IQQ5bh9BnB23RErGA8rUspjeHiQnYTLKN3/3DGhEIkKRxTC7W4AqCY++dhFdKF75gdix+WFW8P9QyJxvuLjBXDc80ZHmEBGNDEFOlGcLaOAgwGWTT3GTB4GwQR0MMNAlIB5w/0iqHLdE14jSMmLGC7nzWYgUJTSe5ZBPkIMsZU3ZQcHKxoPWSDU0yzO2eM7gDgiv5GhhagNmAJaOahcrl0ofTNshOqwwYs7DYPplguUjWMTxbRQ+yY2DTYpiNYFD0ZbY7iDaQcsdlamVuN1iPtNNaTBB8wIXqDwYCFrF63fxQtkafCZJMx2jdQahViEDiKHEwo2mBaaqC4JLC8FL6mSQKW0Y+4lQKMpALrLIxXJFYi+nuzOXX6/wmfihcXHGGHVsFYf6jMDYuQbhPJm4LQ3ouXQOUSPLniYdA2fcfYpsJWU4GwIu8heGPBCVEFcwVLzpENmfmzbYL91CCMKfZcoXsazCKD/yj/wCHUArONzT2f2B3HEb7Z2UL7i0quDEQzQ5IytDqyAtqjbSF4YbzrbKCDLd3WiWYqzITjTcuGcU3XEToLuUcSUiVYGYetXXwP9wPeFWWNc0yyDnno/6gYXsiPJLwBhVoviFCV6FBFkROb009YuZyQ8EqOprIqX7oa9Yl6QKiOau+TBKBTGD8LGDTDuDlHwSWNNaGusjgZW8nKCOw3Lg3yWhU+Y4l5zXLePLhsFzazaeoeYCIfJLg/BR+1RWwjOupFkYHIhvwZ5qHFdy96XqBBZBdlfmAcj1qDcIRIU8zxCwLG7yNxroAqYHPmbRkljupKsW7Rt3vIQUD/wCcbPbZMc6Kq/Ep9B+7jRRF1AS7EdtOY9YjHVengeZbIX4UFDcUom4ZCsO4CmEFv5zUU5CWKB3TpiGAnN52wBLqbxydJXcTaLL4IlN3VTaOv8SyVsjLkyibI+K0pSGbSF6yHMGwW8qVqXCgcFbLgaxLgpf9rCQWSQh3j0wA5DFAFl24VzOqq0vuXGUbTOscxgW6i4YfQgqlWQSKWWjG4JqAgUvTsQ5a0zNhUgV/u5ojACjWDV0ZJXVT6cnwygiDCRHsxvBeZfQyr2HRhpuPblJYs8IFiW0UVUg+SyYLIWhQo5uFsHRC+YBwOe4qDS9HMrofRAsGfUXgHOpTvDww5hfcv0Je2KX9Cw6GgHMaCh8zRfoRAHBQNMpT5gsFJhfK0nAPNEOzL6GZJb3LZgnmIoOt+1myC0FWvUYzHMChltptftqAj/OvM/wp7mq0MLbsjy3C6yJJyAcCV1MhcwPh2SxtVGnNiZqgGKV15uLEtswgrqL87Q6H+papWUog+STDrF3YJb8SxVMmEA9Ay/pLF5S9mbE235FR8QDwhVsK8JUduK7aHLo/BOsNjWVX3Fx7Y3cA+4pdu0COOrIX8seHjiwgWwDao35MyjyUOIBKDZ82uYAVylxGuo2AP9cMUeEYKr5ogUMXTEBiscQsaKGm2vSXFdDC1hFvIx2iOBQbxWLVsrOri3rASxcqF3aMWoRALbR4tLYb3T93IlADZyNfUWyKcl8PmBIg+0NFFoTDsUDQcEapWzfP1Lpawb5qBsw3ieGmTMkrgAeCK38SIpZ+jIzAuLDxfqLDvLjE7aiBdvUp4g04xGcIB9TnEPlaw2ytsDwriOm44tE64eF1MhbaQUDHwtCJXfRZR36gLTot5UTNs8KaXBnWS8i9ekv3m27KqgMgQF0hfF/U05Qtr/yLG+s8O2CQq07aPYXiKOqxVJ9mKnDe1fjkwxGFYJ2XyBGMwKUUA/gahT1iJOjoiClxSmhQYlMgkBN/HwZmDNGi37JnRaNysB/bLijoxgAObNMtRABtMU0vqWurUEKuiI0s0mGqgGqZnBEYEKRvSZF8YmygYb6+IllZGyrhZwEQYMi6zVRZSWwqzrWyWrEh1T9ZiQKW60CtwKU1SlBtw/CUq21kK/Ub6uVgXs7KYgzAG9lrjCDFqqXQvHfNxzhQgMJRtT2VFTiA8KwBoE/88OMWYuDGVsbhVllkWoBelSkqDFX/AIS9jfxUFqxpVXWYtqXbtKiCmnOF3iU004sJYOHI8VCz2dGI5QXHdcxfQaEZvApByZ2jk2ygX2VZYThYwtbQ6PXcEYm3hV8JcUAsvvUt1tKUV7KoaPmArFYFXYcEOs2wpI92VH13AKtYrBEqpGhpYHDmVUS0xW7p7/BpjvqxZZtnMcIC1NgMKKV33TgZuRgFrxi9N5iTcRSlYxBBzC8G6iKg273WtfuJQcrC7AzdemYWgDDeHjxB3Nl/vWJkKW208M+xzTmEXHmWcpfHtCG/7iCC/XUV2RF0I/yMOmCuvMx4TpBEUXblWbiiiFouqhlJsqp/Nkv1oB1NXpC6RTAAKc6uPER7GY2I2GkcJXuGWwfFI5vJLbEW5h20fFzkvuPkPZPBGZWvwwFogIwobJoelFQEeYM9QHNcco6jgWcNavcxRZRnC6IYbsBb44TA5BRgfTnuWuKLjDN7t8+YWKSxuQbg8KDSgKRsgnQQdWxvmXEm2q/AfEEUnAyNnl23G063t4l3EKoLwr9Su0oAtvyeJd9lXt8aahQnyaaxdMkBcRpRsVW0fbKqhhHgXcB6+zGF6gDXFvxBhIhiUmn2QHCK4UXPxHJZVNMNLZDWvgnXE2eLaN3MtDYU0SjTW/ctxyhpUbbDx1qUKGaKcEsAJTZgh3FINhe4CjFPDuFaVHF9Q2sExkhXhII4BmL4sfSXLOBj1KcSFOEsW34l3ZxyXqW6qQBZQ2LURDS0G+POJpNjBbAw7JXeCISeAH9SgVpbko/UUu5EKYM1x5YCwFx8BN+lQWRbHYX7gZaruoVEBZilGEJOGIVC2puLJhqOo2oJasOaXq5W9hQrKIp8/Jv4jYbYYaODmLyAF1nEC3LbcJRcUtug86xEgtS0LTIbGKw+EMvDHVRvDBBZHqN1D2NLNlvJCzsYOMZcwknQOdlVOIOZLRag5d4iaqLdj6oKwsGll2yBeRcLSCt8greYIzgbJTTLaoBcKaAmnYjGPylSvZuANOhgUuj4LLt9xoheUTAkVpV1KlACU3QSsAKclvockT4lURQRw9lxysa+gctfPEVvqzYgOWvaXquDpZrFl/uLzTx2PLUtPaMn3cAGGnDlgtVYwdLcaiimaUgSAwxs1LbqHelRwi8kSTyKIQGxQXCCyq4YqMVdLVdTJkAdYuLfHsECtlnZiNasRvJN4N6KhFZlXDSQ8NBsGI/iQUs14JG4zWWn9VGmqV7WPmUoLIYAUxhjg0L21Xu4tw+n+pctSqmXUTpB5EqZp6n/xAAyEQACAgEDAwMDAwIGAwAAAAABAgARAxIhMQRBURBhcRMigQUyQhQgIzNykbHBNFKh/9oACAECAQE/ANoBcFBTFjk6TEF6R5mNf6l/qPx/AdlWZeixMmwphwROnyOyumQ2+M0T5BjcH4gbSg2sk0IcTaTkc2b9AsAHYTK9favMVQqjyZVCoTC0xm7/ALag4h/dByPQ+jkkkDsYvEYWKgpXU9gZ0z/Sc4X2K7fjsYzKBZPadP8Ae/UZRwaUe8bg/EABCe0ZmKgEy6FxbO55juEHvMa1bGKG3NRydhOOefTH3gIl+ogO0A9xK3lGDmFqEIu2iCgIZRMPT4eoARyNQ4JOkj4Mb9PxK2l8uRq7atv/AJPtAVQKUdhDCTUu5ps2ZdQiyCYQbqDggGGkFRnOr0QcwIa5ECN5E0maWlTeAQEwMZxH+4n2hH2RN6jDg+iAajctiwjtUw4tRF8d5kXFqtRSiOUJO/wBO0Y0DLuhDQMBB71UyJqYVxUGKze5gQ+AIEHzNIlDxKHiUPEpZdHaAkq0oEiA0fQAAtCLUiYNYbIGWgGAX3FQvvUTo1OHFkyZlT6gtQQSa8z+jw1/5mPn/wBWg6XDhKZf6nGyEsvcfxuay7AsKCiljdQaIXaHK7lbJ95YoxT9sIsUe80KvBl8S5pJAIgRu7mWAQPQtNUJNTF1GPKCVJoT6iywx2lUs7iCZv1nrBmYDI1ajQE/Sf1bqOo6xMbu1E7gx8iImo8WBEa/i4VrUY6da/T4Djx2BiASxYi4f1GvuRb/ANIi4epXpOqbqcCFRiY4zVFW7tAL1m+NzDkHYTFjyk3RqEV2MAFbmvxCB2M0LsbjBQK4hYKv3HbyYmVCDp4WZMmQTUSVuAmlvmxDQgZqjG6gVQCoAAMpR2ikXO5ncemVcGOivS/4ikb6G/5qdBhwfXxFMGl73bSR/wAzqsjKWVn+2wFTuTMOwVfFCFiBMHV9diDImd1XsAaEHX/qHfrMp/M6vq+rz42Q9S5BFbntFRACC12JjwqNPAELBVs8QZQ2oe20BFd/eAirFS7HM6lnA+2UxxDm9UwY3VGB7z6LHljUAUEQkWu3eO1AmrqZeq0D9k6vPlxFAhAsGdHmzZcja2JFQxKv07id4UKoC3mA/cYnTgHWVHfeG9X4jDeaoAzavAjdNmZmJIonuYuIpjIZrriDHdkeZnuh4PMRSN/YwErsPNwkmWAVB8xmXcRsgBoKDMeRiWvsRMed8j031N1se4ihz1mDxYMBBKEcEzJxM2PViLd+06+ycdDgGfp6/e9jtG+ZjIuXYncTvMr2WSIqEHftHbHoxKD+0bx7D8baYxNg32l0TAxpqO0ZiYTQb4hxlGYHkcwgEUYFAQqOKhH31Hctixqp3Fxj9yDw0yYBkO5M6hRiAA3uuZ0dlWudJ0aFnonZbu/eJjUZFbfZdoigACuGEzNpUmpsyE96EyoHz4wSRS3samJmPUZVLEheIR7zEKuAdp4neDkmgSRye0QBdQBhIFe59GAMPf5i3bCoFs7mAfcBzQ/7m53PPf0PEb/MB+IK2ho1ASXqtys63kfidJWgzo8DLjy5T3oD/eFgDXeeK8idR/ltEw6CwBJBqdT9b6iMo/jpJ+J0QZWcEb6bhJuY4u7Sh6JZSBSWP4j8D/VHK68Wm+DqjNRE2B/MYxK2N94Wpk9zUHA9DH5EH7quBF2FQH6ecvV7Cp1RLG67idH+1vmLlylPplqW9h7zvj+OYP8AsTILFfEJUMR7zImvG4FWRtc6TE+PLkVh/H0xi7ijf8erUF/MB3My0Qo94D9wmVqfEL5ub9416liEBTsNzGU/axGwg4Hq/A+YmnmDtMpIyY/kzJgJYEDxMSUW2AswYmX5u/aMp+z2g4HyIRe0OP4uBdoVqdpj7xf+vUMp4mrivMNe99hL/wARRXaPiV2xsTWk7RhZEybRNOvfxM/UfVxoukDSK2iG19X4/MB5ErYR0LkVWxjqG5lZP4iaa/kLhvaDt8ifyE4gjAkQjeYhF9RlYH9sXKCeCDDkAqx+YKJFRthAbsx1uXvGcKN5rJW0iXpW/TICQd9u8UMG423uKwPiHGzEfeos+ajI6qSEJF1tvCmRj9zV7RcQH8SYcex2qLdqfefyhi15jcRuTMXeL6BeTCEiX4EF+JR7T/ElNeyGPrGzIRNEZSRv4mJQqAShBGviB8io+proczCjAq+u7mRyNMRzQM+6wTDfcwuL23hXbnvP5RroxewlUOTH5MxxPQGMov8AY8Ve+logFQQExd4MjgVvXg7iFcbX9lfEOFeQ3++0CESpRhHMM1m7CmMHbeopYUBUzM6pa/uilnoNKw1RZT+YdAC6aomGgbuWD3nEY7Rl3mMHeL6nV7QNvVQQXB6XN5XsJQriDf1CqdtUbGAOZo8Q4xcC0N7IhvTQ2iYBj197NzUVAFcG4cmoVtKixYRufmY+87QQ8yxLlzaCAy/aX7QknzL+ZwYbl+l+RC3v6BtjvKE0w7TUCdllDxNMGrwJpc+IqEAwSxOTCfmWfB9BBzA3tNQ8QmavaE7TvLhPv6GETcQNtATXEDEbRS1bibGXvA20sS/f+wTbzAV8+olTb39ARGIogSz6FR5lDzNIhAhA8iaSRsRFD3+4f7wD+zaDTKHYSzLm02n/xAAyEQABAwMDAgUDAwMFAAAAAAABAAIRAyExBBJBEFEFEyIyYSBxgRRDsQZSoSNykZLB/9oACAEDAQE/AOoRR7Dmy1dYeGUGaSh6XBoNR4s5ziqPjGrpvBNRz2nLXncvEKFGlW0+ooiKVYTHYrSsLtYMjsU/S06tfVGsSGU6W4lo7LXeKUarRptLTNLTgABneOXdyqtN4a0k2TkXgAwqUuJe7AwFUdvf8BAElR2W211UEEJvtH0hDATcD6CeEMIoyNrhwZXitP8AV0W62ndlRo3EX2uaIgpoe8MpNbPqkQLkleKDyaGg0ZvUaNzwOJMwtK6dW22LFGszZr2EAeaGhriE6lRYAGj1Tdxzb4CrPNmCcXlVHX2hNpl7oGBlVn4Y3AytsQDkpgF0ZKuqsnb91MBbh9Lfah046SINk3HXR6/WaHe6i/0nLTgoeP6v9rS0aTiI3tYGlBjyX1qrt1STyml4quv2TYe3btuT7ibrUeH/AKegKgqMc+YLARMnEKsHsJa73nK2mVthsBbWsRyrm8IDo4OcQiwkRCNO8hq2u7La7stpUFAWTpUQpRXCaMz1owGCwMnKmJPymA1HFs2ynGXbWBPquY7Y0y/k9lT1YpO3Eh74tzCqV3PJdgk3OSUCTUb9042lOkp0gTEyqe6DKAMLaFH0ypQUqJQXKGRZV3NOxwMkt9XwZXKf4g816tKhpn1fLMPIIAB7XTfEtW0W8Nqf92rRU9f4gzWeXoqgNCkKj7g2JVUtoU9gMvfdx/8AE2s+n7QJPKdNySiihIcDC3VHZaAFsJyvLAC9KJHA67lPwhJVSg9nuKAARygMdAfUQhoPD20xOnZIaJJC8T0Ghb4fXq06LQ8AQQPlUqD6j9oztJ/4Ep7XMdtIgrYSCV4XW8Do6s/raoaDqH+eN0OIBWo1/wDSBqO8h0sw0lxn+UfFPB/IbS8K1b6deq8N1UEltSnchgiU8eyxRb3KeAcKDyvTJQgZUjiESVBJTmOBEiJTKTZElOyOlgEXSbBSi97rukn5KkrlDuih7lVGoqgxqmlp4DgtSa9PRVg+uC3aBtkd1pWMAY5rZeRLnHDAVXfvruMQCZQBLVX8P0FWoH1tMxxOTF07wvwgwGeH0/ytLo9JpyHUtOxpBmwTjVdeCAOYTnt73TQSnN9JJRG0TAATQ119xRaBMJgbyg9gfkRCq1GlzSMBGvGGDrAMKnQD8PstNQpvBLgTHytXSp06bdrQDKCOQgihZwRIJniFi6bqHvftkgRj7BVQJkJriAg6TdO1NJoDWtgkIamgA30OFuAE6qHuqPYzaYPKZUBbDhOU2JMKq8bCJuUbqI+JTQSCi0wqdP0kngp7QNkcry6YYHM2lP2DTVsTBURZFUam2o1os2brR2Dp+Fr3DYwTygnIFHhDITJgFVCQZMJgcHfEKxugYAtwiOwCDZDncx0Ltt+6vcdDeZTbA25TaYbVc5wMOI/wqWH/AGCNY022AWneatz3OFqo3sVeuWUgQAnkupO+Tf8AKM7jKiSAm7g4drpr4oEtI9wCqtAo03cumUEb9Dwh7gh7h8GU87nIQAFyUBafhBNH+k9G0KoZZT/3H+Qh1HKMkNthMlVR6PytEPT+StTO9q1Dw5jRHITAYkn0qrkFMAL2AiQZW/cBMCFRFPy3B5J9QK1e0taR3hBHIQVkMhBvqCOVkIcyg6GFC5VxSeiTZUyYdYYOQh1aCTAyqvltMtB+5QxM3XlGrR2jIkkfC0oA57rVe9vYhU6DnDe1pMJ3pbUByCbLgJphw/KumO2lhOFqqjX02Ef3dHcJuV2RBlHK56HKMFrjzFl8yiTBunNmCmloLsodaJAqNJNpVQONWMyf5PQT5bz9k18NKc6dtzhUNXSYxwIOLJ7973OjLieh4Vxyr90SeT0PCblDCi8o03NyCFBBuFIUcolFFHdtsvDqLaerZvfIc8EzgBatgZq9Q0EEeYYI7G46hEzqAeApUwz7reOCtrrYK7RKBMwiIMLkIiQVKKB6Dr+mpu/cVXT7cOaQhSLsET2ThdRHQrb6Qm06jyYVJhZLXiCCU6JPQmAtwLjfj/Mq8fhF5DjLTbFpRqU2EAPaSRJPZCsSSGN3dzwnNqPIJeW/DSg2B7iY7oLkdBkonCHQdBwhUqx7inn5KLkXLd8q3cIEdwi75QqAEGeU5255d3PWE6NoAzJunWgWJ+FkqybIiYRTjycJsQIKOQnH0lDsUBhDo3rTLoEVKYVR3G9pVS5UKFbuFbuFJ7qTGLJpv9IwLoEXVpQiRKqt3Ms8j5CYwyDD5QsIhHhWUQZ6jlDoTYobZ5UNDZkR9wnRwUQOm0ItEYRCsoEozC4XKP2QMlQSrgZW89lSrFjw7aD8EJ1VzjcBEkonv0cgigh0ctpW0rao6BGEY4CgoTKOEFvWQvz0IUOCnuFI6behj6B0PCH4Vu4VkVKDh2QeP7U5wvZFNyEcfRCEz0hfnoWibK6GEFKn5+jkIbkdyg/RPF0VZWWMnpY4VlCHQESjCkdYsoQwrKT0t0//2Q==", O1 = [
  { id: "mine", label: "我的" },
  { id: "hot", label: "热门" },
  { id: "all", label: "全部" },
  { id: "portrait", label: "人像" },
  { id: "landscape", label: "风光" },
  { id: "wedding", label: "婚纱" },
  { id: "kids", label: "儿童" },
  { id: "food", label: "美食" },
  { id: "film", label: "胶片" },
  { id: "mono", label: "黑白" },
  { id: "cinema", label: "电影感" }
], K1 = [
  "soft",
  "cream-skin",
  "kodak-gold",
  "fuji-fresh",
  "teal-orange",
  "meadow",
  "golden-sunset",
  "mono"
], jp = "orcabox.photo-adjust.my-presets", kp = 24;
function H1() {
  try {
    const r = window.localStorage.getItem(jp);
    if (!r) return [];
    const h = JSON.parse(r);
    return Array.isArray(h) ? h.filter(
      (u) => !!u && typeof u.id == "string" && typeof u.name == "string"
    ).slice(0, kp) : [];
  } catch {
    return [];
  }
}
function op(r) {
  try {
    window.localStorage.setItem(jp, JSON.stringify(r.slice(0, kp)));
  } catch {
  }
}
const Ac = [
  [0, 0],
  [1, 1]
];
function vc(r) {
  return r.map(([h, u]) => ({ x: h, y: u }));
}
function Qt(r = Ac, h = {}) {
  return {
    rgb: vc(r),
    red: vc(h.red ?? Ac),
    green: vc(h.green ?? Ac),
    blue: vc(h.blue ?? Ac)
  };
}
function vt(r, h, u = 0) {
  return { hue: r, saturation: h, luminance: u };
}
function _t(r, h = {}) {
  return {
    shadows: r.shadows ?? vt(0, 0),
    midtones: r.midtones ?? vt(0, 0),
    highlights: r.highlights ?? vt(0, 0),
    blending: h.blending ?? 50,
    balance: h.balance ?? 0
  };
}
function pe(r) {
  const h = () => ({ hue: 0, saturation: 0, luminance: 0 }), u = (c) => ({ ...h(), ...r[c] });
  return {
    red: u("red"),
    orange: u("orange"),
    yellow: u("yellow"),
    green: u("green"),
    aqua: u("aqua"),
    blue: u("blue"),
    purple: u("purple"),
    magenta: u("magenta")
  };
}
function Gr(r) {
  return {
    shadows: 0,
    redHue: 0,
    redSaturation: 0,
    greenHue: 0,
    greenSaturation: 0,
    blueHue: 0,
    blueSaturation: 0,
    ...r
  };
}
const ka = [
  [0, 0],
  [0.22, 0.185],
  [0.5, 0.5],
  [0.78, 0.822],
  [1, 0.975]
], ip = [
  [0, 0],
  [0.24, 0.152],
  [0.5, 0.5],
  [0.76, 0.855],
  [1, 0.985]
], Bh = [
  [0, 0.052],
  [0.28, 0.3],
  [0.5, 0.51],
  [0.76, 0.765],
  [1, 0.955]
], lp = [
  [0, 0.022],
  [0.3, 0.335],
  [0.6, 0.625],
  [0.85, 0.865],
  [1, 0.99]
], Z1 = [
  [0, 0],
  [0.25, 0.185],
  [0.5, 0.43],
  [0.75, 0.715],
  [1, 0.965]
], Mc = [
  [0, 0.028],
  [0.3, 0.31],
  [0.7, 0.7],
  [1, 0.972]
], wc = [
  // ---------------- 人像：肤色是第一主角 ----------------
  {
    id: "soft",
    label: "柔光",
    category: "portrait",
    gradient: "linear-gradient(135deg,#d8cfc4,#efe9e0 55%,#fbf8f3)",
    patch: {
      contrast: -8,
      highlights: -22,
      shadows: 18,
      texture: -6,
      clarity: -6,
      vibrance: 6,
      curves: Qt(Mc),
      grading: _t({ highlights: vt(40, 8) }),
      hsl: pe({ orange: { saturation: 6, luminance: 4 } })
    }
  },
  {
    id: "warm-sun",
    label: "暖阳",
    category: "portrait",
    gradient: "linear-gradient(135deg,#7a5a34,#c99a5b 55%,#f2ddb8)",
    patch: {
      temperature: 12,
      tint: 2,
      highlights: -14,
      vibrance: 10,
      curves: Qt(ka),
      grading: _t({ highlights: vt(38, 22, 4), midtones: vt(32, 8) }),
      hsl: pe({ orange: { saturation: 8, hue: -2 }, yellow: { hue: -6, saturation: 4 } })
    }
  },
  {
    id: "cream-skin",
    label: "奶油肌",
    category: "portrait",
    gradient: "linear-gradient(135deg,#e8cdb2,#f6e6d4 55%,#fdf9f2)",
    patch: {
      contrast: -6,
      highlights: -14,
      shadows: 10,
      texture: -18,
      clarity: -10,
      temperature: 3,
      curves: Qt([
        [0, 0.03],
        [0.3, 0.312],
        [0.7, 0.722],
        [1, 0.972]
      ]),
      hsl: pe({ orange: { saturation: -4, luminance: 6 }, yellow: { saturation: -3 } })
    }
  },
  {
    id: "texture-skin",
    label: "质感肌",
    category: "portrait",
    gradient: "linear-gradient(135deg,#8a6a52,#c9a582 55%,#efe0cc)",
    patch: {
      contrast: 10,
      texture: 14,
      clarity: 12,
      curves: Qt([
        [0, 0],
        [0.3, 0.285],
        [0.7, 0.72],
        [1, 0.995]
      ]),
      hsl: pe({ orange: { luminance: -3, saturation: 2 } })
    }
  },
  {
    id: "cool-fair",
    label: "冷白皮",
    category: "portrait",
    gradient: "linear-gradient(135deg,#c7d3dd,#eef3f6 55%,#ffffff)",
    patch: {
      exposure: 0.1,
      temperature: -12,
      tint: -3,
      vibrance: 6,
      highlights: -6,
      curves: Qt([
        [0, 8e-3],
        [0.5, 0.512],
        [1, 1]
      ]),
      // "冷白皮"要在缩略图上就看得出来：不只是 -温度，暗部与高光都往冷白上带。
      grading: _t({ shadows: vt(205, 14), highlights: vt(196, 10) })
    }
  },
  {
    id: "honey-skin",
    label: "蜜糖肌",
    category: "portrait",
    gradient: "linear-gradient(135deg,#a06a3a,#d8a266 55%,#f4ddba)",
    patch: {
      temperature: 8,
      tint: 2,
      vibrance: 12,
      shadows: 6,
      saturation: -3,
      curves: Qt(ka),
      grading: _t({ midtones: vt(34, 14, 2), highlights: vt(40, 8) }),
      hsl: pe({ orange: { saturation: 8, hue: 2 }, yellow: { saturation: 4 } })
    }
  },
  {
    id: "airy-bright",
    label: "通透明亮",
    category: "portrait",
    gradient: "linear-gradient(135deg,#dfe8ee,#f7fafc 55%,#ffffff)",
    patch: {
      exposure: 0.18,
      shadows: 14,
      highlights: -18,
      vibrance: 8,
      curves: Qt(lp),
      grading: _t({ shadows: vt(210, 6) })
    }
  },
  {
    id: "sculpt",
    label: "立体轮廓",
    category: "portrait",
    gradient: "linear-gradient(135deg,#3a3d42,#8d9298 55%,#e4e8ec)",
    patch: {
      contrast: 12,
      clarity: 10,
      texture: 6,
      shadows: -6,
      blacks: -6,
      curves: Qt(ka),
      grading: _t({ shadows: vt(214, 6) })
    }
  },
  {
    id: "de-shine",
    label: "氛围感",
    category: "portrait",
    gradient: "linear-gradient(135deg,#41352f,#96826f 55%,#e6d7c4)",
    patch: {
      temperature: 4,
      contrast: 6,
      grain: 16,
      grainSize: 2,
      grainRoughness: 45,
      vignette: -26,
      vignetteFeather: 60,
      curves: Qt([
        [0, 0.022],
        [0.5, 0.505],
        [1, 0.978]
      ]),
      grading: _t({ shadows: vt(26, 10), highlights: vt(44, 6) })
    }
  },
  // ---------------- 风光：天空与植被的分离度 ----------------
  {
    id: "punch",
    label: "鲜艳",
    category: "landscape",
    gradient: "linear-gradient(135deg,#2d5f8a,#8fb8d8 55%,#d9ecf7)",
    patch: {
      vibrance: 22,
      saturation: 4,
      texture: 8,
      contrast: 8,
      clarity: 6,
      curves: Qt([
        [0, 0],
        [0.25, 0.235],
        [0.5, 0.5],
        [0.75, 0.775],
        [1, 0.99]
      ]),
      hsl: pe({
        blue: { saturation: 10 },
        aqua: { saturation: 8 },
        green: { saturation: 12, hue: -4 }
      })
    }
  },
  {
    id: "cool-tone",
    label: "冷调",
    category: "landscape",
    gradient: "linear-gradient(135deg,#1d3346,#4d7ea0 55%,#b9d6e8)",
    patch: {
      temperature: -16,
      tint: -4,
      clarity: 6,
      curves: Qt(ka),
      grading: _t({ shadows: vt(210, 20), highlights: vt(200, 12) }),
      hsl: pe({ blue: { saturation: 8, luminance: -3 } })
    }
  },
  {
    id: "crisp",
    label: "清透",
    category: "landscape",
    gradient: "linear-gradient(135deg,#2a6f8e,#9fd4de 55%,#f0fbfc)",
    patch: {
      dehaze: 10,
      clarity: 8,
      vibrance: 10,
      shadows: 6,
      highlights: -6,
      curves: Qt([
        [0, 0],
        [0.3, 0.29],
        [0.7, 0.715],
        [1, 0.992]
      ]),
      hsl: pe({ aqua: { saturation: 6 }, blue: { luminance: 4 } })
    }
  },
  {
    id: "drama",
    label: "高对比",
    category: "landscape",
    gradient: "linear-gradient(135deg,#08090c,#4a5058 55%,#e8edf2)",
    patch: {
      contrast: 14,
      clarity: 12,
      blacks: -8,
      whites: 6,
      curves: Qt(ip)
    }
  },
  {
    id: "blue-ridge",
    label: "苍蓝远山",
    category: "landscape",
    gradient: "linear-gradient(135deg,#22384c,#5b7f9b 55%,#c7dbe8)",
    patch: {
      temperature: -8,
      clarity: 14,
      dehaze: 12,
      vibrance: -4,
      curves: Qt(ka),
      grading: _t({ shadows: vt(215, 20), midtones: vt(208, 8) }),
      hsl: pe({ blue: { hue: -6, saturation: 6 } })
    }
  },
  {
    id: "golden-sunset",
    label: "落日熔金",
    category: "landscape",
    gradient: "linear-gradient(135deg,#6e3a24,#d8823a 55%,#f6cf94)",
    patch: {
      temperature: 14,
      tint: 3,
      highlights: -20,
      shadows: 8,
      vibrance: 10,
      curves: Qt([
        [0, 0.012],
        [0.5, 0.508],
        [0.8, 0.835],
        [1, 0.962]
      ]),
      grading: _t({ highlights: vt(42, 24, 3), midtones: vt(36, 10) }),
      hsl: pe({ orange: { saturation: 10 }, yellow: { saturation: 6, hue: -4 } })
    }
  },
  {
    id: "meadow",
    label: "青空草原",
    category: "landscape",
    gradient: "linear-gradient(135deg,#2f6b3f,#8fc46a 55%,#dff0c8)",
    patch: {
      temperature: -4,
      vibrance: 14,
      clarity: 8,
      saturation: 3,
      curves: Qt(ka),
      hsl: pe({
        green: { hue: -8, saturation: 10, luminance: 2 },
        aqua: { saturation: 8 },
        blue: { saturation: 8 }
      })
    }
  },
  {
    id: "alpine",
    label: "雪山净空",
    category: "landscape",
    gradient: "linear-gradient(135deg,#8fa9bd,#dbe8f1 55%,#ffffff)",
    patch: {
      exposure: 0.12,
      temperature: -5,
      dehaze: 10,
      whites: 8,
      contrast: 8,
      curves: Qt([
        [0, 0],
        [0.35, 0.34],
        [0.75, 0.775],
        [1, 0.995]
      ]),
      grading: _t({ shadows: vt(210, 10) }),
      hsl: pe({ blue: { saturation: 4 }, aqua: { saturation: 4 } })
    }
  },
  {
    id: "forest",
    label: "森林秘境",
    category: "landscape",
    gradient: "linear-gradient(135deg,#12331f,#3f6b45 55%,#9fbfa5)",
    patch: {
      temperature: -2,
      tint: -5,
      shadows: 10,
      clarity: 10,
      vibrance: 8,
      curves: Qt(ka),
      grading: _t({ shadows: vt(150, 14) }),
      hsl: pe({ green: { hue: 10, saturation: 14, luminance: -8 }, aqua: { saturation: 6 } })
    }
  },
  {
    id: "seabreeze",
    label: "海边清风",
    category: "landscape",
    gradient: "linear-gradient(135deg,#2d7f95,#94cbd6 55%,#eef9fb)",
    patch: {
      exposure: 0.1,
      temperature: -6,
      contrast: 5,
      vibrance: 10,
      curves: Qt(ka),
      grading: _t({ shadows: vt(198, 8) }),
      hsl: pe({ aqua: { saturation: 12 }, blue: { saturation: 8 } })
    }
  },
  {
    id: "night-sky",
    label: "星空夜景",
    category: "landscape",
    gradient: "linear-gradient(135deg,#05070f,#1b2a4a 55%,#4b5f8a)",
    patch: {
      exposure: -0.3,
      contrast: 14,
      blacks: -10,
      clarity: 8,
      saturation: 4,
      curves: Qt(Z1),
      grading: _t({ shadows: vt(225, 18), highlights: vt(45, 6) }),
      hsl: pe({ blue: { saturation: 8 }, orange: { saturation: 6 } })
    }
  },
  {
    id: "misty",
    label: "雾中山峦",
    category: "landscape",
    gradient: "linear-gradient(135deg,#9aa7b0,#cfd8de 55%,#f2f5f7)",
    patch: {
      dehaze: -14,
      contrast: -6,
      saturation: -8,
      texture: -6,
      curves: Qt(Mc),
      grading: _t({ shadows: vt(205, 6) })
    }
  },
  // ---------------- 婚纱：白纱细节不能死 ----------------
  {
    id: "wedding-soft",
    label: "柔光婚纱",
    category: "wedding",
    gradient: "linear-gradient(135deg,#e6ded2,#f7f1e8 55%,#ffffff)",
    patch: {
      contrast: -8,
      highlights: -20,
      shadows: 16,
      texture: -10,
      temperature: 2,
      curves: Qt(Mc),
      grading: _t({ highlights: vt(38, 8) }),
      hsl: pe({ orange: { luminance: 4, saturation: 4 } })
    }
  },
  {
    id: "wedding-white",
    label: "纯白圣殿",
    category: "wedding",
    gradient: "linear-gradient(135deg,#dfe6ec,#f5f8fb 55%,#ffffff)",
    patch: {
      exposure: 0.12,
      whites: 6,
      contrast: 5,
      temperature: -2,
      vibrance: 4,
      // 肩部压平：白纱靠曲线留层次，靠 whites 拉高只会糊成一片。
      curves: Qt([
        [0, 4e-3],
        [0.5, 0.508],
        [0.8, 0.842],
        [1, 0.974]
      ]),
      grading: _t({ highlights: vt(200, 5) })
    }
  },
  {
    id: "wedding-romance",
    label: "罗曼蒂克",
    category: "wedding",
    gradient: "linear-gradient(135deg,#c99a92,#eccdc4 55%,#fdf2ee)",
    patch: {
      temperature: 8,
      tint: 3,
      shadows: 10,
      vibrance: 6,
      vignette: -16,
      vignetteFeather: 70,
      curves: Qt([
        [0, 0.024],
        [0.5, 0.508],
        [1, 0.982]
      ]),
      // 罗曼蒂克＝暖粉调，分色要撑得住缩略图尺寸，不然和"柔光婚纱"分不开。
      grading: _t({ highlights: vt(34, 20), shadows: vt(320, 10) })
    }
  },
  {
    id: "wedding-film",
    label: "胶片婚礼",
    category: "wedding",
    gradient: "linear-gradient(135deg,#b8a68c,#ddd0b8 55%,#f6efe0)",
    patch: {
      temperature: 4,
      contrast: 6,
      saturation: -8,
      blacks: 6,
      grain: 18,
      grainSize: 2,
      curves: Qt(Bh),
      grading: _t({ highlights: vt(40, 8) }),
      calibration: Gr({ greenSaturation: -6, blueSaturation: -4 })
    }
  },
  // ---------------- 儿童 ----------------
  {
    id: "kids-honey",
    label: "童真蜜糖",
    category: "kids",
    gradient: "linear-gradient(135deg,#d79a5b,#f0c690 55%,#fdf0d8)",
    patch: {
      exposure: 0.08,
      temperature: 8,
      vibrance: 12,
      shadows: 10,
      curves: Qt(Mc),
      grading: _t({ midtones: vt(36, 10) }),
      hsl: pe({ orange: { saturation: 6, luminance: 4 } })
    }
  },
  {
    id: "kids-cream",
    label: "奶油童趣",
    category: "kids",
    gradient: "linear-gradient(135deg,#e3cdb4,#f7e8d6 55%,#fffaf2)",
    patch: {
      temperature: 4,
      texture: -10,
      contrast: -5,
      shadows: 12,
      vibrance: 10,
      curves: Qt([
        [0, 0.03],
        [0.32, 0.335],
        [0.7, 0.718],
        [1, 0.978]
      ]),
      hsl: pe({ orange: { luminance: 5, saturation: -2 } })
    }
  },
  {
    id: "kids-diary",
    label: "清新日记",
    category: "kids",
    gradient: "linear-gradient(135deg,#a9c7d4,#d8e9ef 55%,#f6fcfd)",
    patch: {
      exposure: 0.14,
      temperature: -3,
      vibrance: 10,
      shadows: 8,
      curves: Qt(lp),
      grading: _t({ shadows: vt(200, 7) }),
      hsl: pe({ green: { saturation: 6 }, blue: { saturation: 6 } })
    }
  },
  // ---------------- 美食：暖要有油光，冷要有水汽 ----------------
  {
    id: "food-warm",
    label: "暖调食光",
    category: "food",
    gradient: "linear-gradient(135deg,#7a4a22,#c98c45 55%,#f3d9ac)",
    patch: {
      temperature: 10,
      vibrance: 10,
      contrast: 8,
      shadows: 6,
      texture: 6,
      curves: Qt(ka),
      grading: _t({ midtones: vt(34, 10), highlights: vt(42, 8) }),
      hsl: pe({ orange: { saturation: 10, luminance: 2 }, yellow: { saturation: 8 } })
    }
  },
  {
    id: "food-fresh",
    label: "清爽冷调",
    category: "food",
    gradient: "linear-gradient(135deg,#3f6f63,#93bcae 55%,#eaf5f0)",
    patch: {
      temperature: -8,
      clarity: 10,
      vibrance: 6,
      highlights: -8,
      curves: Qt([
        [0, 0],
        [0.3, 0.292],
        [0.72, 0.728],
        [1, 0.994]
      ]),
      grading: _t({ shadows: vt(196, 8) }),
      hsl: pe({ green: { saturation: 8 }, aqua: { saturation: 6 } })
    }
  },
  {
    id: "food-retro",
    label: "复古餐桌",
    category: "food",
    gradient: "linear-gradient(135deg,#5b4630,#a5855c 55%,#e8d6b4)",
    patch: {
      temperature: 8,
      saturation: -8,
      blacks: 8,
      grain: 16,
      grainSize: 2,
      vignette: -18,
      vignetteFeather: 65,
      curves: Qt(Bh),
      grading: _t({ highlights: vt(40, 10) }),
      calibration: Gr({ blueSaturation: -6, greenSaturation: -4 })
    }
  },
  // ---------------- 胶片：影调骨架 + 分色 + 颗粒 ----------------
  {
    id: "film",
    label: "胶片",
    category: "film",
    gradient: "linear-gradient(135deg,#4a4338,#8f8674 55%,#dcd4c4)",
    patch: {
      contrast: 10,
      saturation: -10,
      blacks: 10,
      grain: 30,
      grainSize: 2,
      grainRoughness: 55,
      vignette: -20,
      vignetteFeather: 65,
      curves: Qt(ka),
      grading: _t({ shadows: vt(190, 10), highlights: vt(42, 8) }),
      calibration: Gr({ greenSaturation: -5 })
    }
  },
  {
    id: "fade",
    label: "褪色",
    category: "film",
    gradient: "linear-gradient(135deg,#8d8b84,#c3c1b8 55%,#efeee8)",
    patch: {
      contrast: -18,
      saturation: -14,
      blacks: 18,
      vibrance: -4,
      curves: Qt([
        [0, 0.075],
        [0.3, 0.335],
        [0.7, 0.705],
        [1, 0.938]
      ]),
      grading: _t({ shadows: vt(200, 8) })
    }
  },
  {
    id: "vintage",
    label: "复古",
    category: "film",
    gradient: "linear-gradient(135deg,#5a4530,#a4835a 55%,#e6d3ae)",
    patch: {
      temperature: 10,
      saturation: -8,
      blacks: 12,
      grain: 22,
      grainSize: 2,
      vignette: -26,
      vignetteFeather: 60,
      curves: Qt(Bh, {
        red: [
          [0, 0.062],
          [0.5, 0.525],
          [1, 0.985]
        ],
        blue: [
          [0, 0.048],
          [0.5, 0.478],
          [1, 0.925]
        ]
      }),
      grading: _t({ highlights: vt(40, 10) })
    }
  },
  {
    id: "kodak-gold",
    label: "柯达金",
    category: "film",
    gradient: "linear-gradient(135deg,#8a5a2c,#d19a4e 55%,#f6e0b4)",
    patch: {
      temperature: 8,
      saturation: -4,
      contrast: 8,
      grain: 24,
      grainSize: 2,
      curves: Qt(ka, {
        // 金 200 的招牌：高光偏黄、暗部略抬、蓝通道上端压下来。
        red: [
          [0, 0.02],
          [0.4, 0.412],
          [1, 0.995]
        ],
        blue: [
          [0, 0.032],
          [0.55, 0.528],
          [1, 0.945]
        ]
      }),
      grading: _t({ highlights: vt(40, 12), shadows: vt(30, 6) }),
      hsl: pe({ yellow: { saturation: 8, hue: -4 }, orange: { saturation: 6 } }),
      calibration: Gr({ blueSaturation: -8, redSaturation: 6 })
    }
  },
  {
    id: "fuji-fresh",
    label: "富士清新",
    category: "film",
    gradient: "linear-gradient(135deg,#2f6b64,#8fc0bd 55%,#e8f4f2)",
    patch: {
      temperature: -4,
      tint: -3,
      vibrance: 10,
      shadows: 8,
      grain: 16,
      grainSize: 2,
      curves: Qt([
        [0, 0.016],
        [0.32, 0.318],
        [0.72, 0.73],
        [1, 0.988]
      ], {
        // 富士的青绿暗部与干净高光：绿与蓝在低段抬起，红在高段略收。
        green: [
          [0, 0.026],
          [0.5, 0.505],
          [1, 0.985]
        ],
        blue: [
          [0, 0.03],
          [0.5, 0.5],
          [1, 0.975]
        ],
        red: [
          [0, 0],
          [0.6, 0.598],
          [1, 0.972]
        ]
      }),
      // 富士的招牌是青绿暗部 + 干净高光 + 压过的黄绿；在本身就是绿的草原上
      // 也要分得开，所以色相偏移与饱和度都要给够，而不是只改一点点温度。
      grading: _t({ shadows: vt(165, 26), highlights: vt(196, 12) }),
      hsl: pe({
        yellow: { saturation: -14, hue: 12 },
        green: { saturation: 14, hue: 12 },
        aqua: { saturation: 8 },
        blue: { saturation: 8 }
      }),
      calibration: Gr({ greenHue: -10, blueHue: 8 })
    }
  },
  {
    id: "city-night-film",
    label: "城市夜胶片",
    category: "film",
    gradient: "linear-gradient(135deg,#101820,#2f4a5c 55%,#7f9aad)",
    patch: {
      temperature: -3,
      contrast: 14,
      blacks: -6,
      grain: 22,
      grainSize: 2,
      vignette: -22,
      vignetteFeather: 55,
      vignetteHighlights: 40,
      curves: Qt([
        [0, 0.014],
        [0.25, 0.208],
        [0.5, 0.5],
        [0.75, 0.79],
        [1, 0.972]
      ]),
      grading: _t({ shadows: vt(205, 16), highlights: vt(40, 8) })
    }
  },
  // ---------------- 黑白：层次比反差重要 ----------------
  {
    id: "mono",
    label: "银盐经典",
    category: "mono",
    gradient: "linear-gradient(135deg,#1a1a1a,#7d7d7d 55%,#f2f2f2)",
    patch: {
      saturation: -100,
      contrast: 14,
      clarity: 8,
      grain: 18,
      grainSize: 2,
      grainRoughness: 50,
      curves: Qt(ka, {
        // 轻微暖调相纸倾向：红抬起、蓝压下，黑白不发青。
        red: [
          [0, 0.012],
          [0.5, 0.512],
          [1, 0.99]
        ],
        blue: [
          [0, 0],
          [0.5, 0.49],
          [1, 0.962]
        ]
      })
    }
  },
  {
    id: "mono-hard",
    label: "黑白硬调",
    category: "mono",
    gradient: "linear-gradient(135deg,#000000,#4d4d4d 55%,#e6e6e6)",
    patch: {
      saturation: -100,
      contrast: 26,
      blacks: -14,
      whites: 8,
      clarity: 14,
      grain: 24,
      grainSize: 2,
      curves: Qt(ip)
    }
  },
  // ---------------- 电影感：三段分色 ----------------
  {
    id: "cinema",
    label: "电影感",
    category: "cinema",
    gradient: "linear-gradient(135deg,#1d2b33,#5c7f86 55%,#d8dfd6)",
    patch: {
      temperature: 4,
      contrast: 10,
      saturation: -6,
      curves: Qt(ka),
      grading: _t(
        { shadows: vt(210, 12), highlights: vt(40, 10, 2) },
        { blending: 60 }
      )
    }
  },
  {
    id: "matte",
    label: "哑光",
    category: "cinema",
    gradient: "linear-gradient(135deg,#4a4a46,#8d8b83 55%,#d8d5cc)",
    patch: {
      contrast: -6,
      highlights: -10,
      shadows: 14,
      saturation: -10,
      texture: -8,
      curves: Qt([
        [0, 0.058],
        [0.3, 0.318],
        [0.7, 0.708],
        [1, 0.952]
      ]),
      grading: _t({ shadows: vt(200, 8) })
    }
  },
  {
    id: "teal-orange",
    label: "青橙电影",
    category: "cinema",
    gradient: "linear-gradient(135deg,#0c2a30,#3d7b84 55%,#e3a064)",
    patch: {
      contrast: 10,
      saturation: -4,
      vignette: -18,
      vignetteFeather: 65,
      curves: Qt(ka),
      grading: _t(
        { shadows: vt(196, 30), midtones: vt(30, 8), highlights: vt(34, 26) },
        { blending: 55 }
      ),
      hsl: pe({ orange: { saturation: 6, hue: -3 }, aqua: { saturation: 4 } })
    }
  },
  {
    id: "sunset-blvd",
    label: "日落大道",
    category: "cinema",
    gradient: "linear-gradient(135deg,#6e3a24,#d8823a 55%,#f6cf94)",
    patch: {
      temperature: 12,
      tint: 3,
      contrast: 8,
      vibrance: 8,
      vignette: -16,
      vignetteFeather: 65,
      curves: Qt([
        [0, 0.01],
        [0.5, 0.505],
        [0.8, 0.838],
        [1, 0.968]
      ]),
      grading: _t({ highlights: vt(30, 24, 3), midtones: vt(26, 10) }),
      hsl: pe({ orange: { saturation: 8 }, yellow: { saturation: 6 } })
    }
  },
  {
    id: "noir-cool",
    label: "冷调悬疑",
    category: "cinema",
    gradient: "linear-gradient(135deg,#101820,#39505e 55%,#9ab0bc)",
    patch: {
      temperature: -12,
      tint: -4,
      contrast: 12,
      saturation: -14,
      blacks: -8,
      curves: Qt([
        [0, 0],
        [0.24, 0.178],
        [0.5, 0.492],
        [0.76, 0.83],
        [1, 0.978]
      ]),
      grading: _t({ shadows: vt(220, 20), highlights: vt(200, 8) })
    }
  }
];
function W1(r, h) {
  const u = Math.max(0, Math.min(100, h)) / 100;
  if (u >= 1) return r;
  const c = {};
  for (const [g, m] of Object.entries(r)) {
    if (typeof m == "number") {
      const b = g === "grainSize" ? 1 : void 0;
      c[g] = b !== void 0 ? Math.max(b, m * u) : m * u;
      continue;
    }
    if (g === "curves" && m) {
      const b = m, A = (v) => v.map((y) => ({ x: y.x, y: y.x + (y.y - y.x) * u }));
      c.curves = {
        rgb: A(b.rgb),
        red: A(b.red),
        green: A(b.green),
        blue: A(b.blue)
      };
    } else if (g === "grading" && m) {
      const b = m, A = (v) => ({
        hue: v.hue,
        saturation: v.saturation * u,
        luminance: v.luminance * u
      });
      c.grading = {
        shadows: A(b.shadows),
        midtones: A(b.midtones),
        highlights: A(b.highlights),
        blending: b.blending,
        balance: b.balance * u
      };
    } else if (g === "hsl" && m) {
      const b = m, A = (v) => ({
        hue: v.hue * u,
        saturation: v.saturation * u,
        luminance: v.luminance * u
      });
      c.hsl = {
        red: A(b.red),
        orange: A(b.orange),
        yellow: A(b.yellow),
        green: A(b.green),
        aqua: A(b.aqua),
        blue: A(b.blue),
        purple: A(b.purple),
        magenta: A(b.magenta)
      };
    } else if (g === "calibration" && m) {
      const b = m;
      c.calibration = {
        shadows: b.shadows * u,
        redHue: b.redHue * u,
        redSaturation: b.redSaturation * u,
        greenHue: b.greenHue * u,
        greenSaturation: b.greenSaturation * u,
        blueHue: b.blueHue * u,
        blueSaturation: b.blueSaturation * u
      };
    } else
      c[g] = m;
  }
  return c;
}
function Bp(r, h) {
  const u = rp((h.meanLuma - 40) / 60), c = rp((215 - h.meanLuma) / 55), g = Math.min(1, Math.max(0.55, Math.min(u, c))), m = h.clipLow > 0.01 ? 0.5 : 1, b = h.clipHigh > 0.01 ? 0.5 : 1;
  if (g >= 1 && m === 1 && b === 1) return r;
  const A = { ...r };
  if (typeof r.contrast == "number" && r.contrast > 0 && (A.contrast = r.contrast * g), typeof r.blacks == "number" && r.blacks < 0 && (A.blacks = r.blacks * g * m), typeof r.whites == "number" && r.whites > 0 && (A.whites = r.whites * g * b), typeof r.shadows == "number" && r.shadows < 0 && (A.shadows = r.shadows * g), r.curves && (g < 1 || m < 1 || b < 1)) {
    const v = Math.min(m, b), y = (S) => S.map((C) => ({
      x: C.x,
      y: C.x + (C.y - C.x) * g * v
    }));
    A.curves = {
      rgb: y(r.curves.rgb),
      red: r.curves.red.map((S) => ({ ...S })),
      green: r.curves.green.map((S) => ({ ...S })),
      blue: r.curves.blue.map((S) => ({ ...S }))
    };
  }
  return A;
}
function rp(r) {
  return Math.min(1, Math.max(0, r));
}
function Vh(r) {
  return JSON.stringify([
    r.exposure,
    r.contrast,
    r.highlights,
    r.shadows,
    r.whites,
    r.blacks,
    r.temperature,
    r.tint,
    r.texture,
    r.clarity,
    r.dehaze,
    r.vibrance,
    r.saturation,
    r.hsl,
    r.grading,
    r.curves,
    r.calibration,
    r.sharpening,
    r.sharpenRadius,
    r.sharpenDetail,
    r.sharpenMasking,
    r.noiseReduction,
    r.noiseDetail,
    r.colorNoiseReduction,
    r.grain,
    r.grainSize,
    r.grainRoughness,
    r.vignette,
    r.vignetteMidpoint,
    r.vignetteFeather,
    r.vignetteRoundness,
    r.vignetteHighlights,
    r.skinSmooth,
    r.skinPreserve
  ]);
}
function Vp(r, h) {
  const u = ba();
  return {
    ...r,
    geometry: h?.geometry ?? u.geometry,
    masks: h?.masks ?? [],
    spots: h?.spots ?? [],
    warps: h?.warps ?? [],
    skyReplacement: h?.skyReplacement ?? u.skyReplacement
  };
}
function F1(r, h, u, c) {
  const g = ba(), m = Bp(W1(r, h), u);
  return Vp({ ...g, ...Dp(m) }, c);
}
function G1(r, h) {
  const u = ba(), c = Dp(r);
  return delete c.geometry, delete c.masks, delete c.spots, delete c.warps, delete c.skyReplacement, Vp({ ...u, ...c }, h);
}
function Dp(r) {
  const h = (c) => c.map((g) => ({ ...g })), u = { ...r };
  return r.curves && (u.curves = {
    rgb: h(r.curves.rgb),
    red: h(r.curves.red),
    green: h(r.curves.green),
    blue: h(r.curves.blue)
  }), r.grading && (u.grading = {
    shadows: { ...r.grading.shadows },
    midtones: { ...r.grading.midtones },
    highlights: { ...r.grading.highlights },
    blending: r.grading.blending,
    balance: r.grading.balance
  }), r.hsl && (u.hsl = Object.fromEntries(
    Object.entries(r.hsl).map(([c, g]) => [c, { ...g }])
  )), r.calibration && (u.calibration = { ...r.calibration }), u;
}
const Yp = '(function(){"use strict";const Et=["red","orange","yellow","green","aqua","blue","purple","magenta"],vn=[0,30,60,120,180,240,270,300],Sn={dawn:{top:[86,110,168],horizon:[244,186,148]},blue:{top:[72,132,214],horizon:[178,216,245]},sunset:{top:[66,70,132],horizon:[248,138,88]},night:{top:[10,14,34],horizon:[42,54,96]}};function An(t,n,o,e,a){const s=e.semanticMask;if(!s)return;const r=Qt(s);if(!r)return;const c=Sn[a.preset],i=a.strength/100,l=a.texture/100;for(let u=0;u<o;u+=1){const g=u/Math.max(1,o-1),m=c.top[0]+(c.horizon[0]-c.top[0])*g,R=c.top[1]+(c.horizon[1]-c.top[1])*g,E=c.top[2]+(c.horizon[2]-c.top[2])*g,H=Math.min(r.height-1,Math.floor((u+.5)/o*r.height));for(let P=0;P<n;P+=1){const U=Math.min(r.width-1,Math.floor((P+.5)/n*r.width)),_=r.data[H*r.width+U]/255,z=(e.invert?1-_:_)*i;if(z<=.004)continue;const f=(u*n+P)*4,p=1+((t[f]*77+t[f+1]*150+t[f+2]*29)/256/255-.5)*l,v=Math.max(0,Math.min(255,m*p)),L=Math.max(0,Math.min(255,R*p)),B=Math.max(0,Math.min(255,E*p));t[f]=t[f]+(v-t[f])*z,t[f+1]=t[f+1]+(L-t[f+1])*z,t[f+2]=t[f+2]+(B-t[f+2])*z}}}function Ln(t,n,o,e){if(!n||!o||!e.length)return t;const a=Math.min(n,o),s=Uint8ClampedArray.from(t),r=Uint8ClampedArray.from(t);for(const c of e){const i=c.x*n,l=c.y*o,u=c.dx*n*(c.strength/100),g=c.dy*o*(c.strength/100),m=Math.max(2,c.radius*a),R=m*m,E=Math.max(0,Math.floor(i-m)),H=Math.min(n-1,Math.ceil(i+m)),P=Math.max(0,Math.floor(l-m)),U=Math.min(o-1,Math.ceil(l+m));if(!(E>H||P>U)){for(let _=P;_<=U;_+=1){const z=_*n;for(let f=E;f<=H;f+=1){const k=(z+f)*4,p=f-i,v=_-l,L=p*p+v*v;if(L>=R)continue;const B=Math.sqrt(L)/m,W=(1-B*B)*(1-B*B),N=f-u*W,G=_-g*W,q=Math.min(n-1,Math.max(0,N)),C=Math.min(o-1,Math.max(0,G)),w=Math.floor(q),$=Math.floor(C),O=Math.min(n-1,w+1),j=Math.min(o-1,$+1),V=q-w,Z=C-$,J=($*n+w)*4,Mt=($*n+O)*4,lt=(j*n+w)*4,mt=(j*n+O)*4,Ut=(1-V)*(1-Z),Xt=V*(1-Z),zt=(1-V)*Z,Nt=V*Z;for(let et=0;et<4;et+=1)r[k+et]=s[J+et]*Ut+s[Mt+et]*Xt+s[lt+et]*zt+s[mt+et]*Nt}}for(let _=P;_<=U;_+=1){const z=(_*n+E)*4,f=(_*n+H+1)*4;s.set(r.subarray(z,f),z)}}}return t.set(r),t}function wn(t,n,o,e){if(!n||!o||!e.length)return t;for(const a of e){const s=.1+h(a.feather,0,100)/100*.82,r=a.x*n,c=a.y*o,i=a.sourceX*n,l=a.sourceY*o,u=Math.max(2,a.size*n),g=Math.round(i-r),m=Math.round(l-c),R=Math.max(0,Math.floor(r-u-1)),E=Math.min(n-1,Math.ceil(r+u+1)),H=Math.max(0,Math.floor(c-u-1)),P=Math.min(o-1,Math.ceil(c+u+1));let U=0;const _=[0,0,0],z=[0,0,0],f=u*1.02,k=u*1.35;for(let v=H;v<=P;v+=1)for(let L=R;L<=E;L+=1){const B=Math.hypot(L-r,v-c);if(B<f||B>k)continue;const W=(v*n+L)*4,N=Math.min(n-1,Math.max(0,L+g)),q=(Math.min(o-1,Math.max(0,v+m))*n+N)*4;for(let C=0;C<3;C+=1)_[C]+=t[W+C],z[C]+=t[q+C];U+=1}const p=[0,0,0];if(U>0)for(let v=0;v<3;v+=1)p[v]=(_[v]-z[v])/U;for(let v=H;v<=P;v+=1)for(let L=R;L<=E;L+=1){const B=Math.hypot(L-r,v-c);if(B>u)continue;const W=1-Y(1-s,1,B/u);if(W<=.002)continue;const N=(v*n+L)*4,G=Math.min(n-1,Math.max(0,L+g)),C=(Math.min(o-1,Math.max(0,v+m))*n+G)*4;for(let w=0;w<3;w+=1){const $=t[C+w]+p[w];t[N+w]=Math.round(t[N+w]*(1-W)+Math.max(0,Math.min(255,$))*W)}}}return t}function Ft(t,n,o,e){if(t.semanticMask)return 1;const a=In(t.feather),s=(n-t.x)*e,r=o-t.y;let c;if(t.kind==="radial"){const i=Math.max(.001,(t.sizeX??t.size)*e),l=Math.max(.001,(t.sizeY??t.size)*e),u=t.angle*Math.PI/180,g=s*Math.cos(u)+r*Math.sin(u),m=-s*Math.sin(u)+r*Math.cos(u),R=Math.hypot(g/i,m/l);c=1-Y(1-a,1,R)}else{const i=t.angle*Math.PI/180,l=s*Math.cos(i)+r*Math.sin(i),u=Math.abs(l)/Math.max(.001,t.size*e);c=1-Y(1-a,1,u)}return t.invert?1-c:c}function Tn(t,n,o,e){const a=t.range;if(!a||a.kind==="none")return 1;if(a.kind==="color"){const c=Math.max(n,o,e),i=Math.min(n,o,e);if((c>0?(c-i)/c:0)<a.saturation/100)return 0;const u=cn(n,o,e),g=an(u.hue,a.hue);return 1-Y(a.hueWidth,Math.min(180,a.hueWidth*1.35),g)}const s=(n*.2126+o*.7152+e*.0722)*100,r=Math.abs(s-a.luminance);return 1-Y(a.luminanceWidth,Math.min(100,a.luminanceWidth*1.35),r)}function In(t){return .02+h(t,0,100)/100*.98}function Rn(t,n){const o=h(t,0,100)/100;if(o<=0)return n>=.5?1:0;const e=.02+o*.48;return Y(.5-e,.5+e,n)}const yt=new Map;function Qt(t){const n=yt.get(t.data);if(n)return n;let o="";try{o=atob(t.data)}catch{return null}if(o.length!==t.width*t.height)return null;const e=new Uint8Array(o.length);for(let s=0;s<o.length;s+=1)e[s]=o.charCodeAt(s);const a={width:t.width,height:t.height,data:e};if(yt.set(t.data,a),yt.size>8){const s=yt.keys().next().value;s!==void 0&&yt.delete(s)}return a}function _n(t,n,o,e,a){const s=t.semanticMask;if(!s)return 1;const r=Qt(s);if(!r)return 0;const c=Math.min(r.width-1,Math.max(0,Math.floor((n+.5)/e*r.width))),i=Math.min(r.height-1,Math.max(0,Math.floor((o+.5)/a*r.height))),l=Rn(t.feather,r.data[i*r.width+c]/255);return t.invert?1-l:l}function Bn(t,n,o,e,a){if(e<=0)return;const s=n*o,r=new Uint8Array(s);for(let g=0,m=0;g<s;g+=1,m+=4)r[g]=t[m]*77+t[m+1]*150+t[m+2]*29>>8;const c=Math.max(1,Math.round(Math.min(n,o)*.0035*(.5+e/140))),i=Cn(r,n,o,c,2),l=e/100,u=4+a/100*16;for(let g=0,m=0;g<s;g+=1,m+=4){const R=t[m],E=t[m+1],H=t[m+2],P=128-.168736*R-.331264*E+.5*H,U=128+.5*R-.418688*E-.081312*H,_=jt(P,80,68,120,136)*jt(U,138,130,168,180);if(_<=.01)continue;const z=Math.abs(r[g]-i[g]),f=z/(z+u),k=_*l*(1-f);if(k<=.004)continue;const p=1+(i[g]/Math.max(1,r[g])-1)*k;t[m]=R*p,t[m+1]=E*p,t[m+2]=H*p}}function jt(t,n,o,e,a){return t>=n&&t<=e?1:t<=o||t>=a?0:t<n?(t-o)/(n-o):(a-t)/(a-e)}function Cn(t,n,o,e,a){const s=Uint8Array.from(t),r=new Uint8Array(s.length);for(let c=0;c<a;c+=1)Pn(s,r,n,o,e),En(r,s,n,o,e);return s}function Pn(t,n,o,e,a){const s=a*2+1;for(let r=0;r<e;r+=1){const c=r*o;let i=0;for(let l=-a;l<=a;l+=1)i+=t[c+h(l,0,o-1)];for(let l=0;l<o;l+=1)n[c+l]=i/s,i+=t[c+Math.min(o-1,l+a+1)]-t[c+Math.max(0,l-a)]}}function En(t,n,o,e,a){const s=a*2+1;for(let r=0;r<o;r+=1){let c=0;for(let i=-a;i<=a;i+=1)c+=t[h(i,0,e-1)*o+r];for(let i=0;i<e;i+=1)n[i*o+r]=c/s,c+=t[Math.min(e-1,i+a+1)*o+r]-t[Math.max(0,i-a)*o+r]}}function Fn(t,n,o,e,a){const s=e.masks??[];if(Ln(t,n,o,e.warps??[]),e.skyReplacement?.enabled){const r=s.find(c=>c.semanticMask?.kind==="sky"&&!c.invert)||s.find(c=>c.semanticMask?.kind==="sky");r&&An(t,n,o,r,e.skyReplacement)}return Bn(t,n,o,e.skinSmooth??0,e.skinPreserve??60),Yn(t,n,o,{...e},a),t}function Hn(t,n,o,e,a){const s=(e.masks??[]).filter(f=>f.enabled!==!1);if(!s.length)return t;const r=n/Math.max(1,o),c=s.filter(f=>f.exposure!==0||f.contrast!==0||f.saturation!==0||f.temperature!==0||f.tint!==0||f.range?.kind!=="none"||!!f.semanticMask);if(!c.length)return t;const i=n*o*c.length<=(a?.maxBytes??0),l=new Float64Array(3),u=Math.max(1,Math.ceil(n/2)),g=Math.max(1,Math.ceil(o/2)),m=n/u,R=o/g,E=(f,k,p,v,L)=>{const B=(k+.5)*v-.5,W=(p+.5)*L-.5,N=Math.floor(B),G=Math.floor(W),q=B-N,C=W-G,w=Math.min(u-1,Math.max(0,N)),$=Math.min(u-1,Math.max(0,N+1)),O=Math.min(g-1,Math.max(0,G)),j=Math.min(g-1,Math.max(0,G+1)),V=f[O*u+w],Z=f[O*u+$],J=f[j*u+w],Mt=f[j*u+$],lt=V+(Z-V)*q,mt=J+(Mt-J)*q;return(lt+(mt-lt)*C)/255},H=f=>{const k=new Uint8Array(u*g);for(let p=0;p<g;p+=1)for(let v=0;v<u;v+=1)k[p*u+v]=Math.round(Ft(f,(v+.5)/u,(p+.5)/g,r)*255);return k},P=c.map(f=>i?en(a,`mask:${u}x${g}:${JSON.stringify([f.kind,f.x,f.y,f.size,f.sizeX??f.size,f.sizeY??f.size,f.angle,f.feather,f.invert,f.range])}`,u,g,(k,p)=>Ft(f,(k+.5)/u,(p+.5)/g,r)):H(f)),U=c.map(f=>{const k=h(f.temperature,-100,100)/100,p=h(f.tint,-100,100)/100;return{amountFactor:h(f.amount??100,0,100)/100,exposureFactor:Math.pow(2,h(f.exposure,-5,5)),contrastFactor:Math.max(0,1+h(f.contrast,-100,100)/100),shiftR:k*.11+p*.025,shiftG:-p*.08,shiftB:-(k*.11+p*.025),satFactor:1+h(f.saturation,-100,100)/100}}),_=1/m,z=1/R;for(let f=0;f<o;f+=1){const k=(f+.5)/o;for(let p=0;p<n;p+=1){const v=(p+.5)/n,L=(f*n+p)*4;let B=ut[t[L]],W=ut[t[L+1]],N=ut[t[L+2]],G=1;for(let q=0;q<c.length;q+=1){const C=c[q],w=U[q],$=P[q];let O=$?E($,p,f,_,z):Ft(C,v,k,r);if(C.semanticMask&&(O*=_n(C,p,f,n,o)),C.range&&C.range.kind!=="none"&&(O*=Tn(C,B,W,N)),C.blendMode==="intersect"?(O*=G,G=O):C.blendMode==="subtract"?(O=-O,G=Math.max(0,G+O)):G=Math.max(G,O),Math.abs(O)<=.002||(O*=w.amountFactor,O<=.002))continue;on(B,W,N,w.exposureFactor,l);let j=(l[0]-.5)*w.contrastFactor+.5+w.shiftR,V=(l[1]-.5)*w.contrastFactor+.5+w.shiftG,Z=(l[2]-.5)*w.contrastFactor+.5+w.shiftB;const J=j*.2126+V*.7152+Z*.0722;j=J+(j-J)*w.satFactor,V=J+(V-J)*w.satFactor,Z=J+(Z-J)*w.satFactor,B+=(j-B)*O,W+=(V-W)*O,N+=(Z-N)*O}t[L]=Math.round(h(B,0,1)*255),t[L+1]=Math.round(h(W,0,1)*255),t[L+2]=Math.round(h(N,0,1)*255)}}return t}function h(t,n,o){return Math.min(o,Math.max(n,t))}function tn(t){return t<=.04045?t/12.92:Math.pow((t+.055)/1.055,2.4)}function kn(t){const n=h(t,0,1);return n<=.0031308?n*12.92:1.055*Math.pow(n,1/2.4)-.055}const ht=4096,On=Float32Array.from({length:ht},(t,n)=>tn(n/(ht-1))),Dn=Float32Array.from({length:ht},(t,n)=>kn(n/(ht-1)));function nn(t,n){const o=h(n,0,1)*(ht-1),e=Math.floor(o),a=o-e;return t[e]+(t[Math.min(e+1,ht-1)]-t[e])*a}function Lt(t){return t<0||t>1?tn(t):nn(On,t)}function at(t){return nn(Dn,t)}function Un(t=24*1024*1024){return{maxBytes:Math.max(0,t),bytes:0,maps:new Map}}function en(t,n,o,e,a){const s=t?.maps.get(n);if(s)return t.maps.delete(n),t.maps.set(n,s),s;const r=new Uint8Array(o*e);for(let c=0;c<e;c+=1)for(let i=0;i<o;i+=1)r[c*o+i]=Math.round(h(a(i,c),0,1)*255);if(!t||r.byteLength>t.maxBytes)return r;for(;t.bytes+r.byteLength>t.maxBytes&&t.maps.size;){const c=t.maps.keys().next().value;if(c===void 0)break;const i=t.maps.get(c);t.maps.delete(c),t.bytes-=i?.byteLength??0}return t.maps.set(n,r),t.bytes+=r.byteLength,r}const xt=.82,bt=4096,ut=(()=>{const t=new Float64Array(256);for(let n=0;n<256;n+=1)t[n]=n/255;return t})();function on(t,n,o,e,a){if(e===1){a[0]=t,a[1]=n,a[2]=o;return}let s=Lt(t)*e,r=Lt(n)*e,c=Lt(o)*e;const i=Math.max(s,r,c),l=xt;if(i>l){const u=1-l,m=(l+u*(1-Math.exp(-(i-l)/u)))/i;s*=m,r*=m,c*=m}a[0]=at(s),a[1]=at(r),a[2]=at(c)}function Y(t,n,o){const e=h((o-t)/(n-t),0,1);return e*e*(3-2*e)}function an(t,n){return Math.abs((t-n+540)%360-180)}function cn(t,n,o){const e=Math.max(t,n,o),a=Math.min(t,n,o),s=e-a,r=(e+a)/2;let c=0,i=0;return s>0&&(i=s/(1-Math.abs(2*r-1)),e===t?c=60*((n-o)/s%6):e===n?c=60*((o-t)/s+2):c=60*((t-n)/s+4)),{hue:(c+360)%360,saturation:i,lightness:r}}function rn(t,n,o){const e=(1-Math.abs(2*o-1))*n,a=t/60,s=e*(1-Math.abs(a%2-1));let r=0,c=0,i=0;a<1?(r=e,c=s):a<2?(r=s,c=e):a<3?(c=e,i=s):a<4?(c=s,i=e):a<5?(r=s,i=e):(r=e,i=s);const l=o-e/2;return[r+l,c+l,i+l]}function Xn(t,n,o,e){const a=cn(t,n,o);if(a.saturation<.015)return[t,n,o];let s=a.hue,r=a.saturation,c=a.lightness;for(let i=0;i<Et.length;i+=1){const l=Et[i],u=e[l],g=an(a.hue,vn[i]),m=Math.pow(Math.max(0,1-g/52),2);m<.001||(s+=u.hue*m,r*=Math.max(0,1+u.saturation/100*m),c+=u.luminance/100*.35*m)}return rn((s+360)%360,h(r,0,1),h(c,0,1))}function Ht(t,n,o,e=1){if(e<=1){const r=new Uint8ClampedArray(n*o*4);return sn(t,r,n,o),r}const a=new Uint8ClampedArray(n*o*4),s=new Uint8ClampedArray(n*o*4);for(let r=0;r<e;r+=1){const c=r===0?t:r%2===1?a:s,i=r%2===0?a:s;sn(c,i,n,o)}return e%2===1?a:s}function sn(t,n,o,e){for(let a=0;a<e;a+=1){const s=a*o;for(let r=0;r<o;r+=1){const c=(s+r)*4,i=(s+(r>0?r-1:r))*4,l=(s+(r<o-1?r+1:r))*4,u=((a>0?a-1:a)*o+r)*4,g=((a<e-1?a+1:a)*o+r)*4;n[c]=(t[c]*4+t[i]+t[l]+t[u]+t[g])/8,n[c+1]=(t[c+1]*4+t[i+1]+t[l+1]+t[u+1]+t[g+1])/8,n[c+2]=(t[c+2]*4+t[i+2]+t[l+2]+t[u+2]+t[g+2])/8,n[c+3]=t[c+3]}}}function ct(t,n,o){return t*.2126+n*.7152+o*.0722}function zn(t){const n=[];for(let o=1;o<t.length;o+=1){const e=t[o-1],a=t[o];n.push((a.y-e.y)/Math.max(1e-4,a.x-e.x))}return t.map((o,e)=>{if(e===0)return n[0];if(e===t.length-1)return n[n.length-1];const a=n[e-1],s=n[e];if(a*s<=0)return 0;const r=(a+s)/2,c=3*Math.min(Math.abs(a),Math.abs(s));return Math.sign(r)*Math.min(Math.abs(r),c)})}function Nn(t,n,o){if(!n.length)return t;if(n.length===1)return n[0].y;const e=h(t,0,1);if(e<=n[0].x)return n[0].y;const a=n[n.length-1];if(e>=a.x)return a.y;for(let s=1;s<n.length;s+=1){const r=n[s];if(e>r.x)continue;const c=n[s-1],i=Math.max(1e-4,r.x-c.x),l=(e-c.x)/i,u=l*l,g=u*l,m=2*g-3*u+1,R=g-2*u+l,E=-2*g+3*u,H=g-u,P=m*c.y+R*i*o[s-1]+E*r.y+H*i*o[s];return h(P,0,1)}return a.y}const rt=4096;function ft(t){const n=new Float32Array(rt);if(t.length<=1)return n.fill(t.length?t[0].y:0),n;const o=zn(t);for(let e=0;e<rt;e+=1)n[e]=Nn(e/(rt-1),t,o);return n}function wt(t,n){const o=h(n,0,1)*(rt-1),e=Math.floor(o),a=o-e,s=Math.min(e+1,rt-1);return t[e]+(t[s]-t[e])*a}function kt(t,n){const o=new Float32Array(rt);for(let e=0;e<rt;e+=1)o[e]=wt(n,t[e]);return o}const pt=256;function ln(t,n,o,e){const a=new Float32Array(pt),s=h(t-o,0,1),r=h(s-n,0,1),c=h(t+o,0,1),i=h(c+n,0,1);for(let l=0;l<pt;l+=1){const u=l/(pt-1);a[l]=e==="shadows"?1-Y(r,s,u):Y(c,i,u)}return a}function Yn(t,n,o,e,a){if(!n||!o||t.length<n*o*4)return t;const s=Math.pow(2,h(e.exposure,-5,5)),r=new Float64Array(3),c=new Float64Array(256);for(let b=0;b<256;b+=1)c[b]=Lt(b/255)*s;const i=new Float64Array(256);for(let b=0;b<256;b+=1)i[b]=at(c[b]);const l=Math.max(0,1+h(e.contrast,-100,100)/100),u=h(e.vibrance,-100,100)/100,g=1+h(e.saturation,-100,100)/100,m=h(e.temperature,-100,100)/100,R=h(e.tint,-100,100)/100,E=h(e.vignette,-100,100)/100,H=h(e.grain,0,100)/100,P=h(e.noiseReduction,0,100)/100*.65,U=h(e.sharpening,0,100)/100*1.15,_=h(e.colorNoiseReduction,0,100)/100*.8,z=Math.max(1,n-1),f=Math.max(1,o-1),k=Math.max(1,Math.round(h(e.sharpenRadius,.5,3))),p=P||U||_?Ht(t,n,o,k):null,v=s!==1&&!p,L=h(e.sharpenMasking,0,100)/100,B=p&&U&&L>0?Ht(t,n,o,k+2):null,N=(1-h(e.sharpenDetail,0,100)/100)*.07*.5,G=N+.018,C=.025+h(e.noiseDetail,0,100)/100*.1,w=C+.135,$=h(e.vignetteMidpoint,0,100)/100,O=h(e.vignetteFeather,0,100)/100,V=.6+h(e.vignetteRoundness??50,0,100)/100*.9,Z=.34+$*.4,J=Math.min(1.3,Z+.25+O*.55),Mt=(b,K)=>{const D=b/z*2-1,M=K/f*2-1,d=Math.sqrt(D*D+M*M)/1.18;return Y(Z,J,Math.pow(d,V))},lt=E&&a&&n*o<=a.maxBytes?en(a,`vignette:${n}x${o}:${JSON.stringify([e.vignetteMidpoint,e.vignetteFeather,e.vignetteRoundness])}`,n,o,Mt):null,mt=Math.max(1,Math.round(h(e.grainSize,1,3))),Ut=e.shadows!==0||e.highlights!==0||e.whites!==0||e.blacks!==0,Xt=h(e.shadows,-100,100)/100*.28,zt=h(e.highlights,-100,100)/100*.24,Nt=h(e.whites,-100,100)/100*.18,et=h(e.blacks,-100,100)/100*.22,dt=Ut?new Float32Array(bt):null;if(dt)for(let b=0;b<bt;b+=1){const K=b/(bt-1);dt[b]=Xt*(1-Y(.035,.52,K))+zt*Y(.48,.94,K)+Nt*Y(.78,1,K)+et*(1-Y(0,.44,K))}const gn=h(e.texture,-100,100)/100,Mn=h(e.clarity,-100,100)/100,St=h(e.dehaze,-100,100)/100,Rt=gn!==0?Ht(t,n,o,2):null,Yt=1+St*.35,te=1+St*.25,ne=u!==0||g!==1||St!==0,ee=Et.some(b=>{const K=e.hsl[b];return K.hue!==0||K.saturation!==0||K.luminance!==0}),_t=[e.grading.shadows,e.grading.midtones,e.grading.highlights],Bt=_t.some(b=>b.saturation!==0||b.luminance!==0),Wt=Bt?_t.map(b=>rn((b.hue+360)%360,1,.5)):null,oe=h(e.grading.balance,-100,100)/100,mn=h(e.grading.blending,0,100)/100,dn=h(.5-oe*.3,.1,.9),Gt=.16+mn*.34,yn=Gt*Math.max(.12,1-mn*1.5),xn=h(e.calibration?.shadows??0,-100,100),Kt=h(e.calibration?.redHue??0,-100,100),qt=h(e.calibration?.redSaturation??0,-100,100),$t=h(e.calibration?.greenHue??0,-100,100),Vt=h(e.calibration?.greenSaturation??0,-100,100),Zt=h(e.calibration?.blueHue??0,-100,100),Jt=h(e.calibration?.blueSaturation??0,-100,100),ae=xn!==0||Kt!==0||qt!==0||$t!==0||Vt!==0||Zt!==0||Jt!==0,bn=h(e.vignetteHighlights??0,0,100)/100,pn=h(e.grainRoughness??50,0,100)/100,Ct=b=>b.length===2&&b[0].x===0&&b[0].y===0&&b[1].x===1&&b[1].y===1,Pt=!(Ct(e.curves.rgb)&&Ct(e.curves.red)&&Ct(e.curves.green)&&Ct(e.curves.blue))?{red:kt(ft(e.curves.rgb),ft(e.curves.red)),green:kt(ft(e.curves.rgb),ft(e.curves.green)),blue:kt(ft(e.curves.rgb),ft(e.curves.blue))}:null,ce=Bt?ln(dn,Gt,yn,"shadows"):null,re=Bt?ln(dn,Gt,yn,"highlights"):null,se=Wt?Wt.map(b=>[b[0]-.5,b[1]-.5,b[2]-.5]):null,ie=_t.map(b=>b.saturation/100*.65),le=_t.map(b=>b.luminance/100*.16);for(let b=0;b<o;b+=1)for(let K=0;K<n;K+=1){const D=(b*n+K)*4;let M=ut[t[D]],d=ut[t[D+1]],y=ut[t[D+2]];if(p){const S=p[D]/255,x=p[D+1]/255,A=p[D+2]/255,T=ct(S,x,A),F=ct(M,d,y);if(P){const I=P*(1-Y(C,w,Math.abs(F-T)));M+=(S-M)*I,d+=(x-d)*I,y+=(A-y)*I}if(U){let I=(ct(M,d,y)-T)*U;if(I*=Y(N,G,Math.abs(I)),B){const Q=B[D]/255,tt=B[D+1]/255,nt=B[D+2]/255,At=Math.abs(F-ct(Q,tt,nt));I*=1-L+L*Y(.012,.09,At)}I=h(I,-.3,.3),M+=I,d+=I,y+=I}if(_){const I=M*.299+d*.587+y*.114;M+=(I-M)*_,d+=(I-d)*_,y+=(I-y)*_}}if(s!==1)if(v){const S=t[D],x=t[D+1],A=t[D+2];let T=c[S],F=c[x],I=c[A];const Q=T>F?T>I?T:I:F>I?F:I;if(Q<=xt)M=i[S],d=i[x],y=i[A];else{const tt=1-xt,At=(xt+tt*(1-Math.exp(-(Q-xt)/tt)))/Q;T*=At,F*=At,I*=At,M=at(T),d=at(F),y=at(I)}}else on(M,d,y,s,r),M=r[0],d=r[1],y=r[2];M=(M-.5)*l+.5,d=(d-.5)*l+.5,y=(y-.5)*l+.5;let ot=h(M*.2126+d*.7152+y*.0722,0,1);if(dt){const S=ot*(bt-1),x=S|0,A=S-x,T=x+1<bt?x+1:x,F=dt[x]+(dt[T]-dt[x])*A;M+=F,d+=F,y+=F}if(M+=m*.11+R*.025,d-=R*.08,y-=m*.11+R*.025,Rt){const S=Rt[D]/255,x=Rt[D+1]/255,A=Rt[D+2]/255,T=h((ct(M,d,y)-ct(S,x,A))*gn*1.6,-.25,.25);M+=T,d+=T,y+=T}if(Mn){const S=4*ot*(1-ot),x=Mn*.55*(ot-.5)*S;M+=x,d+=x,y+=x}if(St&&(M=(M-.5)*Yt+.5,d=(d-.5)*Yt+.5,y=(y-.5)*Yt+.5),ot=h(M*.2126+d*.7152+y*.0722,0,1),ne){const S=M*.2126+d*.7152+y*.0722,x=Math.max(M,d,y)-Math.min(M,d,y),A=1+u*(1-h(x*1.8,0,1)),T=g*(St?te:1);M=S+(M-S)*T*A,d=S+(d-S)*T*A,y=S+(y-S)*T*A}if(ee&&([M,d,y]=Xn(M,d,y,e.hsl)),Bt&&Wt){const S=Math.min(pt-1,Math.max(0,Math.round(ot*(pt-1)))),x=ce[S],A=re[S],T=Math.max(0,1-x-A);for(let F=0;F<3;F+=1){const I=F===0?x:F===1?T:A,Q=ie[F]*I;if(Q>0){const nt=se[F];M+=nt[0]*Q,d+=nt[1]*Q,y+=nt[2]*Q}const tt=le[F]*I;tt&&(M+=tt,d+=tt,y+=tt)}}if(ae){const S=xn/100*.8*(1-Y(0,.45,ot));if(S&&(M+=S*.025,d-=S*.08,y+=S*.025),Kt||qt){const x=h((M-Math.max(d,y))*4,0,1);if(x>0){const A=Kt*.0018*x;d+=A*M,y-=A*M;const T=qt*.005*x;M+=(M-(d+y)/2)*T}}if($t||Vt){const x=h((d-Math.max(M,y))*4,0,1);if(x>0){const A=$t*.0018*x;y+=A*d,M-=A*d;const T=Vt*.005*x;d+=(d-(M+y)/2)*T}}if(Zt||Jt){const x=h((y-Math.max(M,d))*4,0,1);if(x>0){const A=Zt*.0018*x;M+=A*y,d-=A*y;const T=Jt*.005*x;y+=(y-(M+d)/2)*T}}}if(Pt&&(M=wt(Pt.red,M),d=wt(Pt.green,d),y=wt(Pt.blue,y)),E){const S=lt?lt[D/4]/255:Mt(K,b);let x=1-E*.34*S;if(bn>0){const A=Y(.62,1,ot);x+=(1-x)*A*bn}M*=x,d*=x,y*=x}if(H){const S=Math.floor(K/mt),x=Math.floor(b/mt),A=Math.sin(S*12.9898+x*78.233)*43758.5453,T=(A-Math.floor(A))*2-1,F=Math.sin(S*7.7+x*3.3)*26544.5769,I=1-pn*.5+pn*(F-Math.floor(F))*1.5,Q=ct(M,d,y),tt=4*Q*(1-Q),nt=T*H*.09*I*(.35+.65*tt);M+=nt,d+=nt,y+=nt}t[D]=Math.round(h(M,0,1)*255),t[D+1]=Math.round(h(d,0,1)*255),t[D+2]=Math.round(h(y,0,1)*255)}return t}const Wn=256,Gn=1,Kn=254,qn=2e6;function Tt(){return new Array(Wn).fill(0)}function vt(){return{mean:0,median:0,mode:0,standardDeviation:0,lowPercentile:0,highPercentile:0,clipLow:0,clipHigh:0,effectiveLevels:0}}function hn(){return{bins:{red:Tt(),green:Tt(),blue:Tt(),luma:Tt()},sampleCount:0,stats:{red:vt(),green:vt(),blue:vt(),luma:vt()}}}function Ot(t,n,o){if(n<=0)return 0;const e=o*n;let a=0;for(let s=0;s<t.length;s+=1){const r=t[s]??0;if(!(r<=0)){if(a+r>=e){const c=s+(e-a)/r-.5;return Math.min(t.length-1,Math.max(0,c))}a+=r}}return t.length-1}function It(t,n){if(n<=0)return vt();let o=0,e=0,a=0,s=0,r=0,c=0,i=0;for(let g=0;g<t.length;g+=1){const m=t[g]??0;m<=0||(r+=1,o+=g*m,e+=g*g*m,m>s&&(s=m,a=g),g<=Gn&&(c+=m),g>=Kn&&(i+=m))}const l=o/n,u=Math.max(0,e/n-l*l);return{mean:l,median:Ot(t,n,.5),mode:a,standardDeviation:Math.sqrt(u),lowPercentile:Ot(t,n,.005),highPercentile:Ot(t,n,.995),clipLow:c/n,clipHigh:i/n,effectiveLevels:r}}function $n(t,n,o){const e=hn().bins,a=Math.max(0,Math.floor(n)),s=Math.max(0,Math.floor(o)),r=Math.min(a*s,Math.floor(t.length/4));if(!a||!s||r<=0)return hn();const c=Math.max(1,Math.min(s,Math.round(qn/a))),i=s/c;let l=0;for(let u=0;u<c;u+=1){const g=(u*2654435761>>>0)%1024/1024;let R=Math.min(s-1,Math.floor((u+g)*i))*a*4;for(let E=0;E<a;E+=1){if(t[R+3]===0){R+=4;continue}const H=t[R]??0,P=t[R+1]??0,U=t[R+2]??0;e.red[H]+=1,e.green[P]+=1,e.blue[U]+=1,e.luma[H*54+P*183+U*19+128>>8]+=1,l+=1,R+=4}}return{bins:e,sampleCount:l,stats:{red:It(e.red,l),green:It(e.green,l),blue:It(e.blue,l),luma:It(e.luma,l)}}}let X=null,Dt=null,un=null,st=null;const fn=Un();let it=null,gt=null;function Vn(t,n,o){const e=(o.skyReplacement?.enabled?o.masks??[]:[]).filter(a=>a.semanticMask?.kind==="sky").map(a=>[a.invert,a.semanticMask]);return JSON.stringify([t,n,{...o,masks:[]},e])}const Zn=42e4,Jn=22e4,Qn=32e5;function jn(t){if(!X)return null;const n=X.width*X.height,o=Math.min(Qn,Math.max(Jn,Math.round(t||Zn)));if(n<=o)return X;if(st&&st.pixelBudget>=o&&st.pixelBudget<=o*1.6)return st.base;const e=Math.sqrt(o/n),a=Math.max(1,Math.round(X.width*e)),s=Math.max(1,Math.round(X.height*e)),r=new OffscreenCanvas(X.width,X.height),c=r.getContext("2d"),l=new OffscreenCanvas(a,s).getContext("2d",{alpha:!0});return!c||!l?X:(c.putImageData(new ImageData(X.data,X.width,X.height),0,0),l.imageSmoothingEnabled=!0,l.imageSmoothingQuality="high",l.drawImage(r,0,0,a,s),st={pixelBudget:o,base:{width:a,height:s,data:l.getImageData(0,0,a,s).data}},st.base)}self.onmessage=t=>{const n=t.data;if(n.type==="init"){X={assetId:n.assetId,baseKey:n.baseKey,width:n.width,height:n.height,data:new Uint8ClampedArray(n.data)},Dt=new OffscreenCanvas(n.width,n.height),un=null,st=null,it=null,gt=null,self.postMessage({type:"base-ready",baseKey:n.baseKey});return}if(!X||!Dt||X.assetId!==n.assetId||X.baseKey!==n.baseKey)return;const o=n.interactive?jn(n.interactiveMaxPixels??0):X;if(!o)return;const e=n.interactive?un??=new OffscreenCanvas(o.width,o.height):Dt;(e.width!==o.width||e.height!==o.height)&&(e.width=o.width,e.height=o.height);const a=!n.original&&!n.geometry,s=a?Vn(n.baseKey,n.spots,n.adjustments):null,r=s!==null&&it!==null&&it.key===s&&it.width===o.width&&it.height===o.height;(!gt||gt.width!==o.width||gt.height!==o.height)&&(gt={width:o.width,height:o.height,data:new Uint8ClampedArray(o.width*o.height*4)});const c=gt.data;r?c.set(it.data):(c.set(o.data),a&&(n.spots.length&&wn(c,o.width,o.height,n.spots),Fn(c,o.width,o.height,n.adjustments,fn),it={key:s,width:o.width,height:o.height,data:c.slice()})),a&&Hn(c,o.width,o.height,n.adjustments,fn);const i=e.getContext("2d");if(!i)return;i.putImageData(new ImageData(c,o.width,o.height),0,0);const l={type:"result",requestId:n.requestId,assetId:n.assetId,baseKey:n.baseKey,width:o.width,height:o.height,displayWidth:X.width,displayHeight:X.height,bitmap:e.transferToImageBitmap(),histogram:!n.original&&n.includeHistogram?$n(c,o.width,o.height):null};self.postMessage(l,{transfer:[l.bitmap]})}})();\n', sp = typeof self < "u" && self.Blob && new Blob(["(self.URL || self.webkitURL).revokeObjectURL(self.location.href);", Yp], { type: "text/javascript;charset=utf-8" });
function I1(r) {
  let h;
  try {
    if (h = sp && (self.URL || self.webkitURL).createObjectURL(sp), !h) throw "";
    const u = new Worker(h, {
      name: r?.name
    });
    return u.addEventListener("error", () => {
      (self.URL || self.webkitURL).revokeObjectURL(h);
    }), u;
  } catch {
    return new Worker(
      "data:text/javascript;charset=utf-8," + encodeURIComponent(Yp),
      {
        name: r?.name
      }
    );
  }
}
const X1 = `#version 300 es
precision highp float;
layout(location = 0) in vec2 a_position;
out vec2 v_uv;
void main() {
  // 纹理原点在左上、裁剪空间原点在左下：这里翻转 v，保证画面不上下颠倒。
  v_uv = vec2(a_position.x, -a_position.y) * 0.5 + 0.5;
  gl_Position = vec4(a_position, 0.0, 1.0);
}
`, J1 = `#version 300 es
precision highp float;

in vec2 v_uv;
out vec4 fragColor;

uniform sampler2D u_image;
uniform sampler2D u_blurImage;       // 基图的 1-4-1 两次模糊，供「纹理」用
uniform sampler2D u_curves;          // 256×1：R/G/B 三通道曲线
uniform sampler2D u_gradingWeights;  // 256×1：R=阴影权重 G=高光权重 B=中间调

uniform float u_hasCurves;
uniform float u_exposure;            // EV 增益
uniform float u_contrast;            // 1 + contrast/100
uniform vec4 u_tone;                 // 影调四段（已乘系数）
uniform vec2 u_tempTint;             // temperature/100, tint/100
uniform float u_clarity;             // -1..1
uniform float u_dehaze;              // -1..1
uniform float u_texture;             // -1..1
uniform float u_saturation;          // 1 + sat/100
uniform float u_vibrance;            // -1..1
uniform vec3 u_hsl[8];               // hue(deg), sat/100, lum/100
uniform vec4 u_grading[3];           // hue(deg), sat, lum, (保留)
uniform float u_gradingBalance;      // -1..1
uniform float u_gradingBlending;     // 0..1
uniform vec4 u_calibA;               // shadows, redHue, redSat, greenHue（均已 /100）
uniform vec2 u_calibB;               // greenSat, blueHue
uniform float u_calibBlueSat;
uniform float u_vignette;            // -1..1
uniform vec4 u_vignetteShape;        // midpoint, feather, roundness, highlights
uniform vec2 u_grain;                // amount, roughness
uniform float u_grainSize;

const float SHOULDER_START = 0.82;

float srgbToLinear(float c) {
  return c <= 0.04045 ? c / 12.92 : pow((c + 0.055) / 1.055, 2.4);
}
float linearToSrgb(float c) {
  float b = clamp(c, 0.0, 1.0);
  return b <= 0.0031308 ? b * 12.92 : 1.055 * pow(b, 1.0 / 2.4) - 0.055;
}
float lumaOf(vec3 c) {
  return dot(c, vec3(0.2126, 0.7152, 0.0722));
}
float hueDistance(float a, float b) {
  return abs(mod(a - b + 540.0, 360.0) - 180.0);
}

vec3 rgbToHsl(vec3 c) {
  float maxC = max(c.r, max(c.g, c.b));
  float minC = min(c.r, min(c.g, c.b));
  float delta = maxC - minC;
  float lightness = (maxC + minC) * 0.5;
  float hue = 0.0;
  float saturation = 0.0;
  if (delta > 0.0) {
    saturation = delta / (1.0 - abs(2.0 * lightness - 1.0));
    if (maxC == c.r) hue = 60.0 * mod((c.g - c.b) / delta, 6.0);
    else if (maxC == c.g) hue = 60.0 * ((c.b - c.r) / delta + 2.0);
    else hue = 60.0 * ((c.r - c.g) / delta + 4.0);
  }
  return vec3(mod(hue + 360.0, 360.0), saturation, lightness);
}

vec3 hslToRgb(float hue, float saturation, float lightness) {
  float chroma = (1.0 - abs(2.0 * lightness - 1.0)) * saturation;
  float h = hue / 60.0;
  float x = chroma * (1.0 - abs(mod(h, 2.0) - 1.0));
  vec3 rgb = vec3(0.0);
  if (h < 1.0) rgb = vec3(chroma, x, 0.0);
  else if (h < 2.0) rgb = vec3(x, chroma, 0.0);
  else if (h < 3.0) rgb = vec3(0.0, chroma, x);
  else if (h < 4.0) rgb = vec3(0.0, x, chroma);
  else if (h < 5.0) rgb = vec3(x, 0.0, chroma);
  else rgb = vec3(chroma, 0.0, x);
  float m = lightness - chroma * 0.5;
  return rgb + m;
}

void main() {
  vec4 source = texture(u_image, v_uv);
  vec3 rgb = source.rgb;

  // 曝光：线性空间 × EV，高光肩部压缩后再回 sRGB。
  if (abs(u_exposure - 1.0) > 0.0001) {
    vec3 lin = vec3(srgbToLinear(rgb.r), srgbToLinear(rgb.g), srgbToLinear(rgb.b)) * u_exposure;
    float peak = max(lin.r, max(lin.g, lin.b));
    if (peak > SHOULDER_START) {
      float shoulderRange = 1.0 - SHOULDER_START;
      float mapped = SHOULDER_START + shoulderRange * (1.0 - exp(-(peak - SHOULDER_START) / shoulderRange));
      lin *= mapped / peak;
    }
    rgb = vec3(linearToSrgb(lin.r), linearToSrgb(lin.g), linearToSrgb(lin.b));
  }

  // 对比度
  rgb = (rgb - 0.5) * u_contrast + 0.5;

  // 影调四段
  float toneLuma = clamp(lumaOf(rgb), 0.0, 1.0);
  float shadowW = 1.0 - smoothstep(0.035, 0.52, toneLuma);
  float highlightW = smoothstep(0.48, 0.94, toneLuma);
  float whiteW = smoothstep(0.78, 1.0, toneLuma);
  float blackW = 1.0 - smoothstep(0.0, 0.44, toneLuma);
  rgb += u_tone.x * shadowW + u_tone.y * highlightW + u_tone.z * whiteW + u_tone.w * blackW;

  // 色温 / 色调
  rgb.r += u_tempTint.x * 0.11 + u_tempTint.y * 0.025;
  rgb.g -= u_tempTint.y * 0.08;
  rgb.b -= u_tempTint.x * 0.11 + u_tempTint.y * 0.025;

  // 纹理（中频 unsharp）：与基图的模糊副本比亮度差
  if (abs(u_texture) > 0.0001) {
    vec3 blurredRgb = texture(u_blurImage, v_uv).rgb;
    float tDelta = clamp((lumaOf(rgb) - lumaOf(blurredRgb)) * u_texture * 1.6, -0.25, 0.25);
    rgb += tDelta;
  }

  // 清晰度（中间调 S 形）
  if (abs(u_clarity) > 0.0001) {
    float l = clamp(lumaOf(rgb), 0.0, 1.0);
    float mid = 4.0 * l * (1.0 - l);
    rgb += u_clarity * 0.55 * (l - 0.5) * mid;
  }

  // 去薄雾
  if (abs(u_dehaze) > 0.0001) {
    rgb = (rgb - 0.5) * (1.0 + u_dehaze * 0.35) + 0.5;
  }

  // 饱和度 / 自然饱和度
  float gray = dot(rgb, vec3(0.2126, 0.7152, 0.0722));
  float currentSat = max(rgb.r, max(rgb.g, rgb.b)) - min(rgb.r, min(rgb.g, rgb.b));
  float vibScale = 1.0 + u_vibrance * (1.0 - clamp(currentSat * 1.8, 0.0, 1.0));
  float satScale = u_saturation * (abs(u_dehaze) > 0.0001 ? (1.0 + u_dehaze * 0.25) : 1.0);
  rgb = gray + (rgb - gray) * satScale * vibScale;

  // HSL 混色器（8 通道）
  {
    vec3 hsl = rgbToHsl(rgb);
    if (hsl.y >= 0.015) {
      float hue = hsl.x;
      float saturation = hsl.y;
      float lightness = hsl.z;
      const float centers[8] = float[8](0.0, 30.0, 60.0, 120.0, 180.0, 240.0, 270.0, 300.0);
      for (int index = 0; index < 8; index += 1) {
        float distance = hueDistance(hsl.x, centers[index]);
        float weight = pow(max(0.0, 1.0 - distance / 52.0), 2.0);
        if (weight < 0.001) continue;
        hue += u_hsl[index].x * weight;
        saturation *= max(0.0, 1.0 + u_hsl[index].y * weight);
        lightness += u_hsl[index].z * 0.35 * weight;
      }
      rgb = hslToRgb(mod(hue + 360.0, 360.0), clamp(saturation, 0.0, 1.0), clamp(lightness, 0.0, 1.0));
    }
  }

  // 三向色轮分级（权重查表与 CPU 同源）
  {
    float l = clamp(lumaOf(rgb), 0.0, 1.0);
    vec3 weights = texture(u_gradingWeights, vec2(l, 0.5)).rgb;
    float shadows = weights.r;
    float highlights = weights.g;
    float midtones = max(0.0, 1.0 - shadows - highlights);
    float groupWeights[3] = float[3](shadows, midtones, highlights);
    for (int group = 0; group < 3; group += 1) {
      float weight = groupWeights[group];
      float strength = (u_grading[group].y / 100.0) * 0.65 * weight;
      if (strength > 0.0) {
        vec3 tintRgb = hslToRgb(mod(u_grading[group].x + 360.0, 360.0), 1.0, 0.5);
        rgb += (tintRgb - 0.5) * strength;
      }
      float light = (u_grading[group].z / 100.0) * 0.16 * weight;
      if (abs(light) > 0.0) rgb += light;
    }
  }

  // 校准：阴影色调 + 三原色交叉混合
  {
    float l = clamp(lumaOf(rgb), 0.0, 1.0);
    float shadowTint = u_calibA.x * 0.8 * (1.0 - smoothstep(0.0, 0.45, l));
    rgb.r += shadowTint * 0.025;
    rgb.g -= shadowTint * 0.08;
    rgb.b += shadowTint * 0.025;
    float wR = clamp((rgb.r - max(rgb.g, rgb.b)) * 4.0, 0.0, 1.0);
    if (wR > 0.0 && (abs(u_calibA.y) > 0.0 || abs(u_calibA.z) > 0.0)) {
      float k = u_calibA.y * 0.0018 * wR;
      rgb.g += k * rgb.r;
      rgb.b -= k * rgb.r;
      float s = u_calibA.z * 0.005 * wR;
      rgb.r += (rgb.r - (rgb.g + rgb.b) * 0.5) * s;
    }
    float wG = clamp((rgb.g - max(rgb.r, rgb.b)) * 4.0, 0.0, 1.0);
    if (wG > 0.0 && (abs(u_calibA.w) > 0.0 || abs(u_calibB.x) > 0.0)) {
      float k = u_calibA.w * 0.0018 * wG;
      rgb.b += k * rgb.g;
      rgb.r -= k * rgb.g;
      float s = u_calibB.x * 0.005 * wG;
      rgb.g += (rgb.g - (rgb.r + rgb.b) * 0.5) * s;
    }
    float wB = clamp((rgb.b - max(rgb.r, rgb.g)) * 4.0, 0.0, 1.0);
    if (wB > 0.0 && (abs(u_calibB.y) > 0.0 || abs(u_calibBlueSat) > 0.0)) {
      float k = u_calibB.y * 0.0018 * wB;
      rgb.r += k * rgb.b;
      rgb.g -= k * rgb.b;
      float s = u_calibBlueSat * 0.005 * wB;
      rgb.b += (rgb.b - (rgb.r + rgb.g) * 0.5) * s;
    }
  }

  // 曲线（RGB + 分通道，256 级查表与 CPU 同源）
  if (u_hasCurves > 0.5) {
    rgb = vec3(
      texture(u_curves, vec2(clamp(rgb.r, 0.0, 1.0), 0.5)).r,
      texture(u_curves, vec2(clamp(rgb.g, 0.0, 1.0), 0.5)).g,
      texture(u_curves, vec2(clamp(rgb.b, 0.0, 1.0), 0.5)).b
    );
  }

  // 暗角
  if (abs(u_vignette) > 0.0001) {
    float midpoint = u_vignetteShape.x;
    float feather = u_vignetteShape.y;
    float roundness = u_vignetteShape.z;
    float vignetteHighlights = u_vignetteShape.w;
    float distExponent = 0.6 + roundness * 0.9;
    float vignetteStart = 0.34 + midpoint * 0.4;
    float vignetteEnd = min(1.3, vignetteStart + 0.25 + feather * 0.55);
    vec2 n = v_uv * 2.0 - 1.0;
    float distance = sqrt(n.x * n.x + n.y * n.y) / 1.18;
    float falloff = smoothstep(vignetteStart, vignetteEnd, pow(distance, distExponent));
    float factor = 1.0 - u_vignette * 0.34 * falloff;
    if (vignetteHighlights > 0.0) {
      float l = clamp(lumaOf(rgb), 0.0, 1.0);
      float bright = smoothstep(0.62, 1.0, l);
      factor += (1.0 - factor) * bright * vignetteHighlights;
    }
    rgb *= factor;
  }

  // 颗粒
  if (abs(u_grain.x) > 0.0001) {
    float grainStep = max(1.0, u_grainSize);
    float cellX = floor((v_uv.x * 4096.0) / grainStep);
    float cellY = floor((v_uv.y * 4096.0) / grainStep);
    float noiseSample = fract(sin(cellX * 12.9898 + cellY * 78.233) * 43758.5453);
    float noise = noiseSample * 2.0 - 1.0;
    float ampSample = fract(sin(cellX * 7.7 + cellY * 3.3) * 26544.5769);
    float amp = 1.0 - u_grain.y * 0.5 + u_grain.y * ampSample * 1.5;
    float grainLuma = lumaOf(rgb);
    float midtoneWeight = 4.0 * grainLuma * (1.0 - grainLuma);
    float amount = noise * u_grain.x * 0.09 * amp * (0.35 + 0.65 * midtoneWeight);
    rgb += amount;
  }

  fragColor = vec4(clamp(rgb, 0.0, 1.0), source.a);
}
`;
function cp(r) {
  return r.masks?.length ? "masks" : r.warps?.length ? "warps" : r.spots?.length ? "spots" : r.skyReplacement?.enabled ? "sky" : (r.skinSmooth ?? 0) !== 0 ? "skin" : r.noiseReduction !== 0 || r.colorNoiseReduction !== 0 ? "noiseReduction" : r.sharpening !== 0 ? "sharpening" : null;
}
const P1 = {
  masks: "含蒙版",
  warps: "含液化",
  spots: "含污点修复",
  sky: "天空替换",
  skin: "磨皮",
  noiseReduction: "降噪",
  sharpening: "锐化"
};
function up(r, h, u) {
  const c = r.createShader(h);
  return c ? (r.shaderSource(c, u), r.compileShader(c), r.getShaderParameter(c, r.COMPILE_STATUS) ? c : (console.error("[photo-adjust-gl] shader compile failed:", r.getShaderInfoLog(c)), r.deleteShader(c), null)) : null;
}
function Ec(r, h, u, c) {
  const g = r.createTexture();
  return g ? (r.bindTexture(r.TEXTURE_2D, g), r.texParameteri(r.TEXTURE_2D, r.TEXTURE_WRAP_S, r.CLAMP_TO_EDGE), r.texParameteri(r.TEXTURE_2D, r.TEXTURE_WRAP_T, r.CLAMP_TO_EDGE), r.texParameteri(r.TEXTURE_2D, r.TEXTURE_MIN_FILTER, r.LINEAR), r.texParameteri(r.TEXTURE_2D, r.TEXTURE_MAG_FILTER, r.LINEAR), r.texImage2D(r.TEXTURE_2D, 0, r.RGBA, u, c, 0, r.RGBA, r.UNSIGNED_BYTE, h), g) : null;
}
class _1 {
  canvas = null;
  gl = null;
  program = null;
  uniforms = null;
  imageTexture = null;
  lastDataSet = null;
  blurTexture = null;
  blurBuiltFor = "";
  curvesTexture = null;
  gradingTexture = null;
  imageWidth = 0;
  imageHeight = 0;
  curveCacheKey = "";
  gradingCacheKey = "";
  static isSupported() {
    if (typeof OffscreenCanvas > "u") return !1;
    try {
      return !!new OffscreenCanvas(2, 2).getContext("webgl2");
    } catch {
      return !1;
    }
  }
  get ready() {
    return !!(this.gl && this.program && this.imageTexture);
  }
  ensureContext() {
    if (this.gl && this.program) return this.gl;
    const h = new OffscreenCanvas(2, 2), u = h.getContext("webgl2", {
      alpha: !0,
      premultipliedAlpha: !1,
      antialias: !1,
      preserveDrawingBuffer: !1
    });
    if (!u) return null;
    const c = up(u, u.VERTEX_SHADER, X1), g = up(u, u.FRAGMENT_SHADER, J1);
    if (!c || !g) return null;
    const m = u.createProgram();
    if (!m) return null;
    if (u.attachShader(m, c), u.attachShader(m, g), u.linkProgram(m), u.deleteShader(c), u.deleteShader(g), !u.getProgramParameter(m, u.LINK_STATUS))
      return console.error("[photo-adjust-gl] program link failed:", u.getProgramInfoLog(m)), null;
    const b = u.createBuffer();
    u.bindBuffer(u.ARRAY_BUFFER, b), u.bufferData(
      u.ARRAY_BUFFER,
      new Float32Array([-1, -1, 3, -1, -1, 3]),
      u.STATIC_DRAW
    ), u.enableVertexAttribArray(0), u.vertexAttribPointer(0, 2, u.FLOAT, !1, 0, 0);
    const A = (v) => u.getUniformLocation(m, v);
    return this.canvas = h, this.gl = u, this.program = m, this.uniforms = {
      image: A("u_image"),
      blurImage: A("u_blurImage"),
      curves: A("u_curves"),
      gradingWeights: A("u_gradingWeights"),
      hasCurves: A("u_hasCurves"),
      exposure: A("u_exposure"),
      contrast: A("u_contrast"),
      tone: A("u_tone"),
      tempTint: A("u_tempTint"),
      clarity: A("u_clarity"),
      dehaze: A("u_dehaze"),
      texture: A("u_texture"),
      saturation: A("u_saturation"),
      vibrance: A("u_vibrance"),
      hsl: A("u_hsl"),
      grading: A("u_grading"),
      gradingBalance: A("u_gradingBalance"),
      gradingBlending: A("u_gradingBlending"),
      calibA: A("u_calibA"),
      calibB: A("u_calibB"),
      calibBlueSat: A("u_calibBlueSat"),
      vignette: A("u_vignette"),
      vignetteShape: A("u_vignetteShape"),
      grain: A("u_grain"),
      grainSize: A("u_grainSize")
    }, u;
  }
  setBase(h, u, c) {
    const g = this.ensureContext();
    if (!g || !this.uniforms) return !1;
    if (this.lastDataSet === h && this.imageTexture && this.imageWidth === u && this.imageHeight === c)
      return !0;
    if (this.lastDataSet = h, this.imageTexture && this.imageWidth === u && this.imageHeight === c)
      return g.bindTexture(g.TEXTURE_2D, this.imageTexture), g.texSubImage2D(g.TEXTURE_2D, 0, 0, 0, u, c, g.RGBA, g.UNSIGNED_BYTE, h), this.blurBuiltFor = "", !0;
    this.imageTexture && g.deleteTexture(this.imageTexture);
    const m = Ec(g, new Uint8Array(h.buffer, h.byteOffset, h.length), u, c);
    return m ? (this.imageTexture = m, this.imageWidth = u, this.imageHeight = c, this.blurBuiltFor = "", !0) : !1;
  }
  syncCurves(h) {
    const u = this.gl, c = this.uniforms;
    if (!u || !c) return !1;
    const g = (j) => j.length === 2 && j[0].x === 0 && j[0].y === 0 && j[1].x === 1 && j[1].y === 1;
    if (g(h.curves.rgb) && g(h.curves.red) && g(h.curves.green) && g(h.curves.blue))
      return u.uniform1f(c.hasCurves, 0), !0;
    const b = JSON.stringify(h.curves);
    if (b === this.curveCacheKey && this.curvesTexture)
      return u.uniform1f(c.hasCurves, 1), !0;
    const A = Ln(h.curves.rgb), v = zl(A, Ln(h.curves.red)), y = zl(A, Ln(h.curves.green)), S = zl(A, Ln(h.curves.blue)), C = new Uint8Array(256 * 4);
    for (let j = 0; j < 256; j += 1) {
      const L = j / 255 * 4095, Z = Math.floor(L), it = L - Z, mt = Math.min(Z + 1, 4095), tt = (Y) => (Y[Z] + (Y[mt] - Y[Z]) * it) * 255;
      C[j * 4] = Math.round(tt(v)), C[j * 4 + 1] = Math.round(tt(y)), C[j * 4 + 2] = Math.round(tt(S)), C[j * 4 + 3] = 255;
    }
    this.curvesTexture && u.deleteTexture(this.curvesTexture);
    const k = Ec(u, C, 256, 1);
    return k ? (this.curvesTexture = k, this.curveCacheKey = b, u.uniform1f(c.hasCurves, 1), !0) : !1;
  }
  syncGrading(h) {
    const u = this.gl, c = this.uniforms;
    if (!u || !c) return;
    const g = h.grading.balance / 100, m = h.grading.blending / 100, b = `${g}:${m}`;
    if (b === this.gradingCacheKey && this.gradingTexture) return;
    const A = Math.min(0.9, Math.max(0.1, 0.5 - g * 0.3)), v = 0.16 + m * 0.34, y = v * Math.max(0.12, 1 - m * 1.5), S = Oc(A, v, y, "shadows"), C = Oc(A, v, y, "highlights"), k = new Uint8Array(256 * 4);
    for (let L = 0; L < 256; L += 1)
      k[L * 4] = Math.round(S[L] * 255), k[L * 4 + 1] = Math.round(C[L] * 255), k[L * 4 + 2] = Math.round(Math.max(0, 1 - S[L] - C[L]) * 255), k[L * 4 + 3] = 255;
    this.gradingTexture && u.deleteTexture(this.gradingTexture);
    const j = Ec(u, k, 256, 1);
    j && (this.gradingTexture = j, this.gradingCacheKey = b);
  }
  /**
   * 「纹理」用的模糊副本：基图做两次 1-4-1 模糊（与 CPU 的 buildBlurredCopy 同核）。
   * 只跟基图有关，按图构建一次；拖动纹理滑杆时不再重算。
   */
  ensureBlurTexture(h, u, c) {
    const g = this.gl;
    if (!g) return null;
    const m = `${u}x${c}`;
    if (this.blurTexture && this.blurBuiltFor === m) return this.blurTexture;
    const b = Vc(h, u, c, 2);
    this.blurTexture && g.deleteTexture(this.blurTexture);
    const A = Ec(
      g,
      new Uint8Array(b.buffer, b.byteOffset, b.length),
      u,
      c
    );
    return A ? (this.blurTexture = A, this.blurBuiltFor = m, A) : null;
  }
  /**
   * 渲染一帧到内部画布；返回耗时与输出尺寸。
   * 调用方再把画布内容 blit 到显示 canvas（显示 canvas 保持 2D 上下文）。
   */
  render(h, u, c, g) {
    const m = this.ensureContext(), b = this.uniforms, A = this.canvas;
    if (!m || !b || !A || !this.setBase(h, u, c)) return null;
    const v = performance.now();
    if ((A.width !== u || A.height !== c) && (A.width = u, A.height = c), m.viewport(0, 0, u, c), m.useProgram(this.program), !this.syncCurves(g)) return null;
    this.syncGrading(g), m.activeTexture(m.TEXTURE0), m.bindTexture(m.TEXTURE_2D, this.imageTexture), m.uniform1i(b.image, 0);
    const y = Math.min(100, Math.max(-100, g.texture)) / 100;
    if (m.activeTexture(m.TEXTURE3), Math.abs(y) > 1e-4) {
      const Z = this.ensureBlurTexture(h, u, c);
      m.bindTexture(m.TEXTURE_2D, Z ?? this.imageTexture);
    } else
      m.bindTexture(m.TEXTURE_2D, this.imageTexture);
    m.uniform1i(b.blurImage, 3), m.uniform1f(b.texture, y), m.activeTexture(m.TEXTURE1), m.bindTexture(m.TEXTURE_2D, this.curvesTexture), m.uniform1i(b.curves, 1), m.activeTexture(m.TEXTURE2), m.bindTexture(m.TEXTURE_2D, this.gradingTexture), m.uniform1i(b.gradingWeights, 2), m.uniform1f(b.exposure, Math.pow(2, Math.min(5, Math.max(-5, g.exposure)))), m.uniform1f(b.contrast, Math.max(0, 1 + Math.min(100, Math.max(-100, g.contrast)) / 100)), m.uniform4f(
      b.tone,
      Math.min(100, Math.max(-100, g.shadows)) / 100 * 0.28,
      Math.min(100, Math.max(-100, g.highlights)) / 100 * 0.24,
      Math.min(100, Math.max(-100, g.whites)) / 100 * 0.18,
      Math.min(100, Math.max(-100, g.blacks)) / 100 * 0.22
    ), m.uniform2f(
      b.tempTint,
      Math.min(100, Math.max(-100, g.temperature)) / 100,
      Math.min(100, Math.max(-100, g.tint)) / 100
    ), m.uniform1f(b.clarity, Math.min(100, Math.max(-100, g.clarity)) / 100), m.uniform1f(b.dehaze, Math.min(100, Math.max(-100, g.dehaze)) / 100), m.uniform1f(b.saturation, 1 + Math.min(100, Math.max(-100, g.saturation)) / 100), m.uniform1f(b.vibrance, Math.min(100, Math.max(-100, g.vibrance)) / 100);
    const S = ["red", "orange", "yellow", "green", "aqua", "blue", "purple", "magenta"], C = new Float32Array(24);
    for (let Z = 0; Z < S.length; Z += 1) {
      const it = g.hsl[S[Z]];
      C[Z * 3] = it.hue, C[Z * 3 + 1] = it.saturation / 100, C[Z * 3 + 2] = it.luminance / 100;
    }
    m.uniform3fv(b.hsl, C);
    const k = [g.grading.shadows, g.grading.midtones, g.grading.highlights], j = new Float32Array(12);
    for (let Z = 0; Z < 3; Z += 1) {
      const it = k[Z];
      j[Z * 4] = it.hue, j[Z * 4 + 1] = it.saturation, j[Z * 4 + 2] = it.luminance;
    }
    m.uniform4fv(b.grading, j), m.uniform1f(b.gradingBalance, g.grading.balance / 100), m.uniform1f(b.gradingBlending, g.grading.blending / 100);
    const L = g.calibration;
    return m.uniform4f(
      b.calibA,
      Math.min(100, Math.max(-100, L?.shadows ?? 0)) / 100,
      Math.min(100, Math.max(-100, L?.redHue ?? 0)) / 100,
      Math.min(100, Math.max(-100, L?.redSaturation ?? 0)) / 100,
      Math.min(100, Math.max(-100, L?.greenHue ?? 0)) / 100
    ), m.uniform2f(
      b.calibB,
      Math.min(100, Math.max(-100, L?.greenSaturation ?? 0)) / 100,
      Math.min(100, Math.max(-100, L?.blueHue ?? 0)) / 100
    ), m.uniform1f(
      b.calibBlueSat,
      Math.min(100, Math.max(-100, L?.blueSaturation ?? 0)) / 100
    ), m.uniform1f(b.vignette, Math.min(100, Math.max(-100, g.vignette)) / 100), m.uniform4f(
      b.vignetteShape,
      Math.min(100, Math.max(0, g.vignetteMidpoint)) / 100,
      Math.min(100, Math.max(0, g.vignetteFeather)) / 100,
      Math.min(100, Math.max(0, g.vignetteRoundness ?? 50)) / 100,
      Math.min(100, Math.max(0, g.vignetteHighlights ?? 0)) / 100
    ), m.uniform2f(
      b.grain,
      Math.min(100, Math.max(0, g.grain)) / 100,
      Math.min(100, Math.max(0, g.grainRoughness ?? 50)) / 100
    ), m.uniform1f(b.grainSize, Math.min(3, Math.max(1, Math.round(g.grainSize ?? 1)))), m.drawArrays(m.TRIANGLES, 0, 3), m.finish(), { canvas: A, durationMs: performance.now() - v, width: u, height: c };
  }
  /**
   * 读回当前帧像素，供直方图统计使用。只在非拖拽帧调用：readPixels 会同步，
   * 拖拽期调用会把 GPU 管线拖回 CPU 的节奏。
   */
  readPixels(h, u) {
    const c = this.gl;
    if (!c) return null;
    const g = new Uint8ClampedArray(h * u * 4);
    return c.readPixels(0, 0, h, u, c.RGBA, c.UNSIGNED_BYTE, g), g;
  }
  dispose() {
    const h = this.gl;
    h && (this.imageTexture && h.deleteTexture(this.imageTexture), this.blurTexture && h.deleteTexture(this.blurTexture), this.curvesTexture && h.deleteTexture(this.curvesTexture), this.gradingTexture && h.deleteTexture(this.gradingTexture), this.program && h.deleteProgram(this.program), this.imageTexture = null, this.blurTexture = null, this.blurBuiltFor = "", this.curvesTexture = null, this.gradingTexture = null, this.program = null, this.gl = null, this.canvas = null);
  }
}
const Jr = 256, $1 = 1, tb = 254, eb = 2e6, ab = 5e-3, nb = 1e-3;
function Rc() {
  return new Array(Jr).fill(0);
}
function Pr() {
  return {
    mean: 0,
    median: 0,
    mode: 0,
    standardDeviation: 0,
    lowPercentile: 0,
    highPercentile: 0,
    clipLow: 0,
    clipHigh: 0,
    effectiveLevels: 0
  };
}
function Hh() {
  return {
    bins: {
      red: Rc(),
      green: Rc(),
      blue: Rc(),
      luma: Rc()
    },
    sampleCount: 0,
    stats: {
      red: Pr(),
      green: Pr(),
      blue: Pr(),
      luma: Pr()
    }
  };
}
function Dh(r, h, u) {
  if (h <= 0) return 0;
  const c = u * h;
  let g = 0;
  for (let m = 0; m < r.length; m += 1) {
    const b = r[m] ?? 0;
    if (!(b <= 0)) {
      if (g + b >= c) {
        const A = m + (c - g) / b - 0.5;
        return Math.min(r.length - 1, Math.max(0, A));
      }
      g += b;
    }
  }
  return r.length - 1;
}
function Sc(r, h) {
  if (h <= 0) return Pr();
  let u = 0, c = 0, g = 0, m = 0, b = 0, A = 0, v = 0;
  for (let C = 0; C < r.length; C += 1) {
    const k = r[C] ?? 0;
    k <= 0 || (b += 1, u += C * k, c += C * C * k, k > m && (m = k, g = C), C <= $1 && (A += k), C >= tb && (v += k));
  }
  const y = u / h, S = Math.max(0, c / h - y * y);
  return {
    mean: y,
    median: Dh(r, h, 0.5),
    mode: g,
    standardDeviation: Math.sqrt(S),
    lowPercentile: Dh(r, h, 5e-3),
    highPercentile: Dh(r, h, 0.995),
    clipLow: A / h,
    clipHigh: v / h,
    effectiveLevels: b
  };
}
function Zh(r, h, u) {
  const c = Hh().bins, g = Math.max(0, Math.floor(h)), m = Math.max(0, Math.floor(u)), b = Math.min(g * m, Math.floor(r.length / 4));
  if (!g || !m || b <= 0) return Hh();
  const A = Math.max(
    1,
    Math.min(m, Math.round(eb / g))
  ), v = m / A;
  let y = 0;
  for (let S = 0; S < A; S += 1) {
    const C = (S * 2654435761 >>> 0) % 1024 / 1024;
    let j = Math.min(m - 1, Math.floor((S + C) * v)) * g * 4;
    for (let L = 0; L < g; L += 1) {
      if (r[j + 3] === 0) {
        j += 4;
        continue;
      }
      const Z = r[j] ?? 0, it = r[j + 1] ?? 0, mt = r[j + 2] ?? 0;
      c.red[Z] += 1, c.green[it] += 1, c.blue[mt] += 1, c.luma[Z * 54 + it * 183 + mt * 19 + 128 >> 8] += 1, y += 1, j += 4;
    }
  }
  return {
    bins: c,
    sampleCount: y,
    stats: {
      red: Sc(c.red, y),
      green: Sc(c.green, y),
      blue: Sc(c.blue, y),
      luma: Sc(c.luma, y)
    }
  };
}
const ob = ["red", "green", "blue"];
function zp(r) {
  const h = new Float32Array(Jr), u = new Float32Array(Jr), c = new Float32Array(Jr);
  if (!r) return { ceiling: 1, red: h, green: u, blue: c };
  const g = [];
  for (const y of ob) g.push(...r.bins[y]);
  if (!g.length) return { ceiling: 1, red: h, green: u, blue: c };
  g.sort((y, S) => S - y);
  const m = Math.min(g.length - 1, Math.floor(g.length * ab)), b = g[m] ?? 0, A = Math.max(b, r.sampleCount * nb, 1), v = (y, S) => {
    for (let C = 0; C < Jr; C += 1)
      y[C] = Math.min(1, (S[C] ?? 0) / A);
  };
  return v(h, r.bins.red), v(u, r.bins.green), v(c, r.bins.blue), { ceiling: A, red: h, green: u, blue: c };
}
function qp(r) {
  const { stats: h } = r;
  return {
    low: h.luma.clipLow,
    high: Math.max(
      h.luma.clipHigh,
      h.red.clipHigh,
      h.green.clipHigh,
      h.blue.clipHigh
    )
  };
}
function Yc(r) {
  const h = r.stats.luma, u = h.median, c = qp(r), g = u < 62 ? "under" : u < 92 ? "slightlyUnder" : u > 186 ? "over" : u > 152 ? "slightlyOver" : "balanced", m = h.standardDeviation < 38 ? "flat" : h.standardDeviation > 72 ? "punchy" : "normal", b = r.stats.red.mean - r.stats.blue.mean, A = b > 5 ? "warm" : b < -5 ? "cool" : "neutral";
  return {
    exposure: g,
    contrast: m,
    temperature: A,
    meanLuma: h.mean,
    medianLuma: u,
    clipLow: c.low,
    clipHigh: c.high,
    dynamicRange: Math.max(0, h.highPercentile - h.lowPercentile)
  };
}
const ib = 320, lb = 76, hp = 1e-3, rb = 0.98;
function Tc(r, h) {
  if (!r) return;
  const u = r.getContext("2d");
  if (!u) return;
  const c = r.width, g = r.height;
  u.clearRect(0, 0, c, g), u.fillStyle = "rgba(255, 255, 255, 0.07)";
  for (const k of [0.25, 0.5, 0.75])
    u.fillRect(Math.round(k * c), 0, 1, g);
  if (u.fillRect(0, Math.round(g * 0.5), c, 1), !h || h.sampleCount <= 0) return;
  const m = zp(h), b = c / m.red.length, A = g - 1;
  u.globalCompositeOperation = "screen";
  const v = (k, j) => {
    u.beginPath(), u.moveTo(0, g);
    for (let L = 0; L < k.length; L += 1) {
      const Z = L * b, it = A - (k[L] ?? 0) * (g - 1) * rb;
      u.lineTo(Z, it), u.lineTo(Z + b, it);
    }
    u.lineTo(c, g), u.closePath(), u.fillStyle = j, u.fill();
  };
  v(m.red, "rgba(196, 44, 36, 0.72)"), v(m.green, "rgba(30, 140, 62, 0.66)"), v(m.blue, "rgba(8, 90, 190, 0.7)"), u.globalCompositeOperation = "source-over";
  const y = Math.max(8, Math.round(c * 0.022)), S = (k, j) => {
    u.beginPath(), k === "low" ? (u.moveTo(0, 0), u.lineTo(y, 0), u.lineTo(0, y)) : (u.moveTo(c, 0), u.lineTo(c - y, 0), u.lineTo(c, y)), u.closePath(), u.fillStyle = j, u.fill();
  }, C = qp(h);
  C.low >= hp && S("low", "rgba(95, 168, 224, 0.9)"), C.high >= hp && S("high", "rgba(232, 180, 95, 0.9)");
}
function sb(r) {
  if (r.unprovisioned) return "授权未配置";
  if (r.state === "active") {
    if (r.expiresAt) {
      const h = Math.ceil((r.expiresAt - Date.now()) / 864e5);
      return `已激活 · 剩余 ${Math.max(0, h)} 天`;
    }
    return "已激活 · 永久";
  }
  return r.state === "trial" ? r.trialDaysLeft === 0 ? "试用最后一天" : `试用剩余 ${r.trialDaysLeft ?? 0} 天` : r.state === "suspended" ? "检测到系统时间异常" : "已过期 · 请激活";
}
const cb = "application/x-orcabox-asset-drag";
function ub(r) {
  try {
    return [...new Set((r?.getData(cb) ?? "").split(/\r?\n/).map((h) => h.trim()).filter(Boolean))];
  } catch {
    return [];
  }
}
function hb(r, h) {
  if (r) {
    if (!r.startsWith("file://")) return r;
    try {
      const u = new URL(r);
      let c = decodeURIComponent(u.pathname);
      u.hostname && u.hostname !== "localhost" ? c = `//${u.hostname}${c}` : /^\/[A-Za-z]:/.test(c) && (c = c.slice(1));
      const g = new URLSearchParams(u.search);
      return g.set("path", c), h && g.set("token", h), `orcabox-asset://local?${g.toString()}`;
    } catch {
      return r;
    }
  }
}
function fb(r) {
  return !!(r && (r.kind === "image" || r.kind === "gif") && r.status !== "missing");
}
function db(r, h) {
  return Array.from(r?.files ?? []).flatMap((u) => {
    let c = u.path;
    if (!c)
      try {
        c = h?.(u);
      } catch {
        return [];
      }
    return c ? [{ filePath: c, name: u.name }] : [];
  });
}
async function Wh(r, h, u) {
  const c = new Array(r.length);
  let g = 0;
  const m = Math.min(r.length, Math.max(1, Math.floor(h)));
  return await Promise.all(Array.from({ length: m }, async () => {
    for (; g < r.length; ) {
      const b = g++;
      c[b] = await u(r[b], b);
    }
  })), c;
}
function Yh(r, h) {
  const u = r.replaceAll("\\", "/").replace(/\/$/, "").normalize("NFC");
  return h ? u.toLowerCase() : u;
}
async function pb(r, h, u) {
  const c = new Set(r.map((C) => Yh(C.filePath, u))), g = /* @__PURE__ */ new Map(), m = [...new Set(r.map((C) => C.name).filter(Boolean))];
  await Wh(m, 4, async (C) => {
    let k = 0;
    for (; ; ) {
      const j = await h({
        text: C,
        searchFields: ["name", "path"],
        kinds: ["image", "gif"],
        limit: 250,
        offset: k,
        includeThumbnailSnapshots: !1,
        includeEnrichment: !1
      });
      for (const L of j.assets) {
        const Z = Yh(L.filePath, u);
        c.has(Z) && gb(L) && g.set(Z, L.id);
      }
      if (k += j.assets.length, !j.assets.length || k >= j.total || g.size === c.size) break;
    }
  });
  const A = [], v = [], y = /* @__PURE__ */ new Set(), S = /* @__PURE__ */ new Set();
  for (const C of r) {
    const k = Yh(C.filePath, u);
    if (S.has(k)) continue;
    S.add(k);
    const j = g.get(k);
    j ? y.has(j) || (y.add(j), A.push(j)) : v.push(C);
  }
  return { assetIds: A, unresolvedFiles: v };
}
function gb(r) {
  return !!(r && (r.kind === "image" || r.kind === "gif") && r.status !== "missing");
}
function mb(r, h, u) {
  const c = h ? r.indexOf(h) : -1, g = r.indexOf(u);
  if (g < 0) return [];
  if (c < 0) return [u];
  const m = Math.min(c, g), b = Math.max(c, g);
  return r.slice(m, b + 1);
}
function fp(r, h, u) {
  return {
    selectedIds: mb(r, h, u),
    nextAnchorId: u
  };
}
function bb(r, h) {
  const u = new Set(r);
  return u.has(h) ? u.delete(h) : u.add(h), u;
}
function xb(r) {
  return new Set(r);
}
const yb = ':root{--photo-bg: #111315;--photo-panel: rgba(29, 32, 36, .94);--photo-panel-soft: rgba(44, 48, 54, .78);--photo-row: rgba(255, 255, 255, .075);--photo-border: rgba(255, 255, 255, .105);--photo-border-soft: rgba(255, 255, 255, .065);--photo-text: #f5f6f7;--photo-muted: #9da3ac;--photo-dim: #727981;--photo-accent: #4da3ff;--photo-ai: #b79cff;--photo-ai-strong: #8b5cf6;--photo-ai-border: rgba(167, 139, 250, .58);--photo-ai-soft: rgba(124, 58, 237, .18)}.photo-adjust-shell{position:relative;height:100vh;display:flex;flex-direction:column;overflow:hidden;color:var(--photo-text);background:var(--photo-bg);font:12px -apple-system,BlinkMacSystemFont,SF Pro Text,Segoe UI,sans-serif}.photo-adjust-header{position:relative;height:42px;display:flex;align-items:center;justify-content:space-between;padding:0 12px;border-bottom:1px solid var(--photo-border);background:#1c1f23fa;box-shadow:0 1px #ffffff06 inset;-webkit-app-region:drag}.photo-header-filename{position:absolute;left:50%;transform:translate(-50%);max-width:40%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#b9c1c9;font-size:12px}.photo-toolbar{height:34px;display:flex;align-items:center;gap:4px;padding:0 10px;border-bottom:1px solid var(--photo-border-soft);background:#121419}.photo-toolbar button{display:inline-flex;align-items:center;gap:5px;height:24px;padding:0 8px;border:1px solid transparent;border-radius:6px;color:#a4acb5;background:transparent;font-size:11px;cursor:pointer}.photo-toolbar button:hover{background:#ffffff12;color:#e6eaee}.photo-toolbar button.active{color:#f2f7fc;background:#8cb2d42e;border-color:#a0c4e252}.photo-preview-quality{display:inline-flex;align-items:center;gap:5px;color:#8b949e;font-size:10.5px}.photo-preview-quality select{height:22px;padding:0 4px;border:1px solid var(--photo-border-soft);border-radius:5px;color:#b9c1c9;background:#101318;font-size:10.5px;cursor:pointer}.photo-preview-quality select:focus-visible{outline:2px solid rgba(120,180,235,.62);outline-offset:1px}.photo-toolbar-divider{width:1px;height:13px;background:#ffffff1a}.photo-toolbar-spacer{flex:1}.photo-toolbar .photo-zoom-readout{color:#6f7780;font-size:10.5px;font-variant-numeric:tabular-nums}.photo-adjust-header .photo-title,.photo-adjust-header .photo-header-actions button,.photo-adjust-header .photo-header-count{-webkit-app-region:no-drag}.photo-title,.photo-header-actions,.photo-title span,.photo-header-actions button{display:flex;align-items:center;gap:8px}.photo-title{color:#dce6f0}.photo-title strong{font-size:13px;font-weight:600;letter-spacing:.01em}.photo-title span{color:#727b85;font-size:9px;text-transform:uppercase;letter-spacing:.14em}.photo-header-actions{gap:6px}.photo-history-wrap{position:relative}.photo-history-wrap,.photo-history-popover{-webkit-app-region:no-drag}.photo-history-button{white-space:nowrap}.photo-history-button.active{border-color:#84beeba6;background:#5e96c633}.photo-history-popover{position:absolute;top:calc(100% + 8px);right:0;z-index:20;width:320px;padding:10px;border:1px solid rgba(255,255,255,.14);border-radius:8px;background:#1f2328fa;box-shadow:0 18px 38px #0000006b}.photo-history-popover-head{display:flex;align-items:center;justify-content:space-between;gap:8px}.photo-history-tools{display:flex;align-items:center;gap:4px}.photo-history-popover-head strong{color:#e8edf2;font-size:11px}.photo-history-popover-head button{min-height:24px;padding:0 7px;border:1px solid var(--photo-border-soft);border-radius:5px;color:#bfcbd5;background:#ffffff0f;cursor:pointer;font-size:9px}.photo-history-status{margin:8px 0;color:#7f8b96;font-size:9px}.photo-history-list{display:grid;gap:4px;max-height:230px;overflow-y:auto}.photo-history-popover .photo-history-entry{display:grid;grid-template-columns:minmax(0,1fr);align-items:stretch;gap:3px;width:100%;height:auto;min-height:0;padding:6px 8px;border:1px solid transparent;border-radius:5px;color:#cbd5dd;background:#ffffff09;cursor:pointer;text-align:left}.photo-history-popover .photo-history-entry:hover{border-color:#84beeb6b;background:#5e96c629}.photo-history-popover .photo-history-entry.is-current{border-color:#84beeb8c;background:#5e96c624}.photo-history-popover .photo-history-entry-title{display:flex;align-items:center;gap:6px;min-width:0;white-space:nowrap}.photo-history-popover .photo-history-entry-kind{flex:none;color:#d7dee5;font-size:10px;white-space:nowrap}.photo-history-popover .photo-history-entry-title em{flex:none;padding:0 5px;border-radius:999px;color:#0e1a24;background:#9dc6e8;font-size:8px;font-style:normal;line-height:14px;white-space:nowrap}.photo-history-popover .photo-history-entry-title time{flex:none;margin-left:auto;color:#76828c;font-size:9px;white-space:nowrap}.photo-history-popover .photo-history-entry small{overflow:hidden;color:#8b95a0;font-size:9px;line-height:13px;text-overflow:ellipsis;white-space:nowrap}.photo-history-popover .photo-history-popover-head button{height:24px;min-height:24px;padding:0 7px;font-size:9px;white-space:nowrap}.photo-history-foot{margin-top:8px;padding-top:7px;border-top:1px solid rgba(255,255,255,.07);color:#6f7b85;font-size:9px}.photo-history-empty{padding:12px 4px 6px;color:#707b85;font-size:10px}.photo-header-count{margin-right:4px;color:var(--photo-dim);font-size:10px}.photo-header-actions button{height:26px;gap:6px;padding:0 9px;border:1px solid transparent;border-radius:6px;color:#b6bec6;background:transparent;font-size:11.5px;cursor:pointer;transition:background .14s ease,border-color .14s ease,color .14s ease}.photo-header-actions button:hover{border-color:transparent;color:#fff;background:#ffffff13}.photo-header-actions button:disabled{opacity:.4;cursor:default}.photo-header-actions .photo-primary{padding:0 11px;border-color:#cfe3f6;color:#101d29;background:#d7e9fa;box-shadow:0 1px 2px #00000052}.photo-header-actions .photo-primary:hover{border-color:#e2f0ff;color:#101d29;background:#eaf5ff}.photo-header-actions .photo-icon{width:26px;justify-content:center;padding:0;border:0;color:#99a1aa;background:transparent}.photo-header-actions .photo-icon:hover{color:#e6eaee;background:#ffffff13}.photo-workspace{display:grid;grid-template-columns:56px minmax(0,1fr) 344px;grid-template-rows:minmax(0,1fr) auto;grid-template-areas:"rail canvas controls" "film film film";min-height:0;flex:1;overflow:hidden}.photo-filmstrip{grid-area:film;position:relative;display:flex;flex-direction:column;min-height:0;min-width:0;height:128px;padding:0 0 8px;overflow:hidden;border-top:1px solid var(--photo-border-soft);background:#17191c}.photo-filmstrip:focus{outline:none}.photo-filmstrip-resizer{position:absolute;left:0;right:0;top:-4px;height:9px;z-index:30;cursor:row-resize;touch-action:none;-webkit-user-select:none;user-select:none}.photo-filmstrip-resizer:after{content:"";position:absolute;left:12px;right:12px;top:3px;height:2px;border-radius:1px;background:transparent;transition:background .15s ease}.photo-filmstrip-resizer:hover:after,.photo-filmstrip-resizer.is-dragging:after,.photo-filmstrip-resizer:focus-visible:after{background:#8b5cf6b3}.photo-filmstrip-resizer:focus-visible{outline:none}.photo-import-progress{display:flex;align-items:center;gap:10px;flex:none;min-width:0;height:24px;padding:0 10px;color:#aeb6bf;font-size:10.5px;font-variant-numeric:tabular-nums;background:#0a0c0fa3}.photo-import-progress span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.photo-import-progress i{position:relative;display:block;flex:1 1 auto;min-width:48px;height:3px;overflow:hidden;border-radius:3px;background:#ffffff1f}.photo-import-progress i b{position:absolute;inset:0 auto 0 0;border-radius:inherit;background:#9b7aff;transition:width .24s ease}.photo-import-progress.is-indeterminate i b{animation:photo-import-indeterminate 1.15s ease-in-out infinite}@keyframes photo-import-indeterminate{0%{left:-34%}to{left:100%}}.photo-batchbar{display:flex;flex-wrap:wrap;align-items:center;gap:5px;padding:6px 10px;border-bottom:1px solid var(--photo-border-soft);background:#14161a}.photo-batchbar button{display:inline-flex;align-items:center;gap:5px;height:24px;padding:0 8px;border:1px solid transparent;border-radius:6px;color:#a8b0b9;background:transparent;font-size:11px;cursor:pointer;transition:background .14s ease,color .14s ease}.photo-batchbar button:hover:not(:disabled){color:#e6eaee;background:#ffffff13}.photo-batchbar button:disabled{opacity:.45;cursor:default}.photo-batchbar .photo-batchbar-primary{color:#c4b0ff;border-color:#8b5cf673;background:#7c3aed1f}.photo-batchbar .photo-batchbar-primary:hover:not(:disabled){color:#fff;background:#7c3aed3d}.photo-batchbar-progress{display:inline-flex;align-items:center;gap:8px;color:#9aa2ab;font-size:11px;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.photo-batchbar-progress i{position:relative;width:120px;height:4px;border-radius:2px;background:#ffffff1f;overflow:hidden;flex:none}.photo-batchbar-progress i b{position:absolute;inset:0 auto 0 0;border-radius:2px;background:#8b5cf6;transition:width .25s ease}.photo-batchbar-meta{margin-left:auto;color:#727982;font-size:11px;white-space:nowrap}.photo-filmstrip-row{display:flex;align-items:stretch;gap:6px;flex:1 1 auto;min-height:0;padding:6px 10px 0;overflow-x:auto;overflow-y:hidden;scrollbar-width:thin;scrollbar-color:transparent transparent}.photo-filmstrip-row:hover{scrollbar-color:rgba(150,165,180,.55) transparent}.photo-thumb-cell{position:relative;display:flex;flex:0 0 auto;height:100%}.photo-thumb-check{position:absolute;left:7px;top:7px;z-index:2;display:flex;align-items:center;justify-content:center;width:16px;height:16px;padding:0;border:1px solid rgba(255,255,255,.45);border-radius:4px;color:#fff;background:#0c0e128c;font-size:10px;line-height:1;cursor:pointer}.photo-thumb-check.on{border-color:#8b5cf6;background:#8b5cf6}.photo-thumb{position:relative}.photo-rail-heading{display:none}.photo-rail-heading small{color:#727982;font-weight:500}.photo-thumb{display:flex;flex-direction:column;gap:4px;flex:0 0 auto;width:auto;height:100%;margin:0;padding:4px;border:1px solid transparent;border-radius:7px;color:#aeb4bb;text-align:left;background:transparent;cursor:pointer}.photo-thumb:hover{background:#ffffff0e}.photo-thumb.active{border-color:#9bbedcb3;color:#fff;background:#8cafcc21;box-shadow:0 0 0 1px #ffffff09 inset}.photo-thumb.batch-selected{border-color:#8b5cf6b8;background:#7c3aed24;box-shadow:0 0 0 1px #8b5cf633 inset,0 0 0 1px #8b5cf61a}.photo-thumb img{display:block;flex:none;align-self:flex-start;height:calc(100% - 18px);width:auto;min-width:24px;object-fit:cover;border-radius:4px;background:#25292d;filter:blur(0);transition:filter .36s ease}.photo-thumb img.is-soft{filter:blur(3px)}.photo-thumb span:not(.photo-thumb-check){flex:none;width:0;min-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:10px}.photo-empty-rail{display:flex;flex:1;flex-direction:row;align-items:center;justify-content:center;gap:12px;padding:8px 12px;color:#777f88;text-align:center;line-height:1.5;white-space:nowrap}.photo-empty-rail button{padding:7px 11px;border:1px solid var(--photo-border);border-radius:6px;color:#d6dbe0;background:#ffffff12;cursor:pointer}.photo-canvas{grid-area:canvas;position:relative;display:flex;flex-direction:column;min-height:0;min-width:0;overflow:hidden;background:#0f1113}.photo-render-status{position:absolute;right:12px;bottom:12px;z-index:6;display:inline-flex;align-items:center;gap:8px;padding:3px 8px;border:1px solid rgba(255,255,255,.08);border-radius:5px;color:#8a939c;background:#0c0e11b8;font-size:9.5px;font-variant-numeric:tabular-nums;pointer-events:none}.photo-render-status b{font-weight:650;letter-spacing:.06em}.photo-render-status .is-gpu{color:#8fd3b0}.photo-render-status .is-cpu{color:#e2b169}.photo-render-status .photo-render-status-note{color:#7c858f}.photo-canvas-toolbar{height:39px;display:flex;align-items:center;justify-content:space-between;padding:0 16px;border-bottom:1px solid var(--photo-border-soft);color:#c9cfd6}.photo-canvas-toolbar-right{display:flex;align-items:center;gap:10px}.photo-fit-button,.photo-compare-button{display:inline-flex;align-items:center;gap:5px;padding:3px 7px;border:1px solid var(--photo-border-soft);border-radius:4px;color:#aeb7c1;background:#ffffff09;cursor:pointer;font-size:10px;-webkit-user-select:none;user-select:none;touch-action:none;white-space:nowrap}.photo-fit-button:hover,.photo-compare-button:hover{border-color:#ffffff38;color:#edf2f6;background:#ffffff13}.photo-compare-button.active{border-color:#9bbedcbf;color:#eaf3fb;background:#78a5cd3d}.photo-compare-button.photo-ai-button{border-color:var(--photo-ai-border);color:#eadfff;background:linear-gradient(180deg,rgba(139,92,246,.25),var(--photo-ai-soft));box-shadow:inset 0 1px #ffffff17}.photo-compare-button.photo-ai-button:hover{border-color:#c4b5fdeb;color:#fff;background:linear-gradient(180deg,#a78bfa61,#6d28d93d);box-shadow:0 0 0 3px #8b5cf61f,inset 0 1px #ffffff1f}.photo-compare-button.photo-ai-button:active{transform:translateY(1px)}.photo-compare-button.photo-ai-button.active{border-color:#c4b5fd;color:#fff;background:linear-gradient(180deg,#a78bfa6b,#6d28d94d);box-shadow:0 0 0 3px #8b5cf624,inset 0 1px #ffffff29}.photo-compare-button.photo-ai-button:disabled{border-color:#a78bfa38;color:#e1d6ff7a;background:#7c3aed14;box-shadow:none;opacity:.7;cursor:default}.photo-zoom-readout{min-width:36px;color:#aeb7c1;text-align:right;font-size:10px;font-variant-numeric:tabular-nums}.photo-canvas-meta{color:#747c85;font-size:10px;font-variant-numeric:tabular-nums}.photo-image-stage{display:flex;align-items:center;justify-content:center;min-height:0;min-width:0;flex:1;padding:24px;overflow:hidden;background:#171a1e;cursor:grab;touch-action:none}.photo-image-stage.is-panning{cursor:grabbing}.photo-image-stage.is-wb-picker{cursor:crosshair}.photo-image-stage img,.photo-image-stage canvas{max-width:100%;max-height:100%;object-fit:contain;box-shadow:0 10px 30px #00000073}.photo-viewport{position:relative;display:inline-flex;flex:0 0 auto;max-width:100%;max-height:100%;will-change:transform}.photo-viewport img.photo-preview{display:block;flex:0 0 auto;width:auto;height:auto;max-width:100%;max-height:100%;-webkit-user-select:none;user-select:none}.photo-viewport canvas.photo-preview{display:block;-webkit-user-select:none;user-select:none;image-rendering:auto}.photo-semantic-mask{position:absolute;inset:0;z-index:3;width:100%;height:100%;pointer-events:none;image-rendering:auto}.photo-crop-overlay{position:absolute;inset:0;cursor:move;touch-action:none}.photo-crop-box{position:absolute;box-shadow:0 0 0 1px #ebf2f8d9,0 0 0 9999px #080a0c99;cursor:move}.photo-crop-line{position:absolute;background:#ebf2f852;pointer-events:none}.photo-crop-line.is-v1{left:33.33%;top:0;bottom:0;width:1px}.photo-crop-line.is-v2{left:66.66%;top:0;bottom:0;width:1px}.photo-crop-line.is-h1{top:33.33%;left:0;right:0;height:1px}.photo-crop-line.is-h2{top:66.66%;left:0;right:0;height:1px}.photo-crop-handle{position:absolute;width:14px;height:14px;border:0;border-radius:2px;background:transparent}.photo-crop-handle:before{content:"";position:absolute;width:11px;height:11px;border:2px solid #eaf2f9;background:#14181c66;transition:background .14s ease,transform .14s ease}.photo-crop-handle:hover:before{background:#78aad2a6;transform:scale(1.12)}.photo-crop-handle.is-nw{left:-7px;top:-7px;cursor:nwse-resize}.photo-crop-handle.is-nw:before{left:0;top:0;border-right:0;border-bottom:0}.photo-crop-handle.is-n{left:calc(50% - 7px);top:-7px;cursor:ns-resize}.photo-crop-handle.is-n:before{left:0;right:0;top:0;height:7px;border-bottom:0}.photo-crop-handle.is-ne{right:-7px;top:-7px;cursor:nesw-resize}.photo-crop-handle.is-ne:before{right:0;top:0;border-left:0;border-bottom:0}.photo-crop-handle.is-e{right:-7px;top:calc(50% - 7px);cursor:ew-resize}.photo-crop-handle.is-e:before{right:0;top:0;bottom:0;width:7px;border-left:0}.photo-crop-handle.is-se{right:-7px;bottom:-7px;cursor:nwse-resize}.photo-crop-handle.is-se:before{right:0;bottom:0;border-left:0;border-top:0}.photo-crop-handle.is-s{left:calc(50% - 7px);bottom:-7px;cursor:ns-resize}.photo-crop-handle.is-s:before{left:0;right:0;bottom:0;height:7px;border-top:0}.photo-crop-handle.is-sw{left:-7px;bottom:-7px;cursor:nesw-resize}.photo-crop-handle.is-sw:before{left:0;bottom:0;border-right:0;border-top:0}.photo-crop-handle.is-w{left:-7px;top:calc(50% - 7px);cursor:ew-resize}.photo-crop-handle.is-w:before{left:0;top:0;bottom:0;width:7px;border-right:0}.photo-drop-target{display:flex;flex-direction:column;align-items:center;gap:9px;color:#8a929c;text-align:center}.photo-drop-target strong{color:#d4d9df;font-size:15px;font-weight:600}.photo-controls{grid-area:controls;min-width:0;display:flex;flex-direction:column;border-left:1px solid var(--photo-border);background:var(--photo-panel);box-shadow:-12px 0 36px #0000002e}.photo-controls-fixed{flex:0 0 auto;border-bottom:1px solid var(--photo-border);background:var(--photo-panel)}.photo-controls-fixed .photo-histogram{margin-bottom:8px}.photo-controls-body{display:flex;flex:1;min-height:0}.photo-controls-scroll{flex:1;min-width:0;overflow-y:auto;padding-bottom:10px;scrollbar-width:thin;scrollbar-color:transparent transparent}.photo-controls-scroll:hover,.photo-controls-scroll:focus-within{scrollbar-color:rgba(150,165,180,.56) transparent}.photo-panel-tabs{display:flex;flex:0 0 48px;flex-direction:column;align-items:center;gap:2px;padding:6px 0;border-left:1px solid var(--photo-border-soft);background:#181b1ef7;overflow-y:auto;scrollbar-width:none}.photo-panel-tabs::-webkit-scrollbar{display:none}.photo-panel-tabs button{display:flex;flex-direction:column;align-items:center;gap:3px;width:42px;min-height:42px;padding:5px 0 4px;border:1px solid transparent;border-radius:8px;color:#8b939c;background:transparent;cursor:pointer;transition:color .14s ease,background .14s ease,border-color .14s ease}.photo-panel-tabs button span{font-size:9px;line-height:1;letter-spacing:.02em}.photo-panel-tabs button:hover{color:#dfe6ec;background:#ffffff0d}.photo-panel-tabs button.active{color:#9fd0f7;border-color:#78aad766;background:#4da3ff24}.photo-rail{grid-area:rail;display:flex;flex-direction:column;align-items:center;gap:1px;padding:6px 3px;border-right:1px solid var(--photo-border-soft);background:#181b1ef7;overflow-y:auto;scrollbar-width:none}.photo-rail button{display:flex;align-items:center;justify-content:center;width:32px;height:32px;border:1px solid transparent;border-radius:7px;color:#8b939c;background:transparent;cursor:pointer;transition:color .14s ease,background .14s ease,border-color .14s ease}.photo-rail button:hover:not(:disabled){color:#e2e7ec;background:#ffffff0f}.photo-rail button:disabled{opacity:.4;cursor:default}.photo-rail button{position:relative}.photo-rail button.active{color:#eef3f8;background:#ffffff17;border-color:#ffffff14}.photo-rail button.active:before{content:"";position:absolute;left:-3px;top:50%;width:2px;height:14px;margin-top:-7px;border-radius:1px;background:#8fbfe6}.photo-rail button.photo-rail-ai{color:#a78bff}.photo-rail button.photo-rail-ai:hover:not(:disabled){color:#cbb8ff;background:#7c3aed24}.photo-rail button.photo-rail-ai.active{color:#d3c4ff;background:#7c3aed33;border-color:#a78bfa66}.photo-rail button.photo-rail-ai.active:before{background:#a78bff}.photo-rail-divider{align-self:stretch;height:1px;margin:5px 4px;background:var(--photo-border-soft)}.photo-wb-row{display:flex;align-items:center;justify-content:space-between;margin:10px 0 4px}.photo-wb-row .photo-inspector-subheading{margin:0}.photo-wb-actions{display:flex;align-items:center;gap:6px}.photo-wb-tool-group{display:flex;align-items:center;gap:4px}.photo-auto-button{height:24px;padding:0 10px;border:1px solid rgba(155,190,220,.55);border-radius:5px;color:#eaf3fb;background:#78a5cd38;cursor:pointer;font-size:10px;transition:background .15s ease,border-color .15s ease,transform .1s ease}.photo-auto-button:hover{border-color:#afd0ebcc;background:#8cb9de57}.photo-auto-button:active{transform:scale(.96)}.photo-auto-button.active{border-color:#dceefae6;color:#fff;background:#78a5cd80}.photo-picker-button{padding-inline:8px}.photo-wb-select{height:24px;padding:0 8px;border:1px solid var(--photo-border-soft);border-radius:5px;color:#cbd2d9;background:#ffffff0b;font-size:10px}.photo-preset-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:7px}.photo-preset-cats{display:flex;flex-wrap:nowrap;gap:5px;margin-bottom:10px;padding-bottom:2px;padding-right:14px;overflow-x:auto;scrollbar-width:none;-webkit-mask-image:linear-gradient(to right,#000 0,#000 calc(100% - 16px),transparent 100%);mask-image:linear-gradient(to right,#000 0,#000 calc(100% - 16px),transparent 100%)}.photo-preset-cats[data-overflow=none]{-webkit-mask-image:none;mask-image:none}.photo-preset-cats[data-overflow=left]{-webkit-mask-image:linear-gradient(to right,transparent 0,#000 16px,#000 100%);mask-image:linear-gradient(to right,transparent 0,#000 16px,#000 100%)}.photo-preset-cats[data-overflow=both]{-webkit-mask-image:linear-gradient(to right,transparent 0,#000 16px,#000 calc(100% - 16px),transparent 100%);mask-image:linear-gradient(to right,transparent 0,#000 16px,#000 calc(100% - 16px),transparent 100%)}.photo-preset-cats::-webkit-scrollbar{display:none}.photo-preset-cats button{flex:0 0 auto;white-space:nowrap;padding:4px 10px;border:1px solid var(--photo-border-soft);border-radius:999px;color:#9aa2ab;background:transparent;font-size:11px;cursor:pointer;transition:color .15s ease,background .15s ease,border-color .15s ease}.photo-preset-cat-count{margin-left:5px;padding:0 4px;border-radius:999px;background:#9bbedc4d;color:#e6edf3;font-size:9px;font-style:normal;line-height:1.4}.photo-preset-cats button:hover{color:#e2e7ec;background:#ffffff0f}.photo-preset-cats button.active{color:#fff;border-color:#9bbedca6;background:#8cafcc38}.photo-preset-strength{margin-top:12px;padding-top:10px;border-top:1px solid var(--photo-border-soft)}.photo-preset-strength-hint{display:block;margin-top:2px;color:#6f7780;font-size:10px}.photo-quick-fixes button{color:#cbb8ff;border-color:#a78bfa66;background:#7c3aed1a}.photo-quick-fixes button:hover:not(:disabled){background:#7c3aed33;border-color:#a78bfaa6}.photo-quick-fixes button:disabled{opacity:.45}.photo-preset-card{display:flex;flex-direction:column;padding:0;border:1px solid var(--photo-border-soft);border-radius:7px;overflow:hidden;background:#ffffff09;cursor:pointer;transition:border-color .15s ease,transform .15s ease,box-shadow .15s ease}.photo-preset-card:hover{border-color:#9bbedc8c;transform:translateY(-1px)}.photo-preset-card:active{transform:translateY(0) scale(.98)}.photo-preset-card.is-applied{border-color:#7ab4eed9;box-shadow:inset 0 0 0 1px #7ab4ee73}.photo-preset-card.is-modified{border-color:#9bbedc73;border-style:dashed}.photo-preset-thumb{display:block;aspect-ratio:3 / 2;background:#14171a}.photo-preset-thumb img,.photo-preset-thumb-fallback{display:block;width:100%;height:100%;object-fit:cover}.photo-preset-thumb img{image-rendering:auto}.photo-preset-name{display:block;padding:4px 5px 5px;overflow:hidden;color:#cdd4da;font-size:10px;text-align:center;text-overflow:ellipsis;white-space:nowrap}.photo-preset-card.is-applied .photo-preset-name{color:#e9f2fb}.photo-preset-card.is-mine{position:relative}.photo-preset-apply{display:flex;flex-direction:column;width:100%;padding:0;border:0;background:none;color:inherit;cursor:pointer;text-align:left}.photo-preset-delete{position:absolute;top:3px;right:3px;display:flex;align-items:center;justify-content:center;width:16px;height:16px;padding:0;border:1px solid rgba(255,255,255,.18);border-radius:50%;background:#0c0f12d1;color:#d6dde4;font-size:12px;line-height:1;cursor:pointer;opacity:0;transition:opacity .15s ease,background .15s ease}.photo-preset-card.is-mine:hover .photo-preset-delete,.photo-preset-delete:focus-visible{opacity:1}.photo-preset-delete:hover{border-color:#ff8a7ab3;background:#b23e30e6;color:#fff}.photo-preset-empty{margin:0;padding:14px 2px;color:#6f7780;font-size:10px}.photo-preset-save{display:flex;gap:6px;margin-top:10px;padding-top:10px;border-top:1px solid var(--photo-border-soft)}.photo-preset-save-input{flex:1 1 auto;min-width:0;height:24px;padding:0 8px;border:1px solid var(--photo-border-soft);border-radius:5px;background:#ffffff0a;color:#dde3e9;font:inherit;font-size:10px;outline:none;transition:border-color .15s ease,background .15s ease}.photo-preset-save-input::placeholder{color:#6b737c}.photo-preset-save-input:focus{border-color:#7ab4eeb3;background:#ffffff0f}.photo-preset-save-button{flex:0 0 auto;height:24px;padding:0 11px;border:1px solid rgba(155,190,220,.45);border-radius:5px;background:#8cafcc29;color:#dfe7ee;font-size:10px;cursor:pointer;transition:background .15s ease,border-color .15s ease,opacity .15s ease}.photo-preset-save-button:hover:not(:disabled){border-color:#9bbedcb3;background:#8cafcc42}.photo-preset-save-button:disabled{opacity:.4;cursor:default}.photo-coming-soon{display:flex;flex-direction:column;align-items:center;gap:8px;padding:34px 0 30px;color:#6f7880}.photo-coming-soon span{font-size:10px;letter-spacing:.08em}.photo-mask-toolbar{display:grid;grid-template-columns:repeat(2,1fr);gap:6px;margin-bottom:9px}.photo-mask-toolbar button{display:flex;align-items:center;justify-content:center;gap:6px;min-height:29px;border:1px solid var(--photo-border-soft);border-radius:6px;color:#c3cad2;background:#ffffff0b;cursor:pointer;font-size:10px;transition:color .15s ease,border-color .15s ease,background .15s ease,transform .1s ease}.photo-mask-toolbar button:hover{border-color:#9bbedc80;color:#f0f5fa;background:#ffffff14}.photo-mask-toolbar button:active{transform:scale(.97)}.photo-ai-mask-tools{display:grid;grid-template-columns:repeat(3,1fr);gap:5px;margin-bottom:9px}.photo-ai-mask-tools button{display:inline-flex;align-items:center;justify-content:center;gap:4px;min-height:28px;padding:0 5px;border:1px solid var(--photo-ai-border);border-radius:6px;color:#eadfff;background:linear-gradient(180deg,rgba(139,92,246,.24),var(--photo-ai-soft));cursor:pointer;font-size:9px;white-space:nowrap;transition:border-color .15s ease,background .15s ease,transform .1s ease}.photo-ai-mask-tools button:hover{border-color:#c4b5fdeb;background:linear-gradient(180deg,#a78bfa61,#6d28d93d)}.photo-ai-mask-tools button:active{transform:scale(.97)}.photo-ai-mask-tools button:disabled{border-color:#a78bfa38;color:#e1d6ff7a;background:#7c3aed14;cursor:default}.photo-ai-mask-tools button.is-cancel{grid-column:1 / -1;border-color:#ff787580;color:#ffd7d5;background:#ff453a24}.photo-ai-mask-tools button.is-cancel:hover{border-color:#ff8b88d9;background:#ff453a3d}.photo-mask-list-head{display:flex;align-items:center;justify-content:space-between;margin:2px 0 5px;color:#77818b;font-size:10px;font-weight:600;letter-spacing:.04em}.photo-mask-overlay-toggle{display:inline-flex;align-items:center;gap:5px;height:22px;padding:0 7px;border:1px solid transparent;border-radius:6px;color:#8d97a1;background:transparent;cursor:pointer;font-size:10px;font-weight:500;letter-spacing:0;transition:border-color .15s ease,background .15s ease,color .15s ease}.photo-mask-overlay-toggle kbd{padding:0 4px;border:1px solid rgba(255,255,255,.14);border-radius:3px;color:#8d97a1;background:#ffffff0d;font-family:inherit;font-size:9px;line-height:13px}.photo-mask-overlay-toggle:hover{border-color:#9bbedc66;color:#dfe8f0}.photo-mask-overlay-toggle.active{color:#ffb3ae;background:#ff48481f;border-color:#ff6e6e59}.photo-mask-overlay-toggle.active kbd{color:#ffb3ae;border-color:#ff6e6e59}.photo-mask-list{display:flex;flex-direction:column;gap:2px;margin-bottom:8px;padding:3px;border:1px solid var(--photo-border-soft);border-radius:8px;background:#0000002e}.photo-mask-item{display:grid;grid-template-columns:auto 1fr auto;align-items:center;gap:8px;min-height:34px;padding:3px 4px 3px 3px;border:1px solid transparent;border-radius:6px;color:#b4bcc4;cursor:pointer;outline:none;transition:background .13s ease,border-color .13s ease,color .13s ease}.photo-mask-item:hover{color:#e8edf2;background:#ffffff0b}.photo-mask-item:focus-visible{border-color:#4da3ff99}.photo-mask-item.is-selected{color:#f0f6fb;border-color:#9bbedc8c;background:#78a5cd2e}.photo-mask-item.is-hidden{color:#6f7883}.photo-mask-item.is-hidden .photo-mask-thumb{opacity:.4}.photo-mask-thumb{display:block;flex:0 0 auto;border-radius:3px;box-shadow:0 0 0 1px #ffffff14;image-rendering:auto}.photo-mask-item-name{display:flex;align-items:center;gap:5px;min-width:0;font-size:10.5px}.photo-mask-item-name>svg{flex:0 0 auto;color:#8d97a1}.photo-mask-item.is-selected .photo-mask-item-name>svg{color:#bcd6ea}.photo-mask-item-name strong{overflow:hidden;font-weight:600;text-overflow:ellipsis;white-space:nowrap}.photo-mask-item-name em{flex:0 0 auto;min-width:15px;padding:0 4px;border:1px solid rgba(255,255,255,.12);border-radius:4px;color:#9aa4ae;font-size:9px;font-style:normal;line-height:13px;text-align:center}.photo-mask-item-eye{display:inline-flex;align-items:center;justify-content:center;width:22px;height:22px;padding:0;border:0;border-radius:5px;color:#8d97a1;background:transparent;cursor:pointer;opacity:.55;transition:opacity .13s ease,color .13s ease,background .13s ease}.photo-mask-item:hover .photo-mask-item-eye,.photo-mask-item.is-selected .photo-mask-item-eye,.photo-mask-item.is-hidden .photo-mask-item-eye,.photo-mask-item-eye:focus-visible{opacity:1}.photo-mask-item-eye:hover{color:#f0f4f8;background:#ffffff14}.photo-range-picker{display:inline-flex;align-items:center;gap:5px;width:100%;min-height:25px;margin:2px 0 4px;padding:0 8px;border:1px solid rgba(255,255,255,.12);border-radius:6px;color:#9aa4ae;background:#ffffff0b;cursor:pointer;font-size:10px;transition:border-color .15s ease,color .15s ease,background .15s ease}.photo-range-picker:hover{border-color:#9bbedc8c;color:#dfe8f0}.photo-range-picker.active{border-color:#9bbedcbf;color:#eaf3fb;background:#78a5cd33}.photo-mask-rename{min-width:0;height:22px;padding:0 6px;border:1px solid rgba(77,163,255,.65);border-radius:5px;color:#f0f6fb;background:#0c0f12e6;font-size:10.5px}.photo-mask-rename:focus{outline:none}.photo-mask-pins{position:absolute;inset:0;z-index:5;pointer-events:none}.photo-mask-pin{position:absolute;width:11px;height:11px;margin:-5.5px;border:1.6px solid rgba(240,246,252,.92);border-radius:50%;background:#181c2066;box-shadow:0 1px 4px #00000080;cursor:pointer;pointer-events:auto;transition:transform .12s ease}.photo-mask-pin:hover{transform:scale(1.25)}.photo-mask-pin.is-hidden{opacity:.45}.photo-mask-picking{position:absolute;inset:0;z-index:6;cursor:crosshair;background:#0a0c0f14}.photo-mask-actions{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin-bottom:4px}.photo-mask-actions button{display:inline-flex;align-items:center;justify-content:center;gap:5px;min-height:27px;border:1px solid var(--photo-border-soft);border-radius:6px;color:#c3cad2;background:#ffffff0b;cursor:pointer;font-size:10px;transition:color .15s ease,border-color .15s ease,background .15s ease}.photo-mask-actions button:hover{border-color:#9bbedc80;color:#f0f5fa}.photo-mask-actions button:disabled{color:#6f7883;cursor:default}.photo-mask-actions button.active{border-color:#9bbedcbf;color:#f0f6fb;background:#78a5cd38}.photo-mask-range-row{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin:8px 0 4px}.photo-mask-range-row label{display:grid;grid-template-columns:auto 1fr;align-items:center;gap:6px;min-width:0;color:#8d97a1;font-size:9.5px}.photo-mask-range-row select{min-width:0;height:27px;padding:0 6px;border:1px solid var(--photo-border-soft);border-radius:5px;color:#cbd2d9;background:#ffffff0b;font-size:9px}.photo-mask-range-row select:disabled{color:#6f7883;cursor:default}.photo-mask-chips{display:flex;flex-wrap:wrap;gap:5px;margin-bottom:9px}.photo-mask-chips button{padding:4px 9px;border:1px solid var(--photo-border-soft);border-radius:999px;color:#a9b1b9;background:#ffffff09;cursor:pointer;font-size:10px;transition:color .15s ease,border-color .15s ease,background .15s ease}.photo-mask-chips button:hover{color:#e8edf2}.photo-mask-chips button.active{border-color:#9bbedcbf;color:#f0f6fb;background:#78a5cd38}.photo-mask-row{display:flex;gap:7px;margin-top:10px}.photo-mask-row button{flex:1;min-height:27px;border:1px solid var(--photo-border-soft);border-radius:6px;color:#c3cad2;background:#ffffff0b;cursor:pointer;font-size:10px}.photo-mask-row button.active{border-color:#9bbedcbf;color:#f0f6fb;background:#78a5cd38}.photo-mask-delete{color:#e58c86!important}.photo-mask-delete:hover{border-color:#e58c8699!important;background:#e58c861f!important}.photo-mask-overlay{position:absolute;inset:0;z-index:4;pointer-events:none;touch-action:none}.photo-mask-overlay:not(.is-spot)>*{pointer-events:none}.photo-mask-overlay .photo-mask-handle,.photo-mask-overlay .photo-mask-shape.is-gizmo,.photo-mask-overlay .photo-mask-line.is-center,.photo-mask-overlay.is-spot{pointer-events:auto}.photo-mask-shape{position:absolute;box-sizing:border-box;border:1.4px dashed rgba(240,246,252,.85);box-shadow:0 0 0 1px #00000059;pointer-events:none}.photo-mask-shape.is-radial{border-radius:50%;transform:translate(-50%,-50%)}.photo-mask-shape.is-gizmo{border-color:#f0f6fce6;box-shadow:0 0 0 1px #0006,inset 0 0 0 1px #0000004d;cursor:move;pointer-events:auto;transition:border-color .12s ease}.photo-mask-shape.is-gizmo:hover,.photo-mask-overlay.is-dragging .photo-mask-shape.is-gizmo{border-style:solid}.photo-mask-ring{position:absolute;box-sizing:border-box;border:1px solid rgba(240,246,252,.55);border-radius:50%;box-shadow:0 0 0 1px #0000004d}.photo-mask-stem{position:absolute;height:0;border-top:1px solid rgba(240,246,252,.75);box-shadow:0 0 0 1px #0000004d;transform-origin:0 0}.photo-mask-line{position:absolute;height:0;border-top:1.2px dashed rgba(240,246,252,.85);box-shadow:0 0 0 1px #00000059}.photo-mask-line.is-inner{border-top:1px dotted rgba(240,246,252,.45);box-shadow:none}.photo-mask-line.is-center{height:11px;border:0;box-shadow:none;background:linear-gradient(to bottom,transparent 0 5px,rgba(240,246,252,.95) 5px 6.4px,transparent 6.4px);filter:drop-shadow(0 0 1px rgba(0,0,0,.6));cursor:move;pointer-events:auto}.photo-mask-handle{position:absolute;z-index:2;width:14px;height:14px;margin:-7px;border:2px solid #f0f6fc;border-radius:50%;background:#181c2073;box-shadow:0 1px 5px #0000008c;cursor:grab;pointer-events:auto;transition:transform .12s ease}.photo-mask-handle:hover{transform:scale(1.18)}.photo-mask-handle.is-center{width:16px;height:16px;margin:-8px;cursor:move;background:radial-gradient(circle,rgba(24,28,32,.95) 0 3px,transparent 3.6px) center / 100% 100% no-repeat,#f0f6fcf5}.photo-mask-handle.is-center:hover{transform:scale(1.1)}.photo-mask-handle.is-side{width:11px;height:11px;margin:-5.5px;border-width:1.6px;border-radius:2.5px;border-color:#f0f6fc;background:#181c20c7;transform:rotate(var(--mask-angle, 0deg))}.photo-mask-handle.is-side:hover{transform:rotate(var(--mask-angle, 0deg)) scale(1.2)}.photo-mask-handle.is-rotate{width:13px;height:13px;margin:-6.5px;border-color:#f0f6fc;background:#6da8d8e6;cursor:grab}.photo-mask-handle.is-rotate:hover{transform:scale(1.15)}.photo-mask-overlay.is-dragging .photo-mask-handle{cursor:grabbing}.photo-mask-handle.is-source{background:#e8c878e6;cursor:crosshair}.photo-mask-overlay.is-spot{cursor:crosshair}.photo-spot-brush-preview{position:absolute;z-index:5;box-sizing:border-box;border:1px solid rgba(246,249,252,.96);border-radius:50%;pointer-events:none;opacity:0;will-change:left,top,width,height}.photo-spot-brush-preview>i{position:absolute;inset:0;display:block;border-radius:inherit;background:radial-gradient(circle,rgba(240,246,252,.12) 0 var(--photo-spot-feather-stop, 57%),rgba(240,246,252,.035) var(--photo-spot-feather-stop, 57%) 100%);box-shadow:0 0 0 1px #0c0f12b3,inset 0 0 0 1px #0c0f1259;pointer-events:none}.photo-spot-brush-preview>span{position:absolute;top:-25px;left:50%;padding:3px 6px;border:1px solid rgba(255,255,255,.12);border-radius:4px;background:#0f1216e0;color:#f0f3f6;font-size:10px;line-height:14px;white-space:nowrap;transform:translate(-50%);pointer-events:none}.photo-mask-shape.is-selected{border-color:#f0f6fcf2;border-style:solid}.photo-spot-line{position:absolute;height:0;border-top:1px dashed rgba(232,200,120,.8);transform-origin:0 0;pointer-events:none}.photo-tabs{position:sticky;top:0;z-index:2;display:grid;grid-template-columns:repeat(7,1fr);border-bottom:1px solid var(--photo-border);background:#1d2024f7;-webkit-backdrop-filter:blur(18px);backdrop-filter:blur(18px)}.photo-tabs button{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;height:56px;border:0;border-bottom:2px solid transparent;color:#808892;background:transparent;cursor:pointer;font-size:10px;transition:color .16s ease,border-color .16s ease,background .16s ease}.photo-tabs button:hover,.photo-tabs button.active{color:#f2f5f8}.photo-tabs button:active{background:#ffffff0b}.photo-tabs button.active{border-bottom-color:#d9e5ef}.photo-tab-color,.photo-tab-wheel,.photo-tab-detail,.photo-tab-effects,.photo-tab-curves,.photo-color-icon,.photo-wheel-icon,.photo-detail-icon,.photo-effects-icon{display:inline-block;flex:0 0 auto}.photo-tab-color,.photo-color-icon{width:14px;height:14px;border:1px solid rgba(255,255,255,.55);border-radius:50%;background:conic-gradient(#ff453a,#ffd60a,#30d158,#0a84ff,#bf5af2,#ff453a)}.photo-tab-wheel,.photo-wheel-icon{width:14px;height:14px;border:2px solid #7fb8ec;border-radius:50%;box-shadow:inset 0 0 0 3px #1d2024;background:conic-gradient(#ff453a,#ffd60a,#30d158,#0a84ff,#bf5af2,#ff453a)}.photo-tab-detail,.photo-detail-icon{width:15px;height:13px;border:1px solid #aeb7c0;border-radius:2px;background:linear-gradient(135deg,transparent 43%,#b8c1ca 44% 56%,transparent 57%)}.photo-tab-effects,.photo-effects-icon{width:14px;height:14px;border:1px solid #aeb7c0;border-radius:50%;background:radial-gradient(circle,transparent 0 3px,#aeb7c0 4px 5px,transparent 6px)}.photo-tab-curves,.photo-curve-icon{width:15px;height:14px;border:1px solid #aeb7c0;border-radius:2px;background:linear-gradient(140deg,transparent 0 20%,#aeb7c0 21% 27%,transparent 28% 47%,#aeb7c0 48% 54%,transparent 55% 74%,#aeb7c0 75% 81%,transparent 82%)}.photo-scurve-icon{display:inline-block;flex:0 0 auto;fill:none;stroke:currentColor;stroke-width:1.5;stroke-linecap:round}.photo-scurve-icon .photo-scurve-axis{stroke:#aeb7c066;stroke-width:1}.photo-section{border-bottom:1px solid var(--photo-border-soft)}.photo-section summary{display:flex;align-items:center;justify-content:space-between;gap:8px;min-height:32px;padding:0 12px;color:#dee3e8;cursor:pointer;list-style:none;transition:background .13s ease}.photo-section summary:hover{background:#ffffff08}.photo-section summary::-webkit-details-marker{display:none}.photo-section-title{display:flex;align-items:center;gap:7px}.photo-section-actions{display:flex;align-items:center;gap:4px;color:#7f8993}.photo-section-title>svg{color:#9ba4ad;transition:transform .18s cubic-bezier(.22,1,.36,1)}.photo-section[open] .photo-section-title>svg{transform:rotate(0)}.photo-section:not([open]) .photo-section-title>svg{transform:rotate(-90deg)}.photo-section-title strong{font-size:11.5px;font-weight:600;letter-spacing:.01em}.photo-section-actions{color:#7f8993}.photo-section-reset{display:flex;align-items:center;justify-content:center;width:20px;height:20px;padding:0;border:0;border-radius:5px;color:#8c959f;background:transparent;cursor:pointer;opacity:.45;transition:opacity .14s ease,color .14s ease,background .14s ease}.photo-section summary:hover .photo-section-reset,.photo-section-reset:focus-visible{opacity:1}.photo-section-reset:hover{color:#f0f4f8;background:#ffffff14}.photo-section-status{width:7px;height:7px;border:1px solid rgba(77,163,255,.8);border-radius:50%;background:transparent}.photo-section-body{padding:2px 12px 12px;animation:photo-section-in .16s cubic-bezier(.22,1,.36,1) both}@keyframes photo-section-in{0%{opacity:0;transform:translateY(-3px)}to{opacity:1;transform:translateY(0)}}.photo-section-caption{margin:0 0 10px;color:#7c858f;font-size:9.5px;line-height:1.5}.photo-crop-readout{margin:-5px 0 11px;color:#aeb9c2;font-size:10px;font-variant-numeric:tabular-nums}.photo-inspector-subheading{margin:8px 0 3px;color:#77818b;font-size:10px;font-weight:600;letter-spacing:.04em}.photo-inspector-subheading:first-child{margin-top:2px}.photo-preserve-note{display:flex;align-items:flex-start;gap:7px;margin-top:12px;padding:9px 10px;border:1px solid var(--photo-border-soft);border-radius:7px;color:#8f98a2;background:#ffffff09;font-size:10px;line-height:1.45}.photo-slider{display:grid;grid-template-columns:60px minmax(0,1fr) 40px;align-items:center;gap:8px;min-height:24px;color:#a9b1b9;font-size:11px}.photo-slider-sub{grid-template-columns:60px minmax(0,1fr) 36px;min-height:20px;color:#8f98a1}.photo-slider-sub .photo-slider-label{padding-left:10px;font-size:10.5px}.photo-slider-sub input{height:12px}.photo-slider-sub input::-webkit-slider-runnable-track{height:2px}.photo-slider-sub input::-webkit-slider-thumb{width:7px;height:7px;margin-top:-2.5px;border-width:0}.photo-slider-sub input::-moz-range-track{height:2px}.photo-slider-sub output,.photo-slider-sub .photo-value-scrubber{font-size:9px}.photo-slider-label{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.photo-slider output,.photo-value-scrubber{color:#c9d2da;text-align:right;font-size:10px;font-variant-numeric:tabular-nums}.photo-value-scrubber{display:inline-flex;justify-content:flex-end;min-width:0;padding:3px 2px;border-radius:4px;cursor:ew-resize;-webkit-user-select:none;user-select:none;touch-action:none;transition:color .12s ease,background .12s ease}.photo-value-scrubber:hover,.photo-value-scrubber:focus-visible,.photo-value-scrubber.is-dragging{color:#f0f7ff;background:#78aeda29;outline:none}.photo-slider input.photo-value-input{width:100%;height:18px;min-width:0;padding:0 2px;appearance:textfield;border:1px solid rgba(122,180,238,.7);border-radius:4px;background:#0c1014eb;color:#f2f8ff;font:inherit;font-size:10px;font-variant-numeric:tabular-nums;text-align:right;cursor:text}.photo-slider input.photo-value-input:focus{outline:none;border-color:#7ab4eefa;box-shadow:0 0 0 2px #7ab4ee2e}.photo-slider-track{display:flex;align-items:center;min-width:0}.photo-slider input{--slider-progress: 50%;--slider-zero: 50%;width:100%;height:14px;margin:0;appearance:none;background:transparent;cursor:ew-resize}.photo-slider input::-webkit-slider-runnable-track{height:3px;border-radius:2px;background:var( --slider-gradient, linear-gradient( to right, #7f95a9 0 var(--slider-progress), rgba(255, 255, 255, .1) var(--slider-progress) 100% ) )}.photo-slider input::-webkit-slider-thumb{width:9px;height:9px;margin-top:-3px;appearance:none;border:1px solid rgba(10,13,17,.55);border-radius:50%;background:#dde5ec;box-shadow:0 1px 2px #00000073;transition:background .12s ease,box-shadow .12s ease}.photo-slider input:hover::-webkit-slider-thumb{background:#f4f8fc}.photo-slider input:active::-webkit-slider-thumb{background:#fff;box-shadow:0 0 0 3px #7db4de2e,0 1px 2px #00000073}.photo-slider input::-moz-range-track{height:3px;border-radius:2px;background:var(--slider-gradient, rgba(255, 255, 255, .1))}.photo-slider input::-moz-range-progress{height:3px;border-radius:2px;background:#7f95a9}.photo-slider input::-moz-range-thumb{width:9px;height:9px;border:1px solid rgba(10,13,17,.55);border-radius:50%;background:#dde5ec}.photo-slider input:focus-visible{outline:2px solid rgba(77,163,255,.6);outline-offset:3px;border-radius:4px}.photo-channel-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:5px;margin:3px 0 8px}.photo-channel{display:flex;align-items:center;justify-content:center;gap:4px;min-height:26px;padding:0;border:1px solid var(--photo-border-soft);border-radius:5px;color:#adb4bc;background:#ffffff09;cursor:pointer;font-size:10px;font-family:inherit;transition:color .15s ease,border-color .15s ease,background .15s ease}.photo-channel:hover{border-color:#9bbedc73;color:#edf2f6;background:#ffffff12}.photo-channel i,.photo-hsl-group strong i{width:7px;height:7px;border-radius:50%}.photo-hsl-group{padding:7px 0 8px;border-top:1px solid var(--photo-border-soft);scroll-margin-top:64px}.photo-hsl-group strong{display:flex;align-items:center;gap:6px;margin-bottom:2px;color:#e1e5e9;font-size:11px}.photo-segmented{display:grid;grid-template-columns:repeat(4,1fr);gap:2px;margin-bottom:11px;padding:2px;border:1px solid var(--photo-border-soft);border-radius:7px;background:#ffffff0b}.photo-segmented button{height:24px;padding:0;border:0;border-radius:5px;color:#98a1aa;background:transparent;cursor:pointer;font-size:10px;transition:color .15s ease,background .15s ease}.photo-segmented button:hover{color:#e8edf2}.photo-segmented button.active{color:#10161c;background:#d9e5ef;font-weight:600}.photo-hsl-row{display:grid;grid-template-columns:12px minmax(0,1fr);gap:7px;align-items:center}.photo-hsl-chip{width:9px;height:9px;border-radius:50%;box-shadow:inset 0 0 0 1px #ffffff47,0 0 4px #00000059}.photo-hsl-row .photo-slider{min-height:27px;grid-template-columns:30px minmax(0,1fr) 36px;gap:7px}.photo-hsl-row .photo-slider-label{color:#c6ccd3;font-size:11px}.photo-hsl-row .photo-slider output{font-size:9px}.photo-hsl-row .photo-slider input{height:15px}.photo-hsl-row .photo-slider input::-webkit-slider-runnable-track{height:4px}.photo-hsl-row .photo-slider input::-webkit-slider-thumb{width:11px;height:11px;margin-top:-3.5px;border-width:1.6px}.photo-hsl-row .photo-slider input::-moz-range-track{height:4px}.photo-hsl-component{padding-bottom:5px;margin-bottom:3px;border-bottom:1px solid var(--photo-border-soft)}.photo-hsl-component:last-child{border-bottom:0;margin-bottom:0}.photo-wheel-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;align-items:start}.photo-wheel-card{min-width:0;padding:9px 7px 8px;border:1px solid rgba(255,255,255,.1);border-radius:9px;background:#ffffff09;transition:border-color .16s ease,background .16s ease,transform .16s ease}.photo-wheel-card:hover{border-color:#9bbedc75;background:#ffffff0f;transform:translateY(-1px)}.photo-wheel-card.is-top{grid-column:1 / -1;grid-row:1;justify-self:center;width:min(100%,188px)}.photo-wheel-card.is-left{grid-column:1;grid-row:2}.photo-wheel-card.is-right{grid-column:2;grid-row:2}.photo-wheel-card-heading{display:flex;align-items:flex-start;justify-content:space-between;gap:4px;margin:0 2px 5px}.photo-wheel-card-heading div{display:flex;flex-direction:column;gap:2px;min-width:0}.photo-wheel-card-heading strong{color:#f0f3f5;font-size:11px;font-weight:650}.photo-wheel-card-heading span{color:#7e8892;font-size:9px}.photo-wheel-card-heading button{display:flex;align-items:center;justify-content:center;width:20px;height:20px;padding:0;border:0;border-radius:5px;color:#7f8993;background:transparent;cursor:pointer}.photo-wheel-card-heading button:hover{color:#fff;background:#ffffff14}.photo-wheel{position:relative;width:min(112px,100%);aspect-ratio:1;margin:6px auto 7px;border:1px solid rgba(255,255,255,.16);border-radius:50%;background:conic-gradient(from 0deg,#ff453a,#ff9f0a,#ffd60a,#30d158,#64d2ff,#0a84ff,#5e5ce6,#bf5af2,#ff375f,#ff453a);box-shadow:0 0 0 1px #ffffff0f,0 5px 15px #00000052;cursor:crosshair;touch-action:none}.photo-wheel:before{content:"";position:absolute;inset:8px;border-radius:50%;background:conic-gradient(from 0deg,#ff453a33,#ffd60a2e,#30d1582e,#0a84ff2e,#bf5af233,#ff453a33);filter:blur(4px)}.photo-wheel-core{position:absolute;inset:16px;z-index:1;border:1px solid rgba(255,255,255,.13);border-radius:50%;background:radial-gradient(circle at 42% 38%,#68717b,#2c3137 62%,#202429);box-shadow:inset 0 1px 2px #ffffff29,0 0 0 3px #12141780}.photo-wheel-marker{position:absolute;z-index:2;left:50%;top:50%;width:9px;height:9px;margin:-4.5px;border:2px solid #fff;border-radius:50%;background:#0c0e1040;box-shadow:0 1px 4px #000000b3}.photo-wheel-readout{display:flex;justify-content:space-between;margin:0 3px 5px;color:#858e98;font-size:9px;font-variant-numeric:tabular-nums}.photo-wheel-readout b{color:#dce2e7;font-weight:600}.photo-wheel-card .photo-slider{display:block;min-height:0}.photo-wheel-card .photo-slider-label,.photo-wheel-card .photo-slider output{display:none}.photo-wheel-card .photo-slider-track{display:block}.photo-wheel-global{margin-top:11px;padding-top:9px;border-top:1px solid var(--photo-border-soft)}.photo-ratio-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:5px;margin-bottom:4px}.photo-ratio-chip{min-height:26px;padding:0 4px;border:1px solid var(--photo-border-soft);border-radius:5px;color:#adb4bc;background:#ffffff09;cursor:pointer;font-size:10px;font-variant-numeric:tabular-nums;transition:color .15s ease,border-color .15s ease,background .15s ease}.photo-ratio-chip:hover{border-color:#9bbedc73;color:#edf2f6;background:#ffffff12}.photo-ratio-chip.active{border-color:#9bbedcbf;color:#f0f6fb;background:#78a5cd38}.photo-geometry-buttons{display:grid;grid-template-columns:repeat(2,1fr);gap:6px}.photo-geometry-buttons button{display:flex;align-items:center;justify-content:center;gap:6px;min-height:29px;border:1px solid var(--photo-border-soft);border-radius:6px;color:#c3cad2;background:#ffffff0b;cursor:pointer;font-size:10px;transition:color .15s ease,border-color .15s ease,background .15s ease,transform .1s ease}.photo-geometry-buttons button:hover{border-color:#9bbedc80;color:#f0f5fa;background:#ffffff14}.photo-geometry-buttons button:active{transform:scale(.97)}.photo-geometry-buttons button.active{border-color:#9bbedcbf;color:#f0f6fb;background:#78a5cd38}.photo-crop-icon{width:14px;height:14px;border:1.4px solid #aeb7c0;border-radius:2px;background:linear-gradient(#aeb7c0,#aeb7c0) left top / 5px 1.4px no-repeat,linear-gradient(#aeb7c0,#aeb7c0) left top / 1.4px 5px no-repeat,linear-gradient(#aeb7c0,#aeb7c0) right bottom / 5px 1.4px no-repeat,linear-gradient(#aeb7c0,#aeb7c0) right bottom / 1.4px 5px no-repeat}.photo-notice{position:fixed;bottom:17px;left:50%;z-index:5;transform:translate(-50%);padding:9px 13px;border:1px solid rgba(255,255,255,.15);border-radius:7px;color:#ecf1f5;background:#272b30f5;box-shadow:0 10px 30px #00000073;pointer-events:none;animation:photo-notice-lifecycle var(--photo-notice-duration, 2.6s) ease forwards}@keyframes photo-notice-lifecycle{0%{opacity:0;transform:translate(-50%,6px) scale(.98)}9%,82%{opacity:1;transform:translate(-50%) scale(1)}to{opacity:0;transform:translate(-50%,-3px) scale(.99)}}.photo-histogram{margin:8px 12px 6px;padding:7px 8px 6px;border:1px solid var(--photo-border-soft);border-radius:6px;background:#090b0d85}.photo-histogram-heading,.photo-histogram-axis{display:flex;align-items:center;justify-content:space-between;color:#aeb7c0;font-size:10px}.photo-histogram-heading small{color:#717b85;font-size:9px}.photo-histogram svg,.photo-histogram-canvas{display:block;width:100%;height:72px;margin:6px 0 4px;border-radius:3px}.photo-histogram-grid,.photo-curve-grid{stroke:#ffffff1a;stroke-width:.45;fill:none}.photo-histogram-area{stroke:none;mix-blend-mode:screen;opacity:.55;transition:d .12s linear}.photo-histogram-red{fill:#ff453a9e}.photo-histogram-green{fill:#30d1588c}.photo-histogram-blue{fill:#0a84ff99}.photo-histogram-axis{color:#68727c;font-size:8px}.photo-histogram-heading small.is-warn{color:#e0a05a}.photo-histogram-meta{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:4px;margin-top:3px;color:#6b747d;font-size:8px;font-variant-numeric:tabular-nums}.photo-histogram-meta>span{overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.photo-histogram-meta>span:nth-child(2){text-align:center}.photo-histogram-meta>span:nth-child(3){text-align:right}.photo-histogram-meta .is-clip{color:#d9974f}.photo-reference-strip{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:5px 8px;margin:0 16px 9px;padding:7px 8px;border:1px solid rgba(167,139,250,.36);border-radius:6px;background:#6d28d921;color:#e7ddff;font-size:10px}.photo-reference-strip>div{display:grid;min-width:0;gap:2px}.photo-reference-strip small{overflow:hidden;color:#a99bc5;text-overflow:ellipsis;white-space:nowrap}.photo-reference-strip>button{display:grid;width:22px;height:22px;place-items:center;border:0;border-radius:4px;color:#b7a6d8;background:transparent;cursor:pointer}.photo-reference-strip>button:hover{color:#f2f7fb;background:#ffffff1a}.photo-reference-strip label{display:grid;grid-template-columns:34px minmax(0,1fr) 27px;grid-column:1 / -1;align-items:center;gap:6px;color:#a9bdcb;font-size:9px}.photo-reference-strip input{width:100%;accent-color:#a78bfa}.photo-reference-strip b{color:#e8f2f8;font-size:9px;text-align:right}.photo-curve-editor{margin-top:8px}.photo-curve-neutral{stroke:#ffffff57;stroke-width:.8;fill:none;stroke-dasharray:2 2}.photo-curve-line{fill:none;stroke:#cbdbe8;stroke-width:1.8;vector-effect:non-scaling-stroke}.photo-curve-point{fill:#1a1d20;stroke:#ecf5fb;stroke-width:1.3;vector-effect:non-scaling-stroke}.photo-curve-point.active{fill:#6da8d8}.photo-curve-backdrop{stroke:none;mix-blend-mode:screen;opacity:.3}.photo-curve-backdrop.is-red{fill:#ff453aa8}.photo-curve-backdrop.is-green{fill:#30d15899}.photo-curve-backdrop.is-blue{fill:#0a84ffa8}.photo-curve-toolbar{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:7px}.photo-curve-channels{display:flex;align-items:center;gap:8px}.photo-curve-dot{width:18px;height:18px;padding:0;border:0;border-radius:50%;background:var(--dot-color, #fff);opacity:.85;cursor:pointer;transition:transform .14s ease,box-shadow .14s ease,opacity .14s ease}.photo-curve-dot:hover{transform:scale(1.14);opacity:.9}.photo-curve-dot.active{opacity:1;box-shadow:0 0 0 2px #eef4fa8c,0 0 12px color-mix(in srgb,var(--dot-color, #fff) 45%,transparent)}.photo-curve-footer{display:flex;align-items:center;justify-content:space-between;margin-top:7px}.photo-curve-io{display:inline-flex;align-items:center;gap:6px;color:#727c86;font-size:9px}.photo-curve-io em{font-style:normal}.photo-curve-io b{min-width:24px;color:#d8dfe6;font-weight:600;font-variant-numeric:tabular-nums}.photo-curve-toolbar select,.photo-curve-toolbar button{height:25px;padding:0 8px;border:1px solid var(--photo-border-soft);border-radius:5px;color:#cbd2d9;background:#ffffff0b;font-size:10px}.photo-curve-toolbar button{cursor:pointer}.photo-curve-editor svg{display:block;width:100%;aspect-ratio:1;overflow:visible;border:1px solid var(--photo-border);border-radius:4px;background:#16191d;cursor:crosshair;touch-action:none}.photo-curve-hint{display:block;margin-top:6px;color:#727c86;font-size:9px}@media(max-width:1120px){.photo-workspace{grid-template-columns:54px minmax(0,1fr) 340px}.photo-wheel-grid{gap:5px}.photo-wheel-card{padding-inline:5px}}@media(max-width:900px){.photo-workspace{grid-template-columns:52px minmax(0,1fr)}.photo-controls{position:absolute;top:76px;right:0;bottom:0;z-index:7;width:360px;box-shadow:-15px 0 34px #0000007a}.photo-header-actions button:not(.photo-primary):not(.photo-icon):not(.photo-license-badge){width:30px;padding:0;justify-content:center;font-size:0}.photo-header-count,.photo-title span{display:none}}@media(max-width:640px){.photo-workspace{grid-template-columns:1fr}.photo-filmstrip{display:none}.photo-controls{width:min(100vw,402px)}.photo-image-stage{padding:18px}}.photo-license-badge{display:inline-flex;align-items:center;gap:4px;height:22px;margin-right:2px;padding:0 8px;border:1px solid rgba(167,139,250,.38);border-radius:999px;color:#c2b2f5;background:#7c3aed1f;font-size:10.5px;cursor:pointer;-webkit-app-region:no-drag}.photo-license-badge:hover{background:#7c3aed3d}.photo-license-badge.locked{border-color:#ff786e80;color:#ff9a90;background:#ff453a1f}.photo-license-lock{position:absolute;inset:76px 0 0;z-index:40;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;padding:24px;text-align:center;color:#dfe4ea;background:#0c0e10c7;-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px)}.photo-license-lock strong{font-size:16px}.photo-license-lock span{max-width:420px;color:#9aa2ac;line-height:1.6}.photo-license-lock .photo-primary{margin-top:6px;display:inline-flex;align-items:center;gap:6px}.photo-license-backdrop{position:absolute;inset:0;z-index:60;display:flex;align-items:center;justify-content:center;padding:24px;background:#08090b99}.photo-license-modal{width:min(480px,100%);padding:18px 20px 16px;border:1px solid rgba(255,255,255,.12);border-radius:14px;background:#1e2126fc;box-shadow:0 24px 70px #0000008c}.photo-license-modal-head{display:flex;align-items:center;gap:8px;color:#eef1f5;font-size:14px}.photo-license-modal-head strong{flex:1}.photo-license-close{display:inline-flex;padding:5px;border:0;border-radius:7px;color:#9aa2ac;background:transparent;cursor:pointer}.photo-license-close:hover{background:#ffffff14;color:#eef1f5}.photo-license-note{margin:10px 0 0;color:#9aa2ac;font-size:12px;line-height:1.6}.photo-license-note code{padding:1px 5px;border-radius:5px;background:#a78bfa24;color:#cbb8ff;font-size:11px}.photo-license-input{width:100%;margin-top:12px;padding:10px 11px;border:1px solid rgba(255,255,255,.16);border-radius:9px;background:#14171b;color:#e6eaef;font-family:ui-monospace,SF Mono,Menlo,monospace;font-size:11.5px;line-height:1.6;resize:none;outline:none}.photo-license-input:focus{border-color:#a78bfa99}.photo-license-error{margin:9px 0 0;color:#ff8b80;font-size:12px}.photo-license-machine{display:flex;align-items:center;gap:8px;margin-top:11px;color:#8b929c;font-size:11.5px}.photo-license-machine code{padding:3px 8px;border-radius:6px;background:#ffffff12;color:#cdd3da;font-size:11px;letter-spacing:.04em}.photo-license-machine button{padding:3px 9px;border:1px solid var(--photo-border);border-radius:6px;color:#d6dbe0;background:#ffffff0f;cursor:pointer;font-size:11px}.photo-license-modal-foot{display:flex;justify-content:flex-end;gap:9px;margin-top:16px}.photo-license-modal-foot button{padding:7px 15px;border:1px solid var(--photo-border);border-radius:8px;color:#d6dbe0;background:#ffffff0f;cursor:pointer}.photo-license-modal-foot .photo-primary{border:0;color:#fff;background:var(--photo-ai-border, #8b5cf6)}.photo-license-modal-foot .photo-primary:disabled{opacity:.55;cursor:default}.photo-filmstrip-add{flex:0 0 44px;height:100%;min-height:48px;border:1px dashed rgba(255,255,255,.16);border-radius:7px;color:#6b737c;background:transparent;font-size:16px;cursor:pointer;transition:color .14s ease,background .14s ease,border-color .14s ease}.photo-filmstrip-add:hover{border-color:#ffffff47;color:#d3dae1;background:#ffffff0b}.photo-filmstrip-meta{margin-left:auto;align-self:center;padding-right:4px;color:#6f7780;font-size:10.5px;font-variant-numeric:tabular-nums;white-space:nowrap}.photo-canvas{position:relative}.photo-canvas-chips{position:absolute;left:14px;bottom:14px;z-index:6;display:flex;flex-direction:column;align-items:flex-start;gap:8px;max-width:60%;pointer-events:none}.photo-canvas-chip{display:inline-flex;align-items:center;gap:6px;max-width:100%;padding:6px 10px;border:1px solid rgba(255,255,255,.12);border-radius:8px;color:#d7dae1;background:#0c0e12d1;-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px);font-size:11.5px;overflow:hidden}.photo-canvas-chip-text{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.photo-canvas-chip-mask{color:#ffb3ac;border-color:#ff695c59}.photo-canvas-chip-ref{color:#c4b0ff;border-color:#8b5cf659}.photo-batchbar-select{height:26px;padding:0 6px;border:1px solid var(--photo-border-soft);border-radius:7px;color:#aeb5be;background:#101318;font-size:11.5px;cursor:pointer}.photo-batchbar-quality{display:inline-flex;align-items:center;gap:6px;color:#8f96a0;font-size:11px;white-space:nowrap}.photo-batchbar-quality input[type=range]{width:76px;accent-color:#8b5cf6}.photo-batchbar-quality b{color:#cdd4da;font-weight:500;min-width:22px}.photo-warp-row{display:flex;align-items:center;justify-content:space-between;margin-top:10px;color:#727982;font-size:11px}.photo-warp-row button{padding:5px 11px;border:1px solid rgba(255,120,110,.4);border-radius:7px;color:#ff9a90;background:#ff453a14;font-size:11px;cursor:pointer}.photo-warp-row button:hover:not(:disabled){background:#ff453a29}.photo-warp-row button:disabled{opacity:.45;cursor:default}.photo-image-stage.is-liquify{cursor:crosshair}.photo-reference-zones{display:flex;gap:4px;margin-top:6px}.photo-reference-zones button{padding:3px 9px;border:1px solid rgba(255,255,255,.12);border-radius:999px;color:#9aa2ab;background:transparent;font-size:10.5px;cursor:pointer}.photo-reference-zones button:hover{color:#e2e7ec;background:#ffffff0f}.photo-reference-zones button.active{color:#c4b0ff;border-color:#8b5cf680;background:#7c3aed29}.photo-sky-row{display:flex;align-items:center;gap:8px;margin:4px 0 8px}.photo-sky-toggle{padding:4px 12px;border:1px solid var(--photo-border-soft);border-radius:999px;color:#9aa2ab;background:#ffffff0b;font-size:11px;cursor:pointer}.photo-sky-toggle.on{color:#c4b0ff;border-color:#8b5cf680;background:#7c3aed29}.photo-sky-select{height:26px;padding:0 6px;border:1px solid var(--photo-border-soft);border-radius:7px;color:#aeb5be;background:#101318;font-size:11.5px;cursor:pointer}.photo-sky-hint{color:#8f96a0;font-size:10.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.photo-adjust-shell{-webkit-user-select:none;user-select:none}.photo-adjust-shell input,.photo-adjust-shell textarea,.photo-adjust-shell [contenteditable=true]{-webkit-user-select:text;user-select:text}.photo-adjust-shell button:focus-visible,.photo-adjust-shell summary:focus-visible,.photo-adjust-shell select:focus-visible,.photo-adjust-shell [tabindex]:focus-visible{outline:2px solid rgba(120,180,235,.62);outline-offset:2px}@media(prefers-reduced-motion:reduce){.photo-adjust-shell *,.photo-adjust-shell *:before,.photo-adjust-shell *:after{animation-duration:.001ms!important;animation-iteration-count:1!important;transition-duration:.001ms!important}}', Ye = window.api, Ab = window.orcaboxAssetProtocolToken, dp = [
  { id: "red", label: "红", color: "#ff453a", hue: 0 },
  { id: "orange", label: "橙", color: "#ff9f0a", hue: 30 },
  { id: "yellow", label: "黄", color: "#ffd60a", hue: 55 },
  { id: "green", label: "绿", color: "#30d158", hue: 120 },
  { id: "aqua", label: "青", color: "#64d2ff", hue: 180 },
  { id: "blue", label: "蓝", color: "#0a84ff", hue: 220 },
  { id: "purple", label: "紫", color: "#bf5af2", hue: 280 },
  { id: "magenta", label: "洋红", color: "#ff375f", hue: 320 }
];
if (typeof document < "u" && !document.getElementById("orcabox-photo-adjust-style")) {
  const r = document.createElement("style");
  r.id = "orcabox-photo-adjust-style", r.textContent = yb, document.head.appendChild(r);
}
function zh(r) {
  return hb(r, Ab);
}
function vb() {
  try {
    const r = JSON.parse(new URLSearchParams(window.location.search).get("assetIds") || "[]");
    return Array.isArray(r) ? r.filter((h) => typeof h == "string") : [];
  } catch {
    return [];
  }
}
function Mb(r, h) {
  const u = h < 0.01 ? 3 : h < 0.1 ? 2 : Math.abs(r - Math.round(r)) > 1e-6 ? 1 : 0;
  return (r > 0 ? "+" : "") + r.toFixed(u);
}
function wb(r, h) {
  const u = h < 0.01 ? 3 : h < 0.1 ? 2 : Math.abs(r - Math.round(r)) > 1e-6 ? 1 : 0;
  return r.toFixed(u);
}
function Eb({ size: r = 15 }) {
  return /* @__PURE__ */ s.jsxs(
    "svg",
    {
      className: "photo-scurve-icon",
      width: r,
      height: r,
      viewBox: "0 0 16 16",
      "aria-hidden": "true",
      children: [
        /* @__PURE__ */ s.jsx("path", { d: "M2.4 13.2 C2.4 10.2 5.1 10.2 8 8 C10.9 5.8 13.6 5.8 13.6 2.8" }),
        /* @__PURE__ */ s.jsx("path", { className: "photo-scurve-axis", d: "M2 14 H14 M2 14 V2" })
      ]
    }
  );
}
function Xh(r) {
  const h = atob(r), u = new Uint8Array(h.length);
  for (let c = 0; c < h.length; c += 1) u[c] = h.charCodeAt(c);
  return u;
}
function Rb(r) {
  let h = "";
  for (let u = 0; u < r.length; u += 1) h += String.fromCharCode(r[u]);
  return btoa(h);
}
function Sb(r, h, u) {
  const c = /^data:image\/raw-mask;base64,([^;]+);width=(\d+);height=(\d+)$/.exec(r);
  if (!c) return null;
  const g = Xh(c[1]), m = Number(c[2]), b = Number(c[3]);
  if (!m || !b || g.length < m * b * 4) return null;
  const A = Math.min(1, 384 / Math.max(m, b)), v = Math.max(1, Math.round(m * A)), y = Math.max(1, Math.round(b * A)), S = new Uint8Array(v * y);
  for (let C = 0; C < y; C += 1) {
    const k = Math.min(b - 1, Math.floor((C + 0.5) / y * b)), j = u ? Math.min(u.height - 1, Math.floor((C + 0.5) / y * u.height)) : 0;
    for (let L = 0; L < v; L += 1) {
      const Z = Math.min(m - 1, Math.floor((L + 0.5) / v * m)), it = g[(k * m + Z) * 4];
      let mt = h === "background" ? 255 - it : it;
      if (h === "sky") {
        const tt = u ? Math.min(u.width - 1, Math.floor((L + 0.5) / v * u.width)) : 0, Y = u ? (j * u.width + tt) * 4 : 0, W = u ? u.data[Y] / 255 : 0.5, et = u ? u.data[Y + 1] / 255 : 0.5, rt = u ? u.data[Y + 2] / 255 : 0.5, Mt = W * 0.2126 + et * 0.7152 + rt * 0.0722, J = Math.max(W, et, rt) - Math.min(W, et, rt), ht = Math.max(0, Math.min(1, (rt - Math.max(W, et)) * 3.2 + (rt - W) * 0.4)), Tt = Math.max(0, Math.min(1, (Mt - 0.5) / 0.42)) * Math.max(0, 1 - J * 3), kt = Math.max(0, 1 - Math.max(0, (C / y - 0.28) / 0.62)), Yt = Math.max(ht, Tt * 0.9) * (0.35 + kt * 0.65);
        mt = Math.round((255 - it) * Math.min(1, Yt));
      }
      S[C * v + L] = mt;
    }
  }
  return { kind: h, width: v, height: y, data: Rb(S) };
}
function Tb(r) {
  return /integrity|download/i.test(r) ? "AI 模型下载失败或校验未通过，请检查网络后重试" : /worker exited/i.test(r) ? "AI 引擎异常退出，请重试" : /Invalid AI mask source image/i.test(r) ? "当前照片无法用于 AI 分析，请重新导入后再试" : /onnx|inference|session/i.test(r) ? "AI 引擎推理失败，请重试或更换图片" : /Asset not found/i.test(r) ? "照片已不在素材库中，请重新选择" : r;
}
function Cb(r) {
  const h = Math.min(1, 1600 / Math.max(r.width, r.height)), u = Math.max(1, Math.round(r.width * h)), c = Math.max(1, Math.round(r.height * h)), g = document.createElement("canvas");
  g.width = r.width, g.height = r.height;
  const m = g.getContext("2d");
  if (!m) return null;
  m.putImageData(new ImageData(r.data, r.width, r.height), 0, 0);
  const b = document.createElement("canvas");
  b.width = u, b.height = c;
  const A = b.getContext("2d");
  return A ? (A.imageSmoothingEnabled = !0, A.imageSmoothingQuality = "high", A.drawImage(g, 0, 0, u, c), b.toDataURL("image/png")) : null;
}
function Nb(r) {
  const h = M.useRef(null), u = M.useRef(r);
  u.current = r;
  const [c, g] = M.useState(!1), [m, b] = M.useState(""), A = M.useRef(null), v = M.useRef(null), y = M.useRef(!1), S = (Y, W) => {
    const et = u.current, rt = W ?? et.step, Mt = Math.round(Y / rt) * rt;
    return Math.min(et.max, Math.max(et.min, Number(Mt.toFixed(4))));
  }, C = () => {
    const Y = u.current;
    b(wb(Y.value, Y.step)), g(!0);
  }, k = () => {
    v.current && clearTimeout(v.current), v.current = setTimeout(() => {
      v.current = null, C();
    }, 180);
  };
  M.useEffect(
    () => () => {
      v.current && clearTimeout(v.current);
    },
    []
  ), M.useEffect(() => {
    if (!c) return;
    const Y = A.current;
    Y && (Y.focus(), Y.select());
  }, [c]);
  const j = () => {
    const Y = u.current, W = Number(m.replace(",", ".").replace(/[+\s]/g, "").trim());
    Number.isFinite(W) && Y.onChange(S(W, Y.step)), g(!1);
  }, L = (Y) => {
    Y.preventDefault(), Y.stopPropagation(), window.dispatchEvent(new CustomEvent("photo-adjust:interaction", { detail: !0 })), h.current = {
      pointerId: Y.pointerId,
      startX: Y.clientX,
      startValue: u.current.value,
      fine: Y.shiftKey,
      // ⌘/Ctrl 再细一档：光标每移动 1px 只走 1/50 档，适合收尾微调。
      ultra: Y.metaKey || Y.ctrlKey,
      moved: !1
    }, Y.currentTarget.setPointerCapture(Y.pointerId), Y.currentTarget.classList.add("is-dragging");
  }, Z = (Y) => {
    const W = h.current;
    if (!W || Y.pointerId !== W.pointerId) return;
    const et = u.current, rt = W.ultra ? et.step / 50 : W.fine ? et.step / 10 : et.step, Mt = W.fine || W.ultra ? 1 : 3, J = Math.round((Y.clientX - W.startX) / Mt);
    J !== 0 && (W.moved = !0), et.onChange(S(W.startValue + J * rt, rt));
  }, it = (Y) => {
    const W = h.current;
    W?.pointerId === Y.pointerId && (h.current = null), Y.currentTarget.classList.remove("is-dragging"), W && !W.moved && k();
  }, mt = () => {
    v.current && (clearTimeout(v.current), v.current = null), r.reset?.();
  }, tt = (Y) => {
    const W = u.current, et = W.step / 10, rt = Y.metaKey || Y.ctrlKey ? W.step / 50 : Y.shiftKey ? et : W.step;
    Y.key === "ArrowLeft" || Y.key === "ArrowDown" ? (Y.preventDefault(), W.onChange(S(W.value - rt, rt))) : Y.key === "ArrowRight" || Y.key === "ArrowUp" ? (Y.preventDefault(), W.onChange(S(W.value + rt, rt))) : Y.key === "PageDown" ? (Y.preventDefault(), W.onChange(S(W.value - W.step * 10, W.step))) : Y.key === "PageUp" ? (Y.preventDefault(), W.onChange(S(W.value + W.step * 10, W.step))) : Y.key === "Enter" ? (Y.preventDefault(), C()) : Y.key === "Home" ? (Y.preventDefault(), W.onChange(W.min)) : Y.key === "End" && (Y.preventDefault(), W.onChange(W.max));
  };
  return c ? /* @__PURE__ */ s.jsx(
    "input",
    {
      ref: A,
      className: "photo-value-input",
      value: m,
      inputMode: "decimal",
      spellCheck: !1,
      "aria-label": "输入精确数值",
      onChange: (Y) => b(Y.target.value),
      onBlur: () => {
        if (y.current) {
          y.current = !1, g(!1);
          return;
        }
        j();
      },
      onKeyDown: (Y) => {
        Y.key === "Enter" ? (Y.preventDefault(), A.current?.blur()) : Y.key === "Escape" && (Y.preventDefault(), y.current = !0, A.current?.blur());
      }
    }
  ) : /* @__PURE__ */ s.jsx(
    "output",
    {
      className: "photo-value-scrubber",
      role: "slider",
      tabIndex: 0,
      "aria-valuemin": r.min,
      "aria-valuemax": r.max,
      "aria-valuenow": r.value,
      title: "拖动微调，Shift 精细 10 倍，⌘/Ctrl 再细 50 倍，单击输入精确值，双击复位",
      onPointerDown: L,
      onPointerMove: Z,
      onPointerUp: it,
      onPointerCancel: it,
      onDoubleClick: mt,
      onKeyDown: tt,
      children: Mb(r.value, r.step)
    }
  );
}
function ta(r, h) {
  const u = r.length - 1, c = r.map((m, b) => `${m} ${b / u * 100}%`).join(", "), g = "rgba(240, 246, 252, 0.85)";
  return `linear-gradient(to right, transparent calc(${h}% - 1px), ${g} calc(${h}% - 1px), ${g} calc(${h}% + 1px), transparent calc(${h}% + 1px)), linear-gradient(to right, ${c})`;
}
const ze = {
  temperature: ta(["hsl(210 85% 58%)", "hsl(42 82% 55%)"], 50),
  tint: ta(["hsl(140 58% 50%)", "hsl(322 64% 58%)"], 50),
  exposure: ta(["hsl(0 0% 3%)", "hsl(0 0% 96%)"], 50),
  contrast: ta(["hsl(0 0% 16%)", "hsl(0 0% 82%)"], 50),
  highlights: ta(["hsl(0 0% 28%)", "hsl(0 0% 100%)"], 50),
  shadows: ta(["hsl(0 0% 0%)", "hsl(0 0% 70%)"], 50),
  whites: ta(["hsl(0 0% 42%)", "hsl(0 0% 100%)"], 50),
  blacks: ta(["hsl(0 0% 0%)", "hsl(0 0% 52%)"], 50),
  vibrance: ta(["hsl(0 0% 40%)", "hsl(200 78% 55%)"], 50),
  saturation: ta(["hsl(0 0% 30%)", "hsl(8 88% 56%)"], 50),
  texture: ta(["hsl(0 0% 34%)", "hsl(0 0% 86%)"], 50),
  clarity: ta(["hsl(0 0% 22%)", "hsl(0 0% 80%)"], 50),
  dehaze: ta(["hsl(214 32% 58%)", "hsl(38 42% 52%)"], 50),
  luminance: ta(["hsl(0 0% 5%)", "hsl(0 0% 96%)"], 50)
}, qh = [
  { id: "asshot", label: "原照", temperature: 0, tint: 0 },
  { id: "daylight", label: "日光", temperature: -18, tint: -4 },
  { id: "cloudy", label: "阴天", temperature: 12, tint: 5 },
  { id: "shade", label: "阴影", temperature: 20, tint: 8 },
  { id: "tungsten", label: "白炽灯", temperature: -32, tint: 4 },
  { id: "fluorescent", label: "荧光灯", temperature: -12, tint: -16 },
  { id: "flash", label: "闪光灯", temperature: 9, tint: 2 }
], Li = 210, Oi = 140, Ub = 6, jb = {
  portrait: B1,
  landscape: V1,
  wedding: D1,
  kids: Y1,
  food: z1,
  film: q1,
  mono: Q1,
  cinema: L1
};
function kb(r) {
  return new Promise((h) => {
    const u = new Image();
    u.addEventListener("error", () => h(null), { once: !0 }), u.addEventListener(
      "load",
      () => {
        const c = document.createElement("canvas");
        c.width = Li, c.height = Oi;
        const g = c.getContext("2d", { willReadFrequently: !0 });
        if (!g) {
          h(null);
          return;
        }
        g.imageSmoothingQuality = "high", g.drawImage(u, 0, 0, Li, Oi);
        const m = g.getImageData(0, 0, Li, Oi), b = Yc(
          Zh(m.data, Li, Oi)
        );
        h({
          imageData: m,
          stats: {
            meanLuma: b.meanLuma,
            clipLow: b.clipLow,
            clipHigh: b.clipHigh
          }
        });
      },
      { once: !0 }
    ), u.src = r;
  });
}
function Bb(r) {
  const [h, u] = M.useState({});
  return M.useEffect(() => {
    let c = !1;
    const g = [...new Set(r.map((m) => m.category))];
    return Promise.all(
      g.map(
        async (m) => [m, await kb(jb[m])]
      )
    ).then((m) => {
      if (c) return;
      const b = new Map(m), A = document.createElement("canvas");
      A.width = Li, A.height = Oi;
      const v = A.getContext("2d");
      if (!v) return;
      const y = ba();
      let S = 0;
      const C = () => {
        if (c) return;
        const k = {};
        for (let j = 0; j < Ub && S < r.length; j += 1, S += 1) {
          const L = r[S], Z = b.get(L.category);
          if (!Z) continue;
          const it = new Uint8ClampedArray(Z.imageData.data);
          k1(it, Li, Oi, {
            ...y,
            ...Bp(L.patch, Z.stats)
          }), v.putImageData(
            new ImageData(it, Li, Oi),
            0,
            0
          ), k[L.id] = A.toDataURL("image/jpeg", 0.82);
        }
        u((j) => ({ ...j, ...k })), S < r.length && requestAnimationFrame(C);
      };
      C();
    }), () => {
      c = !0;
    };
  }, [r]), h;
}
function zc(r) {
  return ta(
    [
      `hsl(${(r + 322) % 360} 70% 52%)`,
      `hsl(${r} 82% 55%)`,
      `hsl(${(r + 38) % 360} 70% 52%)`
    ],
    50
  );
}
function qc(r) {
  return ta([`hsl(${r} 10% 42%)`, `hsl(${r} 88% 55%)`], 50);
}
function Vb(r) {
  return ta(
    [`hsl(${r} 55% 7%)`, `hsl(${r} 58% 50%)`, `hsl(${r} 24% 94%)`],
    50
  );
}
function Qh() {
  return Hh();
}
function Db(r) {
  return Array.from({ length: 97 }, (h, u) => {
    const c = u / 96, g = j1(c, r);
    return `${c * 100},${(1 - g) * 100}`;
  }).join(" ");
}
const Yb = [
  { id: "rgb", color: "#f2f5f8", label: "RGB" },
  { id: "red", color: "#ff453a", label: "红" },
  { id: "green", color: "#30d158", label: "绿" },
  { id: "blue", color: "#0a84ff", label: "蓝" }
], pp = [
  {
    id: "linear",
    label: "线性",
    points: [
      { x: 0, y: 0 },
      { x: 1, y: 1 }
    ]
  },
  {
    id: "soft",
    label: "柔和对比",
    points: [
      { x: 0, y: 0.03 },
      { x: 0.25, y: 0.23 },
      { x: 0.5, y: 0.5 },
      { x: 0.75, y: 0.77 },
      { x: 1, y: 0.97 }
    ]
  },
  {
    id: "medium",
    label: "中对比",
    points: [
      { x: 0, y: 0 },
      { x: 0.25, y: 0.21 },
      { x: 0.75, y: 0.79 },
      { x: 1, y: 1 }
    ]
  },
  {
    id: "strong",
    label: "强对比",
    points: [
      { x: 0, y: 0 },
      { x: 0.25, y: 0.13 },
      { x: 0.5, y: 0.5 },
      { x: 0.75, y: 0.87 },
      { x: 1, y: 1 }
    ]
  },
  {
    id: "s-curve",
    label: "S 曲线",
    points: [
      { x: 0, y: 0 },
      { x: 0.18, y: 0.08 },
      { x: 0.42, y: 0.36 },
      { x: 0.58, y: 0.64 },
      { x: 0.82, y: 0.92 },
      { x: 1, y: 1 }
    ]
  },
  {
    id: "matte",
    label: "哑光",
    points: [
      { x: 0, y: 0.08 },
      { x: 0.25, y: 0.28 },
      { x: 0.5, y: 0.52 },
      { x: 0.75, y: 0.76 },
      { x: 1, y: 0.94 }
    ]
  },
  {
    id: "fade",
    label: "褪色",
    points: [
      { x: 0, y: 0.12 },
      { x: 0.2, y: 0.28 },
      { x: 0.5, y: 0.52 },
      { x: 0.8, y: 0.79 },
      { x: 1, y: 0.96 }
    ]
  },
  {
    id: "high-key",
    label: "高调提亮",
    points: [
      { x: 0, y: 0.03 },
      { x: 0.25, y: 0.34 },
      { x: 0.5, y: 0.62 },
      { x: 0.75, y: 0.84 },
      { x: 1, y: 1 }
    ]
  },
  {
    id: "low-key",
    label: "低调压暗",
    points: [
      { x: 0, y: 0 },
      { x: 0.25, y: 0.16 },
      { x: 0.5, y: 0.38 },
      { x: 0.75, y: 0.68 },
      { x: 1, y: 0.97 }
    ]
  },
  {
    id: "negative",
    label: "反相",
    points: [
      { x: 0, y: 1 },
      { x: 1, y: 0 }
    ]
  },
  { id: "custom", label: "自定义" }
];
function zb(r) {
  const [h, u] = M.useState("rgb"), [c, g] = M.useState("linear"), [m, b] = M.useState(null), A = M.useRef(null), v = M.useRef(null), [y, S] = M.useState(null), C = M.useRef(null), k = () => {
    C.current !== null && cancelAnimationFrame(C.current), C.current = requestAnimationFrame(() => {
      C.current = null, v.current && r.onChange(h, v.current);
    });
  };
  M.useEffect(
    () => () => {
      C.current !== null && cancelAnimationFrame(C.current);
    },
    []
  );
  const j = r.curves[h], L = y ?? j, Z = r.histogramData.current, it = h === "rgb" ? null : h, mt = zp(Z.sampleCount > 0 ? Z : null), tt = (J) => {
    const ht = J.currentTarget.getBoundingClientRect(), Tt = Math.min(1, Math.max(0, (J.clientX - ht.left) / ht.width)), kt = Math.min(1, Math.max(0, 1 - (J.clientY - ht.top) / ht.height));
    return { x: Tt, y: kt };
  }, Y = (J) => {
    if (A.current === null) return;
    const ht = A.current, Tt = tt(J), kt = v.current ?? L, Yt = kt[ht - 1]?.x ?? 0, ge = kt[ht + 1]?.x ?? 1, Lt = kt.map(
      (Et, q) => q === ht ? { x: Math.min(ge - 5e-3, Math.max(Yt + 5e-3, Tt.x)), y: Tt.y } : Et
    );
    g("custom"), S(Lt), v.current = Lt, k();
  }, W = (J) => {
    J.currentTarget.setPointerCapture(J.pointerId);
    const ht = tt(J), Tt = J.currentTarget.getBoundingClientRect(), kt = v.current ?? L, Yt = kt.reduce(
      (Et, q, O) => {
        const K = Math.hypot(q.x - ht.x, q.y - ht.y) * Tt.width;
        return !Et || K < Et.distance ? { index: O, distance: K } : Et;
      },
      null
    );
    if (Yt && Yt.distance < 12 && Yt.index !== 0 && Yt.index !== kt.length - 1) {
      A.current = Yt.index, b(Yt.index);
      return;
    }
    if (kt.length >= 16) return;
    const ge = [...kt, ht].sort((Et, q) => Et.x - q.x), Lt = ge.indexOf(ht);
    A.current = Lt, b(Lt), g("custom"), S(ge), v.current = ge, k();
  }, et = (J) => {
    g(J), S(null);
    const ht = pp.find((Tt) => Tt.id === J)?.points;
    ht && (b(null), r.onChange(
      h,
      ht.map((Tt) => ({ ...Tt }))
    ));
  }, rt = (J) => {
    const ht = Math.max(1, J.length - 1), Tt = ["M0,100"];
    for (let kt = 0; kt < J.length; kt += 1) {
      const Yt = Math.round(kt / ht * 1e4) / 100, ge = Math.round((100 - (J[kt] ?? 0) * 96) * 100) / 100;
      Tt.push(`L${Yt},${ge}`);
    }
    return Tt.push("L100,100 Z"), Tt.join("");
  }, Mt = m !== null ? L[m] : null;
  return /* @__PURE__ */ s.jsxs("div", { className: "photo-curve-editor", children: [
    /* @__PURE__ */ s.jsxs("div", { className: "photo-curve-toolbar", children: [
      /* @__PURE__ */ s.jsx("div", { className: "photo-curve-channels", role: "radiogroup", "aria-label": "曲线通道", children: Yb.map((J) => /* @__PURE__ */ s.jsx(
        "button",
        {
          type: "button",
          role: "radio",
          "aria-checked": h === J.id,
          title: J.label,
          className: "photo-curve-dot" + (h === J.id ? " active" : ""),
          style: {
            "--dot-color": J.color,
            background: J.id === "rgb" ? "linear-gradient(135deg, #ff453a 0 33%, #30d158 33% 66%, #0a84ff 66% 100%)" : J.color
          },
          onClick: () => {
            u(J.id), b(null), S(null);
          }
        },
        J.id
      )) }),
      /* @__PURE__ */ s.jsx(
        "select",
        {
          value: c,
          onChange: (J) => et(J.target.value),
          "aria-label": "曲线预设",
          children: pp.map((J) => /* @__PURE__ */ s.jsx("option", { value: J.id, children: J.label }, J.id))
        }
      )
    ] }),
    /* @__PURE__ */ s.jsxs(
      "svg",
      {
        viewBox: "0 0 100 100",
        role: "img",
        "aria-label": "曲线编辑器",
        onPointerDown: W,
        onPointerMove: Y,
        onPointerUp: () => {
          A.current = null, v.current && (C.current !== null && cancelAnimationFrame(C.current), C.current = null, r.onChange(h, v.current), v.current = null, S(null));
        },
        onPointerCancel: () => {
          A.current = null, v.current = null, S(null);
        },
        children: [
          it ? /* @__PURE__ */ s.jsx(
            "path",
            {
              d: rt(mt[it]),
              className: "photo-curve-backdrop is-" + it
            }
          ) : /* @__PURE__ */ s.jsxs(s.Fragment, { children: [
            /* @__PURE__ */ s.jsx("path", { d: rt(mt.red), className: "photo-curve-backdrop is-red" }),
            /* @__PURE__ */ s.jsx("path", { d: rt(mt.green), className: "photo-curve-backdrop is-green" }),
            /* @__PURE__ */ s.jsx("path", { d: rt(mt.blue), className: "photo-curve-backdrop is-blue" })
          ] }),
          /* @__PURE__ */ s.jsx(
            "path",
            {
              d: "M 0 25 H 100 M 0 50 H 100 M 0 75 H 100 M 25 0 V 100 M 50 0 V 100 M 75 0 V 100",
              className: "photo-curve-grid"
            }
          ),
          /* @__PURE__ */ s.jsx("line", { x1: "0", y1: "100", x2: "100", y2: "0", className: "photo-curve-neutral" }),
          /* @__PURE__ */ s.jsx("polyline", { points: Db(L), className: "photo-curve-line" }),
          L.map((J, ht) => /* @__PURE__ */ s.jsx(
            "circle",
            {
              cx: J.x * 100,
              cy: (1 - J.y) * 100,
              r: m === ht ? 3 : 2.2,
              className: "photo-curve-point" + (m === ht ? " active" : "")
            },
            `${J.x}-${J.y}-${ht}`
          ))
        ]
      }
    ),
    /* @__PURE__ */ s.jsxs("div", { className: "photo-curve-footer", children: [
      /* @__PURE__ */ s.jsxs("span", { className: "photo-curve-io", children: [
        /* @__PURE__ */ s.jsx("em", { children: "输入" }),
        /* @__PURE__ */ s.jsx("b", { children: Mt ? Math.round(Mt.x * 255) : "—" }),
        /* @__PURE__ */ s.jsx("em", { children: "输出" }),
        /* @__PURE__ */ s.jsx("b", { children: Mt ? Math.round(Mt.y * 255) : "—" })
      ] }),
      /* @__PURE__ */ s.jsx(
        "button",
        {
          type: "button",
          onClick: () => {
            b(null), et("linear");
          },
          children: "还原"
        }
      )
    ] })
  ] });
}
const gp = 5e-3, mp = 0.01, qb = {
  under: "欠曝",
  slightlyUnder: "偏暗",
  balanced: "正常",
  slightlyOver: "偏亮",
  over: "过曝"
}, Qb = {
  flat: "低对比",
  normal: "",
  punchy: "高对比"
};
function Cc(r) {
  const h = r * 100;
  return h <= 0 ? "0%" : h < 0.05 ? "<0.1%" : (h < 10 ? h.toFixed(1) : String(Math.round(h))) + "%";
}
function Lb({
  canvasRef: r,
  analysis: h
}) {
  const u = h ? [qb[h.exposure], Qb[h.contrast]].filter(Boolean).join(" · ") : "RGB", c = h ? h.exposure === "under" || h.exposure === "over" || h.clipLow >= mp || h.clipHigh >= mp : !1;
  return /* @__PURE__ */ s.jsxs("div", { className: "photo-histogram", "aria-label": "RGB 直方图", children: [
    /* @__PURE__ */ s.jsxs("div", { className: "photo-histogram-heading", children: [
      /* @__PURE__ */ s.jsx("span", { children: "直方图" }),
      /* @__PURE__ */ s.jsx("small", { className: c ? "is-warn" : void 0, children: u })
    ] }),
    /* @__PURE__ */ s.jsx(
      "canvas",
      {
        ref: r,
        width: ib * 2,
        height: lb * 2,
        className: "photo-histogram-canvas",
        role: "img",
        "aria-label": h ? `亮度均值 ${Math.round(h.meanLuma)}，暗部裁切 ${Cc(h.clipLow)}，高光裁切 ${Cc(h.clipHigh)}` : "等待统计数据"
      }
    ),
    /* @__PURE__ */ s.jsxs("div", { className: "photo-histogram-axis", children: [
      /* @__PURE__ */ s.jsx("span", { children: "0" }),
      /* @__PURE__ */ s.jsx("span", { children: "中间调" }),
      /* @__PURE__ */ s.jsx("span", { children: "255" })
    ] }),
    h && /* @__PURE__ */ s.jsxs("div", { className: "photo-histogram-meta", children: [
      /* @__PURE__ */ s.jsxs("span", { title: "亮度通道均值", children: [
        "均值 ",
        Math.round(h.meanLuma)
      ] }),
      /* @__PURE__ */ s.jsxs(
        "span",
        {
          title: "亮度贴合 0–1 级的像素占比（死黑）",
          className: h.clipLow >= gp ? "is-clip" : void 0,
          children: [
            "暗裁 ",
            Cc(h.clipLow)
          ]
        }
      ),
      /* @__PURE__ */ s.jsxs(
        "span",
        {
          title: "任一通道贴合 254–255 级的像素占比（通道溢出）",
          className: h.clipHigh >= gp ? "is-clip" : void 0,
          children: [
            "高裁 ",
            Cc(h.clipHigh)
          ]
        }
      )
    ] })
  ] });
}
const Yl = 0.04;
function bp(r) {
  const h = Math.min(1, Math.max(Yl, r.width)), u = Math.min(1, Math.max(Yl, r.height));
  return {
    x: Math.min(1 - h, Math.max(0, r.x)),
    y: Math.min(1 - u, Math.max(0, r.y)),
    width: h,
    height: u
  };
}
function Ob(r) {
  if (!r || !Number.isFinite(r) || r <= 0) return null;
  let h = 1, u = h / r;
  return u > 1 && (u = 1, h = u * r), { x: (1 - h) / 2, y: (1 - u) / 2, width: h, height: u };
}
function Kb(r) {
  const h = M.useRef(null), u = M.useRef(null), c = M.useRef(!1), g = M.useRef(null), m = (k) => {
    const j = u.current;
    j && (j.style.left = k.x * 100 + "%", j.style.top = k.y * 100 + "%", j.style.width = k.width * 100 + "%", j.style.height = k.height * 100 + "%");
  };
  M.useEffect(() => {
    c.current || m(r.crop);
  }, [r.crop]);
  const b = (k) => {
    const j = h.current?.getBoundingClientRect();
    return !j || j.width < 2 || j.height < 2 ? { x: 0, y: 0 } : {
      x: Math.min(1, Math.max(0, (k.clientX - j.left) / j.width)),
      y: Math.min(1, Math.max(0, (k.clientY - j.top) / j.height))
    };
  }, A = (k, j, L, Z) => {
    if (k === "move")
      return bp({ ...Z, x: Z.x + j, y: Z.y + L });
    const it = k.includes("w"), mt = k.includes("e"), tt = k.startsWith("n"), Y = k.startsWith("s");
    let W = Z.x, et = Z.y, rt = Z.x + Z.width, Mt = Z.y + Z.height;
    it && (W = Math.min(rt - Yl, Math.max(0, Z.x + j))), mt && (rt = Math.max(W + Yl, Math.min(1, Z.x + Z.width + j))), tt && (et = Math.min(Mt - Yl, Math.max(0, Z.y + L))), Y && (Mt = Math.max(et + Yl, Math.min(1, Z.y + Z.height + L)));
    let J = { x: W, y: et, width: rt - W, height: Mt - et };
    if (r.aspect && Number.isFinite(r.aspect) && r.aspect > 0) {
      const ht = it ? "right" : "left", Tt = tt ? "bottom" : "top", kt = ht === "left" ? J.x : J.x + J.width, Yt = Tt === "top" ? J.y : J.y + J.height;
      if (it || mt ? tt || Y : !1) {
        let Lt = J.width, Et = Lt / r.aspect;
        const q = ht === "left" ? 1 - kt : kt, O = Tt === "top" ? 1 - Yt : Yt;
        Et > O && (Et = O, Lt = Et * r.aspect), Lt > q && (Lt = q, Et = Lt / r.aspect);
        const K = ht === "left" ? kt : kt - Lt, Ct = Tt === "top" ? Yt : Yt - Et;
        J = { x: K, y: Ct, width: Lt, height: Et };
      } else if (tt || Y) {
        let Lt = J.height, Et = Lt * r.aspect;
        const q = Math.min(kt, 1 - kt) * 2;
        Et > q && (Et = q, Lt = Et / r.aspect), J = {
          x: kt - Et / 2,
          y: Tt === "top" ? Yt : Yt - Lt,
          width: Et,
          height: Lt
        };
      } else {
        let Lt = J.width, Et = Lt / r.aspect;
        const q = Math.min(Yt, 1 - Yt) * 2;
        Et > q && (Et = q, Lt = Et * r.aspect), J = {
          x: ht === "left" ? kt : kt - Lt,
          y: Yt - Et / 2,
          width: Lt,
          height: Et
        };
      }
    }
    return bp(J);
  }, v = (k) => (j) => {
    j.preventDefault(), j.stopPropagation(), c.current = !0, j.currentTarget.setPointerCapture(j.pointerId);
    const L = b(j);
    g.current = {
      kind: k,
      startX: L.x,
      startY: L.y,
      startRect: r.crop,
      rect: r.crop
    };
  }, y = (k) => {
    const j = g.current;
    if (!j) return;
    const L = b(k), Z = A(j.kind, L.x - j.startX, L.y - j.startY, j.startRect);
    g.current = { ...j, rect: Z }, m(Z);
  }, S = () => {
    const k = g.current;
    g.current = null, c.current && (c.current = !1, k && r.onChange(k.rect));
  }, C = [
    { kind: "nw", className: "is-nw" },
    { kind: "n", className: "is-n" },
    { kind: "ne", className: "is-ne" },
    { kind: "e", className: "is-e" },
    { kind: "se", className: "is-se" },
    { kind: "s", className: "is-s" },
    { kind: "sw", className: "is-sw" },
    { kind: "w", className: "is-w" }
  ];
  return /* @__PURE__ */ s.jsx(
    "div",
    {
      ref: h,
      className: "photo-crop-overlay",
      onPointerDown: v("move"),
      onPointerMove: y,
      onPointerUp: S,
      onPointerCancel: S,
      children: /* @__PURE__ */ s.jsxs(
        "div",
        {
          ref: u,
          className: "photo-crop-box",
          style: {
            left: r.crop.x * 100 + "%",
            top: r.crop.y * 100 + "%",
            width: r.crop.width * 100 + "%",
            height: r.crop.height * 100 + "%"
          },
          children: [
            /* @__PURE__ */ s.jsx("i", { className: "photo-crop-line is-v1" }),
            /* @__PURE__ */ s.jsx("i", { className: "photo-crop-line is-v2" }),
            /* @__PURE__ */ s.jsx("i", { className: "photo-crop-line is-h1" }),
            /* @__PURE__ */ s.jsx("i", { className: "photo-crop-line is-h2" }),
            C.map((k) => /* @__PURE__ */ s.jsx(
              "i",
              {
                className: "photo-crop-handle " + k.className,
                onPointerDown: v(k.kind),
                onPointerMove: y,
                onPointerUp: S,
                onPointerCancel: S
              },
              k.kind
            ))
          ]
        }
      )
    }
  );
}
function Lh(r) {
  const h = (r % 180 + 180) % 180;
  return h < 22.5 || h >= 157.5 ? "ew-resize" : h < 67.5 ? "nwse-resize" : h < 112.5 ? "ns-resize" : "nesw-resize";
}
function Hb(r) {
  const h = M.useRef(null), [u, c] = M.useState(!1), [, g] = M.useState(0);
  M.useEffect(() => {
    const O = h.current;
    if (!O || (g((Q) => Q + 1), typeof ResizeObserver > "u")) return;
    let K = O.offsetWidth, Ct = O.offsetHeight;
    const R = new ResizeObserver(() => {
      O.offsetWidth === K && O.offsetHeight === Ct || (K = O.offsetWidth, Ct = O.offsetHeight, g((Q) => Q + 1));
    });
    return R.observe(O), () => R.disconnect();
  }, []);
  const m = (O) => {
    const K = h.current?.getBoundingClientRect();
    return !K || K.width < 2 || K.height < 2 ? null : {
      host: K,
      width: K.width,
      height: K.height,
      u: (O.clientX - K.left) / K.width,
      v: (O.clientY - K.top) / K.height
    };
  }, b = M.useRef(null), A = (O, K, Ct) => {
    const R = O * Math.PI / 180;
    return (Ct.clientX - K.center.x) * Math.cos(R) + (Ct.clientY - K.center.y) * Math.sin(R);
  }, v = (O, K) => Math.atan2(K.clientY - O.center.y, K.clientX - O.center.x), y = (O) => {
    const K = b.current;
    if (!K) return;
    const Ct = m(O);
    if (!Ct) return;
    if (K.kind === "center") {
      const $ = (O.clientX - K.start.x) / Ct.width, ft = (O.clientY - K.start.y) / Ct.height;
      r.onChange({
        x: Math.round(Math.min(1.5, Math.max(-0.5, K.origin.x + $)) * 1e3) / 1e3,
        y: Math.round(Math.min(1.5, Math.max(-0.5, K.origin.y + ft)) * 1e3) / 1e3
      });
      return;
    }
    if (K.kind === "rotate") {
      const $ = K.origin.angle + (v(K, O) - K.grabAngle) * 180 / Math.PI;
      r.onChange({ angle: Math.round((($ + 180) % 360 + 360) % 360 - 180) });
      return;
    }
    if (K.kind === "a" || K.kind === "b") {
      const $ = K.origin.angle + (v(K, O) - K.grabAngle) * 180 / Math.PI, ft = Math.round((($ + 180) % 360 + 360) % 360 - 180), qt = Math.abs(A(ft, K, O)) / Ct.width;
      r.onChange({
        angle: ft,
        size: Math.round(Math.min(1.5, Math.max(0.05, qt)) * 100) / 100
      });
      return;
    }
    const Q = Math.abs(
      A(
        K.kind === "width" ? K.origin.angle : K.origin.angle + 90,
        K,
        O
      )
    ) / K.grabAxis, nt = Math.round(
      Math.min(1.5, Math.max(0.05, (K.origin.sizeX ?? K.origin.size) * Q)) * 100
    ) / 100;
    if (K.kind === "width") {
      const $ = K.origin.sizeY ?? K.origin.size;
      r.onChange({ sizeX: nt, sizeY: $, size: Math.max(nt, $) });
    } else {
      const $ = K.origin.sizeX ?? K.origin.size;
      r.onChange({ sizeY: nt, sizeX: $, size: Math.max(nt, $) });
    }
  }, S = (O) => (K) => {
    if (K.button !== 0) return;
    const Ct = m(K);
    if (!Ct) return;
    K.preventDefault(), K.stopPropagation();
    const R = {
      x: Ct.host.left + r.mask.x * Ct.width,
      y: Ct.host.top + r.mask.y * Ct.height
    };
    if (O === "center")
      b.current = {
        kind: O,
        start: { x: K.clientX, y: K.clientY },
        origin: { ...r.mask }
      };
    else {
      const $ = Math.atan2(K.clientY - R.y, K.clientX - R.x) ?? 0, ft = r.mask.angle * Math.PI / 180, qt = (r.mask.angle + 90) * (Math.PI / 180), Nt = O === "width" ? Math.abs(
        (K.clientX - R.x) * Math.cos(ft) + (K.clientY - R.y) * Math.sin(ft)
      ) : O === "height" ? Math.abs(
        (K.clientX - R.x) * Math.cos(qt) + (K.clientY - R.y) * Math.sin(qt)
      ) : Math.hypot(K.clientX - R.x, K.clientY - R.y);
      b.current = {
        kind: O,
        start: { x: K.clientX, y: K.clientY },
        origin: { ...r.mask },
        center: R,
        grabAxis: Math.max(1, Nt),
        grabAngle: $
      };
    }
    c(!0);
    const Q = ($) => y($), nt = () => {
      window.removeEventListener("pointermove", Q), window.removeEventListener("pointerup", nt), window.removeEventListener("pointercancel", nt), b.current = null, c(!1);
    };
    window.addEventListener("pointermove", Q), window.addEventListener("pointerup", nt), window.addEventListener("pointercancel", nt);
  }, C = h.current?.offsetWidth ?? 0, k = h.current?.offsetHeight ?? 0, j = r.mask.x * C, L = r.mask.y * k, Z = r.mask.angle, it = Z * Math.PI / 180, mt = Math.cos(it), tt = Math.sin(it), Y = (O, K) => ({
    x: j + O * mt - K * tt,
    y: L + O * tt + K * mt
  }), W = 1 - Ep(r.mask.feather), et = (r.mask.sizeX ?? r.mask.size) * C, rt = (r.mask.sizeY ?? r.mask.size) * C, Mt = r.mask.size * C, J = (C + k) * 2.5, ht = [
    { kind: "width", ...Y(et, 0), axis: Z },
    { kind: "width", ...Y(-et, 0), axis: Z },
    { kind: "height", ...Y(0, rt), axis: Z + 90 },
    { kind: "height", ...Y(0, -rt), axis: Z + 90 }
  ], Tt = Y(0, -rt), kt = Y(0, -rt - 26), Yt = Y(Mt, 0), ge = Y(-Mt, 0), Lt = Y(Mt * W, 0), Et = Y(-Mt * W, 0), q = (O) => ({
    left: O.x,
    top: O.y,
    width: J,
    transform: `translate(-50%, -50%) rotate(${Z + 90}deg)`
  });
  return /* @__PURE__ */ s.jsxs("div", { ref: h, className: "photo-mask-overlay" + (u ? " is-dragging" : ""), children: [
    r.mask.kind === "radial" ? /* @__PURE__ */ s.jsxs(s.Fragment, { children: [
      /* @__PURE__ */ s.jsx(
        "i",
        {
          className: "photo-mask-ring is-inner",
          style: {
            left: j,
            top: L,
            width: et * 2 * W,
            height: rt * 2 * W,
            transform: `translate(-50%, -50%) rotate(${Z}deg)`
          }
        }
      ),
      /* @__PURE__ */ s.jsx(
        "i",
        {
          className: "photo-mask-shape is-radial is-gizmo",
          style: {
            left: j,
            top: L,
            width: et * 2,
            height: rt * 2,
            transform: `translate(-50%, -50%) rotate(${Z}deg)`
          },
          onPointerDown: S("center")
        }
      ),
      /* @__PURE__ */ s.jsx(
        "i",
        {
          className: "photo-mask-stem",
          style: {
            left: Tt.x,
            top: Tt.y,
            width: 26,
            transform: `rotate(${Z - 90}deg)`
          }
        }
      ),
      ht.map((O, K) => /* @__PURE__ */ s.jsx(
        "i",
        {
          className: "photo-mask-handle is-side",
          style: {
            left: O.x,
            top: O.y,
            cursor: Lh(O.axis),
            "--mask-angle": Z + "deg"
          },
          title: O.kind === "width" ? "拖动调整宽度" : "拖动调整高度",
          onPointerDown: S(O.kind)
        },
        K
      )),
      /* @__PURE__ */ s.jsx(
        "i",
        {
          className: "photo-mask-handle is-rotate",
          style: { left: kt.x, top: kt.y },
          title: "拖动旋转蒙版",
          onPointerDown: S("rotate")
        }
      )
    ] }) : /* @__PURE__ */ s.jsxs(s.Fragment, { children: [
      /* @__PURE__ */ s.jsx("i", { className: "photo-mask-line is-edge", style: q(Yt) }),
      /* @__PURE__ */ s.jsx("i", { className: "photo-mask-line is-edge", style: q(ge) }),
      /* @__PURE__ */ s.jsx("i", { className: "photo-mask-line is-inner", style: q(Lt) }),
      /* @__PURE__ */ s.jsx("i", { className: "photo-mask-line is-inner", style: q(Et) }),
      /* @__PURE__ */ s.jsx(
        "i",
        {
          className: "photo-mask-line is-center",
          style: q({ x: j, y: L }),
          onPointerDown: S("center")
        }
      ),
      /* @__PURE__ */ s.jsx(
        "i",
        {
          className: "photo-mask-handle is-side",
          style: {
            left: Yt.x,
            top: Yt.y,
            cursor: Lh(Z),
            "--mask-angle": Z + "deg"
          },
          title: "拖动调整长度与角度",
          onPointerDown: S("a")
        }
      ),
      /* @__PURE__ */ s.jsx(
        "i",
        {
          className: "photo-mask-handle is-side",
          style: {
            left: ge.x,
            top: ge.y,
            cursor: Lh(Z),
            "--mask-angle": Z + "deg"
          },
          title: "拖动调整长度与角度",
          onPointerDown: S("b")
        }
      )
    ] }),
    /* @__PURE__ */ s.jsx(
      "i",
      {
        className: "photo-mask-handle is-center",
        style: { left: j, top: L },
        title: "拖动移动蒙版 · 双击重置位置与形状",
        onPointerDown: S("center"),
        onDoubleClick: () => r.onChange(
          r.mask.kind === "radial" ? { x: 0.5, y: 0.5, angle: 0, size: 0.38, sizeX: 0.38, sizeY: 0.38 } : { x: 0.5, y: 0.5, angle: 0, size: 0.3 }
        )
      }
    )
  ] });
}
function Zb(r) {
  const h = M.useRef(null), [u, c] = M.useState({ width: 0, height: 0 });
  M.useEffect(() => {
    const m = h.current;
    if (!m) return;
    const b = () => {
      const v = m.offsetWidth, y = m.offsetHeight;
      c(
        (S) => S.width === v && S.height === y ? S : { width: v, height: y }
      );
    };
    if (b(), typeof ResizeObserver > "u") return;
    const A = new ResizeObserver(b);
    return A.observe(m), () => A.disconnect();
  }, []);
  const { mask: g } = r;
  return M.useEffect(() => {
    const m = h.current;
    if (!m || u.width < 2 || u.height < 2) return;
    const b = Math.max(1, Math.round(u.width / 2)), A = Math.max(1, Math.round(u.height / 2));
    m.width = b, m.height = A;
    const v = m.getContext("2d");
    if (!v) return;
    const y = v.createImageData(b, A), S = u.width / u.height;
    for (let C = 0; C < A; C += 1) {
      const k = (C + 0.5) / A;
      for (let j = 0; j < b; j += 1) {
        const L = wp(g, (j + 0.5) / b, k, S), Z = (C * b + j) * 4;
        y.data[Z] = 255, y.data[Z + 1] = 66, y.data[Z + 2] = 66, y.data[Z + 3] = Math.round(L * 255 * 0.42);
      }
    }
    v.putImageData(y, 0, 0);
  }, [u, g]), /* @__PURE__ */ s.jsx("canvas", { ref: h, className: "photo-semantic-mask", "aria-hidden": "true" });
}
function Wb(r) {
  const h = M.useRef(null), u = 44, c = Math.max(20, Math.min(44, Math.round(u / Math.max(0.2, r.aspect)))), { mask: g } = r;
  return M.useEffect(() => {
    const m = h.current;
    if (!m) return;
    const b = 2, A = u * b, v = c * b;
    m.width = A, m.height = v;
    const y = m.getContext("2d");
    if (!y) return;
    const S = y.createImageData(A, v), C = g.semanticMask;
    let k = null;
    if (C)
      try {
        k = Xh(C.data);
      } catch {
        k = null;
      }
    for (let j = 0; j < v; j += 1)
      for (let L = 0; L < A; L += 1) {
        let Z;
        if (C)
          if (!k)
            Z = 0;
          else {
            const tt = Math.min(C.width - 1, Math.floor(L / A * C.width)), Y = Math.min(
              C.height - 1,
              Math.floor(j / v * C.height)
            ), W = Rp(
              g.feather,
              k[Y * C.width + tt] / 255
            );
            Z = g.invert ? 1 - W : W;
          }
        else
          Z = wp(
            g,
            (L + 0.5) / A,
            (j + 0.5) / v,
            r.aspect
          );
        const it = Math.round(34 + Z * 206), mt = (j * A + L) * 4;
        S.data[mt] = it, S.data[mt + 1] = it, S.data[mt + 2] = it, S.data[mt + 3] = 255;
      }
    y.putImageData(S, 0, 0);
  }, [c, r.aspect, g]), /* @__PURE__ */ s.jsx(
    "canvas",
    {
      ref: h,
      className: "photo-mask-thumb",
      style: { width: u, height: c },
      "aria-hidden": "true"
    }
  );
}
function Fb(r) {
  const h = M.useRef(null), [, u] = M.useState(0);
  M.useEffect(() => {
    const b = h.current;
    if (!b || (u((S) => S + 1), typeof ResizeObserver > "u")) return;
    let A = b.offsetWidth, v = b.offsetHeight;
    const y = new ResizeObserver(() => {
      b.offsetWidth === A && b.offsetHeight === v || (A = b.offsetWidth, v = b.offsetHeight, u((S) => S + 1));
    });
    return y.observe(b), () => y.disconnect();
  }, []);
  const c = h.current?.offsetWidth ?? 0, g = h.current?.offsetHeight ?? 0, m = r.masks.filter((b) => b.id !== r.activeId);
  return m.length ? /* @__PURE__ */ s.jsx("div", { ref: h, className: "photo-mask-pins", "aria-hidden": !1, children: m.map((b) => /* @__PURE__ */ s.jsx(
    "i",
    {
      className: "photo-mask-pin" + (b.enabled === !1 ? " is-hidden" : ""),
      style: { left: b.x * c, top: b.y * g },
      title: `${Qp(b)} · 点击选中`,
      onPointerDown: (A) => {
        A.preventDefault(), A.stopPropagation(), r.onSelect(b.id);
      }
    },
    b.id
  )) }) : null;
}
function Gb(r) {
  const h = M.useRef(null);
  return M.useEffect(() => {
    const u = r.mask.semanticMask, c = h.current;
    if (!u || !c) return;
    let g;
    try {
      g = Xh(u.data);
    } catch {
      return;
    }
    c.width = u.width, c.height = u.height;
    const m = c.getContext("2d");
    if (!m) return;
    const b = m.createImageData(u.width, u.height);
    for (let A = 0; A < g.length; A += 1) {
      const v = Rp(r.mask.feather, g[A] / 255), y = r.mask.invert ? 1 - v : v, S = A * 4;
      b.data[S] = 255, b.data[S + 1] = 66, b.data[S + 2] = 66, b.data[S + 3] = Math.round(y * 255 * 0.42);
    }
    m.putImageData(b, 0, 0);
  }, [r.mask.feather, r.mask.invert, r.mask.semanticMask]), /* @__PURE__ */ s.jsx("canvas", { ref: h, className: "photo-semantic-mask", "aria-hidden": "true" });
}
function Ib(r, h) {
  const u = M.useRef(null);
  return M.useEffect(() => {
    const c = u.current;
    if (!c) return;
    const g = () => {
      const A = c.scrollWidth - c.clientWidth;
      if (A <= 1) {
        c.dataset.overflow = "none";
        return;
      }
      const v = c.scrollLeft > 1, y = c.scrollLeft < A - 1;
      c.dataset.overflow = v && y ? "both" : v ? "left" : y ? "right" : "none";
    }, m = (A) => {
      if (Math.abs(A.deltaX) >= Math.abs(A.deltaY)) return;
      const v = c.scrollWidth - c.clientWidth;
      if (v <= 1) return;
      const y = A.deltaMode === WheelEvent.DOM_DELTA_LINE ? A.deltaY * 16 : A.deltaMode === WheelEvent.DOM_DELTA_PAGE ? A.deltaY * c.clientWidth : A.deltaY, S = Math.min(v, Math.max(0, c.scrollLeft + y));
      S !== c.scrollLeft && (A.preventDefault(), A.stopPropagation(), c.scrollLeft = S);
    };
    c.addEventListener("wheel", m, { passive: !1 }), c.addEventListener("scroll", g, { passive: !0 });
    const b = new ResizeObserver(g);
    return b.observe(c), g(), () => {
      c.removeEventListener("wheel", m), c.removeEventListener("scroll", g), b.disconnect();
    };
  }, []), M.useEffect(() => {
    const c = u.current, g = c?.querySelector(r);
    if (!c || !g) return;
    const m = 12, b = c.getBoundingClientRect(), A = g.getBoundingClientRect(), v = A.left - b.left + c.scrollLeft, y = v + A.width;
    v - m < c.scrollLeft ? c.scrollLeft = Math.max(0, v - m) : y + m > c.scrollLeft + c.clientWidth && (c.scrollLeft = y + m - c.clientWidth);
  }, [r, h]), u;
}
function Xb(r, h) {
  const u = M.useRef(null);
  return M.useEffect(() => {
    if (!r) return;
    const c = document.activeElement, g = u.current, m = () => Array.from(
      g?.querySelectorAll(
        'button:not(:disabled), textarea:not(:disabled), input:not(:disabled), select:not(:disabled), a[href], [tabindex]:not([tabindex="-1"])'
      ) ?? []
    ).filter((v) => v.offsetParent !== null), b = m()[0];
    b ? b.focus() : g?.focus();
    const A = (v) => {
      if (v.key === "Escape") {
        v.preventDefault(), v.stopPropagation(), h();
        return;
      }
      if (v.key !== "Tab") return;
      const y = m();
      if (!y.length) return;
      const S = y[0], C = y[y.length - 1];
      v.shiftKey && document.activeElement === S ? (v.preventDefault(), C.focus()) : !v.shiftKey && document.activeElement === C && (v.preventDefault(), S.focus());
    };
    return window.addEventListener("keydown", A, !0), () => {
      window.removeEventListener("keydown", A, !0), c?.focus?.();
    };
  }, [r, h]), u;
}
function Jb(r) {
  const h = M.useRef(null), u = M.useRef(null), c = M.useRef(null), g = M.useRef(null), m = M.useRef(!1), b = M.useRef(null), A = () => {
    const tt = h.current?.getBoundingClientRect();
    return !tt || tt.width < 2 || tt.height < 2 ? null : { width: tt.width, height: tt.height };
  }, v = (tt) => {
    const Y = h.current.getBoundingClientRect();
    return {
      x: tt.clientX - Y.left,
      y: tt.clientY - Y.top
    };
  }, y = M.useCallback(
    (tt, Y) => {
      const W = u.current, et = c.current, rt = A();
      if (!W || !et || !rt) return;
      if (m.current = Y, !Y) {
        W.style.opacity = "0";
        return;
      }
      g.current = { clientX: tt.clientX, clientY: tt.clientY };
      const Mt = v(tt), J = Math.max(8, r.brushSize * rt.width), ht = Math.max(18, Math.min(92, 92 - r.brushFeather * 0.7));
      W.style.left = Mt.x - J + "px", W.style.top = Mt.y - J + "px", W.style.width = J * 2 + "px", W.style.height = J * 2 + "px", W.style.setProperty("--photo-spot-feather-stop", ht + "%"), W.style.opacity = "1", et.textContent = "直径 " + Math.round(r.brushSize * 200) + "% · 羽化 " + Math.round(r.brushFeather) + "%";
    },
    [r.brushSize, r.brushFeather]
  );
  M.useEffect(() => {
    m.current && g.current && y(g.current, !0);
  }, [y, r.brushSize, r.brushFeather]);
  const S = (tt) => {
    tt.preventDefault(), tt.stopPropagation();
    const Y = A();
    if (!Y) return;
    const W = v(tt), et = r.spots.find((J) => J.id === r.selectedId);
    if (et) {
      const J = et.sourceX * Y.width, ht = et.sourceY * Y.height;
      if (Math.hypot(W.x - J, W.y - ht) <= 14) {
        b.current = { id: et.id, kind: "source" }, tt.currentTarget.setPointerCapture(tt.pointerId);
        return;
      }
    }
    for (const J of r.spots) {
      const ht = J.x * Y.width, Tt = J.y * Y.height;
      if (Math.hypot(W.x - ht, W.y - Tt) <= Math.max(12, J.size * Y.width)) {
        b.current = { id: J.id, kind: "center" }, r.onSelect(J.id), tt.currentTarget.setPointerCapture(tt.pointerId);
        return;
      }
    }
    const rt = Math.min(1, Math.max(0, W.x / Y.width)), Mt = Math.min(1, Math.max(0, W.y / Y.height));
    r.onAdd(rt, Mt, r.brushSize, r.brushFeather);
  }, C = (tt) => {
    y(tt, !0);
    const Y = b.current, W = A();
    if (!Y || !W) return;
    const et = v(tt), rt = Math.round(Math.min(1.5, Math.max(-0.5, et.x / W.width)) * 1e3) / 1e3, Mt = Math.round(Math.min(1.5, Math.max(-0.5, et.y / W.height)) * 1e3) / 1e3;
    Y.kind === "center" ? r.onUpdate(Y.id, { x: rt, y: Mt }) : r.onUpdate(Y.id, { sourceX: rt, sourceY: Mt });
  }, k = () => {
    b.current = null;
  }, { brushSize: j, onBrushSizeChange: L } = r;
  M.useEffect(() => {
    const tt = h.current;
    if (!tt) return;
    const Y = (W) => {
      W.preventDefault(), W.stopPropagation();
      const et = Math.min(
        0.25,
        Math.max(0.015, j + (W.deltaY < 0 ? 5e-3 : -5e-3))
      );
      L(Math.round(et * 1e3) / 1e3), y(W, !0);
    };
    return tt.addEventListener("wheel", Y, { passive: !1 }), () => tt.removeEventListener("wheel", Y);
  }, [j, L, y]);
  const Z = h.current?.getBoundingClientRect(), it = Z?.width ?? 0, mt = Z?.height ?? 0;
  return /* @__PURE__ */ s.jsxs(
    "div",
    {
      ref: h,
      className: "photo-mask-overlay is-spot",
      onPointerDown: S,
      onPointerMove: C,
      onPointerUp: k,
      onPointerCancel: k,
      onPointerLeave: (tt) => {
        b.current || (m.current = !1, y(tt, !1));
      },
      children: [
        /* @__PURE__ */ s.jsxs("div", { ref: u, className: "photo-spot-brush-preview", "aria-hidden": "true", children: [
          /* @__PURE__ */ s.jsx("span", { ref: c }),
          /* @__PURE__ */ s.jsx("i", {})
        ] }),
        r.spots.map((tt) => {
          const Y = tt.x * it, W = tt.y * mt, et = tt.size * it, rt = tt.sourceX * it, Mt = tt.sourceY * mt, J = tt.id === r.selectedId, ht = Math.atan2(Mt - W, rt - Y) * 180 / Math.PI, Tt = Math.hypot(rt - Y, Mt - W);
          return /* @__PURE__ */ s.jsxs("div", { children: [
            /* @__PURE__ */ s.jsx(
              "i",
              {
                className: "photo-mask-shape is-radial" + (J ? " is-selected" : ""),
                style: { left: Y, top: W, width: et * 2, height: et * 2 }
              }
            ),
            J && /* @__PURE__ */ s.jsxs(s.Fragment, { children: [
              /* @__PURE__ */ s.jsx(
                "i",
                {
                  className: "photo-spot-line",
                  style: {
                    left: Y,
                    top: W,
                    width: Tt,
                    transform: `rotate(${ht}deg)`
                  }
                }
              ),
              /* @__PURE__ */ s.jsx(
                "i",
                {
                  className: "photo-mask-handle is-source",
                  style: { left: rt, top: Mt },
                  title: "取样源"
                }
              )
            ] })
          ] }, tt.id);
        })
      ]
    }
  );
}
function Ba(r) {
  return /* @__PURE__ */ s.jsxs(
    "details",
    {
      className: "photo-section",
      open: r.open ?? !0,
      "data-section-id": r.sectionId,
      onToggle: (h) => r.onToggle?.(h.currentTarget.open),
      onPointerDownCapture: (h) => {
        r.onActivate && (h.target.closest("summary") || r.onActivate());
      },
      children: [
        /* @__PURE__ */ s.jsxs("summary", { children: [
          /* @__PURE__ */ s.jsxs("span", { className: "photo-section-title", children: [
            /* @__PURE__ */ s.jsx(mm, { size: 13 }),
            r.icon,
            /* @__PURE__ */ s.jsx("strong", { children: r.title })
          ] }),
          /* @__PURE__ */ s.jsx("span", { className: "photo-section-actions", children: r.onReset && /* @__PURE__ */ s.jsx(
            "button",
            {
              type: "button",
              className: "photo-section-reset",
              title: "重置" + r.title,
              onClick: (h) => {
                h.preventDefault(), h.stopPropagation(), r.onReset?.();
              },
              children: /* @__PURE__ */ s.jsx(Qc, { size: 13 })
            }
          ) })
        ] }),
        /* @__PURE__ */ s.jsx("div", { className: "photo-section-body", children: r.children })
      ]
    }
  );
}
function ut(r) {
  const h = r.min ?? -100, u = r.max ?? 100, c = r.step ?? 1, g = (r.value - h) / (u - h) * 100, m = (0 - h) / (u - h) * 100, b = M.useRef(null), [A, v] = M.useState(!1), y = M.useRef(null), S = M.useRef(r);
  return S.current = r, M.useEffect(() => {
    const C = b.current;
    if (!C) return;
    const k = (j) => {
      j.preventDefault(), j.stopPropagation();
      const L = S.current, Z = L.min ?? -100, it = L.max ?? 100, mt = L.step ?? 1, tt = j.deltaY < 0 ? 1 : -1, Y = j.shiftKey ? mt / 10 : mt, W = Math.round((L.value + tt * Y) / Y) * Y;
      L.onChange(Math.min(it, Math.max(Z, Number(W.toFixed(4))))), window.dispatchEvent(new CustomEvent("photo-adjust:interaction", { detail: !0 })), y.current && clearTimeout(y.current), y.current = setTimeout(() => {
        y.current = null, window.dispatchEvent(new CustomEvent("photo-adjust:interaction", { detail: !1 }));
      }, 220);
    };
    return C.addEventListener("wheel", k, { passive: !1 }), () => {
      C.removeEventListener("wheel", k), y.current && (clearTimeout(y.current), y.current = null);
    };
  }, []), /* @__PURE__ */ s.jsxs("label", { className: "photo-slider" + (r.sub ? " photo-slider-sub" : ""), children: [
    /* @__PURE__ */ s.jsx("span", { className: "photo-slider-label", children: r.label }),
    /* @__PURE__ */ s.jsx("span", { className: "photo-slider-track", children: /* @__PURE__ */ s.jsx(
      "input",
      {
        ref: b,
        type: "range",
        min: h,
        max: u,
        step: A ? c / 5 : c,
        value: r.value,
        title: r.label + "：滚轮微调，Shift+滚轮 0.1 档，按住 ⌘/Ctrl 拖动 1/5 档，双击复位",
        style: {
          "--slider-progress": g + "%",
          "--slider-zero": m + "%",
          ...r.track ? { "--slider-gradient": r.track } : {}
        },
        onPointerDown: (C) => {
          window.dispatchEvent(new CustomEvent("photo-adjust:interaction", { detail: !0 })), v(C.metaKey || C.ctrlKey);
        },
        onPointerUp: () => v(!1),
        onPointerCancel: () => v(!1),
        onDoubleClick: () => r.reset?.(),
        onChange: (C) => r.onChange(Number(C.target.value))
      }
    ) }),
    /* @__PURE__ */ s.jsx(
      Nb,
      {
        value: r.value,
        min: h,
        max: u,
        step: c,
        onChange: r.onChange,
        reset: r.reset
      }
    )
  ] });
}
const xp = [
  { id: "hue", label: "色相" },
  { id: "saturation", label: "饱和度" },
  { id: "luminance", label: "明亮度" },
  { id: "all", label: "全部" }
];
function Pb(r, h) {
  return r === "hue" ? zc(h) : r === "saturation" ? qc(h) : Vb(h);
}
function yp(r) {
  return /* @__PURE__ */ s.jsxs("div", { className: "photo-hsl-row", children: [
    /* @__PURE__ */ s.jsx("i", { className: "photo-hsl-chip", style: { background: r.color.color } }),
    /* @__PURE__ */ s.jsx(
      ut,
      {
        label: r.color.label,
        track: Pb(r.field, r.color.hue),
        value: r.value,
        onChange: r.onChange,
        reset: () => r.onChange(0)
      }
    )
  ] });
}
function _b(r) {
  const h = M.useRef(null), u = M.useRef(null), c = M.useRef(null), g = M.useRef(r.onChange);
  g.current = r.onChange;
  const m = M.useCallback((v, y) => {
    const S = h.current;
    if (!S) return;
    const C = (v - 90) * Math.PI / 180, k = y / 100 * 43;
    S.style.transform = "translate(" + Math.cos(C) * k + "px, " + Math.sin(C) * k + "px)";
  }, []), b = () => {
    u.current = null;
    const v = c.current;
    v && (c.current = null, g.current(v.hue, v.saturation));
  };
  M.useEffect(() => {
    m(r.hue, r.saturation);
  }, [m, r.hue, r.saturation]), M.useEffect(
    () => () => {
      u.current !== null && cancelAnimationFrame(u.current);
    },
    []
  );
  const A = (v) => {
    const y = v.currentTarget.getBoundingClientRect(), S = v.clientX - y.left - y.width / 2, C = v.clientY - y.top - y.height / 2, k = y.width / 2, j = (Math.atan2(C, S) * 180 / Math.PI + 90 + 360) % 360, L = Math.round(Math.min(k, Math.hypot(S, C)) / k * 100);
    m(j, L), c.current = { hue: j, saturation: L }, u.current === null && (u.current = requestAnimationFrame(b));
  };
  return /* @__PURE__ */ s.jsxs(
    "div",
    {
      className: "photo-wheel",
      onPointerDown: (v) => {
        v.currentTarget.setPointerCapture(v.pointerId), A(v);
      },
      onPointerMove: (v) => {
        v.buttons && A(v);
      },
      onPointerUp: () => {
        u.current !== null && cancelAnimationFrame(u.current), b();
      },
      onPointerCancel: () => {
        u.current !== null && cancelAnimationFrame(u.current), u.current = null, c.current = null, m(r.hue, r.saturation);
      },
      children: [
        /* @__PURE__ */ s.jsx("div", { className: "photo-wheel-core" }),
        /* @__PURE__ */ s.jsx("i", { ref: h, className: "photo-wheel-marker" })
      ]
    }
  );
}
function $b(r) {
  return /* @__PURE__ */ s.jsxs("article", { className: "photo-wheel-card is-" + r.position, children: [
    /* @__PURE__ */ s.jsxs("div", { className: "photo-wheel-card-heading", children: [
      /* @__PURE__ */ s.jsxs("div", { children: [
        /* @__PURE__ */ s.jsx("strong", { children: r.title }),
        /* @__PURE__ */ s.jsx("span", { children: r.subtitle })
      ] }),
      /* @__PURE__ */ s.jsx("button", { type: "button", title: "重置" + r.title, onClick: r.onReset, children: /* @__PURE__ */ s.jsx(Qc, { size: 12 }) })
    ] }),
    /* @__PURE__ */ s.jsx(
      _b,
      {
        hue: r.value.hue,
        saturation: r.value.saturation,
        onChange: (h, u) => {
          r.onChange({ hue: h, saturation: u });
        }
      }
    ),
    /* @__PURE__ */ s.jsxs("div", { className: "photo-wheel-readout", children: [
      /* @__PURE__ */ s.jsxs("span", { children: [
        "H ",
        /* @__PURE__ */ s.jsxs("b", { children: [
          Math.round(r.value.hue),
          "°"
        ] })
      ] }),
      /* @__PURE__ */ s.jsxs("span", { children: [
        "S ",
        /* @__PURE__ */ s.jsx("b", { children: Math.round(r.value.saturation) })
      ] })
    ] }),
    /* @__PURE__ */ s.jsx(
      ut,
      {
        label: "明亮度",
        track: ze.luminance,
        value: r.value.luminance,
        onChange: (h) => r.onChange({ luminance: h }),
        reset: () => r.onChange({ luminance: 0 })
      }
    )
  ] });
}
function Oh(r, h, u, c, g) {
  const m = Math.max(0, (h.offsetWidth * g - r.clientWidth) / 2), b = Math.max(0, (h.offsetHeight * g - r.clientHeight) / 2);
  return {
    x: Math.min(m, Math.max(-m, u)),
    y: Math.min(b, Math.max(-b, c))
  };
}
const tx = /* @__PURE__ */ new Set(["geometry", "erase", "liquify", "mask"]);
function Nc(r) {
  return tx.has(r);
}
const Fh = [
  { id: "adjust", label: "调整" },
  { id: "presets", label: "预设" },
  { id: "mask", label: "蒙版" },
  { id: "portrait", label: "人像" },
  { id: "geometry", label: "裁剪" },
  { id: "erase", label: "修复" },
  { id: "liquify", label: "液化" }
], Gh = {
  adjust: ["basic", "curves", "hsl", "grading", "detail", "effects", "calibration"],
  presets: ["presets"],
  mask: ["mask"],
  portrait: ["portrait"],
  geometry: ["geometry"],
  erase: ["erase"],
  liquify: ["liquify"]
};
function Uc(r) {
  for (const h of Fh)
    if (Gh[h.id].includes(r)) return h.id;
  return "adjust";
}
let Ap = 0;
function jc(r) {
  return Ap += 1, `${r}-${Date.now().toString(36)}${Ap.toString(36)}`;
}
const ex = {
  add: "+",
  subtract: "−",
  intersect: "∩"
}, ax = {
  add: "添加",
  subtract: "减去",
  intersect: "相交"
};
function Qp(r) {
  return r.semanticMask ? r.semanticMask.kind === "subject" ? "AI 主体" : r.semanticMask.kind === "sky" ? "AI 天空" : "AI 背景" : r.kind === "radial" ? "径向" : "线性";
}
const nx = /windows/i.test(navigator.userAgent), Kh = [
  { id: "smooth", label: "流畅", ratio: 0.4, maxPixels: 46e4 },
  { id: "balanced", label: "平衡", ratio: 0.7, maxPixels: 98e4 },
  { id: "sharp", label: "清晰", ratio: 1, maxPixels: 26e5 }
], ox = 24e4, vp = 128, Ir = 112, kc = 480, ix = 0.72;
function lx() {
  const [r, h] = M.useState([]), [u, c] = M.useState(null), [g, m] = M.useState({}), b = M.useRef(g);
  b.current = g;
  const [A, v] = M.useState({}), [y, S] = M.useState(() => /* @__PURE__ */ new Set()), [C, k] = M.useState(null), j = M.useRef(0), L = M.useRef(null), [Z, it] = M.useState(null), [mt, tt] = M.useState("all"), Y = M.useRef(mt);
  Y.current = mt;
  const [W, et] = M.useState(null), [rt, Mt] = M.useState(() => {
    try {
      return window.localStorage.getItem("orcabox.photo-adjust.mask-overlay") !== "false";
    } catch {
      return !0;
    }
  }), [J, ht] = M.useState(null), [Tt, kt] = M.useState({}), [Yt, ge] = M.useState({}), [Lt, Et] = M.useState(!1), q = M.useRef(null), [O, K] = M.useState(() => {
    try {
      return window.localStorage.getItem("orcabox.photo-adjust.autosave") !== "false";
    } catch {
      return !0;
    }
  }), [Ct, R] = M.useState("自动保存已开启"), [Q, nt] = M.useState("basic"), [$, ft] = M.useState({}), qt = M.useRef(null), Nt = M.useRef(0), [me, ne] = M.useState(null), ct = M.useCallback((l) => {
    ne({ id: ++Nt.current, text: l });
  }, []), mn = me ? Math.min(4200, Math.max(2200, 1400 + me.text.length * 70)) : 0;
  M.useEffect(() => {
    if (!me) return;
    const l = setTimeout(() => {
      ne((p) => p?.id === me.id ? null : p);
    }, mn);
    return () => clearTimeout(l);
  }, [me, mn]);
  const [an, Ha] = M.useState(!1), [Oe, bn] = M.useState("all"), [Hi, Zi] = M.useState(100), [ea, xn] = M.useState(null), [aa, On] = M.useState(() => H1()), [nn, vo] = M.useState(""), ri = Bb(wc), [Kn, Mo] = M.useState({}), [Za, Se] = M.useState(() => {
    try {
      const l = window.localStorage.getItem("orcabox.photo-adjust.panelTab");
      if (l && Fh.some((p) => p.id === l)) return l;
    } catch {
    }
    return "adjust";
  }), ya = M.useCallback(
    (l) => l in Kn ? Kn[l] : l === "basic" || Gh[Uc(l)].length === 1,
    [Kn]
  ), be = M.useCallback((l) => {
    Nc(l) && (nt((p) => p === l ? p : l), Se((p) => p === Uc(l) ? p : Uc(l)), Mo((p) => p[l] ? p : { ...p, [l]: !0 }));
  }, []), si = M.useCallback((l, p) => {
    Mo((x) => ({ ...x, [l]: p })), Nc(l) && nt((x) => p ? l : x === l ? "basic" : x);
  }, []), ci = M.useCallback(
    (l) => {
      Se(l);
      try {
        window.localStorage.setItem("orcabox.photo-adjust.panelTab", l);
      } catch {
      }
      Nc(l) ? be(l) : nt("basic");
    },
    [be]
  ), Wa = M.useCallback((l) => {
    nt(l), Se(Uc(l)), Mo((p) => ({ ...p, [l]: !0 })), requestAnimationFrame(() => {
      document.querySelector(`details.photo-section[data-section-id="${l}"]`)?.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  }, []), [je, Va] = M.useState(!1), [na, Fa] = M.useState(!1), [oa, yn] = M.useState(!1), Hn = M.useRef(!1);
  Hn.current = oa;
  const [Ge, Zn] = M.useState(null), An = M.useRef(null), [ui, Vt] = M.useState(() => {
    try {
      const l = window.localStorage.getItem("orcabox.photo-adjust.previewQuality");
      if (l === "smooth" || l === "balanced" || l === "sharp") return l;
    } catch {
    }
    return "balanced";
  }), [we, ce] = M.useState(0), [bt, yt] = M.useState(0), xt = M.useRef(null), [de, Rt] = M.useState(0), [dt, Ot] = M.useState("free"), [Ht, ue] = M.useState("all"), [It, ve] = M.useState(null), [ke, Ke] = M.useState(null), [Aa, Wn] = M.useState(!1), [hi, on] = M.useState(null), [xe, Ql] = M.useState(""), [Ga, ln] = M.useState(null), [vn, fi] = M.useState(null), [Wi, di] = M.useState(0.06), [Ll, wo] = M.useState(50), [pi, ia] = M.useState(), Eo = M.useRef(null), [Fi, Fn] = M.useState(0.12), [gi, Gi] = M.useState(60), $r = M.useCallback(
    (l, p, x, w, N) => {
      if (!u) return;
      const H = (x - l) / N.width, ot = (w - p) / N.height;
      if (Math.hypot(H, ot) < 4e-3) return;
      const P = {
        id: "warp-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 6),
        x: Math.min(1, Math.max(0, l / N.width)),
        y: Math.min(1, Math.max(0, p / N.height)),
        dx: Math.min(0.5, Math.max(-0.5, H)),
        dy: Math.min(0.5, Math.max(-0.5, ot)),
        radius: Fi,
        strength: gi
      };
      Ut((at) => ({
        ...at,
        warps: [...at.warps.slice(-59), P]
      }));
    },
    // setActiveAdjustments 是稳定引用（useCallback([])），这里不列进依赖也不会读到旧闭包；
    // 它声明在本 hook 之后，列进去会触发 TDZ。
    [u, Fi, gi]
  ), [Ol, la] = M.useState(() => {
    const l = window.localStorage.getItem("orcabox.photo-adjust.filmstrip-height"), p = l ? Number(l) : NaN;
    return Number.isFinite(p) ? Math.min(kc, Math.max(Ir, Math.round(p))) : vp;
  }), [ts, es] = M.useState(!1), Gn = M.useRef(null), mi = M.useRef(null), Ii = (l) => {
    if (l.button !== 0) return;
    const p = Gn.current;
    if (!p) return;
    const x = p.parentElement?.getBoundingClientRect().height ?? window.innerHeight, w = Math.max(
      Ir + 40,
      Math.min(kc, Math.round(x * ix))
    );
    mi.current = {
      startY: l.clientY,
      startHeight: p.getBoundingClientRect().height,
      maxHeight: w
    }, l.currentTarget.setPointerCapture(l.pointerId), es(!0), document.body.style.cursor = "row-resize", document.body.style.userSelect = "none";
  }, Kc = (l) => {
    const p = mi.current, x = Gn.current;
    if (!p || !x) return;
    const w = Math.min(
      p.maxHeight,
      Math.max(Ir, Math.round(p.startHeight - (l.clientY - p.startY)))
    );
    x.style.height = w + "px";
  }, ca = (l) => {
    const p = mi.current, x = Gn.current;
    if (mi.current = null, es(!1), document.body.style.cursor = "", document.body.style.userSelect = "", !p || !x) return;
    l.currentTarget.hasPointerCapture(l.pointerId) && l.currentTarget.releasePointerCapture(l.pointerId);
    const w = Math.round(x.getBoundingClientRect().height);
    la(w), window.localStorage.setItem("orcabox.photo-adjust.filmstrip-height", String(w));
  }, Kl = () => {
    window.localStorage.removeItem("orcabox.photo-adjust.filmstrip-height"), la(vp);
  }, [Ie, Xi] = M.useState(null), [In, Mn] = M.useState(!1), Ji = M.useCallback(() => Mn(!1), []), Ro = Xb(In, Ji), [bi, Hl] = M.useState(""), [xi, Pi] = M.useState(""), [_i, as] = M.useState(!1), [yi, Ai] = M.useState(null), rn = Ie !== null && !Ie.unprovisioned && Ie.state !== "trial" && Ie.state !== "active", Ia = M.useCallback(async () => {
    try {
      Xi(await Ye.photoAdjustLicense?.status() ?? null);
    } catch {
    }
  }, []);
  M.useEffect(() => {
    Ia(), Ye.photoAdjustLicense?.machineCode()?.then(Pi)?.catch(() => Pi(""));
  }, [Ia]);
  const So = M.useCallback(async () => {
    if (!(!bi.trim() || _i)) {
      as(!0), Ai(null);
      try {
        const l = await Ye.photoAdjustLicense?.activate(bi);
        l?.ok && l.status ? (Xi(l.status), Mn(!1), Hl(""), ct("激活成功，感谢支持！")) : Ai(l?.error || "激活失败，请检查激活码。");
      } catch {
        Ai("激活失败，请稍后重试。");
      } finally {
        as(!1);
      }
    }
  }, [_i, bi, ct]), wn = M.useRef(/* @__PURE__ */ new Set()), Xn = M.useRef(/* @__PURE__ */ new Map()), qe = M.useRef(null), ua = M.useRef("auto"), ha = M.useRef(null), Da = M.useRef(null), sn = M.useRef(null), va = M.useRef(null), Jn = M.useRef(Qh()), To = M.useRef(null), [ns, Pn] = M.useState(null), Ma = M.useRef(null), Xa = M.useRef(null), Te = M.useRef(null), Ee = M.useRef(null), En = M.useRef(null), _n = M.useRef(null), $n = M.useRef(0), cn = M.useRef(null), vi = M.useRef(0), Rn = M.useRef(null), Co = M.useRef(""), os = M.useRef(0), No = M.useRef(!1), to = M.useRef(null), is = M.useRef(0), Sn = M.useRef(""), Mi = M.useRef(""), $i = M.useRef(!1), Hc = M.useRef(Q), Zc = M.useRef(je), wi = M.useRef(null), Qe = M.useRef(null), wa = M.useRef(null), tl = M.useRef(null), Zl = M.useRef(null), Tn = M.useRef({ zoom: 1, x: 0, y: 0 }), eo = M.useRef(null), Ei = M.useRef(/* @__PURE__ */ new Map()), Wl = M.useRef(/* @__PURE__ */ new Set()), Fl = M.useMemo(() => ba(), []), el = M.useMemo(() => ({ zoom: 1, x: 0, y: 0 }), []), wt = r.find((l) => l.id === u) || null, fa = r.find((l) => l.id === Z) || null, Gl = !!(wt && /\.(arw|cr2|cr3|dng|nef|nrw|orf|raf|raw|rw2|srw)$/i.test(wt.extension)), _ = u && Tt[u] || Fl, Xe = u && $[u] || el, ls = _.masks.some((l) => l.semanticMask?.kind === "sky"), rs = M.useCallback(
    async (l) => {
      const p = zh(g[l.id] || l.fileUrl);
      if (!p) return null;
      const x = new Image();
      x.crossOrigin = "anonymous", x.decoding = "async", x.src = p, await x.decode();
      const w = Math.min(1, 1200 / Math.max(x.naturalWidth, x.naturalHeight)), N = document.createElement("canvas");
      N.width = Math.max(1, Math.round(x.naturalWidth * w)), N.height = Math.max(1, Math.round(x.naturalHeight * w));
      const H = N.getContext("2d", { willReadFrequently: !0 });
      return H ? (H.drawImage(x, 0, 0, N.width, N.height), {
        width: N.width,
        height: N.height,
        data: H.getImageData(0, 0, N.width, N.height).data
      }) : null;
    },
    [g]
  ), al = M.useRef(J);
  al.current = J;
  const Il = M.useCallback(
    (l, p, x, w) => {
      const N = w1(x, w);
      return kt((H) => {
        const ot = H[l];
        return ot ? {
          ...H,
          [l]: E1(ot, p, N)
        } : H;
      }), N;
    },
    []
  ), Xl = M.useCallback(async () => {
    if (!fa || !wt || fa.id === wt.id) return;
    const [l, p] = await Promise.all([
      rs(fa),
      Ee.current
    ]);
    if (!l || !p) return;
    const x = Y.current, w = R1(
      l.data,
      l.width,
      l.height,
      p.data,
      p.width,
      p.height,
      x
    );
    if (!w) {
      ct(
        x === "all" ? "参考图分析失败，请换一张图片重试" : `参考图「${Wr[x]}」样本不足，试试其他匹配范围`
      );
      return;
    }
    const N = al.current, H = N?.targetId === wt.id ? N.applied : M1(), ot = N?.targetId === wt.id ? N.strength : 70, P = Il(wt.id, H, w, ot);
    ht({ targetId: wt.id, match: w, applied: P, strength: ot }), ct(
      x === "all" ? `已匹配参考图 · 置信度 ${Math.round(w.confidence * 100)}%` : `已匹配参考图 · ${Wr[x]} · 置信度 ${Math.round(w.confidence * 100)}%`
    );
  }, [wt, Il, rs, fa, ct]);
  M.useEffect(() => {
    Hc.current = Q, Zc.current = je;
  }, [je, Q]), M.useEffect(() => {
    if (!Ga) return;
    const l = (p) => {
      p.key === "Escape" && ln(null);
    };
    return window.addEventListener("keydown", l), () => window.removeEventListener("keydown", l);
  }, [Ga]), M.useEffect(() => {
    const l = () => {
      oa && yn(!1), Wn(!1);
    }, p = (x) => {
      const w = x.detail;
      yn(!!w);
    };
    return window.addEventListener("pointerup", l), window.addEventListener("pointercancel", l), window.addEventListener("photo-adjust:interaction", p), () => {
      window.removeEventListener("pointerup", l), window.removeEventListener("pointercancel", l), window.removeEventListener("photo-adjust:interaction", p);
    };
  }, [oa]), M.useEffect(() => {
    wi.current = u, ht(null);
  }, [u]);
  const un = M.useCallback(async (l, p) => {
    const x = [...new Set(l)];
    if (!x.length) return;
    const w = p ?? ++j.current;
    L.current && clearTimeout(L.current), k({ stage: "details", done: 0, total: x.length });
    const N = [];
    let H = 0;
    for (let P = 0; P < x.length; P += 6) {
      const at = x.slice(P, P + 6), zt = await Wh(
        at,
        6,
        (ee) => Ye.asset.getById(ee).catch(() => null)
      );
      if (j.current !== w) return;
      const Bt = zt.filter(fb);
      N.push(...Bt), Bt.length && (h((ee) => {
        const Zt = new Map(ee.map((Pt) => [Pt.id, Pt]));
        return Bt.forEach((Pt) => Zt.set(Pt.id, Pt)), [...Zt.values()];
      }), c((ee) => ee || Bt[0].id)), H += at.length, j.current === w && k({ stage: "details", done: H, total: x.length });
    }
    const ot = N.filter((P) => !b.current[P.id]);
    if (ot.length) {
      k({ stage: "previews", done: 0, total: ot.length });
      let P = 0;
      await Wh(
        ot,
        3,
        async (at) => {
          let zt = null;
          for (let Bt = 0; Bt < 12; Bt += 1) {
            if (j.current !== w) return;
            if (zt = await Ye.preview.getImagePreviewSource(at.id).catch(() => null), zt?.url) break;
            await new Promise((ee) => setTimeout(ee, 500));
          }
          j.current === w && (zt?.url && (m((Bt) => ({ ...Bt, [at.id]: zt.url })), S((Bt) => new Set(Bt).add(at.id))), P += 1, k({
            stage: "previews",
            done: P,
            total: ot.length
          }));
        }
      );
    }
    j.current === w && (k({
      stage: "complete",
      done: x.length,
      total: x.length
    }), L.current = setTimeout(() => {
      j.current === w && k(null);
    }, 1200));
  }, []);
  M.useEffect(() => (un(vb()), Ye.system.onPhotoAdjustAssets((l) => {
    un(l);
  })), [un]), M.useEffect(() => {
    if (!u || wn.current.has(u)) return;
    let l = !1;
    return Ye.preview.getPhotoAdjustState(u).then((p) => {
      if (l) return;
      wn.current.add(u);
      const x = p?.adjustments ?? ba();
      Xn.current.set(u, JSON.stringify(x)), kt(
        (w) => w[u] ? w : { ...w, [u]: x }
      ), ge((w) => ({ ...w, [u]: p?.history ?? [] })), R(
        p ? "已恢复上次调色" : O ? "自动保存已开启" : "自动保存已关闭"
      );
    }).catch(() => {
      if (l) return;
      wn.current.add(u);
      const p = Tt[u] ?? ba();
      Xn.current.set(u, JSON.stringify(p)), R("调色数据将在本地保存");
    }), () => {
      l = !0;
    };
  }, [u, O, Tt]), M.useEffect(() => window.electronAPI?.onPreviewImageSourceReady?.(({ assetId: p, source: x }) => {
    x?.url && (m((w) => w[p] === x.url ? w : { ...w, [p]: x.url }), S((w) => new Set(w).add(p)));
  }), []), M.useEffect(() => {
    !wt || g[wt.id] || Ye.preview.getImagePreviewSource(wt.id).then((l) => {
      l?.url && (S((p) => new Set(p).add(wt.id)), m((p) => ({ ...p, [wt.id]: l.url })));
    }).catch((l) => {
      console.error("[photo-adjust] Full image preview request failed:", l), ct("原图预览加载失败，请重试或重新导入图片");
    });
  }, [wt, ct, g]), M.useEffect(() => {
    if (!wt) {
      Xa.current = null, Te.current = null, Ee.current = null, xt.current = null, Jn.current = Qh(), Pn(null), Tc(va.current, null);
      return;
    }
    const l = zh(g[wt.id] || wt.fileUrl);
    if (!l) {
      Jn.current = Qh(), Pn(null), Tc(va.current, null);
      return;
    }
    if (!Xa.current || Xa.current.assetId !== wt.id || Xa.current.source !== l) {
      Xa.current = null, Ee.current = null, xt.current = null, Co.current = "", Sn.current = "", Mi.current = "", to.current = null, (Te.current?.assetId !== wt.id || Te.current?.source !== l) && (Te.current = null);
      const N = Ma.current;
      N && (N.width = 0, N.height = 0);
    }
    let p = !1;
    const x = (N) => {
      if (!p)
        try {
          const H = ha.current, ot = H ? window.getComputedStyle(H) : null, P = H ? Math.max(
            80,
            H.clientWidth - parseFloat(ot?.paddingLeft || "0") - parseFloat(ot?.paddingRight || "0")
          ) : 1e3, at = H ? Math.max(
            80,
            H.clientHeight - parseFloat(ot?.paddingTop || "0") - parseFloat(ot?.paddingBottom || "0")
          ) : 700, zt = N.naturalWidth / N.naturalHeight;
          let Bt = Math.min(N.naturalWidth, P), ee = Bt / zt;
          const Zt = at;
          ee > Zt && (ee = Zt, Bt = ee * zt);
          const Pt = Math.max(Bt, ee) * Math.max(1, Xe.zoom) * Math.min(2, window.devicePixelRatio || 1), Dn = Math.min(1, Pt / Math.max(N.naturalWidth, N.naturalHeight)), Ca = Math.max(1, Math.round(N.naturalWidth * Dn)), ho = Math.max(1, Math.round(N.naturalHeight * Dn)), gl = document.createElement("canvas");
          gl.width = Ca, gl.height = ho;
          const hr = gl.getContext("2d", { willReadFrequently: !0 });
          if (!hr) return;
          hr.drawImage(N, 0, 0, Ca, ho), Xa.current = { assetId: wt.id, source: l, canvas: gl }, Rt((ml) => ml + 1), ia((ml) => ml?.assetId === wt.id ? void 0 : ml), $i.current && ia({ assetId: wt.id, url: l });
        } catch {
          ia({ assetId: wt.id, url: l });
        }
    }, w = Te.current;
    if (w?.assetId === wt.id && w.source === l && w.image.complete)
      x(w.image);
    else {
      const N = new Image();
      N.decoding = "async", N.crossOrigin = "anonymous", N.onload = () => {
        p || (Te.current = { assetId: wt.id, source: l, image: N }, x(N));
      }, N.onerror = () => {
        p || ia({ assetId: wt.id, url: l });
      }, N.src = l;
    }
    return () => {
      p = !0;
    };
  }, [wt, g, Xe.zoom]);
  const Be = _.geometry, Uo = M.useMemo(() => JSON.stringify(Be), [Be]), Cn = M.useMemo(
    () => JSON.stringify([
      de,
      Be.quarterTurns,
      Be.flipH,
      Be.flipV,
      Be.straighten
    ]),
    [Be.flipH, Be.flipV, Be.quarterTurns, Be.straighten, de]
  );
  M.useEffect(() => {
    const l = Xa.current;
    if (!l) {
      Ee.current = null, _n.current = null, En.current = null;
      return;
    }
    const p = JSON.parse(Uo), x = U1(l.canvas.width, l.canvas.height, p);
    let w = _n.current;
    if (w?.key !== Cn) {
      let P = l.canvas;
      const at = (Math.round(p.quarterTurns) % 4 + 4) % 4;
      if (at || p.flipH || p.flipV) {
        const Zt = document.createElement("canvas");
        Zt.width = Math.max(1, x.oriented.width), Zt.height = Math.max(1, x.oriented.height);
        const Pt = Zt.getContext("2d");
        if (!Pt) return;
        Pt.save(), Pt.translate(Zt.width / 2, Zt.height / 2), Pt.rotate(at * Math.PI / 2), Pt.scale(p.flipH ? -1 : 1, p.flipV ? -1 : 1), Pt.drawImage(l.canvas, -l.canvas.width / 2, -l.canvas.height / 2), Pt.restore(), P = Zt;
      }
      let zt = P, Bt = 0, ee = 0;
      if (x.straighten) {
        const Zt = document.createElement("canvas");
        Zt.width = Math.max(1, Math.round(x.straighten.bboxWidth)), Zt.height = Math.max(1, Math.round(x.straighten.bboxHeight));
        const Pt = Zt.getContext("2d");
        if (!Pt) return;
        Pt.fillStyle = "#000000", Pt.fillRect(0, 0, Zt.width, Zt.height), Pt.save(), Pt.translate(Zt.width / 2, Zt.height / 2), Pt.rotate(p.straighten * Math.PI / 180), Pt.drawImage(P, -P.width / 2, -P.height / 2), Pt.restore(), zt = Zt, Bt = x.straighten.cropX, ee = x.straighten.cropY;
      }
      w = { key: Cn, cropSource: zt, cropX: Bt, cropY: ee }, _n.current = w, En.current = null;
    }
    const { cropSource: N, cropX: H, cropY: ot } = w;
    if (En.current?.key !== Cn) {
      const P = document.createElement("canvas");
      P.width = Math.max(1, Math.round(x.cropped.width)), P.height = Math.max(1, Math.round(x.cropped.height));
      const at = P.getContext("2d", { willReadFrequently: !0 });
      if (!at) return;
      at.drawImage(
        N,
        H,
        ot,
        x.cropped.width,
        x.cropped.height,
        0,
        0,
        P.width,
        P.height
      ), En.current = {
        key: Cn,
        assetId: l.assetId,
        width: P.width,
        height: P.height,
        data: at.getImageData(0, 0, P.width, P.height).data
      };
    }
    if (Q !== "geometry") {
      const P = document.createElement("canvas");
      P.width = Math.max(1, x.userCrop.width), P.height = Math.max(1, x.userCrop.height);
      const at = P.getContext("2d", { willReadFrequently: !0 });
      if (!at) return;
      at.drawImage(
        N,
        H + x.userCrop.x,
        ot + x.userCrop.y,
        x.userCrop.width,
        x.userCrop.height,
        0,
        0,
        x.userCrop.width,
        x.userCrop.height
      ), Ee.current = {
        assetId: l.assetId,
        width: P.width,
        height: P.height,
        data: at.getImageData(0, 0, P.width, P.height).data
      }, ce((zt) => zt + 1);
    }
    xt.current = {
      aspect: x.cropped.width / x.cropped.height,
      output: { width: x.final.width, height: x.final.height }
    }, yt((P) => P + 1);
  }, [de, Uo, Cn, Q]);
  const ao = M.useCallback(() => {
    const l = ha.current, p = Ma.current;
    if (!l || !p || !p.width || !p.height) return;
    const x = window.getComputedStyle(l), w = Math.max(
      1,
      l.clientWidth - parseFloat(x.paddingLeft || "0") - parseFloat(x.paddingRight || "0")
    ), N = Math.max(
      1,
      l.clientHeight - parseFloat(x.paddingTop || "0") - parseFloat(x.paddingBottom || "0")
    ), H = p.width / p.height, ot = Math.max(1, Math.floor(Math.min(w, N * H))), P = Math.max(1, Math.floor(ot / H));
    p.style.width = ot + "px", p.style.height = P + "px";
    const at = Da.current;
    if (at && !Qe.current) {
      const zt = Tn.current, Bt = Oh(l, at, zt.x, zt.y, zt.zoom);
      at.style.transform = `translate(${Bt.x}px, ${Bt.y}px) scale(${zt.zoom})`;
    }
  }, []), nl = M.useRef(() => {
  });
  M.useEffect(() => {
    let l;
    try {
      l = new I1(), $i.current = !1;
    } catch (x) {
      $i.current = !0, console.error("[photo-adjust] Preview worker could not start:", x), ct("照片处理器启动失败，当前显示原图预览");
      const w = Xa.current;
      w && ia({ assetId: w.assetId, url: w.source });
      return;
    }
    Rn.current = l;
    const p = () => {
      const x = to.current;
      !x || No.current || Mi.current !== x.baseKey || Sn.current !== x.baseKey || (to.current = null, No.current = !0, l.postMessage({ type: "render", ...x }));
    };
    return nl.current = p, l.onmessage = (x) => {
      const w = x.data;
      if (w.type === "base-ready") {
        w.baseKey === Sn.current && (Mi.current = w.baseKey, p());
        return;
      }
      No.current = !1;
      const N = Ma.current;
      if (w.requestId === is.current && w.baseKey === Sn.current && w.assetId === wi.current && N) {
        (N.width !== w.displayWidth || N.height !== w.displayHeight) && (N.width = w.displayWidth, N.height = w.displayHeight);
        const H = N.getContext("2d");
        H && (H.drawImage(w.bitmap, 0, 0, w.displayWidth, w.displayHeight), ao()), Hn.current || Zn(
          (ot) => ot && ot.pipeline === "cpu" ? {
            ...ot,
            frameMs: Math.round((performance.now() - vi.current) * 10) / 10,
            width: w.displayWidth,
            height: w.displayHeight
          } : ot
        ), w.histogram && (Jn.current = w.histogram, Tc(va.current, w.histogram), Pn(Yc(w.histogram)));
      }
      w.bitmap.close(), p();
    }, l.onerror = (x) => {
      No.current = !1, to.current = null, $i.current = !0, console.error("[photo-adjust] Preview worker failed:", x.message);
      const w = Xa.current;
      w && ia({ assetId: w.assetId, url: w.source }), ct("照片处理器运行失败，当前显示原图预览");
    }, () => {
      nl.current = () => {
      }, Rn.current = null, l.terminate(), No.current = !1, Mi.current = "", to.current = null;
    };
  }, [ct, ao]), M.useEffect(() => {
    const l = Rn.current, p = Q === "geometry" ? En.current : Ee.current, x = p?.assetId;
    if (!l || !p || !x || x !== u) return;
    const w = JSON.stringify(Q === "geometry" ? [x, de, Cn, !0] : [x, de, Uo, !1]);
    if (Co.current === w) return;
    Co.current = w, Sn.current = w, Mi.current = "";
    const N = p.data.slice();
    No.current = !1, to.current = null, l.postMessage(
      {
        type: "init",
        assetId: x,
        baseKey: w,
        width: p.width,
        height: p.height,
        data: N.buffer
      },
      [N.buffer]
    );
  }, [u, we, Uo, Cn, Q, de]);
  const Jl = M.useCallback(
    (l = !1) => {
      const p = Kh.find((ot) => ot.id === ui) ?? Kh[1], x = Da.current?.getBoundingClientRect(), w = Math.min(2, window.devicePixelRatio || 1), N = x && x.width > 2 && x.height > 2 ? x.width * x.height * w * w : 0;
      if (l) {
        const ot = N ? N * 0.3 : 24e4;
        return Math.round(Math.min(3e5, Math.max(16e4, ot)));
      }
      const H = N ? N * p.ratio : p.maxPixels;
      return Math.round(Math.min(p.maxPixels, Math.max(ox, H)));
    },
    [ui]
  );
  M.useEffect(() => {
    $n.current && cancelAnimationFrame($n.current), cn.current && clearTimeout(cn.current);
    const l = !je && Q !== "geometry" && Ee.current !== null && !cp(_), x = Math.max(0, (oa ? l ? 0 : 8 : 16) - (performance.now() - vi.current));
    return cn.current = setTimeout(() => {
      cn.current = null, $n.current = requestAnimationFrame(() => {
        $n.current = 0, vi.current = performance.now();
        const w = Q === "geometry" ? null : Ee.current, N = je ? "compare" : Q === "geometry" ? "geometry" : w ? cp(_) : "base";
        if (!N && w && Ma.current) {
          let P = An.current;
          P || (P = new _1(), An.current = P);
          const at = P.render(w.data, w.width, w.height, _);
          if (at) {
            const zt = Ma.current;
            (zt.width !== at.width || zt.height !== at.height) && (zt.width = at.width, zt.height = at.height);
            const Bt = zt.getContext("2d");
            if (Bt && (Bt.drawImage(at.canvas, 0, 0, at.width, at.height), ao()), !oa && !je && Q !== "geometry") {
              const ee = P.readPixels(at.width, at.height);
              if (ee) {
                const Zt = Zh(ee, at.width, at.height);
                Jn.current = Zt, Tc(va.current, Zt), Pn(Yc(Zt));
              }
            }
            Hn.current || Zn({
              pipeline: "gpu",
              frameMs: Math.round(at.durationMs * 10) / 10,
              width: at.width,
              height: at.height,
              note: null
            });
            return;
          }
        }
        const H = Sn.current;
        if (!H || !u || !Rn.current) return;
        Hn.current || Zn({
          pipeline: "cpu",
          frameMs: 0,
          width: w?.width ?? 0,
          height: w?.height ?? 0,
          note: je ? "对比原图" : Q === "geometry" ? "裁剪/几何" : N === "base" ? "解码中" : N === "compare" ? "对比原图" : N === "geometry" ? "裁剪/几何" : P1[N] ?? "GPU 不可用"
        });
        const ot = ++os.current;
        is.current = ot, to.current = {
          requestId: ot,
          baseKey: H,
          assetId: u,
          adjustments: _,
          spots: _.spots,
          original: je,
          geometry: Q === "geometry",
          // 直方图不再做 100ms 节流：节流会把"最后一帧"的统计漏掉，读数就会停在
          // 上一组参数上（连点预设、方向键微调都会撞上）。24MP 全分辨率图算一次
          // 约 14ms，相对成片渲染可以忽略，换的是读数永远等于当前画面。
          includeHistogram: !oa && !je && Q !== "geometry",
          interactive: oa && !je,
          // 拖拽期用代理帧：像素预算按屏幕显示尺寸实时算，避免放大发虚。
          // CPU 回退（蒙版/液化/磨皮…）走收紧档，否则每帧等于全分辨率重算。
          interactiveMaxPixels: oa && !je ? Jl(
            N !== null && N !== "base" && N !== "compare" && N !== "geometry"
          ) : void 0
        }, nl.current();
      });
    }, x), () => {
      $n.current && (cancelAnimationFrame($n.current), $n.current = 0), cn.current && (clearTimeout(cn.current), cn.current = null);
    };
  }, [
    u,
    _,
    je,
    we,
    Jl,
    Uo,
    oa,
    Q,
    de,
    ao
  ]), M.useEffect(() => {
    const l = ha.current;
    if (!l || typeof ResizeObserver > "u") return;
    const p = new ResizeObserver(() => ao());
    return p.observe(l), () => p.disconnect();
  }, [ao]), M.useEffect(() => {
    const l = ha.current;
    if (!l) return;
    const p = (N) => {
      const H = Da.current;
      H && (H.style.transform = `translate(${N.x}px, ${N.y}px) scale(${N.zoom})`, sn.current && (sn.current.textContent = Math.round(N.zoom * 100) + "%"));
    }, x = () => {
      wa.current && (clearTimeout(wa.current), wa.current = null);
      const N = tl.current;
      tl.current = null;
      const H = Qe.current;
      !N || !H || (Qe.current = null, ft((ot) => ({ ...ot, [N]: H })));
    };
    Zl.current = x;
    const w = (N) => {
      const H = wi.current, ot = Da.current;
      if (!H || !ot) return;
      tl.current = H, N.preventDefault();
      const P = l.getBoundingClientRect(), at = N.clientX - P.left - P.width / 2, zt = N.clientY - P.top - P.height / 2, Bt = N.ctrlKey ? 8e-3 : 15e-4, ee = Qe.current || Tn.current, Zt = Math.min(6, Math.max(0.25, ee.zoom * Math.exp(-N.deltaY * Bt))), Pt = Zt / ee.zoom, Dn = Oh(
        l,
        ot,
        at - (at - ee.x) * Pt,
        zt - (zt - ee.y) * Pt,
        Zt
      );
      Qe.current = { zoom: Zt, x: Dn.x, y: Dn.y }, p(Qe.current), wa.current && clearTimeout(wa.current), wa.current = setTimeout(x, 160);
    };
    return l.addEventListener("wheel", w, { passive: !1 }), () => {
      l.removeEventListener("wheel", w), Zl.current = null, tl.current = null, wa.current && (clearTimeout(wa.current), wa.current = null);
    };
  }, [el]), M.useEffect(() => {
    Zl.current?.();
  }, [u]), M.useEffect(() => {
    if (Tn.current = Xe, !Qe.current) {
      const l = Da.current;
      l && (l.style.transform = `translate(${Xe.x}px, ${Xe.y}px) scale(${Xe.zoom})`), sn.current && (sn.current.textContent = Math.round(Xe.zoom * 100) + "%");
    }
  }, [Xe, u]), M.useEffect(() => {
    const l = (x) => {
      x.target?.closest('input, textarea, select, [contenteditable="true"]') || (x.key === "\\" && !x.metaKey && !x.ctrlKey && !x.altKey && (x.preventDefault(), Va(!0)), (x.key === "o" || x.key === "O") && !x.metaKey && !x.ctrlKey && !x.altKey && Mt((N) => {
        const H = !N;
        try {
          window.localStorage.setItem("orcabox.photo-adjust.mask-overlay", String(H));
        } catch {
        }
        return H;
      }));
    }, p = (x) => {
      x.key === "\\" && Va(!1);
    };
    return window.addEventListener("keydown", l), window.addEventListener("keyup", p), () => {
      window.removeEventListener("keydown", l), window.removeEventListener("keyup", p);
    };
  }, []), M.useEffect(() => {
    if (Q !== "mask" || !It) return;
    const l = (p) => {
      p.key !== "Escape" || p.defaultPrevented || Ga || p.target?.closest('input, textarea, select, [contenteditable="true"]') || ve(null);
    };
    return window.addEventListener("keydown", l), () => window.removeEventListener("keydown", l);
  }, [Q, It, Ga]);
  const Ut = M.useCallback(
    (l) => {
      const p = wi.current;
      p && kt((x) => {
        const w = x[p] || ba();
        return { ...x, [p]: typeof l == "function" ? l(w) : l };
      });
    },
    []
  ), ye = u ? Tt[u] || Fl : null, ol = M.useRef(ye);
  ol.current = ye;
  const Ya = M.useCallback(
    async (l, p, x) => {
      const w = await Ye.preview.savePhotoAdjustState({
        assetId: l,
        adjustments: p,
        reason: x
      });
      if (!w) throw new Error("调色数据保存失败");
      return Xn.current.set(l, JSON.stringify(w.adjustments)), ge((N) => ({ ...N, [l]: w.history })), R(x === "manual" ? "已手动保存调色数据" : "已自动保存调色数据"), w;
    },
    []
  ), jo = M.useMemo(
    () => ye ? JSON.stringify(ye) : "",
    [ye]
  ), [Ce, hn] = M.useState(/* @__PURE__ */ new Set()), Ea = M.useRef(null), [Nn, il] = M.useState(null), [Ja, ll] = M.useState(null), [Un, Pl] = M.useState("auto"), [Ri, ss] = M.useState(90), [rl, Wc] = M.useState(0), cs = M.useCallback((l) => {
    hn((p) => bb(p, l)), Ea.current = l;
  }, []), Fc = (l, p) => {
    if (c(l), p.shiftKey) {
      const x = fp(
        r.map((w) => w.id),
        Ea.current,
        l
      );
      hn(new Set(x.selectedIds)), Ea.current = x.nextAnchorId;
      return;
    }
    Ea.current = l, (p.metaKey || p.ctrlKey) && cs(l);
  }, Gc = (l, p) => {
    if (p.shiftKey) {
      const x = fp(
        r.map((w) => w.id),
        Ea.current,
        l
      );
      hn(new Set(x.selectedIds)), Ea.current = x.nextAnchorId;
      return;
    }
    cs(l);
  }, Ic = (l) => {
    const p = l.target;
    if (!(p instanceof HTMLElement && p.closest('input, textarea, select, [contenteditable="true"]')))
      if ((l.metaKey || l.ctrlKey) && l.key.toLowerCase() === "a") {
        if (!r.length) return;
        l.preventDefault(), hn(xb(r.map((x) => x.id))), Ea.current = r[0].id;
      } else l.key === "Escape" && Ce.size && (l.preventDefault(), hn(/* @__PURE__ */ new Set()), Ea.current = null);
  }, da = M.useCallback(() => {
    u && (il(Tt[u] || null), ct("已复制当前照片的调整参数"));
  }, [u, Tt, ct]), Si = M.useCallback(() => {
    if (!Nn || !u) return;
    const l = JSON.parse(JSON.stringify(Nn));
    kt((p) => ({ ...p, [u]: l })), ct("已粘贴调整参数");
  }, [u, Nn]), us = M.useCallback(async () => {
    if (!Nn || !Ce.size) return;
    const l = JSON.parse(JSON.stringify(Nn)), p = [...Ce];
    let x = 0;
    for (const w of p) {
      kt((N) => ({ ...N, [w]: l }));
      try {
        await Ya(w, l, "manual"), x += 1;
      } catch {
      }
    }
    ct(`已同步调整到 ${x}/${p.length} 张照片`);
  }, [Ce, Nn, Ya, ct]), hs = M.useCallback(async () => {
    if (Ja || rn || !r.length) return;
    const l = Ce.size ? [...Ce] : r.map((P) => P.id), p = /\.(arw|cr2|cr3|dng|nef|nrw|orf|raf|raw|rw2|srw)$/i, x = l.map((P) => r.find((at) => at.id === P)).filter(
      (P) => !!P && !p.test(P.extension)
    ), w = l.length - x.length;
    if (!x.length) {
      ct(w ? "所选照片均为 RAW，暂不支持导出副本" : "没有可导出的照片");
      return;
    }
    ll({ total: x.length, done: 0, current: "" });
    let N = 0, H = 0, ot = "";
    for (const P of x) {
      ll({ total: x.length, done: N + H, current: P.name });
      const at = Tt[P.id] || ba();
      try {
        const zt = await Ye.preview.applyImageEdits({
          assetId: P.id,
          recipe: { photoAdjustments: at },
          saveMode: "copy",
          ...Un === "auto" ? {} : {
            exportFormat: Un,
            exportQuality: Ri,
            exportMaxEdge: rl || void 0
          }
        });
        if (zt.success) N += 1;
        else if (String(zt.error ?? "").includes("photo_adjust_license_locked")) {
          await Ia(), Mn(!0);
          break;
        } else
          H += 1, ot = zt.error || "未知错误";
      } catch (zt) {
        H += 1, ot = zt instanceof Error ? zt.message : String(zt);
      }
    }
    ll(null), ct(
      `批量导出完成：成功 ${N}${H ? " · 失败 " + H + (ot ? "（" + ot + "）" : "") : ""}${w ? " · 跳过 RAW " + w : ""}`
    );
  }, [
    u,
    Tt,
    r,
    Ja,
    Ce,
    Un,
    rl,
    Ri,
    rn,
    Ia,
    ct
  ]);
  M.useEffect(() => {
    if (qe.current && clearTimeout(qe.current), !(!O || !u || !ye || !wn.current.has(u)) && Xn.current.get(u) !== jo)
      return ua.current = ua.current === "restore" ? "restore" : "auto", R("等待自动保存…"), qe.current = setTimeout(() => {
        qe.current = null, Ya(u, ye, ua.current).catch(() => {
          R("自动保存失败");
        }), ua.current = "auto";
      }, 1200), () => {
        qe.current && (clearTimeout(qe.current), qe.current = null);
      };
  }, [jo, ye, u, O, Ya]), M.useEffect(() => {
    const l = () => {
      if (!O || !u || !ye || !wn.current.has(u) || Xn.current.get(u) === jo) return;
      qe.current && (clearTimeout(qe.current), qe.current = null);
      const p = ua.current;
      ua.current = "auto", Ya(u, ye, p).catch(() => {
      });
    };
    return window.addEventListener("pagehide", l), window.addEventListener("beforeunload", l), () => {
      window.removeEventListener("pagehide", l), window.removeEventListener("beforeunload", l);
    };
  }, [jo, ye, u, O, Ya]), M.useEffect(() => {
    const l = (p) => {
      !(p.metaKey || p.ctrlKey) || p.key.toLowerCase() !== "s" || !u || !ye || !wn.current.has(u) || (p.preventDefault(), qe.current && (clearTimeout(qe.current), qe.current = null), ua.current = "manual", Ya(u, ye, "manual").catch(() => {
        R("手动保存失败");
      }));
    };
    return window.addEventListener("keydown", l), () => window.removeEventListener("keydown", l);
  }, [ye, u, Ya]);
  const st = (l, p) => Ut((x) => ({ ...x, [l]: p })), _l = (l, p, x, w) => Ut((N) => {
    const H = N[l];
    return {
      ...N,
      [l]: { ...H, [p]: { ...H[p] || {}, [x]: w } }
    };
  }), Ti = (l) => {
    l && al.current?.targetId === l && ht(null);
  }, fs = () => {
    Ot("free"), xn(null), Ut(ba()), Ti(u);
  }, ko = (l) => {
    u && (ua.current = "restore", Ut(l.adjustments), Ti(u), ct("已恢复历史版本"));
  }, $l = (l) => {
    const p = [], x = (N, H = 0) => (N > 0 ? "+" : "") + N.toFixed(H);
    Math.abs(l.exposure) >= 0.05 && p.push("曝光 " + x(l.exposure, 2)), Math.abs(l.contrast) >= 1 && p.push("对比 " + x(l.contrast)), Math.abs(l.temperature) >= 1 && p.push("色温 " + x(l.temperature)), Math.abs(l.saturation) >= 1 && p.push("饱和 " + x(l.saturation)), l.masks.length && p.push("蒙版 " + l.masks.length), l.warps.length && p.push("液化 " + l.warps.length), l.spots.length && p.push("擦除 " + l.spots.length);
    const w = l.geometry;
    return (w.quarterTurns || w.flipH || w.flipV || Math.abs(w.straighten) > 0.01) && p.push("几何变换"), (w.crop.width < 0.999 || w.crop.height < 0.999) && p.push("已裁剪"), p.length ? p.join(" · ") : "无调整";
  }, Ci = M.useCallback(() => {
    !u || !ye || !wn.current.has(u) || (qe.current && (clearTimeout(qe.current), qe.current = null), ua.current = "manual", Ya(u, ye, "manual").then((l) => {
      const p = l?.history?.[0];
      ct(
        p && JSON.stringify(p.adjustments) === JSON.stringify(ye) ? "已保存当前调整（与最新版本一致）" : "已保存当前调整为新版本"
      );
    }).catch(() => R("手动保存失败")));
  }, [ye, u, Ya, ct]);
  M.useEffect(() => {
    if (!Lt) return;
    const l = (x) => {
      const w = q.current;
      w && x.target instanceof Node && w.contains(x.target) || Et(!1);
    }, p = (x) => {
      x.key === "Escape" && (x.stopPropagation(), Et(!1));
    };
    return window.addEventListener("pointerdown", l, !0), window.addEventListener("keydown", p, !0), () => {
      window.removeEventListener("pointerdown", l, !0), window.removeEventListener("keydown", p, !0);
    };
  }, [Lt]);
  const tr = () => {
    K((l) => {
      const p = !l;
      try {
        window.localStorage.setItem("orcabox.photo-adjust.autosave", String(p));
      } catch {
      }
      return R(p ? "自动保存已开启" : "自动保存已关闭"), p;
    });
  }, ds = () => {
    Ti(u), Ut((l) => ({
      ...l,
      temperature: 0,
      tint: 0,
      exposure: 0,
      contrast: 0,
      highlights: 0,
      shadows: 0,
      whites: 0,
      blacks: 0,
      texture: 0,
      clarity: 0,
      dehaze: 0,
      vibrance: 0,
      saturation: 0
    }));
  }, no = (l, p) => {
    const x = Ee.current, w = Ma.current;
    if (!x || !w) return !1;
    const N = w.getBoundingClientRect();
    if (!N.width || !N.height || l < N.left || l > N.right || p < N.top || p > N.bottom)
      return !1;
    const H = Math.round((l - N.left) / N.width * (x.width - 1)), ot = Math.round((p - N.top) / N.height * (x.height - 1)), P = Math.max(2, Math.min(8, Math.round(Math.min(x.width, x.height) * 0.012))), at = new Uint8ClampedArray((P * 2 + 1) ** 2 * 4);
    let zt = 0;
    for (let ee = ot - P; ee <= ot + P; ee += 1)
      for (let Zt = H - P; Zt <= H + P; Zt += 1) {
        const Pt = Math.max(0, Math.min(x.width - 1, Zt)), Ca = (Math.max(0, Math.min(x.height - 1, ee)) * x.width + Pt) * 4;
        at[zt++] = x.data[Ca], at[zt++] = x.data[Ca + 1], at[zt++] = x.data[Ca + 2], at[zt++] = x.data[Ca + 3];
      }
    const Bt = ep(at, P * 2 + 1, P * 2 + 1);
    return Ut((ee) => ({
      ...ee,
      temperature: Math.round(Bt.temperature),
      tint: Math.round(Bt.tint)
    })), Fa(!1), ct("已应用白平衡取样，可继续微调"), !0;
  }, Bo = () => {
    const l = Ee.current;
    if (!l) return;
    const p = v1(l.data, l.width, l.height), { temperature: x, tint: w } = ep(l.data, l.width, l.height);
    Ut((N) => ({
      ...N,
      exposure: Number(p.toFixed(2)),
      temperature: Math.round(x),
      tint: Math.round(w),
      contrast: 8,
      highlights: -12,
      shadows: 8,
      whites: -5,
      vibrance: 12
    })), ct("已应用自动调整，可继续微调");
  }, He = (l, p) => Ut((x) => ({
    ...x,
    calibration: { ...x.calibration, [l]: p }
  })), ps = () => Ut((l) => ({
    ...l,
    calibration: ba().calibration
  })), oo = () => Ut((l) => ({ ...l, hsl: ba().hsl })), gs = () => Ut((l) => ({
    ...l,
    grading: ba().grading
  })), ms = () => Ut((l) => ({
    ...l,
    sharpening: 0,
    sharpenRadius: 1,
    sharpenDetail: 25,
    sharpenMasking: 0,
    noiseReduction: 0,
    noiseDetail: 50,
    colorNoiseReduction: 0
  })), bs = () => Ut((l) => ({
    ...l,
    vignette: 0,
    vignetteMidpoint: 50,
    vignetteFeather: 50,
    vignetteRoundness: 50,
    vignetteHighlights: 0,
    grain: 0,
    grainSize: 1,
    grainRoughness: 50
  })), Xc = () => Ut((l) => ({
    ...l,
    curves: ba().curves
  })), jn = (l) => Ut((p) => ({ ...p, geometry: { ...p.geometry, ...l } })), xs = (l) => jn({ crop: l }), er = () => {
    Qe.current = null, wa.current && (clearTimeout(wa.current), wa.current = null), u && ft((l) => ({ ...l, [u]: { zoom: 1, x: 0, y: 0 } }));
  }, ys = () => {
    Ot("free"), jn(ba().geometry);
  }, io = M.useMemo(() => xt.current?.aspect ?? null, [bt]), pa = M.useMemo(() => xt.current?.output ?? null, [bt]), sl = M.useMemo(() => {
    if (dt === "free") return null;
    if (dt === "original") return io;
    const [l, p] = dt.split(":").map(Number);
    return l && p ? l / p : null;
  }, [dt, io]), ga = M.useMemo(() => sl === null || !io ? null : sl / io, [sl, io]), Ra = (l) => {
    if (Ot(l), l === "free") return;
    const x = Ob(l === "original" ? 1 : ga);
    x && xs(x);
  }, lo = async () => {
    const l = await Ye.system.pickFiles({
      title: "导入照片",
      filters: [
        {
          name: "图片",
          extensions: ["jpg", "jpeg", "png", "webp", "tif", "tiff", "heic", "heif", "avif"]
        }
      ]
    });
    if (!l.length) return;
    const p = ++j.current;
    L.current && clearTimeout(L.current), k({ stage: "importing", done: 0, total: l.length });
    try {
      const x = await Ye.system.importLocalFiles(l, {
        defaultLibraryImport: "pinterest",
        relativePath: "照片调色",
        referenceExisting: !0
      });
      if (j.current !== p) return;
      const w = x.importedAssetIds ?? [];
      if (w.length) {
        await un(w, p);
        const N = x.error ? "；部分文件导入失败：" + x.error : "";
        ct("已导入 " + w.length + " 张图片" + N);
      } else
        k(null), ct(x.error || "导入失败");
    } catch (x) {
      if (j.current !== p) return;
      k(null), ct(x instanceof Error ? x.message : "导入失败");
    }
  }, ar = async (l) => {
    l.preventDefault();
    const p = ub(l.dataTransfer), x = window.electronAPI, w = p.length ? [] : db(l.dataTransfer, x?.getPathForFile);
    if (!p.length && !w.length) return;
    const N = ++j.current;
    L.current && clearTimeout(L.current), w.length && k({ stage: "matching", done: 0, total: w.length });
    let H = p, ot = w, P = null;
    if (!p.length && w.length) {
      const at = await pb(
        w,
        (zt) => Ye.asset.list(zt),
        /windows/i.test(navigator.userAgent)
      );
      if (j.current !== N) return;
      H = at.assetIds, ot = at.unresolvedFiles, k({ stage: "matching", done: w.length, total: w.length });
    }
    if (!p.length && ot.length > 0) {
      k({ stage: "importing", done: 0, total: ot.length });
      try {
        const at = await Ye.system.importLocalFiles(
          ot.map((zt) => zt.filePath),
          {
            defaultLibraryImport: "pinterest",
            relativePath: "照片调色",
            referenceExisting: !0
          }
        );
        if (j.current !== N) return;
        if (at.importedAssetIds?.length)
          H = [.../* @__PURE__ */ new Set([...H, ...at.importedAssetIds])];
        else if (H.length)
          at.error && (P = at.error);
        else {
          k(null), ct(at.error || "导入失败");
          return;
        }
      } catch (at) {
        if (j.current !== N) return;
        if (!H.length) {
          k(null), ct(at instanceof Error ? at.message : "导入失败");
          return;
        }
        P = at instanceof Error ? at.message : "导入失败";
      }
    }
    if (j.current === N) {
      if (!H.length) {
        k(null), ct("请拖入素材库中的图片");
        return;
      }
      await un(H, N), j.current === N && ct(
        "已加入 " + H.length + " 张图片" + (P ? "；部分照片导入失败：" + P : "")
      );
    }
  }, cl = async () => {
    if (!(!wt || an)) {
      Ha(!0);
      try {
        await Ya(wt.id, _, "manual");
        const l = await Ye.preview.applyImageEdits({
          assetId: wt.id,
          recipe: { photoAdjustments: _ },
          saveMode: "copy"
        });
        l.success ? ct("调色副本已保存到素材库") : String(l.error ?? "").includes("photo_adjust_license_locked") ? (await Ia(), Mn(!0), ct("试用已结束，请先激活插件")) : ct(l.error || "导出失败");
      } catch (l) {
        ct(l instanceof Error ? l.message : "调色数据保存失败");
      } finally {
        Ha(!1);
      }
    }
  }, ul = /* @__PURE__ */ s.jsxs(s.Fragment, { children: [
    /* @__PURE__ */ s.jsxs(Ba, { title: "光效", icon: /* @__PURE__ */ s.jsx(tp, { size: 15 }), onReset: ds, children: [
      /* @__PURE__ */ s.jsxs("div", { className: "photo-wb-row", children: [
        /* @__PURE__ */ s.jsx("div", { className: "photo-inspector-subheading", children: "白平衡" }),
        /* @__PURE__ */ s.jsxs("div", { className: "photo-wb-actions", children: [
          /* @__PURE__ */ s.jsxs("div", { className: "photo-wb-tool-group", children: [
            /* @__PURE__ */ s.jsx("button", { type: "button", className: "photo-auto-button", onClick: Bo, children: "自动" }),
            /* @__PURE__ */ s.jsx(
              "button",
              {
                type: "button",
                className: "photo-auto-button photo-picker-button" + (na ? " active" : ""),
                "aria-pressed": na,
                title: "在照片上点击中性灰或白色区域取样",
                onClick: () => Fa((l) => !l),
                children: "取样"
              }
            )
          ] }),
          /* @__PURE__ */ s.jsxs(
            "select",
            {
              className: "photo-wb-select",
              "aria-label": "白平衡预设",
              value: qh.find(
                (l) => l.temperature === _.temperature && l.tint === _.tint
              )?.id ?? "custom",
              onChange: (l) => {
                const p = qh.find((x) => x.id === l.target.value);
                p && (st("temperature", p.temperature), st("tint", p.tint));
              },
              children: [
                /* @__PURE__ */ s.jsx("option", { value: "custom", disabled: !0, children: "自定义" }),
                qh.map((l) => /* @__PURE__ */ s.jsx("option", { value: l.id, children: l.label }, l.id))
              ]
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ s.jsx(
        ut,
        {
          label: "色温",
          track: ze.temperature,
          value: _.temperature,
          onChange: (l) => st("temperature", l),
          reset: () => st("temperature", 0)
        }
      ),
      /* @__PURE__ */ s.jsx(
        ut,
        {
          label: "色调",
          track: ze.tint,
          value: _.tint,
          onChange: (l) => st("tint", l),
          reset: () => st("tint", 0)
        }
      ),
      /* @__PURE__ */ s.jsx("div", { className: "photo-inspector-subheading", children: "选项" }),
      /* @__PURE__ */ s.jsx(
        ut,
        {
          label: "曝光",
          track: ze.exposure,
          value: _.exposure,
          min: -5,
          max: 5,
          step: 0.05,
          onChange: (l) => st("exposure", l),
          reset: () => st("exposure", 0)
        }
      ),
      /* @__PURE__ */ s.jsx(
        ut,
        {
          label: "对比度",
          track: ze.contrast,
          value: _.contrast,
          step: 0.5,
          onChange: (l) => st("contrast", l),
          reset: () => st("contrast", 0)
        }
      ),
      /* @__PURE__ */ s.jsx(
        ut,
        {
          label: "高光",
          track: ze.highlights,
          value: _.highlights,
          step: 0.5,
          onChange: (l) => st("highlights", l),
          reset: () => st("highlights", 0)
        }
      ),
      /* @__PURE__ */ s.jsx(
        ut,
        {
          label: "阴影",
          track: ze.shadows,
          value: _.shadows,
          step: 0.5,
          onChange: (l) => st("shadows", l),
          reset: () => st("shadows", 0)
        }
      ),
      /* @__PURE__ */ s.jsx(
        ut,
        {
          label: "白色色阶",
          track: ze.whites,
          value: _.whites,
          step: 0.5,
          onChange: (l) => st("whites", l),
          reset: () => st("whites", 0)
        }
      ),
      /* @__PURE__ */ s.jsx(
        ut,
        {
          label: "黑色色阶",
          track: ze.blacks,
          value: _.blacks,
          step: 0.5,
          onChange: (l) => st("blacks", l),
          reset: () => st("blacks", 0)
        }
      ),
      /* @__PURE__ */ s.jsx("div", { className: "photo-inspector-subheading", children: "效果增强" }),
      /* @__PURE__ */ s.jsx(
        ut,
        {
          label: "纹理",
          track: ze.texture,
          value: _.texture,
          onChange: (l) => st("texture", l),
          reset: () => st("texture", 0)
        }
      ),
      /* @__PURE__ */ s.jsx(
        ut,
        {
          label: "清晰度",
          track: ze.clarity,
          value: _.clarity,
          onChange: (l) => st("clarity", l),
          reset: () => st("clarity", 0)
        }
      ),
      /* @__PURE__ */ s.jsx(
        ut,
        {
          label: "去薄雾",
          track: ze.dehaze,
          value: _.dehaze,
          onChange: (l) => st("dehaze", l),
          reset: () => st("dehaze", 0)
        }
      )
    ] }),
    /* @__PURE__ */ s.jsxs(
      Ba,
      {
        title: "颜色",
        icon: /* @__PURE__ */ s.jsx("span", { className: "photo-color-icon" }),
        onReset: () => Ut((l) => ({ ...l, vibrance: 0, saturation: 0 })),
        children: [
          /* @__PURE__ */ s.jsx(
            ut,
            {
              label: "自然饱和度",
              track: ze.vibrance,
              value: _.vibrance,
              onChange: (l) => st("vibrance", l),
              reset: () => st("vibrance", 0)
            }
          ),
          /* @__PURE__ */ s.jsx(
            ut,
            {
              label: "饱和度",
              track: ze.saturation,
              value: _.saturation,
              onChange: (l) => st("saturation", l),
              reset: () => st("saturation", 0)
            }
          )
        ]
      }
    )
  ] }), nr = /* @__PURE__ */ s.jsxs(
    Ba,
    {
      title: "颜色混合器",
      icon: /* @__PURE__ */ s.jsx("span", { className: "photo-color-icon" }),
      onReset: oo,
      children: [
        /* @__PURE__ */ s.jsx("div", { className: "photo-segmented", role: "tablist", "aria-label": "混色器维度", children: xp.map((l) => /* @__PURE__ */ s.jsx(
          "button",
          {
            type: "button",
            role: "tab",
            "aria-selected": Ht === l.id,
            className: Ht === l.id ? "active" : "",
            onClick: () => ue(l.id),
            children: l.label
          },
          l.id
        )) }),
        Ht === "all" ? ["hue", "saturation", "luminance"].map((l) => /* @__PURE__ */ s.jsxs("div", { className: "photo-hsl-component", children: [
          /* @__PURE__ */ s.jsx("div", { className: "photo-inspector-subheading", children: xp.find((p) => p.id === l)?.label }),
          dp.map((p) => /* @__PURE__ */ s.jsx(
            yp,
            {
              color: p,
              field: l,
              value: _.hsl[p.id][l],
              onChange: (x) => _l("hsl", p.id, l, x)
            },
            p.id
          ))
        ] }, l)) : dp.map((l) => /* @__PURE__ */ s.jsx(
          yp,
          {
            color: l,
            field: Ht,
            value: _.hsl[l.id][Ht],
            onChange: (p) => _l("hsl", l.id, Ht, p)
          },
          l.id
        ))
      ]
    }
  ), Vo = /* @__PURE__ */ s.jsxs(
    Ba,
    {
      title: "三向色轮",
      icon: /* @__PURE__ */ s.jsx("span", { className: "photo-wheel-icon" }),
      onReset: gs,
      children: [
        /* @__PURE__ */ s.jsx("p", { className: "photo-section-caption", children: "拖动色轮选择色相与饱和度，滑杆控制明亮度。" }),
        /* @__PURE__ */ s.jsx("div", { className: "photo-wheel-grid", children: [
          ["shadows", "阴影", "暗部"],
          ["midtones", "中间调", "中间"],
          ["highlights", "高光", "亮部"]
        ].map(([l, p, x]) => /* @__PURE__ */ s.jsx(
          $b,
          {
            title: p,
            subtitle: x,
            position: l === "midtones" ? "top" : l === "shadows" ? "left" : "right",
            value: _.grading[l],
            onReset: () => Ut((w) => ({
              ...w,
              grading: { ...w.grading, [l]: { hue: 0, saturation: 0, luminance: 0 } }
            })),
            onChange: (w) => Ut((N) => ({
              ...N,
              grading: {
                ...N.grading,
                [l]: { ...N.grading[l], ...w }
              }
            }))
          },
          l
        )) }),
        /* @__PURE__ */ s.jsxs("div", { className: "photo-wheel-global", children: [
          /* @__PURE__ */ s.jsx(
            ut,
            {
              label: "混合",
              value: _.grading.blending,
              min: 0,
              max: 100,
              onChange: (l) => Ut((p) => ({
                ...p,
                grading: { ...p.grading, blending: l }
              })),
              reset: () => Ut((l) => ({
                ...l,
                grading: { ...l.grading, blending: 50 }
              }))
            }
          ),
          /* @__PURE__ */ s.jsx(
            ut,
            {
              label: "平衡",
              value: _.grading.balance,
              onChange: (l) => Ut((p) => ({
                ...p,
                grading: { ...p.grading, balance: l }
              })),
              reset: () => Ut((l) => ({
                ...l,
                grading: { ...l.grading, balance: 0 }
              }))
            }
          )
        ] })
      ]
    }
  ), As = /* @__PURE__ */ s.jsxs(Ba, { title: "曲线", icon: /* @__PURE__ */ s.jsx(Eb, {}), onReset: Xc, children: [
    /* @__PURE__ */ s.jsx("p", { className: "photo-section-caption", children: "点选通道圆点后编辑曲线，背景为对应通道的直方图。" }),
    /* @__PURE__ */ s.jsx(
      zb,
      {
        curves: _.curves,
        histogramData: Jn,
        onChange: (l, p) => Ut((x) => ({
          ...x,
          curves: { ...x.curves, [l]: p }
        }))
      }
    )
  ] }), hl = /* @__PURE__ */ s.jsxs(
    Ba,
    {
      title: "细节",
      icon: /* @__PURE__ */ s.jsx("span", { className: "photo-detail-icon" }),
      onReset: ms,
      children: [
        /* @__PURE__ */ s.jsx("div", { className: "photo-inspector-subheading", children: "锐化" }),
        /* @__PURE__ */ s.jsx(
          ut,
          {
            label: "数量",
            value: _.sharpening,
            min: 0,
            max: 100,
            onChange: (l) => st("sharpening", l),
            reset: () => st("sharpening", 0)
          }
        ),
        /* @__PURE__ */ s.jsx(
          ut,
          {
            label: "半径",
            sub: !0,
            value: _.sharpenRadius,
            min: 0.5,
            max: 3,
            step: 0.5,
            onChange: (l) => st("sharpenRadius", l),
            reset: () => st("sharpenRadius", 1)
          }
        ),
        /* @__PURE__ */ s.jsx(
          ut,
          {
            label: "细节",
            sub: !0,
            value: _.sharpenDetail,
            min: 0,
            max: 100,
            onChange: (l) => st("sharpenDetail", l),
            reset: () => st("sharpenDetail", 25)
          }
        ),
        /* @__PURE__ */ s.jsx(
          ut,
          {
            label: "蒙版",
            sub: !0,
            value: _.sharpenMasking,
            min: 0,
            max: 100,
            onChange: (l) => st("sharpenMasking", l),
            reset: () => st("sharpenMasking", 0)
          }
        ),
        /* @__PURE__ */ s.jsx("div", { className: "photo-inspector-subheading", children: "降噪" }),
        /* @__PURE__ */ s.jsx(
          ut,
          {
            label: "明度",
            value: _.noiseReduction,
            min: 0,
            max: 100,
            onChange: (l) => st("noiseReduction", l),
            reset: () => st("noiseReduction", 0)
          }
        ),
        /* @__PURE__ */ s.jsx(
          ut,
          {
            label: "细节",
            sub: !0,
            value: _.noiseDetail,
            min: 0,
            max: 100,
            onChange: (l) => st("noiseDetail", l),
            reset: () => st("noiseDetail", 50)
          }
        ),
        /* @__PURE__ */ s.jsx(
          ut,
          {
            label: "颜色",
            value: _.colorNoiseReduction,
            min: 0,
            max: 100,
            onChange: (l) => st("colorNoiseReduction", l),
            reset: () => st("colorNoiseReduction", 0)
          }
        )
      ]
    }
  ), Do = /* @__PURE__ */ s.jsxs(
    Ba,
    {
      title: "效果",
      icon: /* @__PURE__ */ s.jsx("span", { className: "photo-effects-icon" }),
      onReset: bs,
      children: [
        /* @__PURE__ */ s.jsx("div", { className: "photo-inspector-subheading", children: "天空替换" }),
        /* @__PURE__ */ s.jsxs("div", { className: "photo-sky-row", children: [
          /* @__PURE__ */ s.jsx(
            "button",
            {
              type: "button",
              className: _.skyReplacement.enabled ? "photo-sky-toggle on" : "photo-sky-toggle",
              "aria-pressed": _.skyReplacement.enabled,
              onClick: () => st("skyReplacement", {
                ..._.skyReplacement,
                enabled: !_.skyReplacement.enabled
              }),
              children: _.skyReplacement.enabled ? "开" : "关"
            }
          ),
          /* @__PURE__ */ s.jsxs(
            "select",
            {
              className: "photo-sky-select",
              "aria-label": "天空预设",
              value: _.skyReplacement.preset,
              onChange: (l) => st("skyReplacement", {
                ..._.skyReplacement,
                preset: l.target.value
              }),
              children: [
                /* @__PURE__ */ s.jsx("option", { value: "dawn", children: "黎明" }),
                /* @__PURE__ */ s.jsx("option", { value: "blue", children: "蓝天" }),
                /* @__PURE__ */ s.jsx("option", { value: "sunset", children: "晚霞" }),
                /* @__PURE__ */ s.jsx("option", { value: "night", children: "夜空" })
              ]
            }
          ),
          !ls && /* @__PURE__ */ s.jsx("span", { className: "photo-sky-hint", children: "需先在蒙版面板生成 AI 天空蒙版" })
        ] }),
        ls && /* @__PURE__ */ s.jsxs(s.Fragment, { children: [
          /* @__PURE__ */ s.jsx(
            ut,
            {
              label: "替换强度",
              sub: !0,
              value: _.skyReplacement.strength,
              min: 0,
              max: 100,
              onChange: (l) => st("skyReplacement", { ..._.skyReplacement, strength: l }),
              reset: () => st("skyReplacement", { ..._.skyReplacement, strength: 85 })
            }
          ),
          /* @__PURE__ */ s.jsx(
            ut,
            {
              label: "云层细节",
              sub: !0,
              value: _.skyReplacement.texture,
              min: 0,
              max: 100,
              onChange: (l) => st("skyReplacement", { ..._.skyReplacement, texture: l }),
              reset: () => st("skyReplacement", { ..._.skyReplacement, texture: 30 })
            }
          )
        ] }),
        /* @__PURE__ */ s.jsx(
          ut,
          {
            label: "暗角",
            value: _.vignette,
            onChange: (l) => st("vignette", l),
            reset: () => st("vignette", 0)
          }
        ),
        /* @__PURE__ */ s.jsx(
          ut,
          {
            label: "中点",
            sub: !0,
            value: _.vignetteMidpoint,
            min: 0,
            max: 100,
            onChange: (l) => st("vignetteMidpoint", l),
            reset: () => st("vignetteMidpoint", 50)
          }
        ),
        /* @__PURE__ */ s.jsx(
          ut,
          {
            label: "羽化",
            sub: !0,
            value: _.vignetteFeather,
            min: 0,
            max: 100,
            onChange: (l) => st("vignetteFeather", l),
            reset: () => st("vignetteFeather", 50)
          }
        ),
        /* @__PURE__ */ s.jsx(
          ut,
          {
            label: "圆度",
            sub: !0,
            value: _.vignetteRoundness,
            min: 0,
            max: 100,
            onChange: (l) => st("vignetteRoundness", l),
            reset: () => st("vignetteRoundness", 50)
          }
        ),
        /* @__PURE__ */ s.jsx(
          ut,
          {
            label: "高光",
            sub: !0,
            value: _.vignetteHighlights,
            min: 0,
            max: 100,
            onChange: (l) => st("vignetteHighlights", l),
            reset: () => st("vignetteHighlights", 0)
          }
        ),
        /* @__PURE__ */ s.jsx(
          ut,
          {
            label: "颗粒",
            value: _.grain,
            min: 0,
            max: 100,
            onChange: (l) => st("grain", l),
            reset: () => st("grain", 0)
          }
        ),
        /* @__PURE__ */ s.jsx(
          ut,
          {
            label: "大小",
            sub: !0,
            value: _.grainSize,
            min: 1,
            max: 3,
            step: 1,
            onChange: (l) => st("grainSize", l),
            reset: () => st("grainSize", 1)
          }
        ),
        /* @__PURE__ */ s.jsx(
          ut,
          {
            label: "粗糙度",
            sub: !0,
            value: _.grainRoughness,
            min: 0,
            max: 100,
            onChange: (l) => st("grainRoughness", l),
            reset: () => st("grainRoughness", 50)
          }
        ),
        /* @__PURE__ */ s.jsxs("div", { className: "photo-preserve-note", children: [
          /* @__PURE__ */ s.jsx(G0, { size: 13 }),
          /* @__PURE__ */ s.jsx("span", { children: "保存会生成新的调色副本，原始照片不会被覆盖。" })
        ] })
      ]
    }
  ), Jc = /* @__PURE__ */ s.jsxs(
    Ba,
    {
      title: "裁剪与旋转",
      icon: /* @__PURE__ */ s.jsx("span", { className: "photo-crop-icon" }),
      onReset: ys,
      children: [
        /* @__PURE__ */ s.jsx("p", { className: "photo-section-caption", children: "在画面上拖动裁剪框调整构图；选中比例后拖动会锁定比例。" }),
        pa && /* @__PURE__ */ s.jsxs("p", { className: "photo-crop-readout", children: [
          "裁剪输出 ",
          pa.width,
          " × ",
          pa.height,
          " px"
        ] }),
        /* @__PURE__ */ s.jsx("div", { className: "photo-inspector-subheading", children: "比例" }),
        /* @__PURE__ */ s.jsx("div", { className: "photo-ratio-grid", children: [
          ["free", "自由"],
          ["original", "原始"],
          ["1:1", "1:1"],
          ["4:5", "4:5"],
          ["5:4", "5:4"],
          ["3:2", "3:2"],
          ["2:3", "2:3"],
          ["4:3", "4:3"],
          ["3:4", "3:4"],
          ["16:9", "16:9"],
          ["9:16", "9:16"]
        ].map(([l, p]) => /* @__PURE__ */ s.jsx(
          "button",
          {
            type: "button",
            className: "photo-ratio-chip" + (dt === l ? " active" : ""),
            onClick: () => Ra(l),
            children: p
          },
          l
        )) }),
        /* @__PURE__ */ s.jsx("div", { className: "photo-inspector-subheading", children: "旋转与翻转" }),
        /* @__PURE__ */ s.jsxs("div", { className: "photo-geometry-buttons", children: [
          /* @__PURE__ */ s.jsxs(
            "button",
            {
              type: "button",
              onClick: () => jn({ quarterTurns: (Math.round(Be.quarterTurns) + 3) % 4 }),
              children: [
                /* @__PURE__ */ s.jsx(Qc, { size: 13 }),
                "向左 90°"
              ]
            }
          ),
          /* @__PURE__ */ s.jsxs(
            "button",
            {
              type: "button",
              onClick: () => jn({ quarterTurns: (Math.round(Be.quarterTurns) + 1) % 4 }),
              children: [
                /* @__PURE__ */ s.jsx(Gm, { size: 13 }),
                "向右 90°"
              ]
            }
          ),
          /* @__PURE__ */ s.jsxs(
            "button",
            {
              type: "button",
              className: Be.flipH ? "active" : "",
              onClick: () => jn({ flipH: !Be.flipH }),
              children: [
                /* @__PURE__ */ s.jsx(Um, { size: 13 }),
                "水平翻转"
              ]
            }
          ),
          /* @__PURE__ */ s.jsxs(
            "button",
            {
              type: "button",
              className: Be.flipV ? "active" : "",
              onClick: () => jn({ flipV: !Be.flipV }),
              children: [
                /* @__PURE__ */ s.jsx(km, { size: 13 }),
                "垂直翻转"
              ]
            }
          )
        ] }),
        /* @__PURE__ */ s.jsx("div", { className: "photo-inspector-subheading", children: "矫直" }),
        /* @__PURE__ */ s.jsx(
          ut,
          {
            label: "角度",
            value: Be.straighten,
            min: -15,
            max: 15,
            step: 0.1,
            onChange: (l) => jn({ straighten: l }),
            reset: () => jn({ straighten: 0 })
          }
        )
      ]
    }
  ), ma = M.useCallback(
    (l, p) => {
      const x = Ee.current;
      let w = { meanLuma: 128, clipLow: 0, clipHigh: 0 };
      if (x) {
        const H = x.assetId + ":" + x.width + "x" + x.height;
        if (To.current?.key !== H) {
          const ot = Yc(
            Zh(x.data, x.width, x.height)
          );
          To.current = {
            key: H,
            stats: {
              meanLuma: ot.meanLuma,
              clipLow: ot.clipLow,
              clipHigh: ot.clipHigh
            }
          };
        }
        w = To.current.stats;
      }
      const N = F1(
        l.patch,
        p,
        w,
        ol.current
      );
      Ut(() => N), Ot("free"), xn({ id: l.id, signature: Vh(N) }), ct(
        p >= 100 ? "已应用预设 · " + l.label : "已应用预设 · " + l.label + "（强度 " + p + "%）"
      );
    },
    [ct, Ut]
  ), or = M.useCallback(
    (l) => {
      const p = G1(l.adjustments, ol.current);
      Ut(() => p), xn({ id: l.id, signature: Vh(p) }), ct("已应用预设 · " + l.name);
    },
    [ct, Ut]
  ), Pa = M.useCallback(() => {
    const l = nn.trim();
    if (!l) return;
    const p = ol.current;
    if (!p) return;
    let x = "";
    try {
      const H = Ma.current;
      if (H && H.width > 2) {
        const ot = document.createElement("canvas"), P = Math.min(1, 240 / Math.max(H.width, H.height));
        ot.width = Math.max(1, Math.round(H.width * P)), ot.height = Math.max(1, Math.round(H.height * P));
        const at = ot.getContext("2d");
        at && (at.drawImage(H, 0, 0, ot.width, ot.height), x = ot.toDataURL("image/jpeg", 0.7));
      }
    } catch {
      x = "";
    }
    const N = [{
      id: "my-" + Date.now().toString(36),
      name: l,
      adjustments: JSON.parse(JSON.stringify(p)),
      thumb: x,
      createdAt: Date.now()
    }, ...aa].slice(0, 24);
    On(N), op(N), vo(""), bn("mine"), ct("已保存预设 · " + l);
  }, [aa, nn, ct]), vs = M.useCallback(
    (l) => {
      const p = aa.filter((x) => x.id !== l);
      On(p), op(p);
    },
    [aa]
  ), fl = M.useMemo(() => Oe === "hot" ? K1.map((l) => wc.find((p) => p.id === l)).filter(
    (l) => !!l
  ) : Oe === "all" ? wc : wc.filter((l) => l.category === Oe), [Oe]), ro = M.useMemo(
    () => ye ? Vh(ye) : "",
    [ye]
  ), dl = (l) => !ea || ea.id !== l ? "none" : ro === ea.signature ? "applied" : "modified", ir = Ib("button.active", Oe), Yo = /* @__PURE__ */ s.jsxs(Ba, { title: "预设", icon: /* @__PURE__ */ s.jsx(Nh, { size: 15 }), onReset: fs, children: [
    /* @__PURE__ */ s.jsx("div", { ref: ir, className: "photo-preset-cats", role: "tablist", "aria-label": "预设分类", children: O1.map((l) => /* @__PURE__ */ s.jsxs(
      "button",
      {
        type: "button",
        role: "tab",
        "aria-selected": Oe === l.id,
        className: Oe === l.id ? "active" : "",
        onClick: () => bn(l.id),
        children: [
          l.label,
          l.id === "mine" && aa.length > 0 ? /* @__PURE__ */ s.jsx("em", { className: "photo-preset-cat-count", children: aa.length }) : null
        ]
      },
      l.id
    )) }),
    /* @__PURE__ */ s.jsx("p", { className: "photo-section-caption", children: Oe === "mine" ? "「我的」是存下来的本地预设，点一下套用到当前照片，悬停可以删除。" : "每个分类用各自的参考图预览观感，点击即应用，应用后可继续微调。" }),
    Oe === "mine" ? aa.length ? /* @__PURE__ */ s.jsx("div", { className: "photo-preset-grid", children: aa.map((l) => /* @__PURE__ */ s.jsxs(
      "div",
      {
        className: "photo-preset-card is-mine" + (dl(l.id) === "applied" ? " is-applied" : ""),
        children: [
          /* @__PURE__ */ s.jsxs(
            "button",
            {
              type: "button",
              className: "photo-preset-apply",
              onClick: () => or(l),
              title: l.name,
              children: [
                /* @__PURE__ */ s.jsx("span", { className: "photo-preset-thumb", children: l.thumb ? /* @__PURE__ */ s.jsx("img", { src: l.thumb, alt: "", draggable: !1 }) : /* @__PURE__ */ s.jsx(
                  "i",
                  {
                    className: "photo-preset-thumb-fallback",
                    style: { background: "linear-gradient(135deg,#5d6b78,#aeb9c4)" }
                  }
                ) }),
                /* @__PURE__ */ s.jsx("span", { className: "photo-preset-name", children: l.name })
              ]
            }
          ),
          /* @__PURE__ */ s.jsx(
            "button",
            {
              type: "button",
              className: "photo-preset-delete",
              title: "删除预设",
              "aria-label": "删除预设 " + l.name,
              onClick: () => vs(l.id),
              children: "×"
            }
          )
        ]
      },
      l.id
    )) }) : /* @__PURE__ */ s.jsx("p", { className: "photo-preset-empty", children: "还没有保存的预设。调好一张后在下面输入名字即可保存。" }) : /* @__PURE__ */ s.jsx("div", { className: "photo-preset-grid", children: fl.map((l) => {
      const p = ri[l.id], x = dl(l.id);
      return /* @__PURE__ */ s.jsxs(
        "button",
        {
          type: "button",
          className: "photo-preset-card" + (x === "applied" ? " is-applied" : "") + (x === "modified" ? " is-modified" : ""),
          onClick: () => ma(l, Hi),
          title: l.label,
          children: [
            /* @__PURE__ */ s.jsx("span", { className: "photo-preset-thumb", children: p ? /* @__PURE__ */ s.jsx("img", { src: p, alt: "", draggable: !1 }) : (
              // 参考图解码完成前先用原有渐变占位，避免卡片闪一下空白。
              /* @__PURE__ */ s.jsx(
                "i",
                {
                  className: "photo-preset-thumb-fallback",
                  style: { background: l.gradient }
                }
              )
            ) }),
            /* @__PURE__ */ s.jsx("span", { className: "photo-preset-name", children: l.label })
          ]
        },
        l.id
      );
    }) }),
    /* @__PURE__ */ s.jsxs("div", { className: "photo-preset-strength", children: [
      /* @__PURE__ */ s.jsx(
        ut,
        {
          label: "预设强度",
          value: Hi,
          min: 0,
          max: 100,
          step: 1,
          onChange: Zi,
          reset: () => Zi(100)
        }
      ),
      /* @__PURE__ */ s.jsx("span", { className: "photo-preset-strength-hint", children: "应用时按此比例缩放预设参数" })
    ] }),
    /* @__PURE__ */ s.jsxs("div", { className: "photo-preset-save", children: [
      /* @__PURE__ */ s.jsx(
        "input",
        {
          className: "photo-preset-save-input",
          value: nn,
          placeholder: "保存当前效果为预设…",
          maxLength: 24,
          "aria-label": "保存当前效果为预设",
          onChange: (l) => vo(l.target.value),
          onKeyDown: (l) => {
            l.key === "Enter" ? (l.preventDefault(), Pa()) : l.key === "Escape" && (l.preventDefault(), vo(""));
          }
        }
      ),
      /* @__PURE__ */ s.jsx(
        "button",
        {
          type: "button",
          className: "photo-preset-save-button",
          onClick: Pa,
          disabled: !nn.trim(),
          children: "保存"
        }
      )
    ] })
  ] }), zo = /* @__PURE__ */ s.jsxs(Ba, { title: "校准", icon: /* @__PURE__ */ s.jsx(Rm, { size: 15 }), onReset: ps, children: [
    /* @__PURE__ */ s.jsx("p", { className: "photo-section-caption", children: "在全局色之上微调阴影色调与三原色偏移，模拟相机校准风格。" }),
    /* @__PURE__ */ s.jsx(
      ut,
      {
        label: "阴影",
        track: ze.tint,
        value: _.calibration.shadows,
        onChange: (l) => He("shadows", l),
        reset: () => He("shadows", 0)
      }
    ),
    /* @__PURE__ */ s.jsx("div", { className: "photo-inspector-subheading", children: "红原色" }),
    /* @__PURE__ */ s.jsx(
      ut,
      {
        label: "色相",
        sub: !0,
        track: zc(0),
        value: _.calibration.redHue,
        onChange: (l) => He("redHue", l),
        reset: () => He("redHue", 0)
      }
    ),
    /* @__PURE__ */ s.jsx(
      ut,
      {
        label: "饱和度",
        sub: !0,
        track: qc(0),
        value: _.calibration.redSaturation,
        onChange: (l) => He("redSaturation", l),
        reset: () => He("redSaturation", 0)
      }
    ),
    /* @__PURE__ */ s.jsx("div", { className: "photo-inspector-subheading", children: "绿原色" }),
    /* @__PURE__ */ s.jsx(
      ut,
      {
        label: "色相",
        sub: !0,
        track: zc(120),
        value: _.calibration.greenHue,
        onChange: (l) => He("greenHue", l),
        reset: () => He("greenHue", 0)
      }
    ),
    /* @__PURE__ */ s.jsx(
      ut,
      {
        label: "饱和度",
        sub: !0,
        track: qc(120),
        value: _.calibration.greenSaturation,
        onChange: (l) => He("greenSaturation", l),
        reset: () => He("greenSaturation", 0)
      }
    ),
    /* @__PURE__ */ s.jsx("div", { className: "photo-inspector-subheading", children: "蓝原色" }),
    /* @__PURE__ */ s.jsx(
      ut,
      {
        label: "色相",
        sub: !0,
        track: zc(240),
        value: _.calibration.blueHue,
        onChange: (l) => He("blueHue", l),
        reset: () => He("blueHue", 0)
      }
    ),
    /* @__PURE__ */ s.jsx(
      ut,
      {
        label: "饱和度",
        sub: !0,
        track: qc(240),
        value: _.calibration.blueSaturation,
        onChange: (l) => He("blueSaturation", l),
        reset: () => He("blueSaturation", 0)
      }
    )
  ] }), za = _.spots.find((l) => l.id === vn) || null, kn = (l, p) => Ut((x) => ({
    ...x,
    spots: x.spots.map((w) => w.id === l ? { ...w, ...p } : w)
  })), Sa = (l, p, x = Wi, w = Ll) => {
    if (_.spots.length >= 20) {
      ct("最多支持 20 个污点");
      return;
    }
    const N = "spot-" + Date.now().toString(36), H = Math.max(0.07, x * 2.4), ot = l + H <= 0.98 ? l + H : Math.max(0.02, l - H);
    Ut((P) => ({
      ...P,
      spots: [
        ...P.spots,
        {
          id: N,
          x: l,
          y: p,
          size: x,
          feather: w,
          sourceX: ot,
          sourceY: Math.min(0.98, Math.max(0.02, p))
        }
      ]
    })), fi(N);
  }, Ta = (l) => {
    Ut((p) => ({
      ...p,
      spots: p.spots.filter((x) => x.id !== l)
    })), fi((p) => p === l ? null : p);
  }, so = /* @__PURE__ */ s.jsxs(
    Ba,
    {
      title: "液化塑形",
      icon: /* @__PURE__ */ s.jsx(Uh, { size: 15 }),
      onReset: () => {
        Ut((l) => ({ ...l, warps: [] })), ct("已清除全部液化变形");
      },
      children: [
        /* @__PURE__ */ s.jsx("p", { className: "photo-section-caption", children: "在照片上按住拖动即可推拉像素（分段提交，可叠加）。适合瘦脸、瘦身、微调轮廓。" }),
        /* @__PURE__ */ s.jsx(
          ut,
          {
            label: "笔刷大小",
            value: Math.round(Fi * 100),
            min: 3,
            max: 50,
            step: 1,
            onChange: (l) => Fn(l / 100),
            reset: () => Fn(0.12)
          }
        ),
        /* @__PURE__ */ s.jsx(
          ut,
          {
            label: "推拉强度",
            sub: !0,
            value: gi,
            min: 10,
            max: 100,
            step: 1,
            onChange: Gi,
            reset: () => Gi(60)
          }
        ),
        /* @__PURE__ */ s.jsxs("div", { className: "photo-warp-row", children: [
          /* @__PURE__ */ s.jsx("span", { children: _.warps.length ? "已推拉 " + _.warps.length + " 段" : "尚未推拉" }),
          /* @__PURE__ */ s.jsx(
            "button",
            {
              type: "button",
              disabled: !_.warps.length,
              onClick: () => {
                Ut((l) => ({ ...l, warps: [] })), ct("已清除全部液化变形");
              },
              children: "清除全部"
            }
          )
        ] })
      ]
    }
  ), fn = /* @__PURE__ */ s.jsxs(
    Ba,
    {
      title: "擦除",
      icon: /* @__PURE__ */ s.jsx(mc, { size: 15 }),
      onReset: () => {
        fi(null), Ut((l) => ({ ...l, spots: [] }));
      },
      children: [
        /* @__PURE__ */ s.jsx("p", { className: "photo-section-caption", children: "移动鼠标可预览擦除范围，点击后自动取样修复；滚轮可调整笔刷大小，拖动虚线源点可手动指定取样位置。" }),
        /* @__PURE__ */ s.jsx("div", { className: "photo-erase-brush-title", children: "新建擦除笔刷" }),
        /* @__PURE__ */ s.jsx(
          ut,
          {
            label: "大小",
            sub: !0,
            min: 0.015,
            max: 0.25,
            step: 5e-3,
            value: Wi,
            onChange: di,
            reset: () => di(0.06)
          }
        ),
        /* @__PURE__ */ s.jsx(
          ut,
          {
            label: "羽化",
            sub: !0,
            min: 0,
            max: 100,
            value: Ll,
            onChange: wo,
            reset: () => wo(50)
          }
        ),
        _.spots.length > 0 ? /* @__PURE__ */ s.jsx("div", { className: "photo-mask-chips", children: _.spots.map((l, p) => /* @__PURE__ */ s.jsxs(
          "button",
          {
            type: "button",
            className: l.id === vn ? "active" : "",
            onClick: () => {
              fi(l.id), di(l.size), wo(l.feather);
            },
            children: [
              "污点 ",
              p + 1
            ]
          },
          l.id
        )) }) : /* @__PURE__ */ s.jsxs("div", { className: "photo-coming-soon", children: [
          /* @__PURE__ */ s.jsx(mc, { size: 22 }),
          /* @__PURE__ */ s.jsx("span", { children: "在画面上点击添加污点" })
        ] }),
        za && /* @__PURE__ */ s.jsxs(s.Fragment, { children: [
          /* @__PURE__ */ s.jsx(
            ut,
            {
              label: "大小",
              sub: !0,
              min: 0.015,
              max: 0.25,
              step: 5e-3,
              value: za.size,
              onChange: (l) => kn(za.id, { size: l }),
              reset: () => kn(za.id, { size: 0.06 })
            }
          ),
          /* @__PURE__ */ s.jsx(
            ut,
            {
              label: "羽化",
              sub: !0,
              min: 0,
              max: 100,
              value: za.feather,
              onChange: (l) => kn(za.id, { feather: l }),
              reset: () => kn(za.id, { feather: 50 })
            }
          ),
          /* @__PURE__ */ s.jsx("div", { className: "photo-mask-row", children: /* @__PURE__ */ s.jsx(
            "button",
            {
              type: "button",
              className: "photo-mask-delete",
              onClick: () => Ta(za.id),
              children: "删除污点"
            }
          ) })
        ] })
      ]
    }
  ), G = _.masks.find((l) => l.id === It) || null, Qo = (ke && _.masks.find((l) => l.id === ke) || null) ?? G, pl = G ? _.masks.findIndex((l) => l.id === G.id) : -1, lr = xt.current?.aspect ?? 1.5, Je = () => {
    const l = !rt;
    Mt(l);
    try {
      window.localStorage.setItem("orcabox.photo-adjust.mask-overlay", String(l));
    } catch {
    }
  }, pt = (l, p) => Ut((x) => ({
    ...x,
    masks: x.masks.map((w) => w.id === l ? { ...w, ...p } : w)
  })), Ft = (l) => {
    ve(l), be("mask");
  }, Bn = (l) => {
    if (_.masks.length >= 12) {
      ct("最多支持 12 个蒙版");
      return;
    }
    const p = jc("mask");
    Ut((x) => x.masks.length >= 12 ? x : {
      ...x,
      masks: [
        ...x.masks,
        {
          id: p,
          kind: l,
          x: 0.5,
          y: 0.5,
          // Linear half-length 0.3 keeps both end handles inside a typical frame.
          size: l === "radial" ? 0.38 : 0.3,
          ...l === "radial" ? { sizeX: 0.38, sizeY: 0.38 } : {},
          angle: 0,
          feather: 50,
          invert: !1,
          enabled: !0,
          range: {
            kind: "none",
            hue: 30,
            hueWidth: 30,
            saturation: 15,
            luminance: 50,
            luminanceWidth: 25
          },
          blendMode: "add",
          exposure: 0,
          contrast: 0,
          saturation: 0,
          temperature: 0,
          tint: 0
        }
      ]
    }), Ft(p);
  }, _a = (l) => {
    const p = _.masks.find((N) => N.id === l);
    if (!p) return;
    if (_.masks.length >= 12) {
      ct("最多支持 12 个蒙版");
      return;
    }
    const x = jc("mask"), w = p.semanticMask ? 0 : 0.04;
    Ut((N) => {
      const H = N.masks.findIndex((at) => at.id === l);
      if (H < 0 || N.masks.length >= 12) return N;
      const ot = {
        ...p,
        id: x,
        x: Math.min(1.5, p.x + w),
        y: Math.min(1.5, p.y + w),
        range: p.range ? { ...p.range } : p.range
      }, P = [...N.masks];
      return P.splice(H + 1, 0, ot), { ...N, masks: P };
    }), Ft(x);
  }, rr = (l) => {
    Ut((p) => ({
      ...p,
      masks: p.masks.map(
        (x) => x.id === l ? { ...x, enabled: x.enabled === !1 } : x
      )
    }));
  }, co = [
    {
      id: "teeth",
      label: "牙齿美白",
      y: 0.62,
      size: 0.16,
      rangeKind: "color",
      hue: 42,
      hueWidth: 44,
      saturation: 4,
      deltas: { exposure: 0.25, contrast: 0, saturation: -12, temperature: -16, tint: 0 },
      notice: "已创建牙齿美白蒙版 · 在画面上拖动到牙齿位置"
    },
    {
      id: "eyes",
      label: "亮眼",
      y: 0.45,
      size: 0.1,
      rangeKind: "color",
      hue: 40,
      hueWidth: 50,
      saturation: 5,
      deltas: { exposure: 0.3, contrast: 10, saturation: -6, temperature: 0, tint: 0 },
      notice: "已创建亮眼蒙版 · 在画面上拖动到眼睛位置"
    },
    {
      id: "de-shine",
      label: "祛油光",
      y: 0.35,
      size: 0.18,
      rangeKind: "color",
      hue: 40,
      hueWidth: 60,
      saturation: 6,
      deltas: { exposure: -0.1, contrast: -8, saturation: 0, temperature: -6, tint: 0 },
      notice: "已创建祛油光蒙版 · 在画面上拖动到额头/鼻翼"
    },
    {
      id: "blush",
      label: "腮红",
      y: 0.52,
      size: 0.2,
      rangeKind: "none",
      hue: 0,
      hueWidth: 30,
      saturation: 15,
      deltas: { exposure: 0, contrast: 0, saturation: 6, temperature: 4, tint: 10 },
      notice: "已创建腮红蒙版 · 拖动到脸颊并调小范围"
    }
  ], Ms = M.useCallback(
    (l) => {
      const p = jc("mask-fix-" + l.id);
      let x = !1;
      if (Ut((w) => w.masks.length >= 12 ? w : (x = !0, {
        ...w,
        masks: [
          ...w.masks,
          {
            id: p,
            kind: "radial",
            x: 0.5,
            y: l.y,
            size: l.size,
            sizeX: l.size,
            sizeY: l.size,
            angle: 0,
            feather: 65,
            invert: !1,
            enabled: !0,
            range: {
              kind: l.rangeKind,
              hue: l.hue,
              hueWidth: l.hueWidth,
              saturation: l.saturation,
              luminance: 50,
              luminanceWidth: 25
            },
            blendMode: "add",
            exposure: l.deltas.exposure,
            contrast: l.deltas.contrast,
            saturation: l.deltas.saturation,
            temperature: l.deltas.temperature,
            tint: l.deltas.tint
          }
        ]
      })), !x) {
        ct("最多支持 12 个蒙版");
        return;
      }
      ve(p), be("mask"), Mt(!0), ct(l.notice);
    },
    [be, ct, Ut]
  ), sr = (l, p) => {
    const x = jc(`mask-ai-${l}`);
    Ut(
      (w) => w.masks.length >= 12 ? w : {
        ...w,
        masks: [
          ...w.masks,
          {
            id: x,
            kind: "radial",
            x: 0.5,
            y: 0.5,
            size: 0.5,
            sizeX: 0.5,
            sizeY: 0.5,
            angle: 0,
            feather: 20,
            invert: !1,
            enabled: !0,
            range: {
              kind: "none",
              hue: 30,
              hueWidth: 30,
              saturation: 15,
              luminance: 50,
              luminanceWidth: 25
            },
            blendMode: "add",
            semanticMask: p,
            exposure: 0,
            contrast: 0,
            saturation: 0,
            temperature: 0,
            tint: 0
          }
        ]
      }
    ), Ft(x);
  }, Ni = () => {
    const l = eo.current;
    l && (Wl.current.add(l), Ye.preview.cancelSmartCutoutPreview(l), eo.current = null, et(null), ct("已取消 AI 蒙版生成"));
  }, Ui = async (l) => {
    if (!wt || W) return;
    if (_.masks.length >= 12) {
      ct("最多支持 12 张蒙版");
      return;
    }
    const p = wt.id, x = b1(p, l, _.geometry), w = Ei.current.get(x);
    if (w) {
      sr(l, w), ct(
        l === "subject" ? "已复用缓存的 AI 主体蒙版" : l === "sky" ? "已复用缓存的 AI 天空蒙版" : "已复用缓存的 AI 背景蒙版"
      );
      return;
    }
    const N = `photo-mask-${l}-${Date.now()}`;
    et(l), eo.current = N;
    try {
      const H = await Ye.preview.generateSmartCutoutPreview({
        assetId: p,
        sourceImageDataUrl: Ee.current ? Cb(Ee.current) ?? void 0 : void 0,
        operationId: N
      });
      if (Wl.current.delete(N)) {
        ct("已取消 AI 蒙版生成");
        return;
      }
      if (!H.success || !H.maskDataUrl)
        throw new Error(H.error || "AI 蒙版生成失败");
      if (wi.current !== p) return;
      const P = Sb(H.maskDataUrl, l, Ee.current);
      if (!P) throw new Error("AI 蒙版数据无效");
      Ei.current.size >= 24 && Ei.current.delete(Ei.current.keys().next().value), Ei.current.set(x, P), sr(l, P), ct(
        l === "subject" ? "已生成 AI 主体蒙版" : l === "sky" ? "已生成 AI 天空蒙版" : "已生成 AI 背景蒙版"
      );
    } catch (H) {
      const ot = Wl.current.delete(N);
      ct(ot ? "已取消 AI 蒙版生成" : Tb(H instanceof Error ? H.message : "AI 蒙版生成失败"));
    } finally {
      eo.current === N && (eo.current = null, et(null));
    }
  }, ws = (l) => {
    const p = _.masks.findIndex((w) => w.id === l), x = _.masks[p - 1] ?? _.masks[p + 1] ?? null;
    Ut((w) => ({
      ...w,
      masks: w.masks.filter((N) => N.id !== l)
    })), ve((w) => w === l ? x?.id ?? null : w), Ke((w) => w === l ? null : w);
  }, ji = /* @__PURE__ */ s.jsxs(
    Ba,
    {
      title: "人像精修",
      icon: /* @__PURE__ */ s.jsx(bc, { size: 15 }),
      onReset: () => {
        st("skinSmooth", 0), st("skinPreserve", 60);
      },
      children: [
        /* @__PURE__ */ s.jsx("p", { className: "photo-section-caption", children: "肤色识别磨皮：只平滑肤色区域的低频亮度，眼睛、嘴唇、发丝等高细节区域自动避开。" }),
        /* @__PURE__ */ s.jsx(
          ut,
          {
            label: "磨皮",
            value: _.skinSmooth,
            min: 0,
            max: 100,
            step: 1,
            onChange: (l) => st("skinSmooth", l),
            reset: () => st("skinSmooth", 0)
          }
        ),
        /* @__PURE__ */ s.jsx(
          ut,
          {
            label: "细节保留",
            sub: !0,
            value: _.skinPreserve,
            min: 0,
            max: 100,
            step: 1,
            onChange: (l) => st("skinPreserve", l),
            reset: () => st("skinPreserve", 60)
          }
        ),
        /* @__PURE__ */ s.jsx("div", { className: "photo-inspector-subheading", children: "快速局部（智能蒙版预设）" }),
        /* @__PURE__ */ s.jsx("div", { className: "photo-mask-toolbar photo-quick-fixes", children: co.map((l) => /* @__PURE__ */ s.jsxs(
          "button",
          {
            type: "button",
            disabled: !wt,
            title: l.notice,
            onClick: () => Ms(l),
            children: [
              /* @__PURE__ */ s.jsx(bc, { size: 13 }),
              l.label
            ]
          },
          l.id
        )) })
      ]
    }
  ), cr = /* @__PURE__ */ s.jsxs(
    Ba,
    {
      title: "蒙版",
      icon: /* @__PURE__ */ s.jsx(gc, { size: 15 }),
      onReset: () => {
        ve(null), Ut((l) => ({ ...l, masks: [] }));
      },
      children: [
        /* @__PURE__ */ s.jsx("p", { className: "photo-section-caption", children: "画布上拖动中心钉移动蒙版，拖动四边手柄缩放、顶部手柄旋转；红色越浓调整越强，按 O 可隐藏红色选区；点击画面空白处或按 Esc 取消选中、收起编辑框。" }),
        /* @__PURE__ */ s.jsxs("div", { className: "photo-mask-toolbar", children: [
          /* @__PURE__ */ s.jsxs("button", { type: "button", onClick: () => Bn("radial"), children: [
            /* @__PURE__ */ s.jsx(I0, { size: 13 }),
            "径向蒙版"
          ] }),
          /* @__PURE__ */ s.jsxs("button", { type: "button", onClick: () => Bn("linear"), children: [
            /* @__PURE__ */ s.jsx($0, { size: 13 }),
            "线性蒙版"
          ] })
        ] }),
        /* @__PURE__ */ s.jsxs("div", { className: "photo-ai-mask-tools", children: [
          [
            ["subject", "AI 主体"],
            ["sky", "AI 天空"],
            ["background", "AI 背景"]
          ].map(([l, p]) => /* @__PURE__ */ s.jsxs(
            "button",
            {
              type: "button",
              className: "photo-ai-button",
              disabled: !wt || !!W,
              onClick: () => {
                Ui(l);
              },
              children: [
                /* @__PURE__ */ s.jsx(Ch, { size: 12 }),
                W === l ? "分析中…" : p
              ]
            },
            l
          )),
          W && /* @__PURE__ */ s.jsxs("button", { type: "button", className: "photo-ai-button is-cancel", onClick: Ni, children: [
            /* @__PURE__ */ s.jsx(xc, { size: 12 }),
            "取消"
          ] })
        ] }),
        _.masks.length > 0 && /* @__PURE__ */ s.jsxs(s.Fragment, { children: [
          /* @__PURE__ */ s.jsxs("div", { className: "photo-mask-list-head", children: [
            /* @__PURE__ */ s.jsxs("span", { children: [
              "蒙版 · ",
              _.masks.length
            ] }),
            /* @__PURE__ */ s.jsxs(
              "button",
              {
                type: "button",
                className: "photo-mask-overlay-toggle" + (rt ? " active" : ""),
                "aria-pressed": rt,
                onClick: Je,
                title: "切换红色选区覆盖层，方便查看调参后的画面（快捷键 O）",
                children: [
                  rt ? /* @__PURE__ */ s.jsx(P0, { size: 12 }) : /* @__PURE__ */ s.jsx(J0, { size: 12 }),
                  "红色选区",
                  /* @__PURE__ */ s.jsx("kbd", { children: "O" })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ s.jsx(
            "div",
            {
              className: "photo-mask-list",
              role: "listbox",
              "aria-label": "蒙版列表",
              onPointerLeave: () => Ke(null),
              children: _.masks.map((l, p) => {
                const x = l.id === It, w = l.enabled === !1, N = l.blendMode ?? "add";
                return /* @__PURE__ */ s.jsxs(
                  "div",
                  {
                    role: "option",
                    tabIndex: 0,
                    "aria-selected": x,
                    className: "photo-mask-item" + (x ? " is-selected" : "") + (w ? " is-hidden" : ""),
                    onPointerEnter: () => Ke(l.id),
                    onClick: () => Ft(l.id),
                    onKeyDown: (H) => {
                      (H.key === "Enter" || H.key === " ") && (H.preventDefault(), Ft(l.id));
                    },
                    children: [
                      /* @__PURE__ */ s.jsx(Wb, { mask: l, aspect: lr }),
                      hi === l.id ? /* @__PURE__ */ s.jsx(
                        "input",
                        {
                          className: "photo-mask-rename",
                          value: xe,
                          autoFocus: !0,
                          maxLength: 32,
                          "aria-label": "蒙版名称",
                          onChange: (H) => Ql(H.target.value),
                          onClick: (H) => H.stopPropagation(),
                          onKeyDown: (H) => {
                            H.key === "Enter" && (pt(l.id, {
                              name: xe.trim() ? xe.trim() : void 0
                            }), on(null)), H.key === "Escape" && on(null);
                          },
                          onBlur: () => {
                            pt(l.id, {
                              name: xe.trim() ? xe.trim() : void 0
                            }), on(null);
                          }
                        }
                      ) : /* @__PURE__ */ s.jsxs("span", { className: "photo-mask-item-name", children: [
                        l.semanticMask ? /* @__PURE__ */ s.jsx(Ch, { size: 11 }) : l.kind === "radial" ? /* @__PURE__ */ s.jsx(I0, { size: 11 }) : /* @__PURE__ */ s.jsx($0, { size: 11 }),
                        /* @__PURE__ */ s.jsx(
                          "strong",
                          {
                            title: "双击重命名",
                            onDoubleClick: (H) => {
                              H.stopPropagation(), Ql(l.name ?? ""), on(l.id);
                            },
                            children: l.name?.trim() || `${Qp(l)} ${p + 1}`
                          }
                        ),
                        p > 0 && /* @__PURE__ */ s.jsx("em", { title: `与前面的蒙版${ax[N]}`, children: ex[N] }),
                        l.invert && /* @__PURE__ */ s.jsx("em", { title: "已反转", children: "反" })
                      ] }),
                      /* @__PURE__ */ s.jsx(
                        "button",
                        {
                          type: "button",
                          className: "photo-mask-item-eye",
                          "aria-label": w ? "显示此蒙版的调整" : "隐藏此蒙版的调整",
                          "aria-pressed": !w,
                          title: w ? "显示此蒙版的调整" : "隐藏此蒙版的调整（对比效果）",
                          onClick: (H) => {
                            H.stopPropagation(), rr(l.id);
                          },
                          children: w ? /* @__PURE__ */ s.jsx(J0, { size: 12 }) : /* @__PURE__ */ s.jsx(P0, { size: 12 })
                        }
                      )
                    ]
                  },
                  l.id
                );
              })
            }
          )
        ] }),
        G && /* @__PURE__ */ s.jsxs(s.Fragment, { children: [
          /* @__PURE__ */ s.jsxs("div", { className: "photo-mask-actions", children: [
            /* @__PURE__ */ s.jsxs(
              "button",
              {
                type: "button",
                className: G.invert ? "active" : "",
                "aria-pressed": G.invert,
                onClick: () => pt(G.id, { invert: !G.invert }),
                children: [
                  /* @__PURE__ */ s.jsx(Am, { size: 12 }),
                  "反转"
                ]
              }
            ),
            /* @__PURE__ */ s.jsxs(
              "button",
              {
                type: "button",
                disabled: _.masks.length >= 12,
                onClick: () => _a(G.id),
                children: [
                  /* @__PURE__ */ s.jsx(Mm, { size: 12 }),
                  "复制"
                ]
              }
            ),
            /* @__PURE__ */ s.jsxs(
              "button",
              {
                type: "button",
                className: "photo-mask-delete",
                onClick: () => ws(G.id),
                children: [
                  /* @__PURE__ */ s.jsx(o1, { size: 12 }),
                  "删除"
                ]
              }
            )
          ] }),
          /* @__PURE__ */ s.jsxs("div", { className: "photo-mask-range-row", children: [
            /* @__PURE__ */ s.jsxs("label", { children: [
              /* @__PURE__ */ s.jsx("span", { children: "叠加" }),
              /* @__PURE__ */ s.jsxs(
                "select",
                {
                  value: G.blendMode ?? "add",
                  "aria-label": "蒙版组合方式",
                  disabled: pl === 0,
                  title: pl === 0 ? "第一张蒙版是基础选区，无需叠加方式" : "与前面蒙版叠加的方式",
                  onChange: (l) => pt(G.id, {
                    blendMode: l.target.value
                  }),
                  children: [
                    /* @__PURE__ */ s.jsx("option", { value: "add", children: "添加" }),
                    /* @__PURE__ */ s.jsx("option", { value: "subtract", children: "减去" }),
                    /* @__PURE__ */ s.jsx("option", { value: "intersect", children: "相交" })
                  ]
                }
              )
            ] }),
            /* @__PURE__ */ s.jsxs("label", { children: [
              /* @__PURE__ */ s.jsx("span", { children: "范围" }),
              /* @__PURE__ */ s.jsxs(
                "select",
                {
                  value: G.range?.kind ?? "none",
                  "aria-label": "蒙版范围",
                  onChange: (l) => pt(G.id, {
                    range: {
                      kind: l.target.value,
                      hue: G.range?.hue ?? 30,
                      hueWidth: G.range?.hueWidth ?? 30,
                      saturation: G.range?.saturation ?? 15,
                      luminance: G.range?.luminance ?? 50,
                      luminanceWidth: G.range?.luminanceWidth ?? 25
                    }
                  }),
                  children: [
                    /* @__PURE__ */ s.jsx("option", { value: "none", children: "全部像素" }),
                    /* @__PURE__ */ s.jsx("option", { value: "color", children: "颜色范围" }),
                    /* @__PURE__ */ s.jsx("option", { value: "luminance", children: "明度范围" })
                  ]
                }
              )
            ] })
          ] }),
          G.range && G.range.kind !== "none" && /* @__PURE__ */ s.jsxs(
            "button",
            {
              type: "button",
              className: "photo-range-picker" + (Ga ? " active" : ""),
              onClick: () => ln(
                (l) => l === G.range.kind ? null : G.range.kind
              ),
              children: [
                /* @__PURE__ */ s.jsx(Zm, { size: 12 }),
                Ga ? "点击画面取样 · Esc 取消" : G.range.kind === "color" ? "在画面上取样颜色" : "在画面上取样明度"
              ]
            }
          ),
          G.range?.kind === "color" && /* @__PURE__ */ s.jsxs(s.Fragment, { children: [
            /* @__PURE__ */ s.jsx(
              ut,
              {
                label: "色相中心",
                min: 0,
                max: 360,
                value: G.range.hue,
                onChange: (l) => pt(G.id, { range: { ...G.range, hue: l } }),
                reset: () => pt(G.id, { range: { ...G.range, hue: 30 } })
              }
            ),
            /* @__PURE__ */ s.jsx(
              ut,
              {
                label: "色相范围",
                min: 1,
                max: 180,
                value: G.range.hueWidth,
                onChange: (l) => pt(G.id, {
                  range: { ...G.range, hueWidth: l }
                }),
                reset: () => pt(G.id, { range: { ...G.range, hueWidth: 30 } })
              }
            ),
            /* @__PURE__ */ s.jsx(
              ut,
              {
                label: "最低饱和",
                min: 0,
                max: 100,
                value: G.range.saturation,
                onChange: (l) => pt(G.id, {
                  range: { ...G.range, saturation: l }
                }),
                reset: () => pt(G.id, { range: { ...G.range, saturation: 15 } })
              }
            )
          ] }),
          G.range?.kind === "luminance" && /* @__PURE__ */ s.jsxs(s.Fragment, { children: [
            /* @__PURE__ */ s.jsx(
              ut,
              {
                label: "明度中心",
                min: 0,
                max: 100,
                value: G.range.luminance,
                onChange: (l) => pt(G.id, {
                  range: { ...G.range, luminance: l }
                }),
                reset: () => pt(G.id, { range: { ...G.range, luminance: 50 } })
              }
            ),
            /* @__PURE__ */ s.jsx(
              ut,
              {
                label: "明度范围",
                min: 1,
                max: 100,
                value: G.range.luminanceWidth,
                onChange: (l) => pt(G.id, {
                  range: { ...G.range, luminanceWidth: l }
                }),
                reset: () => pt(G.id, {
                  range: { ...G.range, luminanceWidth: 25 }
                })
              }
            )
          ] }),
          /* @__PURE__ */ s.jsx(
            ut,
            {
              label: "量",
              value: G.amount ?? 100,
              min: 0,
              max: 100,
              step: 1,
              onChange: (l) => pt(G.id, { amount: l }),
              reset: () => pt(G.id, { amount: 100 })
            }
          ),
          /* @__PURE__ */ s.jsx(
            ut,
            {
              label: "曝光",
              track: ze.exposure,
              min: -5,
              max: 5,
              step: 0.05,
              value: G.exposure,
              onChange: (l) => pt(G.id, { exposure: l }),
              reset: () => pt(G.id, { exposure: 0 })
            }
          ),
          /* @__PURE__ */ s.jsx(
            ut,
            {
              label: "对比度",
              track: ze.contrast,
              value: G.contrast,
              onChange: (l) => pt(G.id, { contrast: l }),
              reset: () => pt(G.id, { contrast: 0 })
            }
          ),
          /* @__PURE__ */ s.jsx(
            ut,
            {
              label: "饱和度",
              track: ze.saturation,
              value: G.saturation,
              onChange: (l) => pt(G.id, { saturation: l }),
              reset: () => pt(G.id, { saturation: 0 })
            }
          ),
          /* @__PURE__ */ s.jsx(
            ut,
            {
              label: "色温",
              track: ze.temperature,
              value: G.temperature,
              onChange: (l) => pt(G.id, { temperature: l }),
              reset: () => pt(G.id, { temperature: 0 })
            }
          ),
          /* @__PURE__ */ s.jsx(
            ut,
            {
              label: "色调",
              track: ze.tint,
              value: G.tint,
              onChange: (l) => pt(G.id, { tint: l }),
              reset: () => pt(G.id, { tint: 0 })
            }
          ),
          /* @__PURE__ */ s.jsx("div", { className: "photo-inspector-subheading", children: "蒙版范围" }),
          /* @__PURE__ */ s.jsx(
            ut,
            {
              label: "羽化",
              sub: !0,
              min: 0,
              max: 100,
              value: G.feather,
              onChange: (l) => pt(G.id, { feather: l }),
              reset: () => pt(G.id, { feather: 50 })
            }
          ),
          G.kind === "radial" ? /* @__PURE__ */ s.jsxs(s.Fragment, { children: [
            /* @__PURE__ */ s.jsx(
              ut,
              {
                label: "宽度",
                sub: !0,
                min: 0.05,
                max: 1.5,
                step: 0.01,
                value: G.sizeX ?? G.size,
                onChange: (l) => pt(G.id, {
                  sizeX: l,
                  sizeY: G.sizeY ?? G.size,
                  size: Math.max(l, G.sizeY ?? G.size)
                }),
                reset: () => pt(G.id, { sizeX: 0.38, size: 0.38 })
              }
            ),
            /* @__PURE__ */ s.jsx(
              ut,
              {
                label: "高度",
                sub: !0,
                min: 0.05,
                max: 1.5,
                step: 0.01,
                value: G.sizeY ?? G.size,
                onChange: (l) => pt(G.id, {
                  sizeY: l,
                  sizeX: G.sizeX ?? G.size,
                  size: Math.max(l, G.sizeX ?? G.size)
                }),
                reset: () => pt(G.id, { sizeY: 0.38, size: 0.38 })
              }
            ),
            /* @__PURE__ */ s.jsx(
              ut,
              {
                label: "旋转",
                sub: !0,
                min: -180,
                max: 180,
                value: G.angle,
                onChange: (l) => pt(G.id, { angle: l }),
                reset: () => pt(G.id, { angle: 0 })
              }
            )
          ] }) : /* @__PURE__ */ s.jsxs(s.Fragment, { children: [
            /* @__PURE__ */ s.jsx(
              ut,
              {
                label: "长度",
                sub: !0,
                min: 0.05,
                max: 1.5,
                step: 0.01,
                value: G.size,
                onChange: (l) => pt(G.id, { size: l }),
                reset: () => pt(G.id, { size: 0.3 })
              }
            ),
            /* @__PURE__ */ s.jsx(
              ut,
              {
                label: "角度",
                sub: !0,
                min: -180,
                max: 180,
                value: G.angle,
                onChange: (l) => pt(G.id, { angle: l }),
                reset: () => pt(G.id, { angle: 0 })
              }
            )
          ] })
        ] })
      ]
    }
  ), uo = [
    ["presets", Yo],
    ["basic", ul],
    ["portrait", ji],
    ["curves", As],
    ["hsl", nr],
    ["grading", Vo],
    ["detail", hl],
    ["effects", Do],
    ["calibration", zo],
    ["geometry", Jc],
    ["erase", fn],
    ["liquify", so],
    ["mask", cr]
  ], dn = {
    adjust: /* @__PURE__ */ s.jsx(_m, { size: 15 }),
    presets: /* @__PURE__ */ s.jsx(Nh, { size: 15 }),
    mask: /* @__PURE__ */ s.jsx(gc, { size: 15 }),
    portrait: /* @__PURE__ */ s.jsx(bc, { size: 15 }),
    geometry: /* @__PURE__ */ s.jsx(X0, { size: 15 }),
    erase: /* @__PURE__ */ s.jsx(mc, { size: 15 }),
    liquify: /* @__PURE__ */ s.jsx(Uh, { size: 15 })
  }, Vn = /* @__PURE__ */ s.jsx(s.Fragment, { children: uo.filter(([l]) => Gh[Za].includes(l)).map(
    ([l, p]) => M.isValidElement(p) ? M.cloneElement(
      p,
      {
        sectionId: l,
        open: ya(l),
        onToggle: (x) => si(l, x),
        onActivate: Nc(l) ? () => be(l) : void 0
      }
    ) : p
  ) }), ra = u ? Yt[u] || [] : [], ur = Lt && ra.length > 0 ? JSON.stringify(ra[0].adjustments) === jo : !1;
  return /* @__PURE__ */ s.jsxs(
    "div",
    {
      className: "photo-adjust-shell",
      onPointerDownCapture: (l) => {
        const p = l.target;
        p.closest(
          [
            'input[type="range"]',
            ".photo-wheel",
            ".photo-curve-editor",
            ".photo-crop-overlay",
            ".photo-mask-overlay",
            ".photo-spot-overlay",
            ".photo-value-scrubber",
            ".photo-ratio-chip",
            ".photo-geometry-buttons button"
          ].join(", ")
        ) && (yn(!0), p.closest('input[type="range"], .photo-value-scrubber') && p.closest('details.photo-section[data-section-id="mask"]') && Wn(!0));
      },
      onDragOver: (l) => l.preventDefault(),
      onDrop: (l) => {
        ar(l);
      },
      children: [
        /* @__PURE__ */ s.jsxs("header", { className: "photo-adjust-header", children: [
          /* @__PURE__ */ s.jsxs("div", { className: "photo-title", children: [
            /* @__PURE__ */ s.jsx(hm, { size: 18 }),
            /* @__PURE__ */ s.jsx("strong", { children: "照片调色" }),
            /* @__PURE__ */ s.jsx("span", { children: "Develop" })
          ] }),
          /* @__PURE__ */ s.jsx("span", { className: "photo-header-filename", children: wt?.name || "未选择照片" }),
          /* @__PURE__ */ s.jsxs("div", { className: "photo-header-actions", children: [
            Ie && /* @__PURE__ */ s.jsxs(
              "button",
              {
                type: "button",
                className: "photo-license-badge" + (rn ? " locked" : ""),
                title: "点击查看授权与激活",
                onClick: () => Mn(!0),
                children: [
                  Ie.unprovisioned ? /* @__PURE__ */ s.jsx(G0, { size: 13 }) : Ie.state === "active" ? /* @__PURE__ */ s.jsx(dm, { size: 13 }) : /* @__PURE__ */ s.jsx(Th, { size: 13 }),
                  sb(Ie)
                ]
              }
            ),
            /* @__PURE__ */ s.jsxs("button", { onClick: () => {
              lo();
            }, children: [
              /* @__PURE__ */ s.jsx(Vm, { size: 15 }),
              "导入"
            ] }),
            /* @__PURE__ */ s.jsxs("div", { className: "photo-history-wrap", ref: q, children: [
              /* @__PURE__ */ s.jsxs(
                "button",
                {
                  type: "button",
                  className: Lt ? "photo-history-button active" : "photo-history-button",
                  disabled: !wt,
                  title: "查看调色版本历史",
                  onClick: () => Et((l) => !l),
                  children: [
                    /* @__PURE__ */ s.jsx(Ym, { size: 15 }),
                    "版本历史",
                    ra.length ? " · " + ra.length : ""
                  ]
                }
              ),
              Lt && wt && /* @__PURE__ */ s.jsxs("div", { className: "photo-history-popover", role: "dialog", "aria-label": "调色版本历史", children: [
                /* @__PURE__ */ s.jsxs("div", { className: "photo-history-popover-head", children: [
                  /* @__PURE__ */ s.jsx("strong", { children: "调色版本历史" }),
                  /* @__PURE__ */ s.jsxs("div", { className: "photo-history-tools", children: [
                    /* @__PURE__ */ s.jsx("button", { type: "button", onClick: Ci, disabled: rn, children: "存为新版本" }),
                    /* @__PURE__ */ s.jsx("button", { type: "button", onClick: tr, children: O ? "自动保存：开" : "自动保存：关" })
                  ] })
                ] }),
                /* @__PURE__ */ s.jsxs("div", { className: "photo-history-status", children: [
                  Ct,
                  " · Cmd/Ctrl+S 保存"
                ] }),
                ra.length ? /* @__PURE__ */ s.jsx("div", { className: "photo-history-list", children: ra.map((l, p) => {
                  const x = l.adjustments === ye || p === 0 && ur;
                  return /* @__PURE__ */ s.jsxs(
                    "button",
                    {
                      type: "button",
                      className: "photo-history-entry" + (x ? " is-current" : ""),
                      title: "点击恢复到该版本",
                      onClick: () => ko(l),
                      children: [
                        /* @__PURE__ */ s.jsxs("span", { className: "photo-history-entry-title", children: [
                          /* @__PURE__ */ s.jsx("span", { className: "photo-history-entry-kind", children: l.reason === "manual" ? "手动保存" : l.reason === "restore" ? "恢复版本" : "自动保存" }),
                          x && /* @__PURE__ */ s.jsx("em", { children: "当前" }),
                          /* @__PURE__ */ s.jsx("time", { children: new Date(l.createdAt).toLocaleString() })
                        ] }),
                        /* @__PURE__ */ s.jsx("small", { children: $l(l.adjustments) })
                      ]
                    },
                    l.id
                  );
                }) }) : /* @__PURE__ */ s.jsx("div", { className: "photo-history-empty", children: "调整后会自动保留版本" }),
                /* @__PURE__ */ s.jsx("div", { className: "photo-history-foot", children: "最多保留 50 个版本 · 点击条目即恢复" })
              ] })
            ] }),
            /* @__PURE__ */ s.jsxs(
              "button",
              {
                className: "photo-primary",
                disabled: !wt || an || Gl || rn,
                title: Gl ? "RAW 显影与全分辨率导出尚未支持；调色参数仍会自动保存。" : void 0,
                onClick: () => {
                  cl();
                },
                children: [
                  /* @__PURE__ */ s.jsx(Xm, { size: 15 }),
                  an ? "保存中…" : Gl ? "RAW 暂不支持导出" : "保存副本"
                ]
              }
            ),
            nx && /* @__PURE__ */ s.jsxs(s.Fragment, { children: [
              /* @__PURE__ */ s.jsx(
                "button",
                {
                  type: "button",
                  className: "photo-icon",
                  title: "最小化",
                  "aria-label": "最小化窗口",
                  onClick: () => {
                    Ye.system.minimizeWindow();
                  },
                  children: /* @__PURE__ */ s.jsx(Km, { size: 15 })
                }
              ),
              /* @__PURE__ */ s.jsx(
                "button",
                {
                  type: "button",
                  className: "photo-icon",
                  title: "最大化 / 还原",
                  "aria-label": "最大化或还原窗口",
                  onClick: () => {
                    Ye.system.maximizeWindow();
                  },
                  children: /* @__PURE__ */ s.jsx(e1, { size: 12 })
                }
              )
            ] }),
            /* @__PURE__ */ s.jsx("button", { className: "photo-icon", title: "关闭", onClick: () => {
              Ye.system.closeWindow();
            }, children: /* @__PURE__ */ s.jsx(xc, { size: 16 }) })
          ] })
        ] }),
        /* @__PURE__ */ s.jsxs("div", { className: "photo-toolbar", children: [
          /* @__PURE__ */ s.jsxs("button", { type: "button", onClick: fs, title: "重置全部调整", children: [
            /* @__PURE__ */ s.jsx(Qc, { size: 14 }),
            "重置"
          ] }),
          /* @__PURE__ */ s.jsx("i", { className: "photo-toolbar-divider" }),
          /* @__PURE__ */ s.jsx(
            "button",
            {
              type: "button",
              className: je ? "active" : "",
              title: "按住查看未调色的原图（快捷键 \\\\）",
              onPointerDown: () => Va(!0),
              onPointerUp: () => Va(!1),
              onPointerLeave: () => Va(!1),
              onContextMenu: (l) => l.preventDefault(),
              children: "对比原图"
            }
          ),
          /* @__PURE__ */ s.jsx("button", { type: "button", onClick: () => er(), title: "适合窗口", children: "适合窗口" }),
          /* @__PURE__ */ s.jsxs(
            "label",
            {
              className: "photo-preview-quality",
              title: "拖动参数时的预览画质：越清晰越跟手越慢，松手后始终按全分辨率出片",
              children: [
                "预览",
                /* @__PURE__ */ s.jsx(
                  "select",
                  {
                    "aria-label": "拖拽预览画质",
                    value: ui,
                    onChange: (l) => {
                      const p = l.target.value;
                      Vt(p);
                      try {
                        window.localStorage.setItem("orcabox.photo-adjust.previewQuality", p);
                      } catch {
                      }
                    },
                    children: Kh.map((l) => /* @__PURE__ */ s.jsx("option", { value: l.id, children: l.label }, l.id))
                  }
                )
              ]
            }
          ),
          /* @__PURE__ */ s.jsx("span", { className: "photo-toolbar-spacer" }),
          /* @__PURE__ */ s.jsxs("span", { ref: sn, className: "photo-zoom-readout", children: [
            Math.round(Xe.zoom * 100),
            "%"
          ] })
        ] }),
        /* @__PURE__ */ s.jsxs("div", { className: "photo-workspace", children: [
          /* @__PURE__ */ s.jsxs("nav", { className: "photo-rail", "aria-label": "调色工具", children: [
            /* @__PURE__ */ s.jsx(
              "button",
              {
                type: "button",
                className: Q === "geometry" ? "active" : "",
                title: "裁剪",
                onClick: () => Wa("geometry"),
                children: /* @__PURE__ */ s.jsx(X0, { size: 16 })
              }
            ),
            /* @__PURE__ */ s.jsx(
              "button",
              {
                type: "button",
                className: Q === "erase" ? "active" : "",
                title: "擦除污点",
                onClick: () => Wa("erase"),
                children: /* @__PURE__ */ s.jsx(mc, { size: 16 })
              }
            ),
            /* @__PURE__ */ s.jsx(
              "button",
              {
                type: "button",
                className: Q === "liquify" ? "active" : "",
                title: "液化塑形",
                onClick: () => Wa("liquify"),
                children: /* @__PURE__ */ s.jsx(Uh, { size: 16 })
              }
            ),
            /* @__PURE__ */ s.jsx(
              "button",
              {
                type: "button",
                className: Q === "mask" ? "active" : "",
                title: "蒙版",
                onClick: () => Wa("mask"),
                children: /* @__PURE__ */ s.jsx(gc, { size: 16 })
              }
            ),
            /* @__PURE__ */ s.jsx(
              "button",
              {
                type: "button",
                className: Q === "presets" ? "active" : "",
                title: "预设库",
                onClick: () => Wa("presets"),
                children: /* @__PURE__ */ s.jsx(Nh, { size: 16 })
              }
            ),
            /* @__PURE__ */ s.jsx("i", { className: "photo-rail-divider" }),
            /* @__PURE__ */ s.jsx(
              "button",
              {
                type: "button",
                className: "photo-rail-ai",
                title: "人像精修",
                onClick: () => Wa("portrait"),
                children: /* @__PURE__ */ s.jsx(bc, { size: 16 })
              }
            ),
            /* @__PURE__ */ s.jsx(
              "button",
              {
                type: "button",
                className: "photo-rail-ai" + (fa ? " active" : ""),
                disabled: !wt,
                title: fa ? "取消参考图" : "把当前照片设为参考色彩",
                onClick: () => {
                  wt && (it((l) => l === wt.id ? null : wt.id), ht(null));
                },
                children: /* @__PURE__ */ s.jsx(_0, { size: 16 })
              }
            ),
            /* @__PURE__ */ s.jsx(
              "button",
              {
                type: "button",
                className: "photo-rail-ai",
                disabled: !fa || !wt || fa.id === wt.id,
                title: "将参考图的影调与色彩匹配到当前照片",
                onClick: () => {
                  Xl();
                },
                children: /* @__PURE__ */ s.jsx(Ch, { size: 16 })
              }
            ),
            /* @__PURE__ */ s.jsx("i", { className: "photo-rail-divider" })
          ] }),
          /* @__PURE__ */ s.jsxs(
            "aside",
            {
              ref: Gn,
              className: "photo-filmstrip",
              style: { height: Ol },
              tabIndex: 0,
              onKeyDown: Ic,
              "aria-keyshortcuts": "Control+A Meta+A Escape",
              children: [
                /* @__PURE__ */ s.jsx(
                  "div",
                  {
                    className: "photo-filmstrip-resizer" + (ts ? " is-dragging" : ""),
                    role: "separator",
                    "aria-orientation": "horizontal",
                    "aria-label": "拖动调整照片栏高度",
                    "aria-valuemin": Ir,
                    "aria-valuemax": kc,
                    "aria-valuenow": Math.round(Ol),
                    tabIndex: 0,
                    title: "拖动调整高度 · 双击恢复默认 · 聚焦后可按 ↑↓",
                    onKeyDown: (l) => {
                      if (l.key !== "ArrowUp" && l.key !== "ArrowDown") return;
                      l.preventDefault();
                      const p = l.shiftKey ? 32 : 8;
                      la(
                        (x) => Math.min(
                          kc,
                          Math.max(
                            Ir,
                            x + (l.key === "ArrowUp" ? p : -p)
                          )
                        )
                      );
                    },
                    onPointerDown: Ii,
                    onPointerMove: Kc,
                    onPointerUp: ca,
                    onPointerCancel: ca,
                    onDoubleClick: Kl
                  }
                ),
                C && /* @__PURE__ */ s.jsxs(
                  "div",
                  {
                    className: "photo-import-progress" + (C.stage === "importing" ? " is-indeterminate" : ""),
                    role: "status",
                    "aria-live": "polite",
                    "aria-label": "照片导入进度",
                    children: [
                      /* @__PURE__ */ s.jsx("span", { children: C.stage === "matching" ? `正在匹配素材库 ${C.done}/${C.total}` : C.stage === "importing" ? `正在导入 ${C.total} 张照片…` : C.stage === "details" ? `正在加入画廊 ${C.done}/${C.total}` : C.stage === "previews" ? `正在加载清晰预览 ${C.done}/${C.total}` : `照片已就绪 ${C.total} 张` }),
                      /* @__PURE__ */ s.jsx("i", { children: /* @__PURE__ */ s.jsx(
                        "b",
                        {
                          style: {
                            width: C.stage === "importing" ? "34%" : `${Math.round(
                              C.done / Math.max(1, C.total) * 100
                            )}%`
                          }
                        }
                      ) })
                    ]
                  }
                ),
                /* @__PURE__ */ s.jsxs("div", { className: "photo-batchbar", children: [
                  /* @__PURE__ */ s.jsx(
                    "button",
                    {
                      type: "button",
                      disabled: !wt,
                      onClick: da,
                      title: "复制当前照片的全部调整参数",
                      children: "复制调整"
                    }
                  ),
                  /* @__PURE__ */ s.jsx(
                    "button",
                    {
                      type: "button",
                      disabled: !Nn || !wt,
                      onClick: Si,
                      title: "把复制的参数粘贴到当前照片",
                      children: "粘贴调整"
                    }
                  ),
                  /* @__PURE__ */ s.jsxs(
                    "button",
                    {
                      type: "button",
                      disabled: !Nn || !Ce.size,
                      onClick: () => {
                        us();
                      },
                      title: "把复制的参数同步到勾选的照片",
                      children: [
                        "同步到所选",
                        Ce.size ? "（" + Ce.size + "）" : ""
                      ]
                    }
                  ),
                  /* @__PURE__ */ s.jsx("i", { className: "photo-toolbar-divider" }),
                  /* @__PURE__ */ s.jsx(
                    "button",
                    {
                      type: "button",
                      className: "photo-batchbar-primary",
                      disabled: !r.length || !!Ja || rn,
                      onClick: () => {
                        hs();
                      },
                      title: Ce.size ? "导出勾选照片的调色副本" : "导出全部照片的调色副本",
                      children: "批量导出"
                    }
                  ),
                  /* @__PURE__ */ s.jsxs(
                    "select",
                    {
                      className: "photo-batchbar-select",
                      "aria-label": "导出格式",
                      value: Un,
                      onChange: (l) => Pl(l.target.value),
                      children: [
                        /* @__PURE__ */ s.jsx("option", { value: "auto", children: "跟随原图" }),
                        /* @__PURE__ */ s.jsx("option", { value: "jpeg", children: "JPEG" }),
                        /* @__PURE__ */ s.jsx("option", { value: "png", children: "PNG" }),
                        /* @__PURE__ */ s.jsx("option", { value: "webp", children: "WebP" })
                      ]
                    }
                  ),
                  (Un === "jpeg" || Un === "webp") && /* @__PURE__ */ s.jsxs("label", { className: "photo-batchbar-quality", children: [
                    "质量",
                    /* @__PURE__ */ s.jsx(
                      "input",
                      {
                        type: "range",
                        min: 1,
                        max: 100,
                        value: Ri,
                        onChange: (l) => ss(Number(l.target.value))
                      }
                    ),
                    /* @__PURE__ */ s.jsx("b", { children: Ri })
                  ] }),
                  /* @__PURE__ */ s.jsxs(
                    "select",
                    {
                      className: "photo-batchbar-select",
                      "aria-label": "最长边",
                      value: rl,
                      onChange: (l) => Wc(Number(l.target.value)),
                      children: [
                        /* @__PURE__ */ s.jsx("option", { value: 0, children: "原图尺寸" }),
                        /* @__PURE__ */ s.jsx("option", { value: 4096, children: "最长边 4096" }),
                        /* @__PURE__ */ s.jsx("option", { value: 2048, children: "最长边 2048" }),
                        /* @__PURE__ */ s.jsx("option", { value: 1080, children: "最长边 1080" })
                      ]
                    }
                  ),
                  Ja ? /* @__PURE__ */ s.jsxs("span", { className: "photo-batchbar-progress", children: [
                    /* @__PURE__ */ s.jsx("i", { children: /* @__PURE__ */ s.jsx(
                      "b",
                      {
                        style: {
                          width: Math.round(Ja.done / Math.max(1, Ja.total) * 100) + "%"
                        }
                      }
                    ) }),
                    "正在导出 ",
                    Ja.done + 1,
                    "/",
                    Ja.total,
                    " · ",
                    Ja.current
                  ] }) : /* @__PURE__ */ s.jsx("span", { className: "photo-batchbar-meta", children: Ce.size ? `已选 ${Ce.size} / ${r.length} 张 · Shift 连选 · ⌘/Ctrl+A 全选` : "Shift 连选 · ⌘/Ctrl 多选 · ⌘/Ctrl+A 全选 · 未选则导出全部" })
                ] }),
                /* @__PURE__ */ s.jsxs("div", { className: "photo-filmstrip-row", children: [
                  r.map((l) => {
                    const p = zh(
                      g[l.id] || l.thumbnailUrl || l.fileUrl
                    ), x = !y.has(l.id) || A[l.id] !== p;
                    return (
                      // 角标原来嵌在缩略图 button 里（interactive 嵌套），键盘永远到不了。
                      // 拆成并排的两个按钮：整卡切换照片，角标独立聚焦/空格勾选。
                      /* @__PURE__ */ s.jsxs("div", { className: "photo-thumb-cell", children: [
                        /* @__PURE__ */ s.jsxs(
                          "button",
                          {
                            type: "button",
                            className: "photo-thumb " + (l.id === u ? "active " : "") + (Ce.has(l.id) ? "batch-selected" : ""),
                            "aria-current": l.id === u ? "true" : void 0,
                            "aria-pressed": Ce.has(l.id),
                            onClick: (w) => Fc(l.id, w),
                            title: "点击切换照片 · Shift 连选 · ⌘/Ctrl 多选",
                            children: [
                              /* @__PURE__ */ s.jsx(
                                "img",
                                {
                                  className: x ? "is-soft" : "",
                                  src: p,
                                  alt: "",
                                  loading: "lazy",
                                  decoding: "async",
                                  onLoad: () => {
                                    p && v((w) => w[l.id] === p ? w : { ...w, [l.id]: p });
                                  }
                                }
                              ),
                              /* @__PURE__ */ s.jsx("span", { children: l.name })
                            ]
                          }
                        ),
                        /* @__PURE__ */ s.jsx(
                          "button",
                          {
                            type: "button",
                            role: "checkbox",
                            "aria-checked": Ce.has(l.id),
                            "aria-label": "选择 " + l.name,
                            className: "photo-thumb-check" + (Ce.has(l.id) ? " on" : ""),
                            onClick: (w) => Gc(l.id, w),
                            children: Ce.has(l.id) ? "✓" : ""
                          }
                        )
                      ] }, l.id)
                    );
                  }),
                  /* @__PURE__ */ s.jsx(
                    "button",
                    {
                      type: "button",
                      className: "photo-filmstrip-add",
                      title: "导入图片",
                      onClick: () => {
                        lo();
                      },
                      children: "+"
                    }
                  ),
                  /* @__PURE__ */ s.jsx("span", { className: "photo-filmstrip-meta", children: r.length ? r.length + " 张照片" : "从素材库选择图片，或拖入图片" })
                ] })
              ]
            }
          ),
          /* @__PURE__ */ s.jsxs("main", { className: "photo-canvas", children: [
            (G || fa) && /* @__PURE__ */ s.jsxs("div", { className: "photo-canvas-chips", children: [
              G && /* @__PURE__ */ s.jsxs("span", { className: "photo-canvas-chip photo-canvas-chip-mask", children: [
                /* @__PURE__ */ s.jsx(gc, { size: 12 }),
                /* @__PURE__ */ s.jsxs("span", { className: "photo-canvas-chip-text", children: [
                  "蒙版",
                  " ",
                  Math.max(
                    1,
                    _.masks.findIndex((l) => l.id === G.id) + 1
                  ),
                  G.semanticMask ? " · AI" : ""
                ] })
              ] }),
              fa && /* @__PURE__ */ s.jsxs("span", { className: "photo-canvas-chip photo-canvas-chip-ref", children: [
                /* @__PURE__ */ s.jsx(_0, { size: 12 }),
                /* @__PURE__ */ s.jsxs("span", { className: "photo-canvas-chip-text", children: [
                  "参考图 · ",
                  fa.name
                ] })
              ] })
            ] }),
            /* @__PURE__ */ s.jsx(
              "div",
              {
                ref: ha,
                className: "photo-image-stage" + (na ? " is-wb-picker" : "") + (Q === "liquify" ? " is-liquify" : ""),
                onPointerDown: (l) => {
                  if (!(l.button !== 0 || !u)) {
                    if (na) {
                      l.preventDefault(), no(l.clientX, l.clientY);
                      return;
                    }
                    if (Q === "liquify") {
                      const p = Da.current?.getBoundingClientRect();
                      if (!p) return;
                      l.preventDefault();
                      try {
                        l.currentTarget.setPointerCapture(l.pointerId);
                      } catch {
                      }
                      Eo.current = { rect: p, lastX: l.clientX, lastY: l.clientY };
                      return;
                    }
                    l.currentTarget.setPointerCapture(l.pointerId), qt.current = {
                      x: l.clientX,
                      y: l.clientY,
                      originX: Tn.current.x,
                      originY: Tn.current.y
                    }, Qe.current = { ...Tn.current }, l.currentTarget.classList.add("is-panning");
                  }
                },
                onPointerMove: (l) => {
                  const p = qt.current, x = Da.current, w = Eo.current;
                  if (w) {
                    $r(
                      w.lastX,
                      w.lastY,
                      l.clientX,
                      l.clientY,
                      w.rect
                    ), w.lastX = l.clientX, w.lastY = l.clientY;
                    return;
                  }
                  if (!p || !u || !x) return;
                  const N = p.originX + l.clientX - p.x, H = p.originY + l.clientY - p.y, ot = Oh(
                    l.currentTarget,
                    x,
                    N,
                    H,
                    Qe.current?.zoom ?? Tn.current.zoom
                  );
                  Qe.current = {
                    zoom: Qe.current?.zoom ?? Tn.current.zoom,
                    x: ot.x,
                    y: ot.y
                  }, x.style.transform = `translate(${ot.x}px, ${ot.y}px) scale(${Qe.current.zoom})`;
                },
                onPointerUp: (l) => {
                  const p = Qe.current, x = qt.current, w = Eo.current;
                  if (w) {
                    $r(
                      w.lastX,
                      w.lastY,
                      l.clientX,
                      l.clientY,
                      w.rect
                    ), Eo.current = null;
                    return;
                  }
                  Qe.current = null, qt.current = null, l.currentTarget.classList.remove("is-panning"), p && u && ft((N) => ({ ...N, [u]: p })), x && Q === "mask" && It && !Ga && !na && Math.hypot(l.clientX - x.x, l.clientY - x.y) < 4 && ve(null);
                },
                onPointerCancel: (l) => {
                  Qe.current = null, qt.current = null, l.currentTarget.classList.remove("is-panning");
                },
                onDoubleClick: () => er(),
                children: wt ? pi?.assetId === wt.id ? /* @__PURE__ */ s.jsx(
                  "div",
                  {
                    ref: Da,
                    className: "photo-viewport",
                    style: {
                      transform: `translate(${Xe.x}px, ${Xe.y}px) scale(${Xe.zoom})`
                    },
                    children: /* @__PURE__ */ s.jsx(
                      "img",
                      {
                        src: pi.url,
                        alt: wt.name,
                        className: "photo-preview",
                        draggable: !1
                      }
                    )
                  }
                ) : /* @__PURE__ */ s.jsxs(
                  "div",
                  {
                    ref: Da,
                    className: "photo-viewport",
                    style: {
                      transform: `translate(${Xe.x}px, ${Xe.y}px) scale(${Xe.zoom})`
                    },
                    children: [
                      /* @__PURE__ */ s.jsx("canvas", { ref: Ma, className: "photo-preview" }),
                      Q === "mask" && Qo && Qo.enabled !== !1 && rt && !Aa && (Qo.semanticMask ? /* @__PURE__ */ s.jsx(Gb, { mask: Qo }) : /* @__PURE__ */ s.jsx(Zb, { mask: Qo })),
                      Q === "geometry" && /* @__PURE__ */ s.jsx(
                        Kb,
                        {
                          crop: Be.crop,
                          aspect: ga,
                          onChange: xs
                        }
                      ),
                      Q === "mask" && /* @__PURE__ */ s.jsx(
                        Fb,
                        {
                          masks: _.masks,
                          activeId: It,
                          onSelect: Ft
                        }
                      ),
                      Q === "mask" && G && !G.semanticMask && /* @__PURE__ */ s.jsx(
                        Hb,
                        {
                          mask: G,
                          onChange: (l) => pt(G.id, l)
                        }
                      ),
                      Q === "mask" && Ga && G && /* @__PURE__ */ s.jsx(
                        "div",
                        {
                          className: "photo-mask-picking",
                          title: "点击画面取样 · Esc 取消",
                          onPointerDown: (l) => {
                            l.preventDefault();
                            const p = Ma.current;
                            if (!p) return;
                            const x = p.getBoundingClientRect(), w = Math.round(
                              (l.clientX - x.left) / x.width * p.width
                            ), N = Math.round(
                              (l.clientY - x.top) / x.height * p.height
                            );
                            if (w < 0 || N < 0 || w >= p.width || N >= p.height) return;
                            const H = p.getContext("2d")?.getImageData(w, N, 1, 1).data;
                            if (!H) return;
                            const ot = Ga, P = m1(H[0], H[1], H[2]), at = G.range;
                            pt(G.id, {
                              range: ot === "color" ? {
                                kind: ot,
                                hue: P.hue,
                                hueWidth: at?.hueWidth ?? 30,
                                saturation: Math.max(
                                  at?.saturation ?? 15,
                                  Math.round(P.saturation)
                                ),
                                luminance: at?.luminance ?? 50,
                                luminanceWidth: at?.luminanceWidth ?? 25
                              } : {
                                kind: ot,
                                hue: at?.hue ?? 30,
                                hueWidth: at?.hueWidth ?? 30,
                                saturation: at?.saturation ?? 15,
                                luminance: Math.round(P.luminance),
                                luminanceWidth: at?.luminanceWidth ?? 25
                              }
                            }), ln(null);
                          }
                        }
                      ),
                      Q === "erase" && /* @__PURE__ */ s.jsx(
                        Jb,
                        {
                          spots: _.spots,
                          selectedId: vn,
                          brushSize: Wi,
                          brushFeather: Ll,
                          onSelect: fi,
                          onAdd: Sa,
                          onBrushSizeChange: di,
                          onUpdate: kn
                        }
                      )
                    ]
                  }
                ) : /* @__PURE__ */ s.jsxs("div", { className: "photo-drop-target", children: [
                  /* @__PURE__ */ s.jsx(tp, { size: 36 }),
                  /* @__PURE__ */ s.jsx("strong", { children: "选择照片开始调色" }),
                  /* @__PURE__ */ s.jsx("span", { children: "支持从素材库多选后右键打开，也可直接导入" })
                ] })
              }
            ),
            Ge && /* @__PURE__ */ s.jsxs("div", { className: "photo-render-status", role: "status", "aria-live": "polite", children: [
              /* @__PURE__ */ s.jsx("b", { className: Ge.pipeline === "gpu" ? "is-gpu" : "is-cpu", children: Ge.pipeline === "gpu" ? "GPU" : "CPU" }),
              /* @__PURE__ */ s.jsx("span", { children: Ge.frameMs > 0 ? Ge.frameMs + " ms" : "<0.1 ms" }),
              /* @__PURE__ */ s.jsx("span", { children: Ge.width > 0 ? Ge.width + "×" + Ge.height : "—" }),
              /* @__PURE__ */ s.jsx("span", { children: Ge.frameMs > 0 ? Math.min(240, Math.round(1e3 / Math.max(0.5, Ge.frameMs))) + " fps" : "60+ fps" }),
              Ge.note && /* @__PURE__ */ s.jsx("span", { className: "photo-render-status-note", children: Ge.note })
            ] })
          ] }),
          /* @__PURE__ */ s.jsxs("aside", { className: "photo-controls", children: [
            /* @__PURE__ */ s.jsxs("div", { className: "photo-controls-fixed", children: [
              /* @__PURE__ */ s.jsx(Lb, { canvasRef: va, analysis: ns }),
              fa && /* @__PURE__ */ s.jsxs("div", { className: "photo-reference-strip", children: [
                /* @__PURE__ */ s.jsxs("div", { children: [
                  /* @__PURE__ */ s.jsx("span", { children: "参考图" }),
                  /* @__PURE__ */ s.jsx("small", { children: fa.name }),
                  /* @__PURE__ */ s.jsx(
                    "div",
                    {
                      className: "photo-reference-zones",
                      role: "radiogroup",
                      "aria-label": "追色匹配范围",
                      onKeyDown: (l) => {
                        if (l.key !== "ArrowRight" && l.key !== "ArrowDown" && l.key !== "ArrowLeft" && l.key !== "ArrowUp")
                          return;
                        l.preventDefault();
                        const p = Object.keys(
                          Wr
                        ), x = l.key === "ArrowRight" || l.key === "ArrowDown" ? 1 : -1, w = p[(p.indexOf(mt) + x + p.length) % p.length];
                        tt(w), l.currentTarget.querySelectorAll('[role="radio"]')[p.indexOf(w)]?.focus();
                      },
                      children: Object.keys(Wr).map(
                        (l) => /* @__PURE__ */ s.jsx(
                          "button",
                          {
                            type: "button",
                            role: "radio",
                            "aria-checked": mt === l,
                            tabIndex: mt === l ? 0 : -1,
                            className: mt === l ? "active" : "",
                            onClick: () => tt(l),
                            children: Wr[l]
                          },
                          l
                        )
                      )
                    }
                  )
                ] }),
                /* @__PURE__ */ s.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      it(null), ht(null);
                    },
                    title: "清除参考图",
                    children: /* @__PURE__ */ s.jsx(xc, { size: 12 })
                  }
                ),
                /* @__PURE__ */ s.jsxs("label", { children: [
                  "强度",
                  /* @__PURE__ */ s.jsx(
                    "input",
                    {
                      type: "range",
                      min: 0,
                      max: 100,
                      value: J?.strength ?? 70,
                      onChange: (l) => {
                        const p = Number(l.target.value), x = al.current;
                        if (!x || !x.targetId || !x.match) return;
                        const w = Il(
                          x.targetId,
                          x.applied,
                          x.match,
                          p
                        );
                        ht({ ...x, strength: p, applied: w });
                      }
                    }
                  ),
                  /* @__PURE__ */ s.jsxs("b", { children: [
                    J?.strength ?? 70,
                    "%"
                  ] })
                ] })
              ] })
            ] }),
            /* @__PURE__ */ s.jsxs("div", { className: "photo-controls-body", children: [
              /* @__PURE__ */ s.jsx("div", { className: "photo-controls-scroll", children: Vn }),
              /* @__PURE__ */ s.jsx("nav", { className: "photo-panel-tabs", "aria-label": "参数板块", children: Fh.map((l) => /* @__PURE__ */ s.jsxs(
                "button",
                {
                  type: "button",
                  className: Za === l.id ? "active" : "",
                  "aria-pressed": Za === l.id,
                  title: l.label,
                  onClick: () => ci(l.id),
                  children: [
                    dn[l.id],
                    /* @__PURE__ */ s.jsx("span", { children: l.label })
                  ]
                },
                l.id
              )) })
            ] })
          ] })
        ] }),
        rn && /* @__PURE__ */ s.jsxs("div", { className: "photo-license-lock", role: "alert", children: [
          /* @__PURE__ */ s.jsx(Lm, { size: 22 }),
          /* @__PURE__ */ s.jsx("strong", { children: Ie?.state === "suspended" ? "检测到系统时间异常" : "免费试用已结束" }),
          /* @__PURE__ */ s.jsx("span", { children: Ie?.message }),
          /* @__PURE__ */ s.jsxs("button", { type: "button", className: "photo-primary", onClick: () => Mn(!0), children: [
            /* @__PURE__ */ s.jsx(Th, { size: 14 }),
            "输入激活码"
          ] })
        ] }),
        In && /* @__PURE__ */ s.jsx(
          "div",
          {
            className: "photo-license-backdrop",
            onPointerDown: (l) => {
              l.target === l.currentTarget && Ji();
            },
            children: /* @__PURE__ */ s.jsxs(
              "div",
              {
                ref: Ro,
                className: "photo-license-modal",
                role: "dialog",
                "aria-modal": "true",
                "aria-labelledby": "photo-license-modal-title",
                tabIndex: -1,
                children: [
                  /* @__PURE__ */ s.jsxs("header", { className: "photo-license-modal-head", children: [
                    /* @__PURE__ */ s.jsx(Th, { size: 15 }),
                    /* @__PURE__ */ s.jsx("strong", { id: "photo-license-modal-title", children: "激活照片调色" }),
                    /* @__PURE__ */ s.jsx(
                      "button",
                      {
                        type: "button",
                        className: "photo-license-close",
                        "aria-label": "关闭激活窗口",
                        onClick: Ji,
                        children: /* @__PURE__ */ s.jsx(xc, { size: 14 })
                      }
                    )
                  ] }),
                  Ie && !Ie.unprovisioned && /* @__PURE__ */ s.jsx("p", { className: "photo-license-note", children: Ie.message }),
                  Ie?.unprovisioned && /* @__PURE__ */ s.jsxs("p", { className: "photo-license-note", children: [
                    "授权体系尚未配置：在本机运行 ",
                    /* @__PURE__ */ s.jsx("code", { children: "node scripts/license/gen.mjs keygen" }),
                    " ",
                    "生成密钥并重新构建后生效；配置前全功能放行。"
                  ] }),
                  /* @__PURE__ */ s.jsx(
                    "textarea",
                    {
                      className: "photo-license-input",
                      value: bi,
                      onChange: (l) => Hl(l.target.value),
                      placeholder: "粘贴激活码（PCA1. 开头）",
                      rows: 4,
                      spellCheck: !1
                    }
                  ),
                  yi && /* @__PURE__ */ s.jsx("p", { className: "photo-license-error", role: "alert", children: yi }),
                  /* @__PURE__ */ s.jsxs("div", { className: "photo-license-machine", children: [
                    /* @__PURE__ */ s.jsx("span", { children: "本机机器码" }),
                    /* @__PURE__ */ s.jsx("code", { children: xi || "获取中…" }),
                    /* @__PURE__ */ s.jsx(
                      "button",
                      {
                        type: "button",
                        disabled: !xi,
                        onClick: () => {
                          xi && (navigator.clipboard.writeText(xi), ct("机器码已复制"));
                        },
                        children: "复制"
                      }
                    )
                  ] }),
                  /* @__PURE__ */ s.jsxs("footer", { className: "photo-license-modal-foot", children: [
                    /* @__PURE__ */ s.jsx("button", { type: "button", onClick: () => Mn(!1), children: "稍后再说" }),
                    /* @__PURE__ */ s.jsx(
                      "button",
                      {
                        type: "button",
                        className: "photo-primary",
                        disabled: !bi.trim() || _i,
                        onClick: () => {
                          So();
                        },
                        children: _i ? "激活中…" : "激活"
                      }
                    )
                  ] })
                ]
              }
            )
          }
        ),
        me && /* @__PURE__ */ s.jsx(
          "div",
          {
            className: "photo-notice",
            role: "status",
            style: { "--photo-notice-duration": mn + "ms" },
            children: me.text
          },
          me.id
        )
      ]
    }
  );
}
function rx(r) {
  const h = om.createRoot(r);
  return h.render(/* @__PURE__ */ s.jsx(lx, {})), () => h.unmount();
}
function sx(r) {
  r.registerToolbarAction({ actionId: "open-photo-adjust", label: { zh: "照片调色", en: "Photo Develop" }, icon: "icon.svg", order: 210, handler: () => {
    r.api.system.openPhotoAdjustWindow().catch((h) => console.error("[photo-adjust] open failed", h));
  } }), r.registerContextMenuItem({ itemId: "photo-adjust", target: "asset", label: { zh: "照片调色", en: "Photo Develop" }, icon: "icon.svg", order: 47, handler: ({ assetIds: h }) => {
    r.api.system.openPhotoAdjustWindow(h).catch((u) => console.error("[photo-adjust] open failed", u));
  } });
}
export {
  sx as default,
  rx as renderStandalonePanel
};
