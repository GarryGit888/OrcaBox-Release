# 图像对比工具 / Image Compare

OrcaBox external plugin for comparing image groups in a standalone panel.

- Drag images from the OrcaBox asset library into either side.
- Keep multiple images in each group and switch with the thumbnail rail.
- Compare side by side, with a wipe slider, overlay opacity, or difference blending.
- Synchronized zoom and pan; source images remain read only.
