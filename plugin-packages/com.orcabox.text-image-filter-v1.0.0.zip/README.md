# 文本筛图 / Text Photo Filter

从素材工具栏的插件入口打开「文本筛图」，也可以在图片上右键打开。默认使用当前选中素材所在目录；未选中素材时使用当前浏览的来源文件夹。面板右上角可通过 OrcaBox 的文件夹搜索或「最近常用」切换来源。只匹配所选目录中已索引、可见的图片，不递归扫描子目录。

粘贴客户聊天、文件名清单或编号（例如 `IMG_1715.JPG、0933、2231`），主素材区实时预览。匹配完全在本地运行，无需模型、网络或账号。带扩展名时优先匹配完整文件名；纯数字忽略前导零，同编号命中的多张图片都会显示。写入前请检查「对应多张」和未匹配条目。

- **仅筛选**：保留结果并折叠编辑区；退出面板即恢复普通素材视图。
- **新建文件夹**：可编辑文件夹名，将命中的原格式图片复制到来源目录下的新文件夹。不会移动原图或覆盖已有文件。
- **打评分标记**：选择 1–5 星并确认，覆盖命中素材的现有评分；XMP 同步遵循宿主设置。

需要包含工作区插件面板和 `asset.copyImagesToSourceSubfolder` 接口的 OrcaBox 1.4.3 或更新构建。早期不含这两项接口的 1.4.3 安装包不能使用。源码构建首次验证后再独立发布插件。

Open **Text Photo Filter** from the toolbar’s plugin launcher or a photo’s context menu. Paste a message containing filenames or numbers. The main grid previews matches as you type. Choose another source from the folder picker; only indexed photos in that folder are matched. Matching is offline. Full filenames preserve their extension; numeric IDs ignore leading zeros and may match multiple photos.

- **Filter only** collapses the editor and keeps matches visible. Close the panel to clear the filter.
- **New folder** copies matching photos into a named subfolder without moving or overwriting originals.
- **Rate photos** replaces the rating on each match, following OrcaBox’s XMP settings.

Requires an OrcaBox 1.4.3 or later build with workspace panels and `asset.copyImagesToSourceSubfolder` support.
