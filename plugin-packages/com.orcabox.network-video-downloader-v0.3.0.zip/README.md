# 网络视频下载插件（Network Video Downloader）

OrcaBox 外部插件。以独立面板窗口运行：粘贴桌面链接、手机分享链接或带链接的分享文本，批量下载常见平台的视频或音频。

## 系统要求

- **OrcaBox 1.3.6 或更高版本**（依赖独立插件面板窗口与来源目录 API）
- macOS 13+ / Windows 10 1809+（Windows 11 可获得亚克力磨砂窗口材质）
- 首次使用需要网络：下载引擎（yt-dlp）会在首次探针/下载时自动从 GitHub 获取并校验安装；网络受限环境请先在 OrcaBox「设置 → 网络」配置导入代理

## 功能

- **独立面板窗口**：可拖拽移动、边缘缩放、最小化与关闭，支持磨砂玻璃质感
- **批量队列**：一次粘贴多条链接自动去重入队，最多 2 路并发下载
- **三种下载位置**：系统下载目录 / 自定义文件夹 / **来源目录**（从 OrcaBox 来源目录树中任意选择文件夹，文件落位后自动进入资料库，不重复导入）
- **来源目录树选择器**：懒加载展开/合并子文件夹，逐层浏览后选定
- **下载设置**：视频 / 仅音频 MP3、画质上限（4K–480p）、浏览器登录态来源（自动/Chrome/Edge/Firefox/Safari/不读取）
- **历史记录**：保留最近 80 条下载记录，可单条删除
- **下载引擎自动供给**：首次使用自动下载官方 yt-dlp 独立二进制（SHA-256 校验），放入插件 `bin/` 目录；也支持系统 PATH、Homebrew 或手动指定路径

## 已覆盖的常见入口

哔哩哔哩 · 小红书 · 抖音 · YouTube · X / Twitter · Instagram · Pinterest · Wallhaven · 其他 yt-dlp 支持的公开视频页面

不承诺所有站点、私密内容、付费内容和需要验证码的页面都能下载。部分站点（如 Instagram）在网络受限地区需要配置代理。请只下载你有权保存的内容，并遵守目标平台的服务条款与版权要求。

## 安装

1. 打开 OrcaBox「插件管理器」。
2. 选择插件包文件夹或 zip（解压后的目录）进行安装。
3. 启用插件后，工具栏会出现「下载网络视频」入口。

## 使用

1. 点击工具栏「下载网络视频」，打开独立下载面板。
2. 粘贴电脑链接、移动端分享链接或包含链接的分享文本（也可直接拖入）。
3. 在「下载到」一行选择落盘位置：系统目录 / 自定义文件夹 / 来源目录。
4. 点击「批量下载」或单条下载；下载完成可自动导入 OrcaBox 资料库。
5. 首次下载时引擎自动就位（需要网络）；对 B 站 / 抖音 / 小红书等站点，建议在设置中选择已登录的浏览器登录态。

下载器不生成播放代理、转码预览或后台任务；只在用户主动下载时调用引擎。

## 构建与打包（开发者）

在 OrcaBox 项目根目录运行：

```bash
# 构建 dist 并同步到本机已安装的插件目录
npx vite build --config plugins-dev/com.orcabox.network-video-downloader/vite.config.ts

# 打成可独立安装的 zip / 文件夹
npm run package:plugin:network-video-downloader
```

产物位置：

```text
output/plugin-packages/com.orcabox.network-video-downloader/package
output/plugin-packages/com.orcabox.network-video-downloader/com.orcabox.network-video-downloader-v<版本>.zip
```
